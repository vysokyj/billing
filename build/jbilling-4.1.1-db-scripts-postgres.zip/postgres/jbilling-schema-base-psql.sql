-- Create Database Lock Table
CREATE TABLE public.databasechangeloglock (ID INT NOT NULL, LOCKED BOOLEAN NOT NULL, LOCKGRANTED TIMESTAMP WITHOUT TIME ZONE, LOCKEDBY VARCHAR(255), CONSTRAINT PK_DATABASECHANGELOGLOCK PRIMARY KEY (ID));

-- Initialize Database Lock Table
DELETE FROM public.databasechangeloglock;

INSERT INTO public.databasechangeloglock (ID, LOCKED) VALUES (1, FALSE);

-- Lock Database
-- Create Database Change Log Table
CREATE TABLE public.databasechangelog (ID VARCHAR(255) NOT NULL, AUTHOR VARCHAR(255) NOT NULL, FILENAME VARCHAR(255) NOT NULL, DATEEXECUTED TIMESTAMP WITHOUT TIME ZONE NOT NULL, ORDEREXECUTED INT NOT NULL, EXECTYPE VARCHAR(10) NOT NULL, MD5SUM VARCHAR(35), DESCRIPTION VARCHAR(255), COMMENTS VARCHAR(255), TAG VARCHAR(255), LIQUIBASE VARCHAR(20));

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-1::Emiliano Conde
CREATE TABLE public.ach (id INT NOT NULL, user_id INT, aba_routing VARCHAR(40) NOT NULL, bank_account VARCHAR(60) NOT NULL, account_type INT NOT NULL, bank_name VARCHAR(50) NOT NULL, account_name VARCHAR(100) NOT NULL, optlock INT NOT NULL, gateway_key VARCHAR(100), CONSTRAINT ach_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-1', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 1, '7:8922bfebfc70cb70fd4684f82e90ecc0', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-2::Emiliano Conde
CREATE TABLE public.ageing_entity_step (id INT NOT NULL, entity_id INT, status_id INT, days INT NOT NULL, optlock INT NOT NULL, CONSTRAINT ageing_entity_step_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-2', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 2, '7:4543e51971682f746629b64f60f25424', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-3::Emiliano Conde
CREATE TABLE public.base_user (id INT NOT NULL, entity_id INT, password VARCHAR(40), deleted INT DEFAULT 0 NOT NULL, language_id INT, status_id INT, subscriber_status INT DEFAULT 1, currency_id INT, create_datetime TIMESTAMP WITHOUT TIME ZONE NOT NULL, last_status_change TIMESTAMP WITHOUT TIME ZONE, last_login TIMESTAMP WITHOUT TIME ZONE, user_name VARCHAR(50), failed_attempts INT DEFAULT 0 NOT NULL, optlock INT NOT NULL, CONSTRAINT base_user_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-3', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 3, '7:58002b5f2f43d673944e6db319c95e25', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-4::Emiliano Conde
CREATE TABLE public.billing_process (id INT NOT NULL, entity_id INT NOT NULL, billing_date date NOT NULL, period_unit_id INT NOT NULL, period_value INT NOT NULL, is_review INT NOT NULL, paper_invoice_batch_id INT, retries_to_do INT DEFAULT 0 NOT NULL, optlock INT NOT NULL, CONSTRAINT billing_process_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-4', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 4, '7:65e4f1f41f33afa3af2aaf9f11fe894a', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-5::Emiliano Conde
CREATE TABLE public.billing_process_configuration (id INT NOT NULL, entity_id INT, next_run_date date NOT NULL, generate_report INT NOT NULL, retries INT, days_for_retry INT, days_for_report INT, review_status INT NOT NULL, period_unit_id INT NOT NULL, period_value INT NOT NULL, due_date_unit_id INT NOT NULL, due_date_value INT NOT NULL, df_fm INT, only_recurring INT DEFAULT 1 NOT NULL, invoice_date_process INT NOT NULL, optlock INT NOT NULL, auto_payment INT DEFAULT 0 NOT NULL, maximum_periods INT DEFAULT 1 NOT NULL, auto_payment_application INT DEFAULT 0 NOT NULL, CONSTRAINT billing_process_config_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-5', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 5, '7:f5069e51fd697b6062afaf2f78e5ecbb', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-6::Emiliano Conde
CREATE TABLE public.blacklist (id INT NOT NULL, entity_id INT NOT NULL, create_datetime TIMESTAMP WITHOUT TIME ZONE NOT NULL, type INT NOT NULL, source INT NOT NULL, credit_card INT, credit_card_id INT, contact_id INT, user_id INT, optlock INT NOT NULL, meta_field_value_id INT, CONSTRAINT blacklist_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-6', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 6, '7:76ea4196cc9ae7f5e4b05d5b2e905b45', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-7::Emiliano Conde
CREATE TABLE public.breadcrumb (id INT NOT NULL, user_id INT NOT NULL, controller VARCHAR(255) NOT NULL, action VARCHAR(255), name VARCHAR(255), object_id INT, version INT NOT NULL, description VARCHAR(255), CONSTRAINT breadcrumb_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-7', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 7, '7:1c468637211181df1494d3c2fffde1df', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-9::Emiliano Conde
CREATE TABLE public.contact (id INT NOT NULL, organization_name VARCHAR(200), street_addres1 VARCHAR(100), street_addres2 VARCHAR(100), city VARCHAR(50), state_province VARCHAR(30), postal_code VARCHAR(15), country_code VARCHAR(2), last_name VARCHAR(30), first_name VARCHAR(30), person_initial VARCHAR(5), person_title VARCHAR(40), phone_country_code INT, phone_area_code INT, phone_phone_number VARCHAR(20), fax_country_code INT, fax_area_code INT, fax_phone_number VARCHAR(20), email VARCHAR(200), create_datetime TIMESTAMP WITHOUT TIME ZONE NOT NULL, deleted INT DEFAULT 0 NOT NULL, notification_include INT DEFAULT 1, user_id INT, optlock INT NOT NULL, CONSTRAINT contact_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-9', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 8, '7:485c707222e5a3a59e85a58dc72deaa8', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-10::Emiliano Conde
CREATE TABLE public.contact_map (id INT NOT NULL, contact_id INT, type_id INT NOT NULL, table_id INT NOT NULL, foreign_id INT NOT NULL, optlock INT NOT NULL, CONSTRAINT contact_map_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-10', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 9, '7:2475e48c7730001b948dc413a3673707', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-11::Emiliano Conde
CREATE TABLE public.contact_type (id INT NOT NULL, entity_id INT, is_primary INT, optlock INT NOT NULL, CONSTRAINT contact_type_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-11', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 10, '7:0714008a0e79b913249812348bd92812', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-12::Emiliano Conde
CREATE TABLE public.country (id INT NOT NULL, code VARCHAR(2) NOT NULL, CONSTRAINT country_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-12', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 11, '7:a22dc68a8e1cc035fc8e6b98c243afa2', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-13::Emiliano Conde
CREATE TABLE public.credit_card (id INT NOT NULL, cc_number VARCHAR(100) NOT NULL, cc_number_plain VARCHAR(20), cc_expiry date NOT NULL, name VARCHAR(150), cc_type INT NOT NULL, deleted INT DEFAULT 0 NOT NULL, gateway_key VARCHAR(100), optlock INT NOT NULL, CONSTRAINT credit_card_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-13', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 12, '7:91dad5ca3c80ba7f0c86cd403ad1f5a1', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-14::Emiliano Conde
CREATE TABLE public.currency (id INT NOT NULL, symbol VARCHAR(10) NOT NULL, code VARCHAR(3) NOT NULL, country_code VARCHAR(2) NOT NULL, optlock INT, CONSTRAINT currency_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-14', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 13, '7:bb023c716e85f3e5a6ecc18addf74c93', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-15::Emiliano Conde
CREATE TABLE public.currency_entity_map (currency_id INT, entity_id INT);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-15', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 14, '7:b3dc34c78a6d99215bd55e3cf9f024a5', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-16::Emiliano Conde
CREATE TABLE public.currency_exchange (id INT NOT NULL, entity_id INT, currency_id INT, rate numeric(22, 10) NOT NULL, create_datetime TIMESTAMP WITHOUT TIME ZONE NOT NULL, optlock INT NOT NULL, valid_since date DEFAULT '1970-01-01' NOT NULL, CONSTRAINT currency_exchange_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-16', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 15, '7:ccbc91b77accf90af85fe7a7f1e8eb50', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-17::Emiliano Conde
CREATE TABLE public.customer (id INT NOT NULL, user_id INT, partner_id INT, referral_fee_paid INT, invoice_delivery_method_id INT NOT NULL, notes VARCHAR(1000), auto_payment_type INT, due_date_unit_id INT, due_date_value INT, df_fm INT, parent_id INT, is_parent INT, exclude_aging INT DEFAULT 0 NOT NULL, invoice_child INT, current_order_id INT, optlock INT NOT NULL, balance_type INT NOT NULL, dynamic_balance numeric(22, 10), credit_limit numeric(22, 10), auto_recharge numeric(22, 10), use_parent_pricing BOOLEAN NOT NULL, CONSTRAINT customer_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-17', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 16, '7:eeaa643a00b54017268d1f7d2d685561', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-18::Emiliano Conde
CREATE TABLE public.customer_meta_field_map (customer_id INT NOT NULL, meta_field_value_id INT NOT NULL);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-18', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 17, '7:b86cc87b63206be74e0bf0810603b4b9', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-20::Emiliano Conde
CREATE TABLE public.entity (id INT NOT NULL, external_id VARCHAR(20), description VARCHAR(100) NOT NULL, create_datetime TIMESTAMP WITHOUT TIME ZONE NOT NULL, language_id INT NOT NULL, currency_id INT NOT NULL, optlock INT NOT NULL, CONSTRAINT entity_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-20', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 18, '7:875167c97cb7a74f69518cce3669b6bf', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-21::Emiliano Conde
CREATE TABLE public.entity_delivery_method_map (method_id INT, entity_id INT);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-21', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 19, '7:e3a0537c1e4c52573487d9a174ea5868', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-22::Emiliano Conde
CREATE TABLE public.entity_payment_method_map (entity_id INT, payment_method_id INT);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-22', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 20, '7:ad866e4480035e2d3611d758b1aae457', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-23::Emiliano Conde
CREATE TABLE public.entity_report_map (report_id INT NOT NULL, entity_id INT NOT NULL);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-23', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 21, '7:4a31d34d4f9622f1d949707fd6f5af9a', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-24::Emiliano Conde
CREATE TABLE public.enumeration (id INT NOT NULL, entity_id INT NOT NULL, name VARCHAR(50) NOT NULL, optlock INT NOT NULL, CONSTRAINT enumeration_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-24', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 22, '7:841d8cd76ebe7329c4a5eb65f1b75215', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-25::Emiliano Conde
CREATE TABLE public.enumeration_values (id INT NOT NULL, enumeration_id INT NOT NULL, value VARCHAR(50) NOT NULL, optlock INT NOT NULL, CONSTRAINT enumeration_values_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-25', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 23, '7:d069497f8f0f4d5633a95960dae1c927', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-26::Emiliano Conde
CREATE TABLE public.event_log (id INT NOT NULL, entity_id INT, user_id INT, table_id INT, foreign_id INT NOT NULL, create_datetime TIMESTAMP WITHOUT TIME ZONE NOT NULL, level_field INT NOT NULL, module_id INT NOT NULL, message_id INT NOT NULL, old_num INT, old_str VARCHAR(1000), old_date TIMESTAMP WITHOUT TIME ZONE, optlock INT NOT NULL, affected_user_id INT, CONSTRAINT event_log_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-26', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 24, '7:b72e670cb94ade1967424839e713c7a6', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-27::Emiliano Conde
CREATE TABLE public.event_log_message (id INT NOT NULL, CONSTRAINT event_log_message_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-27', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 25, '7:f0321e258497e2fcbf1837269cf57697', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-28::Emiliano Conde
CREATE TABLE public.event_log_module (id INT NOT NULL, CONSTRAINT event_log_module_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-28', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 26, '7:9ac47f41854098201d8e3327bab3aaa9', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-29::Emiliano Conde
CREATE TABLE public.filter (id INT NOT NULL, filter_set_id INT NOT NULL, type VARCHAR(255) NOT NULL, constraint_type VARCHAR(255) NOT NULL, field VARCHAR(255) NOT NULL, template VARCHAR(255) NOT NULL, visible BOOLEAN NOT NULL, integer_value INT, string_value VARCHAR(255), start_date_value TIMESTAMP WITHOUT TIME ZONE, end_date_value TIMESTAMP WITHOUT TIME ZONE, version INT NOT NULL, boolean_value BOOLEAN, decimal_value numeric(22, 10), decimal_high_value numeric(22, 10), CONSTRAINT filter_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-29', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 27, '7:9a6a68eac5722813ddb11fb3f5b5c7cf', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-30::Emiliano Conde
CREATE TABLE public.filter_set (id INT NOT NULL, name VARCHAR(255) NOT NULL, user_id INT NOT NULL, version INT NOT NULL, CONSTRAINT filter_set_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-30', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 28, '7:c5ff89ba8a44fa1d04755fbe4d9aaba0', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-31::Emiliano Conde
CREATE TABLE public.filter_set_filter (filter_set_filters_id INT, filter_id INT);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-31', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 29, '7:f08d28a18f9bd6f14e882e433112d7c8', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-32::Emiliano Conde
CREATE TABLE public.generic_status (id INT NOT NULL, dtype VARCHAR(50) NOT NULL, status_value INT NOT NULL, can_login INT, CONSTRAINT generic_status_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-32', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 30, '7:df80d416e3a998ec1c9367b6a150e910', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-33::Emiliano Conde
CREATE TABLE public.generic_status_type (id VARCHAR(50) NOT NULL, CONSTRAINT generic_status_type_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-33', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 31, '7:3e5399c547a512022ed5924ab230808c', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-34::Emiliano Conde
CREATE TABLE public.international_description (table_id INT NOT NULL, foreign_id INT NOT NULL, psudo_column VARCHAR(20) NOT NULL, language_id INT NOT NULL, content VARCHAR(4000) NOT NULL);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-34', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 32, '7:4de2c4d22bbb5f42b88b5c865fab7eb6', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-35::Emiliano Conde
CREATE TABLE public.invoice (id INT NOT NULL, create_datetime TIMESTAMP WITHOUT TIME ZONE NOT NULL, billing_process_id INT, user_id INT, delegated_invoice_id INT, due_date date NOT NULL, total numeric(22, 10) NOT NULL, payment_attempts INT DEFAULT 0 NOT NULL, status_id INT DEFAULT 1 NOT NULL, balance numeric(22, 10), carried_balance numeric(22, 10) NOT NULL, in_process_payment INT DEFAULT 1 NOT NULL, is_review INT NOT NULL, currency_id INT NOT NULL, deleted INT DEFAULT 0 NOT NULL, paper_invoice_batch_id INT, customer_notes VARCHAR(1000), public_number VARCHAR(40), last_reminder date, overdue_step INT, create_timestamp TIMESTAMP WITHOUT TIME ZONE NOT NULL, optlock INT NOT NULL, CONSTRAINT invoice_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-35', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 33, '7:07262c39b56be415cf7c37fe63d42a69', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-36::Emiliano Conde
CREATE TABLE public.invoice_delivery_method (id INT NOT NULL, CONSTRAINT invoice_delivery_method_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-36', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 34, '7:3b091de78f648afe18f9e9ad3e66413d', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-37::Emiliano Conde
CREATE TABLE public.invoice_line (id INT NOT NULL, invoice_id INT, type_id INT, amount numeric(22, 10) NOT NULL, quantity numeric(22, 10), price numeric(22, 10), deleted INT DEFAULT 0 NOT NULL, item_id INT, description VARCHAR(1000), source_user_id INT, is_percentage INT DEFAULT 0 NOT NULL, optlock INT NOT NULL, CONSTRAINT invoice_line_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-37', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 35, '7:ed8dd86cf5fbfb408f6181aedc2cfca8', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-38::Emiliano Conde
CREATE TABLE public.invoice_line_type (id INT NOT NULL, description VARCHAR(50) NOT NULL, order_position INT NOT NULL, CONSTRAINT invoice_line_type_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-38', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 36, '7:0fcd69c5133c7417e57410ad49c90c14', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-39::Emiliano Conde
CREATE TABLE public.invoice_meta_field_map (invoice_id INT NOT NULL, meta_field_value_id INT NOT NULL);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-39', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 37, '7:0cf8dfbe640acc6dbc3bc62c3a90561b', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-40::Emiliano Conde
CREATE TABLE public.item (id INT NOT NULL, internal_number VARCHAR(50), entity_id INT, percentage numeric(22, 10), deleted INT DEFAULT 0 NOT NULL, has_decimals INT DEFAULT 0 NOT NULL, optlock INT NOT NULL, gl_code VARCHAR(50), CONSTRAINT item_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-40', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 38, '7:1caca3a71ad2afbd8ccd8f830215c6a9', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-41::Emiliano Conde
CREATE TABLE public.item_meta_field_map (item_id INT NOT NULL, meta_field_value_id INT NOT NULL);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-41', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 39, '7:aefc2c13166967dbade6e629788be8f8', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-43::Emiliano Conde
CREATE TABLE public.item_type (id INT NOT NULL, entity_id INT NOT NULL, description VARCHAR(100), order_line_type_id INT NOT NULL, optlock INT NOT NULL, internal BOOLEAN NOT NULL, CONSTRAINT item_type_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-43', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 40, '7:78fa99c7075e71184d35caa2a64e1323', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-44::Emiliano Conde
CREATE TABLE public.item_type_exclude_map (item_id INT NOT NULL, type_id INT NOT NULL);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-44', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 41, '7:e71d4833b5fd6f8c33fb4afdac2f6602', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-45::Emiliano Conde
CREATE TABLE public.item_type_map (item_id INT, type_id INT);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-45', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 42, '7:dd8d274a4d158e81346dd07dbae9e4dc', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-46::Emiliano Conde
CREATE TABLE public.jbilling_seqs (name VARCHAR(255), next_id INT);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-46', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 43, '7:b27b564b5e45ff66688f7b59be7da0ae', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-47::Emiliano Conde
CREATE TABLE public.jbilling_table (id INT NOT NULL, name VARCHAR(50) NOT NULL, CONSTRAINT jbilling_table_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-47', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 44, '7:fd1da3e1a613390da6c9c50de7ec8dd1', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-48::Emiliano Conde
CREATE TABLE public.language (id INT NOT NULL, code VARCHAR(2) NOT NULL, description VARCHAR(50) NOT NULL, CONSTRAINT language_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-48', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 45, '7:28e24c30a1fcf81bd315d1cc66162b5b', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-49::Emiliano Conde
CREATE TABLE public.list_meta_field_values (meta_field_value_id INT NOT NULL, list_value VARCHAR(255));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-49', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 46, '7:dff7780f47c39c01843ce852439b56b2', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-56::Emiliano Conde
CREATE TABLE public.meta_field_name (id INT NOT NULL, name VARCHAR(100), entity_type VARCHAR(25) NOT NULL, data_type VARCHAR(25) NOT NULL, is_disabled BOOLEAN, is_mandatory BOOLEAN, display_order INT, default_value_id INT, optlock INT NOT NULL, entity_id INT DEFAULT 1, CONSTRAINT meta_field_name_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-56', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 47, '7:cfeb764e680a99849337a34ac178dbc7', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-57::Emiliano Conde
CREATE TABLE public.meta_field_value (id INT NOT NULL, meta_field_name_id INT NOT NULL, dtype VARCHAR(10) NOT NULL, boolean_value BOOLEAN, date_value TIMESTAMP WITHOUT TIME ZONE, decimal_value numeric(22, 10), integer_value INT, string_value VARCHAR(1000));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-57', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 48, '7:c3c22ccb5d4b12a2fea500373e60d062', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-58::Emiliano Conde
CREATE TABLE public.notification_category (id INT NOT NULL, CONSTRAINT notification_category_pk PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-58', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 49, '7:13d5847e8c5ad95b0fc5726d373c88fb', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-59::Emiliano Conde
CREATE TABLE public.notification_message (id INT NOT NULL, type_id INT, entity_id INT NOT NULL, language_id INT NOT NULL, use_flag INT DEFAULT 1 NOT NULL, optlock INT NOT NULL, CONSTRAINT notifictn_msg_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-59', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 50, '7:4198e76fefd9fa386fb430303d822a67', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-60::Emiliano Conde
CREATE TABLE public.notification_message_arch (id INT NOT NULL, type_id INT, create_datetime TIMESTAMP WITHOUT TIME ZONE NOT NULL, user_id INT, result_message VARCHAR(200), optlock INT NOT NULL, CONSTRAINT notifictn_msg_arch_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-60', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 51, '7:fc642db573ffdc1e618a3c8687842080', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-61::Emiliano Conde
CREATE TABLE public.notification_message_arch_line (id INT NOT NULL, message_archive_id INT, section INT NOT NULL, content VARCHAR(1000) NOT NULL, optlock INT NOT NULL, CONSTRAINT notifictn_msg_arch_line_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-61', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 52, '7:83b1023dfb24225ce9a2d81c5b42bc83', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-62::Emiliano Conde
CREATE TABLE public.notification_message_line (id INT NOT NULL, message_section_id INT, content VARCHAR(1000) NOT NULL, optlock INT NOT NULL, CONSTRAINT notifictn_msg_line_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-62', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 53, '7:73cbcc198f3501f7806a785f3d209bbc', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-63::Emiliano Conde
CREATE TABLE public.notification_message_section (id INT NOT NULL, message_id INT, section INT, optlock INT NOT NULL, CONSTRAINT notifictn_msg_section_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-63', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 54, '7:d74efc0344146b6b79f3b7a2c1fd379f', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-64::Emiliano Conde
CREATE TABLE public.notification_message_type (id INT NOT NULL, optlock INT NOT NULL, category_id INT, CONSTRAINT notifictn_msg_type_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-64', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 55, '7:a7df71b28261768069a3b4b85f9c8eee', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-65::Emiliano Conde
CREATE TABLE public.order_billing_type (id INT NOT NULL, CONSTRAINT order_billing_type_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-65', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 56, '7:cf70309e8abd8b593c5de9baf45167fa', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-66::Emiliano Conde
CREATE TABLE public.order_line (id INT NOT NULL, order_id INT, item_id INT, type_id INT, amount numeric(22, 10) NOT NULL, quantity numeric(22, 10), price numeric(22, 10), item_price INT, create_datetime TIMESTAMP WITHOUT TIME ZONE NOT NULL, deleted INT DEFAULT 0 NOT NULL, description VARCHAR(1000), optlock INT NOT NULL, use_item BOOLEAN NOT NULL, CONSTRAINT order_line_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-66', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 57, '7:bd24286b5bd6410a6e61920a11d9864b', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-67::Emiliano Conde
CREATE TABLE public.order_line_type (id INT NOT NULL, editable INT NOT NULL, CONSTRAINT order_line_type_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-67', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 58, '7:25caddd42f70cd1fb8578934ce32151a', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-68::Emiliano Conde
CREATE TABLE public.order_meta_field_map (order_id INT NOT NULL, meta_field_value_id INT NOT NULL);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-68', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 59, '7:ba7faa6025e643508a1356a016a5441a', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-69::Emiliano Conde
CREATE TABLE public.order_period (id INT NOT NULL, entity_id INT, value INT, unit_id INT, optlock INT NOT NULL, CONSTRAINT order_period_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-69', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 60, '7:4f304ef3ad2349533a4bf8dcccdf81c4', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-70::Emiliano Conde
CREATE TABLE public.order_process (id INT NOT NULL, order_id INT, invoice_id INT, billing_process_id INT, periods_included INT, period_start date, period_end date, is_review INT NOT NULL, origin INT, optlock INT NOT NULL, CONSTRAINT order_process_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-70', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 61, '7:e9a90e7c10705101a981030ce0a5d182', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-71::Emiliano Conde
CREATE TABLE public.paper_invoice_batch (id INT NOT NULL, total_invoices INT NOT NULL, delivery_date date, is_self_managed INT NOT NULL, optlock INT NOT NULL, CONSTRAINT paper_invoice_batch_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-71', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 62, '7:d6f47d891ec3566bf5fa9d0781164aaf', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-72::Emiliano Conde
CREATE TABLE public.partner (id INT NOT NULL, user_id INT, balance numeric(22, 10) NOT NULL, total_payments numeric(22, 10) NOT NULL, total_refunds numeric(22, 10) NOT NULL, total_payouts numeric(22, 10) NOT NULL, percentage_rate numeric(22, 10), referral_fee numeric(22, 10), fee_currency_id INT, one_time INT NOT NULL, period_unit_id INT NOT NULL, period_value INT NOT NULL, next_payout_date date NOT NULL, due_payout numeric(22, 10), automatic_process INT NOT NULL, related_clerk INT, optlock INT NOT NULL, CONSTRAINT partner_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-72', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 63, '7:8bb31b2fcc7078088b1d9549003c7542', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-73::Emiliano Conde
CREATE TABLE public.partner_meta_field_map (partner_id INT NOT NULL, meta_field_value_id INT NOT NULL);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-73', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 64, '7:d9572ef7e927f18157afd29cd88599f4', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-74::Emiliano Conde
CREATE TABLE public.partner_payout (id INT NOT NULL, starting_date date NOT NULL, ending_date date NOT NULL, payments_amount numeric(22, 10) NOT NULL, refunds_amount numeric(22, 10) NOT NULL, balance_left numeric(22, 10) NOT NULL, payment_id INT, partner_id INT, optlock INT NOT NULL, CONSTRAINT partner_payout_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-74', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 65, '7:d3b6218392df92ad908a3c93b13d283f', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-75::Emiliano Conde
CREATE TABLE public.partner_range (id INT NOT NULL, partner_id INT, percentage_rate numeric(22, 10), referral_fee numeric(22, 10), range_from INT NOT NULL, range_to INT NOT NULL, optlock INT NOT NULL, CONSTRAINT partner_range_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-75', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 66, '7:53b048b2daaae2527524683fa9370126', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-76::Emiliano Conde
CREATE TABLE public.payment (id INT NOT NULL, user_id INT, attempt INT, result_id INT, amount numeric(22, 10) NOT NULL, create_datetime TIMESTAMP WITHOUT TIME ZONE NOT NULL, update_datetime TIMESTAMP WITHOUT TIME ZONE, payment_date date, method_id INT NOT NULL, credit_card_id INT, deleted INT DEFAULT 0 NOT NULL, is_refund INT DEFAULT 0 NOT NULL, is_preauth INT DEFAULT 0 NOT NULL, payment_id INT, currency_id INT NOT NULL, payout_id INT, ach_id INT, balance numeric(22, 10), optlock INT NOT NULL, payment_period INT, payment_notes VARCHAR(500), CONSTRAINT payment_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-76', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 67, '7:1dcd25aebd541861664bb25e6a95aeb5', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-77::Emiliano Conde
CREATE TABLE public.payment_authorization (id INT NOT NULL, payment_id INT, processor VARCHAR(40) NOT NULL, code1 VARCHAR(40) NOT NULL, code2 VARCHAR(40), code3 VARCHAR(40), approval_code VARCHAR(20), avs VARCHAR(20), transaction_id VARCHAR(40), md5 VARCHAR(100), card_code VARCHAR(100), create_datetime date NOT NULL, response_message VARCHAR(200), optlock INT NOT NULL, CONSTRAINT payment_authorization_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-77', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 68, '7:8cc0b8eb3dc4c57bca43fb74fe8ba9f6', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-78::Emiliano Conde
CREATE TABLE public.payment_info_cheque (id INT NOT NULL, payment_id INT, bank VARCHAR(50), cheque_number VARCHAR(50), cheque_date date, optlock INT NOT NULL, CONSTRAINT payment_info_cheque_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-78', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 69, '7:faf64042497651dbe58fca13b595121c', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-79::Emiliano Conde
CREATE TABLE public.payment_invoice (id INT NOT NULL, payment_id INT, invoice_id INT, amount numeric(22, 10), create_datetime TIMESTAMP WITHOUT TIME ZONE NOT NULL, optlock INT NOT NULL, CONSTRAINT payment_invoice_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-79', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 70, '7:8d8395b59d4135177e3e97152321c39d', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-80::Emiliano Conde
CREATE TABLE public.payment_meta_field_map (payment_id INT NOT NULL, meta_field_value_id INT NOT NULL);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-80', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 71, '7:9c176496b9d4502ce7931395f35bc44a', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-81::Emiliano Conde
CREATE TABLE public.payment_method (id INT NOT NULL, CONSTRAINT payment_method_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-81', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 72, '7:f8806b3d1ca780622b4dfec350732459', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-82::Emiliano Conde
CREATE TABLE public.payment_result (id INT NOT NULL, CONSTRAINT payment_result_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-82', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 73, '7:5a5559ed5e9105e545520f786702ba41', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-83::Emiliano Conde
CREATE TABLE public.period_unit (id INT NOT NULL, CONSTRAINT period_unit_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-83', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 74, '7:48f296de8c91d93c6051f5aee0cccf03', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-92::Emiliano Conde
CREATE TABLE public.pluggable_task (id INT NOT NULL, entity_id INT NOT NULL, type_id INT, processing_order INT NOT NULL, optlock INT NOT NULL, notes VARCHAR(1000), CONSTRAINT pluggable_task_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-92', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 75, '7:7a0fe4fd689496a88bec4d08ea2d14ee', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-93::Emiliano Conde
CREATE TABLE public.pluggable_task_parameter (id INT NOT NULL, task_id INT, name VARCHAR(50) NOT NULL, int_value INT, str_value VARCHAR(500), float_value numeric(22, 10), optlock INT NOT NULL, CONSTRAINT pluggable_task_parameter_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-93', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 76, '7:c730a0ddbcc43ae41d0d171037197776', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-94::Emiliano Conde
CREATE TABLE public.pluggable_task_type (id INT NOT NULL, category_id INT NOT NULL, class_name VARCHAR(200) NOT NULL, min_parameters INT NOT NULL, CONSTRAINT pluggable_task_type_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-94', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 77, '7:eb876cba9f2fec2d625d99cce58529a9', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-95::Emiliano Conde
CREATE TABLE public.pluggable_task_type_category (id INT NOT NULL, interface_name VARCHAR(200) NOT NULL, CONSTRAINT pluggable_task_type_cat_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-95', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 78, '7:cc69581564adc173b25c8c4e03690842', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-96::Emiliano Conde
CREATE TABLE public.preference (id INT NOT NULL, type_id INT, table_id INT NOT NULL, foreign_id INT NOT NULL, value VARCHAR(200), CONSTRAINT preference_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-96', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 79, '7:35f4c7e4a908c1ef59be622b6c33ace8', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-97::Emiliano Conde
CREATE TABLE public.preference_type (id INT NOT NULL, def_value VARCHAR(200), CONSTRAINT preference_type_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-97', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 80, '7:37490816ce942e643a637c26331286fa', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-100::Emiliano Conde
CREATE TABLE public.process_run (id INT NOT NULL, process_id INT, run_date date NOT NULL, started TIMESTAMP WITHOUT TIME ZONE NOT NULL, finished TIMESTAMP WITHOUT TIME ZONE, payment_finished TIMESTAMP WITHOUT TIME ZONE, invoices_generated INT, optlock INT NOT NULL, status_id INT NOT NULL, CONSTRAINT process_run_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-100', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 81, '7:9205df323f2c15c685ed06f9f4491eab', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-101::Emiliano Conde
CREATE TABLE public.process_run_total (id INT NOT NULL, process_run_id INT, currency_id INT NOT NULL, total_invoiced numeric(22, 10), total_paid numeric(22, 10), total_not_paid numeric(22, 10), optlock INT NOT NULL, CONSTRAINT process_run_total_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-101', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 82, '7:0c5a94d1f3378394d68b44396f4d1e43', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-102::Emiliano Conde
CREATE TABLE public.process_run_total_pm (id INT NOT NULL, process_run_total_id INT, payment_method_id INT, total numeric(22, 10) NOT NULL, optlock INT NOT NULL, CONSTRAINT process_run_total_pm_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-102', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 83, '7:42bdcdfcead0d065149cad55681524c0', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-103::Emiliano Conde
CREATE TABLE public.process_run_user (id INT NOT NULL, process_run_id INT NOT NULL, user_id INT NOT NULL, status INT NOT NULL, created TIMESTAMP WITHOUT TIME ZONE NOT NULL, optlock INT NOT NULL, CONSTRAINT process_run_user_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-103', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 84, '7:c08d47ebd7356606e269e4a327170596', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-104::Emiliano Conde
CREATE TABLE public.promotion (id INT NOT NULL, item_id INT, code VARCHAR(50) NOT NULL, notes VARCHAR(200), once INT NOT NULL, since date, until date, CONSTRAINT promotion_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-104', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 85, '7:b461b8cf0707edf2c94478c7c2d794e0', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-105::Emiliano Conde
CREATE TABLE public.promotion_user_map (user_id INT, promotion_id INT);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-105', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 86, '7:ace973ecfbf315e6d3f82bd53dc0b477', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-106::Emiliano Conde
CREATE TABLE public.purchase_order (id INT NOT NULL, user_id INT, period_id INT, billing_type_id INT NOT NULL, active_since date, active_until date, cycle_start date, create_datetime TIMESTAMP WITHOUT TIME ZONE NOT NULL, next_billable_day date, created_by INT, status_id INT NOT NULL, currency_id INT NOT NULL, deleted INT DEFAULT 0 NOT NULL, notify INT, last_notified TIMESTAMP WITHOUT TIME ZONE, notification_step INT, due_date_unit_id INT, due_date_value INT, df_fm INT, anticipate_periods INT, own_invoice INT, notes VARCHAR(200), notes_in_invoice INT, is_current INT, optlock INT NOT NULL, CONSTRAINT purchase_order_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-106', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 87, '7:e3de9bcdddb0cc988d7610d2a1a00b32', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-108::Emiliano Conde
CREATE TABLE public.recent_item (id INT NOT NULL, type VARCHAR(255) NOT NULL, object_id INT NOT NULL, user_id INT NOT NULL, version INT NOT NULL, CONSTRAINT recent_item_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-108', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 88, '7:a68dac8b48dc6f65ff2dea5770001986', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-109::Emiliano Conde
CREATE TABLE public.report (id INT NOT NULL, type_id INT NOT NULL, name VARCHAR(255) NOT NULL, file_name VARCHAR(500) NOT NULL, optlock INT NOT NULL, CONSTRAINT report_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-109', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 89, '7:af705ddba5368bd508b083effb1cfb82', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-110::Emiliano Conde
CREATE TABLE public.report_parameter (id INT NOT NULL, report_id INT NOT NULL, dtype VARCHAR(10) NOT NULL, name VARCHAR(255) NOT NULL, CONSTRAINT report_parameter_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-110', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 90, '7:826d2988bdefbd37d26bbb65d9fc1108', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-111::Emiliano Conde
CREATE TABLE public.report_type (id INT NOT NULL, name VARCHAR(255) NOT NULL, optlock INT NOT NULL, CONSTRAINT report_type_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-111', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 91, '7:50d7aa6e39cc87396f27d68615c8d50c', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-112::Emiliano Conde
CREATE TABLE public.role (id INT NOT NULL, entity_id INT, role_type_id INT, CONSTRAINT role_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-112', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 92, '7:1f7885410869f4615dac1e1d07cff696', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-113::Emiliano Conde
CREATE TABLE public.shortcut (id INT NOT NULL, user_id INT NOT NULL, controller VARCHAR(255) NOT NULL, action VARCHAR(255), name VARCHAR(255), object_id INT, version INT NOT NULL, CONSTRAINT shortcut_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-113', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 93, '7:d2a95b4dfdcbd8b9a73ca63ff5e345d0', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-114::Emiliano Conde
CREATE TABLE public.user_credit_card_map (user_id INT, credit_card_id INT);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-114', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 94, '7:5f78d6ae3f31a54c849af6522260a069', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-115::Emiliano Conde
CREATE TABLE public.user_role_map (user_id INT, role_id INT);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-115', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 95, '7:07c7b1f6224b8988f6f3e8ad0e8c047e', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-319::Mahesh Shivarkar
CREATE TABLE public.item_price (id INT NOT NULL, item_id INT, currency_id INT, price numeric(22, 10) NOT NULL, OPTLOCK INT NOT NULL, CONSTRAINT item_price_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-319', 'Mahesh Shivarkar', 'descriptors/database/jbilling-schema.xml', NOW(), 96, '7:8d8f703ad7dacac3ebcbd47e68eedec0', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-117::Emiliano Conde
ALTER TABLE public.international_description ADD CONSTRAINT international_description_pkey PRIMARY KEY (table_id, foreign_id, psudo_column, language_id);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-117', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 97, '7:87e9550f859e966dec9d281cdfc1dd48', 'addPrimaryKey', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-119::Emiliano Conde
ALTER TABLE public.item_type_exclude_map ADD CONSTRAINT item_type_exclude_map_pkey PRIMARY KEY (item_id, type_id);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-119', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 98, '7:f1c2782ad773845b19553e79f3dc5391', 'addPrimaryKey', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-123::Emiliano Conde
ALTER TABLE public.meta_field_value ADD CONSTRAINT meta_field_value_id_key UNIQUE (id);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-123', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 99, '7:52309a419b3950177c73af5949f47005', 'addUniqueConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-275::Emiliano Conde
CREATE INDEX ix_base_user_un ON public.base_user(entity_id, user_name);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-275', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 100, '7:c2686f9acf46dd4643804f0a81082846', 'createIndex', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-276::Emiliano Conde
CREATE INDEX ix_blacklist_entity_type ON public.blacklist(entity_id, type);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-276', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 101, '7:d7c7866adc8d375251789a69edb20467', 'createIndex', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-277::Emiliano Conde
CREATE INDEX ix_blacklist_user_type ON public.blacklist(user_id, type);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-277', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 102, '7:cc67f9419e6ef2dcc2bbe073d6b6b9de', 'createIndex', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-278::Emiliano Conde
CREATE INDEX contact_i_del ON public.contact(deleted);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-278', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 103, '7:1727b1798178b0ffffff18a67f5a6867', 'createIndex', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-279::Emiliano Conde
CREATE INDEX ix_contact_address ON public.contact(street_addres1, city, postal_code, street_addres2, state_province, country_code);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-279', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 104, '7:f0f3154cbeec62c6ccb10d1a8343e62d', 'createIndex', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-280::Emiliano Conde
CREATE INDEX ix_contact_fname ON public.contact(first_name);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-280', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 105, '7:13a830711e5f414436fb33a1ad519e42', 'createIndex', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-281::Emiliano Conde
CREATE INDEX ix_contact_fname_lname ON public.contact(first_name, last_name);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-281', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 106, '7:d987b9fbc745b67acc8e9a32e96aea70', 'createIndex', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-282::Emiliano Conde
CREATE INDEX ix_contact_lname ON public.contact(last_name);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-282', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 107, '7:3d28edff13be5e4423c26486379c6f31', 'createIndex', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-283::Emiliano Conde
CREATE INDEX ix_contact_orgname ON public.contact(organization_name);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-283', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 108, '7:6372c28e52eed7014b5bde10a28cf251', 'createIndex', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-284::Emiliano Conde
CREATE INDEX ix_contact_phone ON public.contact(phone_phone_number, phone_area_code, phone_country_code);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-284', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 109, '7:01c0d61a65dc8b722bd648b6dc482e0a', 'createIndex', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-285::Emiliano Conde
CREATE INDEX contact_map_i_3 ON public.contact_map(table_id, foreign_id, type_id);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-285', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 110, '7:0596149a2dc329fb8b9b4f98ae54ac49', 'createIndex', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-286::Emiliano Conde
CREATE INDEX ix_cc_number ON public.credit_card(cc_number_plain);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-286', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 111, '7:011eb535742a8d00970f215048f2e125', 'createIndex', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-287::Emiliano Conde
CREATE INDEX ix_cc_number_encrypted ON public.credit_card(cc_number);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-287', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 112, '7:a6b890a6877ebeda60c8f84a60b4a89f', 'createIndex', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-288::Emiliano Conde
CREATE INDEX currency_entity_map_i_2 ON public.currency_entity_map(currency_id, entity_id);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-288', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 113, '7:433d0a908a559a67d282e419687a1e4d', 'createIndex', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-289::Emiliano Conde
CREATE INDEX ix_el_main ON public.event_log(module_id, message_id, create_datetime);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-289', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 114, '7:579e254c79923e01621b59846f089e29', 'createIndex', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-290::Emiliano Conde
CREATE INDEX international_description_i_2 ON public.international_description(table_id, foreign_id, language_id);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-290', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 115, '7:379c46ff8b1b0fac4db10022e6ca8f33', 'createIndex', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-291::Emiliano Conde
CREATE INDEX ix_invoice_date ON public.invoice(create_datetime);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-291', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 116, '7:dff786eb144e47a9499fba98377131e4', 'createIndex', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-292::Emiliano Conde
CREATE INDEX ix_invoice_due_date ON public.invoice(user_id, due_date);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-292', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 117, '7:31f0f76bd0a1c9473d28095b3658667d', 'createIndex', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-293::Emiliano Conde
CREATE INDEX ix_invoice_number ON public.invoice(user_id, public_number);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-293', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 118, '7:055ef896d9761d0d49de010db685c5a6', 'createIndex', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-294::Emiliano Conde
CREATE INDEX ix_invoice_ts ON public.invoice(create_timestamp, user_id);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-294', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 119, '7:a32d1fd84eb1c7b88823b5c7cab181c6', 'createIndex', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-295::Emiliano Conde
CREATE INDEX ix_invoice_user_id ON public.invoice(user_id, deleted);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-295', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 120, '7:11975e32cbfcd912b4b1bf2dbd8c779b', 'createIndex', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-296::Emiliano Conde
CREATE INDEX ix_item_ent ON public.item(entity_id, internal_number);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-296', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 121, '7:424bd03aa3aa1646b793f863fe253558', 'createIndex', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-298::Emiliano Conde
CREATE INDEX ix_order_process_in ON public.order_process(invoice_id);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-298', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 122, '7:b4212acd1e65f02d3087997ca0330c10', 'createIndex', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-299::Emiliano Conde
CREATE INDEX ix_uq_order_process_or_bp ON public.order_process(order_id, billing_process_id);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-299', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 123, '7:20828164f60f1229ca1505ece7c2fc85', 'createIndex', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-300::Emiliano Conde
CREATE INDEX ix_uq_order_process_or_in ON public.order_process(order_id, invoice_id);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-300', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 124, '7:d6728c6bf7bb9dd186588af165a2dbaf', 'createIndex', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-301::Emiliano Conde
CREATE INDEX partner_range_p ON public.partner_range(partner_id);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-301', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 125, '7:e69e0236869430e4fbb47d9588f13541', 'createIndex', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-302::Emiliano Conde
CREATE INDEX payment_i_2 ON public.payment(user_id, create_datetime);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-302', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 126, '7:69ff6e381675605c0c160f3099e7bb87', 'createIndex', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-303::Emiliano Conde
CREATE INDEX payment_i_3 ON public.payment(user_id, balance);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-303', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 127, '7:e537aeb410d8893d88eb5510e2fe0075', 'createIndex', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-304::Emiliano Conde
CREATE INDEX create_datetime ON public.payment_authorization(create_datetime);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-304', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 128, '7:2e5779c6ca114f02133ea1e248061cdd', 'createIndex', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-305::Emiliano Conde
CREATE INDEX transaction_id ON public.payment_authorization(transaction_id);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-305', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 129, '7:b0f88448f336a132cc2d4ba0da17b797', 'createIndex', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-306::Emiliano Conde
CREATE INDEX ix_uq_payment_inv_map_pa_in ON public.payment_invoice(payment_id, invoice_id);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-306', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 130, '7:2f8061b9e79a61c46232286ebf3acd81', 'createIndex', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-310::Emiliano Conde
CREATE INDEX bp_pm_index_total ON public.process_run_total_pm(process_run_total_id);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-310', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 131, '7:3bbb241087ab9de6bea8468c2690e9c8', 'createIndex', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-311::Emiliano Conde
CREATE INDEX ix_promotion_code ON public.promotion(code);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-311', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 132, '7:3f79c343ef2321709d4918093a2e00b4', 'createIndex', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-312::Emiliano Conde
CREATE INDEX promotion_user_map_i_2 ON public.promotion_user_map(user_id, promotion_id);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-312', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 133, '7:06085b0f16fc1e534a141f5df2ccbf50', 'createIndex', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-313::Emiliano Conde
CREATE INDEX ix_purchase_order_date ON public.purchase_order(user_id, create_datetime);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-313', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 134, '7:051124011bcc345dfd247fe6f1bb0b98', 'createIndex', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-314::Emiliano Conde
CREATE INDEX purchase_order_i_notif ON public.purchase_order(active_until, notification_step);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-314', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 135, '7:872164576f404bd25d2e1aacac05048b', 'createIndex', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-315::Emiliano Conde
CREATE INDEX purchase_order_i_user ON public.purchase_order(user_id, deleted);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-315', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 136, '7:dcf50778ee2fc38371c76339adf703a4', 'createIndex', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-316::Emiliano Conde
CREATE INDEX user_credit_card_map_i_2 ON public.user_credit_card_map(user_id, credit_card_id);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-316', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 137, '7:77a38d8be0387955425076e143f63cb2', 'createIndex', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-317::Emiliano Conde
CREATE INDEX user_role_map_i_2 ON public.user_role_map(user_id, role_id);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-317', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 138, '7:dbc868040f1429f41108777e8f88a6cb', 'createIndex', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::20120530-#2825-Fix-percentage-products-in-Plans::Juan Vidal
INSERT INTO public.order_period (id, entity_id, value, unit_id, optlock) VALUES (5.0, NULL, NULL, NULL, 1.0);

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (17.0, 5.0, 'description', 1.0, 'All Orders');

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('20120530-#2825-Fix-percentage-products-in-Plans', 'Juan Vidal', 'descriptors/database/jbilling-schema.xml', NOW(), 139, '7:59fa33cc692b00665d419b4848aaf91c', 'insert (x2)', '', 'EXECUTED', '3.2.2');

