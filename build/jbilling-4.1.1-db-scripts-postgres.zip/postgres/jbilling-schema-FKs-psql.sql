-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-126::Emiliano Conde
ALTER TABLE public.ach ADD CONSTRAINT ach_fk_1 FOREIGN KEY (user_id) REFERENCES public.base_user (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-126', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 1, '7:75a4458852605f08e980823b5f9006ab', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-127::Emiliano Conde
ALTER TABLE public.ageing_entity_step ADD CONSTRAINT ageing_entity_step_fk_2 FOREIGN KEY (entity_id) REFERENCES public.entity (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-127', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 2, '7:5f2ce32f0fb8497611f789eac19f99f1', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-128::Emiliano Conde
ALTER TABLE public.base_user ADD CONSTRAINT base_user_fk_5 FOREIGN KEY (currency_id) REFERENCES public.currency (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-128', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 3, '7:e673d72b62e0b22b635bee51da2289d9', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-129::Emiliano Conde
ALTER TABLE public.base_user ADD CONSTRAINT base_user_fk_3 FOREIGN KEY (entity_id) REFERENCES public.entity (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-129', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 4, '7:b97de99f9ba546281e8562bd7e21cff6', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-130::Emiliano Conde
ALTER TABLE public.base_user ADD CONSTRAINT base_user_fk_4 FOREIGN KEY (language_id) REFERENCES public.language (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-130', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 5, '7:d2aee44b966453cd7b6c53627329350e', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-131::Emiliano Conde
ALTER TABLE public.billing_process ADD CONSTRAINT billing_process_fk_2 FOREIGN KEY (entity_id) REFERENCES public.entity (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-131', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 6, '7:1cd30f95824988b0117aa5bf311e5356', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-132::Emiliano Conde
ALTER TABLE public.billing_process ADD CONSTRAINT billing_process_fk_3 FOREIGN KEY (paper_invoice_batch_id) REFERENCES public.paper_invoice_batch (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-132', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 7, '7:74305f78440d940e59ad1c67ceed861e', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-133::Emiliano Conde
ALTER TABLE public.billing_process ADD CONSTRAINT billing_process_fk_1 FOREIGN KEY (period_unit_id) REFERENCES public.period_unit (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-133', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 8, '7:814576f082018486e8363af201bab961', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-134::Emiliano Conde
ALTER TABLE public.billing_process_configuration ADD CONSTRAINT billing_proc_configtn_fk_2 FOREIGN KEY (entity_id) REFERENCES public.entity (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-134', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 9, '7:3f1504236ed54fe5131c6177c970fa0c', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-135::Emiliano Conde
ALTER TABLE public.billing_process_configuration ADD CONSTRAINT billing_proc_configtn_fk_1 FOREIGN KEY (period_unit_id) REFERENCES public.period_unit (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-135', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 10, '7:4c23adfc033faf802947f6592ea77891', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-136::Emiliano Conde
ALTER TABLE public.blacklist ADD CONSTRAINT blacklist_fk_1 FOREIGN KEY (entity_id) REFERENCES public.entity (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-136', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 11, '7:c5df405e06b4187a05748d0b4f59630d', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-137::Emiliano Conde
ALTER TABLE public.blacklist ADD CONSTRAINT blacklist_fk_4 FOREIGN KEY (meta_field_value_id) REFERENCES public.meta_field_value (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-137', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 12, '7:60be39df8fdbb0ddc081fbebe8c54b64', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-138::Emiliano Conde
ALTER TABLE public.blacklist ADD CONSTRAINT blacklist_fk_2 FOREIGN KEY (user_id) REFERENCES public.base_user (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-138', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 13, '7:8806a5a1135003ff02aa0eb2d69a704b', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-139::Emiliano Conde
ALTER TABLE public.contact_map ADD CONSTRAINT contact_map_fk_3 FOREIGN KEY (contact_id) REFERENCES public.contact (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-139', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 14, '7:70b7422a6eff32b27fb9fe08e9e45217', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-140::Emiliano Conde
ALTER TABLE public.contact_map ADD CONSTRAINT contact_map_fk_1 FOREIGN KEY (table_id) REFERENCES public.jbilling_table (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-140', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 15, '7:0ea2224088b851ccf69dafb3afee7e40', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-141::Emiliano Conde
ALTER TABLE public.contact_map ADD CONSTRAINT contact_map_fk_2 FOREIGN KEY (type_id) REFERENCES public.contact_type (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-141', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 16, '7:76ba18fb2bebb05f411d0531bd7e6c8e', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-142::Emiliano Conde
ALTER TABLE public.contact_type ADD CONSTRAINT contact_type_fk_1 FOREIGN KEY (entity_id) REFERENCES public.entity (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-142', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 17, '7:1ed5930e3268ad94fba96e21fdea1249', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-143::Emiliano Conde
ALTER TABLE public.currency_entity_map ADD CONSTRAINT currency_entity_map_fk_2 FOREIGN KEY (currency_id) REFERENCES public.currency (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-143', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 18, '7:04d4799989743cd5704499e274368b2b', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-144::Emiliano Conde
ALTER TABLE public.currency_entity_map ADD CONSTRAINT currency_entity_map_fk_1 FOREIGN KEY (entity_id) REFERENCES public.entity (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-144', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 19, '7:4c73be0bc45aaf334bcf63c573e938cb', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-145::Emiliano Conde
ALTER TABLE public.currency_exchange ADD CONSTRAINT currency_exchange_fk_1 FOREIGN KEY (currency_id) REFERENCES public.currency (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-145', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 20, '7:e6b0f05a91612c4b440b5f99a8c0ea50', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-146::Emiliano Conde
ALTER TABLE public.customer ADD CONSTRAINT customer_fk_1 FOREIGN KEY (invoice_delivery_method_id) REFERENCES public.invoice_delivery_method (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-146', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 21, '7:7b3dcbcd8269799b4b0c8fa9bd09bec4', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-147::Emiliano Conde
ALTER TABLE public.customer ADD CONSTRAINT customer_fk_2 FOREIGN KEY (partner_id) REFERENCES public.partner (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-147', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 22, '7:d558528ecd03f62b1e9e338f59bf5d56', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-148::Emiliano Conde
ALTER TABLE public.customer ADD CONSTRAINT customer_fk_3 FOREIGN KEY (user_id) REFERENCES public.base_user (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-148', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 23, '7:6f46f0b755b98fde27e472d096d40a2a', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-149::Emiliano Conde
ALTER TABLE public.customer_meta_field_map ADD CONSTRAINT customer_meta_field_map_fk_1 FOREIGN KEY (customer_id) REFERENCES public.customer (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-149', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 24, '7:33fa4ce421c443142f0287ef168f0fbb', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-150::Emiliano Conde
ALTER TABLE public.customer_meta_field_map ADD CONSTRAINT customer_meta_field_map_fk_2 FOREIGN KEY (meta_field_value_id) REFERENCES public.meta_field_value (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-150', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 25, '7:0da342a911166e62660c407d77c3bd5a', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-153::Emiliano Conde
ALTER TABLE public.entity ADD CONSTRAINT entity_fk_1 FOREIGN KEY (currency_id) REFERENCES public.currency (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-153', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 26, '7:b827b4302366b9c807f81366a68e0de4', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-154::Emiliano Conde
ALTER TABLE public.entity ADD CONSTRAINT entity_fk_2 FOREIGN KEY (language_id) REFERENCES public.language (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-154', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 27, '7:b7ad5cb6690e13eb64461b5a98dbdf53', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-155::Emiliano Conde
ALTER TABLE public.entity_delivery_method_map ADD CONSTRAINT entity_delivry_methd_map_fk1 FOREIGN KEY (entity_id) REFERENCES public.entity (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-155', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 28, '7:05fbf423084f303b0d367b0737430e6c', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-156::Emiliano Conde
ALTER TABLE public.entity_delivery_method_map ADD CONSTRAINT entity_delivry_methd_map_fk2 FOREIGN KEY (method_id) REFERENCES public.invoice_delivery_method (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-156', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 29, '7:bf67b3134da20eb6268a3e97d1d9081c', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-157::Emiliano Conde
ALTER TABLE public.entity_payment_method_map ADD CONSTRAINT entity_payment_method_map_fk_2 FOREIGN KEY (entity_id) REFERENCES public.entity (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-157', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 30, '7:a27db18ae366812b1e64968d629573c3', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-158::Emiliano Conde
ALTER TABLE public.entity_payment_method_map ADD CONSTRAINT entity_payment_method_map_fk_1 FOREIGN KEY (payment_method_id) REFERENCES public.payment_method (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-158', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 31, '7:c94b05a44d2d7df27e2ac602046c7887', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-159::Emiliano Conde
ALTER TABLE public.entity_report_map ADD CONSTRAINT report_map_entity_id_fk FOREIGN KEY (entity_id) REFERENCES public.entity (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-159', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 32, '7:368aee5dd0f38f4a77f2542debc79054', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-160::Emiliano Conde
ALTER TABLE public.entity_report_map ADD CONSTRAINT report_map_report_id_fk FOREIGN KEY (report_id) REFERENCES public.report (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-160', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 33, '7:f8b376c9402563d5e4bbea8e8f8ba9c4', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-161::Emiliano Conde
ALTER TABLE public.enumeration_values ADD CONSTRAINT enumeration_values_fk_1 FOREIGN KEY (enumeration_id) REFERENCES public.enumeration (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-161', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 34, '7:7e0038d684ebf592939a347817ab97da', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-162::Emiliano Conde
ALTER TABLE public.event_log ADD CONSTRAINT event_log_fk_6 FOREIGN KEY (affected_user_id) REFERENCES public.base_user (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-162', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 35, '7:1acb6f8b10f87a06b38717d675d9a6b9', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-163::Emiliano Conde
ALTER TABLE public.event_log ADD CONSTRAINT event_log_fk_2 FOREIGN KEY (entity_id) REFERENCES public.entity (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-163', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 36, '7:4d42cbc89214b0789261d5b38054d506', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-164::Emiliano Conde
ALTER TABLE public.event_log ADD CONSTRAINT event_log_fk_5 FOREIGN KEY (message_id) REFERENCES public.event_log_message (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-164', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 37, '7:40a8bb1b37873c28120d3dd4aa282157', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-165::Emiliano Conde
ALTER TABLE public.event_log ADD CONSTRAINT event_log_fk_1 FOREIGN KEY (module_id) REFERENCES public.event_log_module (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-165', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 38, '7:9ac531852fc3f7cd0837aa589faa582e', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-166::Emiliano Conde
ALTER TABLE public.event_log ADD CONSTRAINT event_log_fk_4 FOREIGN KEY (table_id) REFERENCES public.jbilling_table (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-166', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 39, '7:3004d4c9e496d94c854f76ea48c0076d', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-167::Emiliano Conde
ALTER TABLE public.event_log ADD CONSTRAINT event_log_fk_3 FOREIGN KEY (user_id) REFERENCES public.base_user (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-167', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 40, '7:63a2ef8480517cbdb4087901ced6188d', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-168::Emiliano Conde
ALTER TABLE public.generic_status ADD CONSTRAINT generic_status_fk_1 FOREIGN KEY (dtype) REFERENCES public.generic_status_type (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-168', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 41, '7:aba5c2cf49fee6f01873e796c6105418', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-169::Emiliano Conde
ALTER TABLE public.international_description ADD CONSTRAINT international_description_fk_1 FOREIGN KEY (language_id) REFERENCES public.language (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-169', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 42, '7:79f8a3d295ad88ab7b517cb8ee83c692', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-170::Emiliano Conde
ALTER TABLE public.invoice ADD CONSTRAINT invoice_fk_1 FOREIGN KEY (billing_process_id) REFERENCES public.billing_process (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-170', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 43, '7:c1310382bb7ec369d5f26c0eb1fbb667', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-171::Emiliano Conde
ALTER TABLE public.invoice ADD CONSTRAINT invoice_fk_3 FOREIGN KEY (currency_id) REFERENCES public.currency (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-171', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 44, '7:cf1dcec7874b07a0ad7e15f99b027a0b', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-172::Emiliano Conde
ALTER TABLE public.invoice ADD CONSTRAINT invoice_fk_4 FOREIGN KEY (delegated_invoice_id) REFERENCES public.invoice (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-172', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 45, '7:a369d57ca2662da122f75b8da071d19b', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-173::Emiliano Conde
ALTER TABLE public.invoice ADD CONSTRAINT invoice_fk_2 FOREIGN KEY (paper_invoice_batch_id) REFERENCES public.paper_invoice_batch (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-173', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 46, '7:ad42dcd59467e0f28e6996bb5d3c0fa4', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-174::Emiliano Conde
ALTER TABLE public.invoice_line ADD CONSTRAINT invoice_line_fk_1 FOREIGN KEY (invoice_id) REFERENCES public.invoice (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-174', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 47, '7:5f7d0419cbe31f8b8ee7df86b1937270', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-175::Emiliano Conde
ALTER TABLE public.invoice_line ADD CONSTRAINT invoice_line_fk_2 FOREIGN KEY (item_id) REFERENCES public.item (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-175', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 48, '7:3c483115556a8b38cdc15ad39c3b3492', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-176::Emiliano Conde
ALTER TABLE public.invoice_line ADD CONSTRAINT invoice_line_fk_3 FOREIGN KEY (type_id) REFERENCES public.invoice_line_type (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-176', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 49, '7:148ee59fc185fa10a75ccf2f2b7bbf1f', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-177::Emiliano Conde
ALTER TABLE public.invoice_meta_field_map ADD CONSTRAINT invoice_meta_field_map_fk_1 FOREIGN KEY (invoice_id) REFERENCES public.invoice (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-177', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 50, '7:325d811db324fa6318d992f3982290c5', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-178::Emiliano Conde
ALTER TABLE public.invoice_meta_field_map ADD CONSTRAINT invoice_meta_field_map_fk_2 FOREIGN KEY (meta_field_value_id) REFERENCES public.meta_field_value (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-178', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 51, '7:a985100c3fafe73b9457178f9295a3be', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-179::Emiliano Conde
ALTER TABLE public.item ADD CONSTRAINT item_fk_1 FOREIGN KEY (entity_id) REFERENCES public.entity (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-179', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 52, '7:9a6ab972e31b150963fdd2356beb9c7c', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-180::Emiliano Conde
ALTER TABLE public.item_meta_field_map ADD CONSTRAINT item_meta_field_map_fk_1 FOREIGN KEY (item_id) REFERENCES public.item (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-180', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 53, '7:c53734d21ae9b060abeaafc155f83145', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-181::Emiliano Conde
ALTER TABLE public.item_meta_field_map ADD CONSTRAINT item_meta_field_map_fk_2 FOREIGN KEY (meta_field_value_id) REFERENCES public.meta_field_value (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-181', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 54, '7:2e163eefd39c2db61858c16001014541', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-184::Emiliano Conde
ALTER TABLE public.item_type ADD CONSTRAINT item_type_fk_1 FOREIGN KEY (entity_id) REFERENCES public.entity (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-184', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 55, '7:f55ae3b446a476dc9fb9411591bb2543', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-185::Emiliano Conde
ALTER TABLE public.item_type_exclude_map ADD CONSTRAINT item_type_exclude_item_id_fk FOREIGN KEY (item_id) REFERENCES public.item (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-185', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 56, '7:4f3177adff776b02f07504d2ef55b2d8', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-186::Emiliano Conde
ALTER TABLE public.item_type_exclude_map ADD CONSTRAINT item_type_exclude_type_id_fk FOREIGN KEY (type_id) REFERENCES public.item_type (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-186', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 57, '7:80107e941ca59227c531c848985c3bf9', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-187::Emiliano Conde
ALTER TABLE public.item_type_map ADD CONSTRAINT item_type_map_fk_1 FOREIGN KEY (item_id) REFERENCES public.item (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-187', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 58, '7:f7361473b2cd5d91a6a28a0154a2e095', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-188::Emiliano Conde
ALTER TABLE public.item_type_map ADD CONSTRAINT item_type_map_fk_2 FOREIGN KEY (type_id) REFERENCES public.item_type (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-188', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 59, '7:dcb2e6763c0d385509fb5515068667ab', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-197::Emiliano Conde
ALTER TABLE public.meta_field_name ADD CONSTRAINT meta_field_name_fk_1 FOREIGN KEY (default_value_id) REFERENCES public.meta_field_value (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-197', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 60, '7:9b1b8c900ce348daae8ef8f47fdcaad0', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-198::Emiliano Conde
ALTER TABLE public.meta_field_name ADD CONSTRAINT meta_field_entity_id_fk FOREIGN KEY (entity_id) REFERENCES public.entity (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-198', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 61, '7:61387e4e43008981acc9f7b66c24c8a2', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-199::Emiliano Conde
ALTER TABLE public.meta_field_value ADD CONSTRAINT meta_field_value_fk_1 FOREIGN KEY (meta_field_name_id) REFERENCES public.meta_field_name (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-199', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 62, '7:4c6e3731514d76c12d13fae3e4fa3d23', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-200::Emiliano Conde
ALTER TABLE public.notification_message ADD CONSTRAINT notification_message_fk_3 FOREIGN KEY (entity_id) REFERENCES public.entity (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-200', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 63, '7:6859fa8993edd74e0f8a609871de66bf', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-201::Emiliano Conde
ALTER TABLE public.notification_message ADD CONSTRAINT notification_message_fk_1 FOREIGN KEY (language_id) REFERENCES public.language (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-201', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 64, '7:acb4a155eea2c455856a8de38cdfdd88', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-202::Emiliano Conde
ALTER TABLE public.notification_message ADD CONSTRAINT notification_message_fk_2 FOREIGN KEY (type_id) REFERENCES public.notification_message_type (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-202', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 65, '7:3ec857f24a27a75824df0cb2f90f6344', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-203::Emiliano Conde
ALTER TABLE public.notification_message_arch_line ADD CONSTRAINT notif_mess_arch_line_fk_1 FOREIGN KEY (message_archive_id) REFERENCES public.notification_message_arch (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-203', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 66, '7:b2b4130291b13a57a3810adb4a47ce94', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-204::Emiliano Conde
ALTER TABLE public.notification_message_line ADD CONSTRAINT notification_message_line_fk_1 FOREIGN KEY (message_section_id) REFERENCES public.notification_message_section (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-204', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 67, '7:ead685db40b963c35fc1c19741dfd38f', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-205::Emiliano Conde
ALTER TABLE public.notification_message_section ADD CONSTRAINT notification_msg_section_fk_1 FOREIGN KEY (message_id) REFERENCES public.notification_message (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-205', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 68, '7:25fa80b9806b625b5afd37bf3c5ba704', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-206::Emiliano Conde
ALTER TABLE public.notification_message_type ADD CONSTRAINT category_id_fk_1 FOREIGN KEY (category_id) REFERENCES public.notification_category (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-206', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 69, '7:cfc81314a958f756a9369c8a87eab006', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-207::Emiliano Conde
ALTER TABLE public.order_line ADD CONSTRAINT order_line_fk_1 FOREIGN KEY (item_id) REFERENCES public.item (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-207', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 70, '7:dec079d2acc7ffdde9f0d46e92ac1115', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-208::Emiliano Conde
ALTER TABLE public.order_line ADD CONSTRAINT order_line_fk_2 FOREIGN KEY (order_id) REFERENCES public.purchase_order (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-208', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 71, '7:5e484ec21018d0b9da7b1b9da5b7d03a', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-209::Emiliano Conde
ALTER TABLE public.order_line ADD CONSTRAINT order_line_fk_3 FOREIGN KEY (type_id) REFERENCES public.order_line_type (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-209', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 72, '7:0a30b63874b23a3d00dd0d08c74cc41c', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-210::Emiliano Conde
ALTER TABLE public.order_meta_field_map ADD CONSTRAINT order_meta_field_map_fk_2 FOREIGN KEY (meta_field_value_id) REFERENCES public.meta_field_value (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-210', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 73, '7:57e8ee891eaf66558ec183a69efbc64f', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-211::Emiliano Conde
ALTER TABLE public.order_meta_field_map ADD CONSTRAINT order_meta_field_map_fk_1 FOREIGN KEY (order_id) REFERENCES public.purchase_order (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-211', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 74, '7:b2b7afe0b718b46aa02588f9cd5dc90e', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-212::Emiliano Conde
ALTER TABLE public.order_period ADD CONSTRAINT order_period_fk_1 FOREIGN KEY (entity_id) REFERENCES public.entity (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-212', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 75, '7:be1220080dbe423f7f720d9df7179d2c', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-213::Emiliano Conde
ALTER TABLE public.order_period ADD CONSTRAINT order_period_fk_2 FOREIGN KEY (unit_id) REFERENCES public.period_unit (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-213', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 76, '7:72551c40edbab7f01d0e65f219bc5d97', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-214::Emiliano Conde
ALTER TABLE public.order_process ADD CONSTRAINT order_process_fk_1 FOREIGN KEY (order_id) REFERENCES public.purchase_order (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-214', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 77, '7:23b4bc660215da2c1b87563a29de3cbb', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-215::Emiliano Conde
ALTER TABLE public.partner ADD CONSTRAINT partner_fk_2 FOREIGN KEY (fee_currency_id) REFERENCES public.currency (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-215', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 78, '7:cdaeac3fed333286507b082a79c96e0f', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-216::Emiliano Conde
ALTER TABLE public.partner ADD CONSTRAINT partner_fk_1 FOREIGN KEY (period_unit_id) REFERENCES public.period_unit (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-216', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 79, '7:6491850a4fe692c81fdbb217280bbe64', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-217::Emiliano Conde
ALTER TABLE public.partner ADD CONSTRAINT partner_fk_3 FOREIGN KEY (related_clerk) REFERENCES public.base_user (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-217', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 80, '7:f9ac90aa76552717f6b8dd874d917b41', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-218::Emiliano Conde
ALTER TABLE public.partner ADD CONSTRAINT partner_fk_4 FOREIGN KEY (user_id) REFERENCES public.base_user (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-218', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 81, '7:a42b948787df60198c9004274072a675', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-219::Emiliano Conde
ALTER TABLE public.partner_meta_field_map ADD CONSTRAINT partner_meta_field_map_fk_2 FOREIGN KEY (meta_field_value_id) REFERENCES public.meta_field_value (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-219', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 82, '7:49e038365abfb81b94e85c2c25d7d70d', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-220::Emiliano Conde
ALTER TABLE public.partner_meta_field_map ADD CONSTRAINT partner_meta_field_map_fk_1 FOREIGN KEY (partner_id) REFERENCES public.partner (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-220', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 83, '7:1500f6f47029683281bc7b2e8292f726', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-221::Emiliano Conde
ALTER TABLE public.partner_payout ADD CONSTRAINT partner_payout_fk_1 FOREIGN KEY (partner_id) REFERENCES public.partner (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-221', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 84, '7:129c344be312e649bf894e350d95b3e1', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-222::Emiliano Conde
ALTER TABLE public.payment ADD CONSTRAINT payment_fk_1 FOREIGN KEY (ach_id) REFERENCES public.ach (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-222', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 85, '7:42359f8afd2b6db651722cf404c60b2d', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-223::Emiliano Conde
ALTER TABLE public.payment ADD CONSTRAINT payment_fk_4 FOREIGN KEY (credit_card_id) REFERENCES public.credit_card (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-223', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 86, '7:52bb8c9f7f1ad2d08f80a47f20702e9b', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-224::Emiliano Conde
ALTER TABLE public.payment ADD CONSTRAINT payment_fk_2 FOREIGN KEY (currency_id) REFERENCES public.currency (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-224', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 87, '7:6849ea30a8540c1be986fcdfc03e17f3', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-225::Emiliano Conde
ALTER TABLE public.payment ADD CONSTRAINT payment_fk_6 FOREIGN KEY (method_id) REFERENCES public.payment_method (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-225', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 88, '7:010da80e97cf08a7495a8bab95b6f65e', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-226::Emiliano Conde
ALTER TABLE public.payment ADD CONSTRAINT payment_fk_3 FOREIGN KEY (payment_id) REFERENCES public.payment (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-226', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 89, '7:42c7e285e08d764c551e2ddbcbd926e2', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-227::Emiliano Conde
ALTER TABLE public.payment ADD CONSTRAINT payment_fk_5 FOREIGN KEY (result_id) REFERENCES public.payment_result (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-227', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 90, '7:b44fdcf89b27873fd93714b547314afa', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-228::Emiliano Conde
ALTER TABLE public.payment_authorization ADD CONSTRAINT payment_authorization_fk_1 FOREIGN KEY (payment_id) REFERENCES public.payment (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-228', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 91, '7:c71d08ed6e2235b7c6ae6b2594ca42ca', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-229::Emiliano Conde
ALTER TABLE public.payment_info_cheque ADD CONSTRAINT payment_info_cheque_fk_1 FOREIGN KEY (payment_id) REFERENCES public.payment (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-229', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 92, '7:75fc3797d3a4ba34b7625484fae3e0f7', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-230::Emiliano Conde
ALTER TABLE public.payment_invoice ADD CONSTRAINT payment_invoice_fk_1 FOREIGN KEY (invoice_id) REFERENCES public.invoice (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-230', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 93, '7:4d29bc601d3c8c90dc3641dd9f1845c4', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-231::Emiliano Conde
ALTER TABLE public.payment_invoice ADD CONSTRAINT payment_invoice_fk_2 FOREIGN KEY (payment_id) REFERENCES public.payment (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-231', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 94, '7:b2fe4aa6cee8ce8e0e6f3c5467a2c87d', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-232::Emiliano Conde
ALTER TABLE public.payment_meta_field_map ADD CONSTRAINT payment_meta_field_map_fk_2 FOREIGN KEY (meta_field_value_id) REFERENCES public.meta_field_value (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-232', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 95, '7:57d343b6a41f159d61cba9795c4d70ae', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-233::Emiliano Conde
ALTER TABLE public.payment_meta_field_map ADD CONSTRAINT payment_meta_field_map_fk_1 FOREIGN KEY (payment_id) REFERENCES public.payment (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-233', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 96, '7:17ac0584178afafd9831a8c810d9c3ee', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-247::Emiliano Conde
ALTER TABLE public.pluggable_task ADD CONSTRAINT pluggable_task_fk_2 FOREIGN KEY (entity_id) REFERENCES public.entity (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-247', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 97, '7:8de30a7a3d4fad9c4c9b534d9a32a3d9', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-249::Emiliano Conde
ALTER TABLE public.pluggable_task_parameter ADD CONSTRAINT pluggable_task_parameter_fk_1 FOREIGN KEY (task_id) REFERENCES public.pluggable_task (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-249', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 98, '7:95a7ab19c2e772287a661a19e7c62b32', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-250::Emiliano Conde
ALTER TABLE public.pluggable_task_type ADD CONSTRAINT pluggable_task_type_fk_1 FOREIGN KEY (category_id) REFERENCES public.pluggable_task_type_category (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-250', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 99, '7:0ef59f7c632a6c8b6f7e3e0b88534353', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-251::Emiliano Conde
ALTER TABLE public.preference ADD CONSTRAINT preference_fk_2 FOREIGN KEY (table_id) REFERENCES public.jbilling_table (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-251', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 100, '7:e2d8293585bf55ef1030a5bbc0c41504', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-252::Emiliano Conde
ALTER TABLE public.preference ADD CONSTRAINT preference_fk_1 FOREIGN KEY (type_id) REFERENCES public.preference_type (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-252', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 101, '7:3e40b2c12f93d4bb17992e6d5d01ec8d', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-256::Emiliano Conde
ALTER TABLE public.process_run ADD CONSTRAINT process_run_fk_1 FOREIGN KEY (process_id) REFERENCES public.billing_process (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-256', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 102, '7:7744c9a47a2e8c3ff7fffd49a94010fb', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-257::Emiliano Conde
ALTER TABLE public.process_run ADD CONSTRAINT process_run_fk_2 FOREIGN KEY (status_id) REFERENCES public.generic_status (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-257', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 103, '7:bfc0510a2ee7d38ad7ab2d75a9972d2e', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-258::Emiliano Conde
ALTER TABLE public.process_run_total ADD CONSTRAINT process_run_total_fk_1 FOREIGN KEY (currency_id) REFERENCES public.currency (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-258', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 104, '7:15bbd9ad1be11b4a9dcec7ed34679947', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-259::Emiliano Conde
ALTER TABLE public.process_run_total ADD CONSTRAINT process_run_total_fk_2 FOREIGN KEY (process_run_id) REFERENCES public.process_run (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-259', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 105, '7:b304182d1e2c2cdf5e7b49bd35bb80c1', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-260::Emiliano Conde
ALTER TABLE public.process_run_total_pm ADD CONSTRAINT process_run_total_pm_fk_1 FOREIGN KEY (payment_method_id) REFERENCES public.payment_method (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-260', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 106, '7:dd1ed1cac11d56dfd406defa182b6824', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-261::Emiliano Conde
ALTER TABLE public.process_run_user ADD CONSTRAINT process_run_user_fk_1 FOREIGN KEY (process_run_id) REFERENCES public.process_run (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-261', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 107, '7:968f5c629f6c1903a38ebecc8533eeef', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-262::Emiliano Conde
ALTER TABLE public.process_run_user ADD CONSTRAINT process_run_user_fk_2 FOREIGN KEY (user_id) REFERENCES public.base_user (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-262', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 108, '7:79156e7a592a64e23527208e5e675897', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-263::Emiliano Conde
ALTER TABLE public.promotion ADD CONSTRAINT promotion_fk_1 FOREIGN KEY (item_id) REFERENCES public.item (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-263', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 109, '7:e6db865fb6d446b2197012876fa7da21', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-264::Emiliano Conde
ALTER TABLE public.promotion_user_map ADD CONSTRAINT promotion_user_map_fk_2 FOREIGN KEY (promotion_id) REFERENCES public.promotion (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-264', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 110, '7:ea5ce4eaffe78b9c3e22df6d2b993ef4', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-265::Emiliano Conde
ALTER TABLE public.promotion_user_map ADD CONSTRAINT promotion_user_map_fk_1 FOREIGN KEY (user_id) REFERENCES public.base_user (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-265', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 111, '7:b31723792215e0944355c4c9e88ee4c5', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-266::Emiliano Conde
ALTER TABLE public.purchase_order ADD CONSTRAINT purchase_order_fk_2 FOREIGN KEY (billing_type_id) REFERENCES public.order_billing_type (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-266', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 112, '7:10fab1f295c37475c84fff8d5216621a', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-267::Emiliano Conde
ALTER TABLE public.purchase_order ADD CONSTRAINT purchase_order_fk_5 FOREIGN KEY (created_by) REFERENCES public.base_user (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-267', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 113, '7:4c19e257741ff1192e15ef611b3756d3', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-268::Emiliano Conde
ALTER TABLE public.purchase_order ADD CONSTRAINT purchase_order_fk_1 FOREIGN KEY (currency_id) REFERENCES public.currency (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-268', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 114, '7:f1825551f57751ddb85cdb205ece5348', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-269::Emiliano Conde
ALTER TABLE public.purchase_order ADD CONSTRAINT purchase_order_fk_3 FOREIGN KEY (period_id) REFERENCES public.order_period (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-269', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 115, '7:934a52ce8b78df006eb498b925c56919', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-270::Emiliano Conde
ALTER TABLE public.purchase_order ADD CONSTRAINT purchase_order_fk_4 FOREIGN KEY (user_id) REFERENCES public.base_user (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-270', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 116, '7:d4374eaf5120aa300a92d3c5bde3e54b', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-272::Emiliano Conde
ALTER TABLE public.role ADD CONSTRAINT role_entity_id_fk FOREIGN KEY (entity_id) REFERENCES public.entity (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-272', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 117, '7:9c64ee7a22c79f65096967374724864b', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-273::Emiliano Conde
ALTER TABLE public.user_role_map ADD CONSTRAINT user_role_map_fk_1 FOREIGN KEY (role_id) REFERENCES public.role (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-273', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 118, '7:ac2b6866e164e675a7fa39d9ebea125f', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-274::Emiliano Conde
ALTER TABLE public.user_role_map ADD CONSTRAINT user_role_map_fk_2 FOREIGN KEY (user_id) REFERENCES public.base_user (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-274', 'Emiliano Conde', 'descriptors/database/jbilling-schema.xml', NOW(), 119, '7:fdf5cb55c7696fcc46c1957aa70455c8', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-320::Mahesh Shivarkar
ALTER TABLE public.item_price ADD CONSTRAINT item_price_fk_1 FOREIGN KEY (currency_id) REFERENCES public.currency (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-320', 'Mahesh Shivarkar', 'descriptors/database/jbilling-schema.xml', NOW(), 120, '7:692ad199923acbe9dbe6bd36ef9601e2', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-schema.xml::1337623084753-321::Mahesh Shivarkar
ALTER TABLE public.item_price ADD CONSTRAINT item_price_fk_2 FOREIGN KEY (item_id) REFERENCES public.item (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-321', 'Mahesh Shivarkar', 'descriptors/database/jbilling-schema.xml', NOW(), 121, '7:dce9f5277aff5d62f2665f00f3bf2159', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Release Database Lock
