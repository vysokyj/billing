-- Changeset descriptors/database/jbilling-upgrade-4.1.xml::#6316-new-password-column-size::Maeis Gharibjanian
-- Increasing the size of the password column. This should be enough to store
--             most hashes generated from known hashing methods plus the generated salt.
ALTER TABLE public.base_user ALTER COLUMN password TYPE VARCHAR(1024);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#6316-new-password-column-size', 'Maeis Gharibjanian', 'descriptors/database/jbilling-upgrade-4.1.xml', NOW(), 1, '7:a69af898af6060ad2d0517488e188a44', 'modifyDataType', 'Increasing the size of the password column. This should be enough to store
            most hashes generated from known hashing methods plus the generated salt.', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.1.xml::#6316-hashing-method-column::Khurram M Cheema
-- Adding a column to represent the encryption scheme. Here we are assuming that
--             all clients are sticking to the default password hashing method which is MD5.
ALTER TABLE public.base_user ADD encryption_scheme INT;

UPDATE public.base_user SET encryption_scheme = '2';

ALTER TABLE public.base_user ALTER COLUMN  encryption_scheme SET NOT NULL;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#6316-hashing-method-column', 'Khurram M Cheema', 'descriptors/database/jbilling-upgrade-4.1.xml', NOW(), 2, '7:036f9f96c6e43aac3f5b9d35f2dfdcc0', 'addColumn, update, addNotNullConstraint', 'Adding a column to represent the encryption scheme. Here we are assuming that
            all clients are sticking to the default password hashing method which is MD5.', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.1.xml::#10595-Password lockout for failed login attempts::Bilal Shah
-- Constant ID may need to be changed during merging of this feature to later branches to avoid overlapping with other preference IDs
ALTER TABLE public.base_user ADD account_locked_time TIMESTAMP WITHOUT TIME ZONE;

INSERT INTO public.preference_type (id, def_value) VALUES (68.0, '0');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 68.0, 'description', 1.0, 'Account Lockout Time');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 68.0, 'instruction', 1.0, 'Number of minutes a User''s account will remain locked after the number of allowed retries (Preference 39) are exhausted.');

UPDATE public.international_description SET content = 'The number of retries to allow before locking the user account. A locked user account will be locked for the amount of minutes specified in Preference 68. To enable this locking feature, setting Preference 68 to a non-zero value is a must.' WHERE table_id = 50 and foreign_id = 39 and language_id = 1 and psudo_column = 'instruction';

INSERT INTO public.event_log_message (id) VALUES ((select max(e.id)+1 from event_log_message e));

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, (select max(e.id) from event_log_message e), 'description', 1.0, 'A failed login attempt was made.');

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#10595-Password lockout for failed login attempts', 'Bilal Shah', 'descriptors/database/jbilling-upgrade-4.1.xml', NOW(), 3, '7:f07d2c0f2498e8ef7b2587fc9a9aff76', 'addColumn, insert (x3), update, insert (x2)', 'Constant ID may need to be changed during merging of this feature to later branches to avoid overlapping with other preference IDs', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.1.xml::#11107 - Line Percentage::Rohit Gupta
ALTER TABLE public.item DROP COLUMN percentage;

ALTER TABLE public.order_line ADD is_percentage BOOLEAN NOT NULL DEFAULT FALSE;

ALTER TABLE public.order_change ADD is_percentage BOOLEAN NOT NULL DEFAULT FALSE;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#11107 - Line Percentage', 'Rohit Gupta', 'descriptors/database/jbilling-upgrade-4.1.xml', NOW(), 4, '7:6db888e7c55aeb530e55840193ee6d23', 'dropColumn, addColumn (x2)', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.1.xml::#10256:Asset Reservation::Morales Fernando G.
-- Adding reservation parameter
-- Asset reservation table
-- Adding indexes
ALTER TABLE public.item ADD reservation_duration INT NOT NULL DEFAULT 0;

CREATE TABLE public.asset_reservation (id INT NOT NULL, user_id INT NOT NULL, creator_user_id INT NOT NULL, asset_id INT NOT NULL, start_date TIMESTAMP WITHOUT TIME ZONE NOT NULL, end_date TIMESTAMP WITHOUT TIME ZONE NOT NULL, optlock INT NOT NULL, CONSTRAINT asset_reservation_pkey PRIMARY KEY (id));

CREATE INDEX asset_reservation_end_date_index ON public.asset_reservation(end_date);

ALTER TABLE public.asset_reservation ADD CONSTRAINT asset_reservation_fk_1 FOREIGN KEY (creator_user_id) REFERENCES public.base_user (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE public.asset_reservation ADD CONSTRAINT asset_reservation_fk_2 FOREIGN KEY (user_id) REFERENCES public.base_user (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE public.asset_reservation ADD CONSTRAINT asset_reservation_fk_3 FOREIGN KEY (asset_id) REFERENCES public.asset (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#10256:Asset Reservation', 'Morales Fernando G.', 'descriptors/database/jbilling-upgrade-4.1.xml', NOW(), 5, '7:cedb8fafce6fbd6013eb22a57c560123', 'addColumn, createTable, createIndex, addForeignKeyConstraint (x3)', 'Adding reservation parameter
Asset reservation table
Adding indexes', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.1.xml::#11243-AIT-Inhancement::Rohit Gupta
ALTER TABLE public.account_type ADD notification_ait_id INT;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#11243-AIT-Inhancement', 'Rohit Gupta', 'descriptors/database/jbilling-upgrade-4.1.xml', NOW(), 6, '7:14eae727b861c4856f58f3c2d09763a0', 'addColumn', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.1.xml::20141030-#10344-asset-assignment-history::Vladimir Carevski
-- #10344 Implementing the asset assignment feature
CREATE TABLE public.asset_assignment (id INT NOT NULL, asset_id INT NOT NULL, order_line_id INT NOT NULL, start_datetime TIMESTAMP WITHOUT TIME ZONE NOT NULL, end_datetime TIMESTAMP WITHOUT TIME ZONE, CONSTRAINT asset_assignment_pkey PRIMARY KEY (id));

ALTER TABLE public.asset_assignment ADD CONSTRAINT asset_assignment_fk_1 FOREIGN KEY (asset_id) REFERENCES public.asset (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE public.asset_assignment ADD CONSTRAINT asset_assignment_fk_2 FOREIGN KEY (order_line_id) REFERENCES public.order_line (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.jbilling_table (id, name) VALUES ((select max(jt.id)+1 from jbilling_table jt), 'asset_assignment');

insert into asset_assignment (id, asset_id, order_line_id, start_datetime)

               (select a.id, a.id, a.order_line_id, ooc.application_date
                    from asset a
                        inner join order_line ol on a.order_line_id = ol.id
                        inner join order_change ooc on ooc.order_line_id = ol.id
                    where
                        a.order_line_id is not null
                    and ooc.id = (
                       select oc.id from order_change oc
                            inner join order_change_asset_map ocam on ocam.order_change_id = oc.id
                        where oc.order_line_id = ol.id
                            and ocam.asset_id = a.id
                            order by oc.application_date desc
                            limit 1));

UPDATE public.jbilling_seqs SET next_id = coalesce((select max(p.id)+1 from asset_assignment p),1) WHERE name='asset_assignment';

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('20141030-#10344-asset-assignment-history', 'Vladimir Carevski', 'descriptors/database/jbilling-upgrade-4.1.xml', NOW(), 7, '7:85a2e8a1b01613855662ae5616b0551f', 'createTable, addForeignKeyConstraint (x2), insert, sql, update', '#10344 Implementing the asset assignment feature', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.1.xml::#10355 - reset password after expiry period::Bilal Shah
CREATE TABLE public.user_password_map (id INT NOT NULL, base_user_id INT NOT NULL, date_created TIMESTAMP WITHOUT TIME ZONE NOT NULL, new_password VARCHAR(1024) NOT NULL, CONSTRAINT user_password_map_pkey PRIMARY KEY (id));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#10355 - reset password after expiry period', 'Bilal Shah', 'descriptors/database/jbilling-upgrade-4.1.xml', NOW(), 8, '7:68f190ea4b1614612a893e12fe5e57d9', 'createTable', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.1.xml::20150307-missing-not-null-constraint::Vikas Bodani
ALTER TABLE public.reset_password_code ALTER COLUMN  base_user_id SET NOT NULL;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('20150307-missing-not-null-constraint', 'Vikas Bodani', 'descriptors/database/jbilling-upgrade-4.1.xml', NOW(), 9, '7:c9267f9080df0cefd6cf3eec8330da71', 'addNotNullConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.1.xml::#8922-20150309-customer-price-active-expiry-date::Vikas Bodani
-- Price subscription and expiration dates for customer price. Price expiration dates for Account Type price
ALTER TABLE public.account_type_price ADD price_expiry_date date;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#8922-20150309-customer-price-active-expiry-date', 'Vikas Bodani', 'descriptors/database/jbilling-upgrade-4.1.xml', NOW(), 10, '7:dbaf95d6034043e784fb1a86a90e9583', 'addColumn', 'Price subscription and expiration dates for customer price. Price expiration dates for Account Type price', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.1.xml::#10256:Asset Reservation scheduler plugin::Aman Goel
UPDATE public.pluggable_task_type SET min_parameters = 0.0 WHERE class_name='com.sapienter.jbilling.server.item.tasks.CheckAssetReservationCronScheduledTask';

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#10256:Asset Reservation scheduler plugin', 'Aman Goel', 'descriptors/database/jbilling-upgrade-4.1.xml', NOW(), 11, '7:90aea8639ce31a2f7ac2f3ec125763cb', 'update', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.1.xml::#11369-Feature to identify inactive accounts::Aadil Nazir
-- #11369 Develop ability to identify inactive accounts
-- Added new column in base_user, value is set to date on which a user is marked in-active
-- Add new preference of Number of days after which a User's account will become inactive
-- Constant ID may need to be changed during merging of this feature to later branches to avoid overlapping with other preference IDs
-- foreign_id may need to be changed depending upon preference ID assigned above during merging to later branches
-- foreign_id may need to be changed depending upon preference ID assigned above during merging to later branches
-- Add new plug-in to make users inactive if they are not logged-in for number of days specified in the preference created above
-- Constant ID may need to be changed during merging of this feature to later branches to avoid overlapping with other plug-ins
-- foreign_id may need to be changed depending upon plug-in ID assigned above during merging to later branches
-- foreign_id may need to be changed depending upon plug-in ID assigned above during merging to later branches
ALTER TABLE public.base_user ADD account_disabled_date date;

INSERT INTO public.preference_type (id, def_value) VALUES ((select max(t.id)+1 from preference_type t), '60');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 70.0, 'description', 1.0, 'Expire Inactive Accounts After Days');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 70.0, 'instruction', 1.0, 'Number of days after which a User''s account will become inactive. This will disable the ability to login to jBilling for that user.');

INSERT INTO public.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (coalesce((select max(p.id)+1 from pluggable_task_type p),1), 22.0, 'com.sapienter.jbilling.server.pluggableTask.InactiveUserManagementTask', 0.0);

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, (select max(id) from pluggable_task_type), 'title', 1.0, 'Inactive user account management plugin');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, (select max(id) from pluggable_task_type), 'description', 1.0, 'This is a scheduled plugin that takes in user that has not been logged-in for number of days specified in preference 55 and update there status to Inactive.');

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#11369-Feature to identify inactive accounts', 'Aadil Nazir', 'descriptors/database/jbilling-upgrade-4.1.xml', NOW(), 12, '7:0029c3ea1466b22e1614446811447527', 'addColumn, insert (x6)', '#11369 Develop ability to identify inactive accounts
Added new column in base_user, value is set to date on which a user is marked in-active
Add new preference of Number of days after which a User''s account will become inactive
Constant ID may nee...', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.1.xml::#11369-Report for Feature to identify inactive accounts::Aadil Nazir
INSERT INTO public.report (id, type_id, name, file_name, optlock) VALUES ((select coalesce(max(r.id), 1)+1 from report r), (select id from report_type rt where rt.name = 'user'), 'user_activity', 'user_activity.jasper', 0.0);

INSERT INTO public.report_parameter (id, report_id, dtype, name) VALUES ((select coalesce(max(rp.id), 1)+1 from report_parameter rp), (select id from report r where r.name = 'user_activity'), 'integer', 'activity_days');

INSERT INTO public.report_parameter (id, report_id, dtype, name) VALUES ((select coalesce(max(rp.id), 1)+1 from report_parameter rp), (select id from report r where r.name = 'user_activity'), 'string', 'active_status');

INSERT INTO public.report_parameter (id, report_id, dtype, name) VALUES ((select coalesce(max(rp.id), 1)+1 from report_parameter rp), (select id from report r where r.name = 'user_activity'), 'string', 'order_by');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES ((select id from jbilling_table jt where jt.name = 'report'), (select id from report r where r.name = 'user_activity'), 'description', 1.0, 'Statement of User Activity within specified number of days');

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#11369-Report for Feature to identify inactive accounts', 'Aadil Nazir', 'descriptors/database/jbilling-upgrade-4.1.xml', NOW(), 13, '7:2d1c3191bac0f451e55b33913117f2c1', 'insert (x5)', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.1.xml::#10815-filter-key-data::Aman Goel
ALTER TABLE public.filter ADD field_key_data VARCHAR(255);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#10815-filter-key-data', 'Aman Goel', 'descriptors/database/jbilling-upgrade-4.1.xml', NOW(), 14, '7:356b48eb7828a2853e02eafcf06bb88c', 'addColumn', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.1.xml::#12636-granting-user-credentials::Javier Rivero
INSERT INTO public.preference_type (id, def_value) VALUES ('71', '24');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, '71', 'description', 1.0, 'Forgot Password Expiration (hours)');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 71.0, 'instruction', 1.0, 'Hours until the link for password change expires.');

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#12636-granting-user-credentials', 'Javier Rivero', 'descriptors/database/jbilling-upgrade-4.1.xml', NOW(), 15, '7:ed963aa825b6157a3ec6bc956fd4b38c', 'insert (x3)', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.1.xml::#12702:Default credentials changed::Nelson Secchi
-- Description for the preference type, this is shown on the list of preferences
INSERT INTO public.preference_type (id, def_value) VALUES ('75', '0');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 75.0, 'description', 1.0, 'Should credentials be created by default');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 75.0, 'instruction', 1.0, '1 to have credentials created by default when the user is created. 0 (default) to require credential creation be requested upon creation.');

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#12702:Default credentials changed', 'Nelson Secchi', 'descriptors/database/jbilling-upgrade-4.1.xml', NOW(), 16, '7:35065b00a050ae10ca0042bd16557ba3', 'insert (x3)', 'Description for the preference type, this is shown on the list of preferences', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.1.xml::#12702:Credentials email message notification::Nelson Secchi
-- We need a new message for when credentials are being created
-- Define the notification message type. For new entities, this id will be used on EntityDefaults
INSERT INTO public.notification_message_type (id, category_id, optlock) VALUES (21, 4.0, 0.0);

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, 21, 'description', 1.0, 'Credentials creation');

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#12702:Credentials email message notification', 'Nelson Secchi', 'descriptors/database/jbilling-upgrade-4.1.xml', NOW(), 17, '7:783b49539fb94b3473a4a1d0da39b7ff', 'insert (x2)', 'We need a new message for when credentials are being created
Define the notification message type. For new entities, this id will be used on EntityDefaults', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.1.xml::#12686_Default_Security_Preferences:validation_rules::Fernando G. Morales
-- Add validation rule to the preference type
-- Define validation rules and add to preferences
-- Set rule for preference: Lock-out user after failed login attempts
-- Set rule for preference: 'Expire user passwords after days'
-- Set rule for preference: 'Expire Inactive Accounts After Days'
ALTER TABLE public.preference_type ADD validation_rule_id INT;

ALTER TABLE public.preference_type ADD CONSTRAINT preference_type_vr_fk_1 FOREIGN KEY (validation_rule_id) REFERENCES public.validation_rule (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.validation_rule (id, rule_type, enabled, optlock) VALUES (coalesce((select max(t.id)+1 from validation_rule t),1), 'RANGE', TRUE, 0.0);

INSERT INTO public.validation_rule_attributes (validation_rule_id, attribute_name, attribute_value) VALUES ((select max(t.id) from validation_rule t), 'minRange', '0');

INSERT INTO public.validation_rule_attributes (validation_rule_id, attribute_name, attribute_value) VALUES ((select max(t.id) from validation_rule t), 'maxRange', '7');

INSERT INTO public.international_description (foreign_id, table_id, psudo_column, language_id, content) VALUES ((select max(t.id) from validation_rule t), (select id from jbilling_table where name='validation_rule'), 'errorMessage', 1.0, 'Failed login attempts can not be more than 6');

UPDATE public.preference_type SET validation_rule_id = (select max(vr.id) from validation_rule vr) WHERE id = 39;

INSERT INTO public.validation_rule (id, rule_type, enabled, optlock) VALUES (coalesce((select max(t.id)+1 from validation_rule t),1), 'RANGE', TRUE, 0.0);

INSERT INTO public.validation_rule_attributes (validation_rule_id, attribute_name, attribute_value) VALUES ((select max(t.id) from validation_rule t), 'minRange', '0');

INSERT INTO public.validation_rule_attributes (validation_rule_id, attribute_name, attribute_value) VALUES ((select max(t.id) from validation_rule t), 'maxRange', '91');

INSERT INTO public.international_description (foreign_id, table_id, psudo_column, language_id, content) VALUES ((select max(t.id) from validation_rule t), (select id from jbilling_table where name='validation_rule'), 'errorMessage', 1.0, 'Passwords must expire before 90 days');

UPDATE public.preference_type SET validation_rule_id = (select max(vr.id) from validation_rule vr) WHERE id = 40;

INSERT INTO public.validation_rule (id, rule_type, enabled, optlock) VALUES (coalesce((select max(t.id)+1 from validation_rule t),1), 'RANGE', TRUE, 0.0);

INSERT INTO public.validation_rule_attributes (validation_rule_id, attribute_name, attribute_value) VALUES ((select max(t.id) from validation_rule t), 'minRange', '0');

INSERT INTO public.validation_rule_attributes (validation_rule_id, attribute_name, attribute_value) VALUES ((select max(t.id) from validation_rule t), 'maxRange', '91');

INSERT INTO public.international_description (foreign_id, table_id, psudo_column, language_id, content) VALUES ((select max(t.id) from validation_rule t), (select id from jbilling_table where name='validation_rule'), 'errorMessage', 1.0, 'Inactive account checks must be done quicker than 90 days');

UPDATE public.preference_type SET validation_rule_id = (select max(vr.id) from validation_rule vr) WHERE id = 69;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#12686_Default_Security_Preferences:validation_rules', 'Fernando G. Morales', 'descriptors/database/jbilling-upgrade-4.1.xml', NOW(), 18, '7:53dd8bd71fcea8b8569fce4179903be3', 'addColumn, addForeignKeyConstraint, insert (x4), update, insert (x4), update, insert (x4), update', 'Add validation rule to the preference type
Define validation rules and add to preferences
Set rule for preference: Lock-out user after failed login attempts
Set rule for preference: ''Expire user passwords after days''
Set rule for preference: ''Expi...', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.1.xml::#12686_Default_Security_Preferences:remove_preferences::Fernando G. Morales
-- Removed the HIDE CC CARD NUMBER preference
DELETE FROM public.preference  WHERE type_id=37;

DELETE FROM public.international_description  WHERE table_id = (select id from jbilling_table where name ='preference_type') and foreign_id=37;

DELETE FROM public.preference_type  WHERE id=37;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#12686_Default_Security_Preferences:remove_preferences', 'Fernando G. Morales', 'descriptors/database/jbilling-upgrade-4.1.xml', NOW(), 19, '7:1883338c62a37c25051f10319d25f896', 'delete (x3)', 'Removed the HIDE CC CARD NUMBER preference', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.1.xml::#12686_Default_Security_Preferences:validation_rules for Telco-4.1::Nelson Secchi
-- Reverts the validation set for validation rule 69
-- Set rule for preference: 'Expire Inactive Accounts After Days'
-- This assumes that the last changeset that added validations was #12686_Default_Security_Preferences:validation_rules
UPDATE public.preference_type SET validation_rule_id = NULL WHERE id = 69;

UPDATE public.preference_type SET validation_rule_id = (select max(vr.id) from validation_rule vr) WHERE id = 70;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#12686_Default_Security_Preferences:validation_rules for Telco-4.1', 'Nelson Secchi', 'descriptors/database/jbilling-upgrade-4.1.xml', NOW(), 20, '7:e5405d4382d92d96ba131c215d32b5b4', 'update (x2)', 'Reverts the validation set for validation rule 69
Set rule for preference: ''Expire Inactive Accounts After Days''
This assumes that the last changeset that added validations was #12686_Default_Security_Preferences:validation_rules', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.1.xml::#12602-audit-log-user-related-information::Bilal Shah
INSERT INTO public.event_log_message (id) VALUES (38.0);

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 38.0, 'description', 1.0, 'User logged in successfully');

INSERT INTO public.event_log_message (id) VALUES (39.0);

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 39.0, 'description', 1.0, 'User logged out successfully');

INSERT INTO public.event_log_message (id) VALUES (40.0);

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 40.0, 'description', 1.0, 'User failed to log in due to incorrect username/password');

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#12602-audit-log-user-related-information', 'Bilal Shah', 'descriptors/database/jbilling-upgrade-4.1.xml', NOW(), 21, '7:ece4e4787c89579d6f4d3559b3e10a19', 'insert (x6)', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.1.xml::#08072015::Ravi Singhal
UPDATE public.notification_message_line SET content = 'Hello  $first_name $last_name,\n\nYou (or someone pretending to be you) requested a password reset of your account.\n\nYou may reset your password from the following link:\n\n$newPasswordLink\n\nAdmin:\t$organization_name' WHERE content = 'Hello  $first_name $last_name,\r\n\r\nYou (or someone pretending to be you) requested a password reset of your account.\r\n\r\nIf you access the following link your password will be changed to: $newPassword\r\n\r\n$newPasswordLink'
    			or
    			content = '<p>Hello $first_name $last_name,</p><p>You (or someone pretending to be you) requested a password reset of your account.</p><p>If you access the following link your password will be changed to: <strong>$newPassword</strong></p><p><a href="$newPasswordLink">$newPasswordLink</a></p>';

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#08072015', 'Ravi Singhal', 'descriptors/database/jbilling-upgrade-4.1.xml', NOW(), 22, '7:b29f6452dfcfb3d951ab0707167fcafd', 'update', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.1.xml::#14013 Adding Asset reservation minute and it's validation::Vivek Yadav
-- Adding default reservation minute for asset reservation
-- Add validation rule for Asset reservation duration
INSERT INTO public.validation_rule (id, rule_type, enabled, optlock) VALUES (coalesce((select max(t.id)+1 from validation_rule t),1), 'RANGE', TRUE, 0.0);

INSERT INTO public.validation_rule_attributes (validation_rule_id, attribute_name, attribute_value) VALUES ((select max(t.id) from validation_rule t), 'minRange', '0');

INSERT INTO public.validation_rule_attributes (validation_rule_id, attribute_name, attribute_value) VALUES ((select max(t.id) from validation_rule t), 'maxRange', '600000');

INSERT INTO public.international_description (foreign_id, table_id, psudo_column, language_id, content) VALUES ((select max(t.id) from validation_rule t), (select id from jbilling_table where name='validation_rule'), 'errorMessage', 1.0, 'Reservation duration should be between 0 and 600000');

INSERT INTO public.preference_type (id, def_value, validation_rule_id) VALUES ((select max(p.id) + 1 from preference_type p), '10', (select max(vr.id) from validation_rule vr));

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, (select max(id) from preference_type), 'description', 1.0, 'Default Asset Reservation Duration');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, (select max(id) from preference_type), 'instruction', 1.0, 'Add Default Asset reservation minute here. It will work if product is asset enabled. (Must be greater than zero)');

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#14013 Adding Asset reservation minute and it''s validation', 'Vivek Yadav', 'descriptors/database/jbilling-upgrade-4.1.xml', NOW(), 23, '7:00c17424aaffa96a0d0b97ef9d232db2', 'insert (x7)', 'Adding default reservation minute for asset reservation
Add validation rule for Asset reservation duration', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.1.xml::Removing PricingRuleTask::Manisha Gupta
DELETE FROM public.pluggable_task_parameter  WHERE task_id=(select id from pluggable_task where type_id =61);

DELETE FROM public.pluggable_task  WHERE type_id =61;

DELETE FROM public.pluggable_task  WHERE type_id =53;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('Removing PricingRuleTask', 'Manisha Gupta', 'descriptors/database/jbilling-upgrade-4.1.xml', NOW(), 24, '7:07c5e70e759ab45d5e119af6ed5f2212', 'delete (x3)', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.1.xml::Removing Preferences for mediation, provisioning and ITG::Manisha Gupta
DELETE FROM public.preference_type  WHERE id in (47,48,69);

DELETE FROM public.preference  WHERE type_id in (47,48,69);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('Removing Preferences for mediation, provisioning and ITG', 'Manisha Gupta', 'descriptors/database/jbilling-upgrade-4.1.xml', NOW(), 25, '7:8341a3e69161ab22b689419a01f98f22', 'delete (x2)', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.1.xml::20151102-host-preferences::Vikas Bodani
CREATE TABLE public.jb_host_master (jb_version CHAR(10), jb_allow_signup BOOLEAN DEFAULT TRUE, jb_git_url VARCHAR(256), jb_last_git_commit CHAR(10) DEFAULT null);

INSERT INTO public.jb_host_master (jb_version, jb_git_url) VALUES ('CE-4.1.1', 'git@github.com:WebDataConsulting/billing.git');

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('20151102-host-preferences', 'Vikas Bodani', 'descriptors/database/jbilling-upgrade-4.1.xml', NOW(), 26, '7:51e98da0c796456d0fbc687a7288aedf', 'createTable, insert', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.1.xml::jbilling-mediation-2.x-1::Vikas Bodani
-- This table may exists because it may have gotten created from previous builds
CREATE TABLE public.mediation_cfg (id INT NOT NULL, entity_id INT NOT NULL, create_datetime TIMESTAMP WITHOUT TIME ZONE NOT NULL, name VARCHAR(50) NOT NULL, order_value INT NOT NULL, pluggable_task_id INT NOT NULL, optlock INT NOT NULL, CONSTRAINT mediation_cfg_pkey PRIMARY KEY (id));

CREATE TABLE public.mediation_errors (accountcode VARCHAR(50) NOT NULL, src VARCHAR(50), dst VARCHAR(50), dcontext VARCHAR(50), clid VARCHAR(50), channel VARCHAR(50), dstchannel VARCHAR(50), lastapp VARCHAR(50), lastdata VARCHAR(50), start_time TIMESTAMP WITHOUT TIME ZONE, answer TIMESTAMP WITHOUT TIME ZONE, end_time TIMESTAMP WITHOUT TIME ZONE, duration INT, billsec INT, disposition VARCHAR(50), amaflags VARCHAR(50), userfield VARCHAR(50), error_message VARCHAR(200), should_retry BOOLEAN, CONSTRAINT mediation_errors_pkey PRIMARY KEY (accountcode));

CREATE TABLE public.mediation_order_map (mediation_process_id INT NOT NULL, order_id INT NOT NULL);

CREATE TABLE public.mediation_process (id INT NOT NULL, configuration_id INT NOT NULL, start_datetime TIMESTAMP WITHOUT TIME ZONE NOT NULL, end_datetime TIMESTAMP WITHOUT TIME ZONE, orders_affected INT NOT NULL, optlock INT NOT NULL, CONSTRAINT mediation_process_pkey PRIMARY KEY (id));

CREATE TABLE public.mediation_record (id_key VARCHAR(100) NOT NULL, start_datetime TIMESTAMP WITHOUT TIME ZONE NOT NULL, mediation_process_id INT, optlock INT NOT NULL, status_id INT NOT NULL, id INT NOT NULL, CONSTRAINT mediation_record_pkey PRIMARY KEY (id));

CREATE TABLE public.mediation_record_line (id INT NOT NULL, order_line_id INT NOT NULL, event_date TIMESTAMP WITHOUT TIME ZONE NOT NULL, amount numeric(22, 10) NOT NULL, quantity numeric(22, 10) NOT NULL, description VARCHAR(200), optlock INT NOT NULL, mediation_record_id INT NOT NULL, CONSTRAINT mediation_record_line_pkey PRIMARY KEY (id));

ALTER TABLE public.mediation_cfg ADD CONSTRAINT mediation_cfg_fk_1 FOREIGN KEY (pluggable_task_id) REFERENCES public.pluggable_task (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE public.mediation_order_map ADD CONSTRAINT mediation_order_map_fk_1 FOREIGN KEY (mediation_process_id) REFERENCES public.mediation_process (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE public.mediation_order_map ADD CONSTRAINT mediation_order_map_fk_2 FOREIGN KEY (order_id) REFERENCES public.purchase_order (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE public.mediation_process ADD CONSTRAINT mediation_process_fk_1 FOREIGN KEY (configuration_id) REFERENCES public.mediation_cfg (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE public.mediation_record ADD CONSTRAINT mediation_record_fk_1 FOREIGN KEY (mediation_process_id) REFERENCES public.mediation_process (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE public.mediation_record ADD CONSTRAINT mediation_record_fk_2 FOREIGN KEY (status_id) REFERENCES public.generic_status (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE public.mediation_record_line ADD CONSTRAINT mediation_record_line_fk_1 FOREIGN KEY (mediation_record_id) REFERENCES public.mediation_record (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE public.mediation_record_line ADD CONSTRAINT mediation_record_line_fk_2 FOREIGN KEY (order_line_id) REFERENCES public.order_line (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.jbilling_seqs (name, next_id) VALUES ('mediation_cfg', 1.0);

INSERT INTO public.jbilling_seqs (name, next_id) VALUES ('mediation_process', 1.0);

INSERT INTO public.jbilling_seqs (name, next_id) VALUES ('mediation_record_line', 1.0);

INSERT INTO public.jbilling_seqs (name, next_id) VALUES ('mediation_record', 0.0);

INSERT INTO public.generic_status_type (id) VALUES ('mediation_record_status');

INSERT INTO public.pluggable_task_type_category (id, interface_name) VALUES (15.0, 'com.sapienter.jbilling.server.mediation.task.IMediationReader');

INSERT INTO public.pluggable_task_type_category (id, interface_name) VALUES (16.0, 'com.sapienter.jbilling.server.mediation.task.IMediationProcess');

INSERT INTO public.pluggable_task_type_category (id, interface_name) VALUES (21.0, 'com.sapienter.jbilling.server.mediation.task.IMediationErrorHandler');

INSERT INTO public.jbilling_table (id, name) VALUES (82.0, 'mediation_cfg');

INSERT INTO public.jbilling_table (id, name) VALUES (83.0, 'mediation_process');

INSERT INTO public.jbilling_table (id, name) VALUES (86.0, 'mediation_record_line');

INSERT INTO public.jbilling_table (id, name) VALUES (91.0, 'mediation_record_status');

INSERT INTO public.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (32.0, 15.0, 'com.sapienter.jbilling.server.mediation.task.SeparatorFileReader', 2.0);

INSERT INTO public.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (33.0, 16.0, 'com.sapienter.jbilling.server.mediation.task.TestMediationTask', 0.0);

INSERT INTO public.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (34.0, 15.0, 'com.sapienter.jbilling.server.mediation.task.FixedFileReader', 2.0);

INSERT INTO public.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (44.0, 15.0, 'com.sapienter.jbilling.server.mediation.task.JDBCReader', 0.0);

INSERT INTO public.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (45.0, 15.0, 'com.sapienter.jbilling.server.mediation.task.MySQLReader', 0.0);

INSERT INTO public.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (71.0, 21.0, 'com.sapienter.jbilling.server.mediation.task.SaveToFileMediationErrorHandler', 0.0);

INSERT INTO public.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (73.0, 21.0, 'com.sapienter.jbilling.server.mediation.task.SaveToJDBCMediationErrorHandler', 1.0);

INSERT INTO public.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (81.0, 22.0, 'com.sapienter.jbilling.server.mediation.task.MediationProcessTask', 0.0);

INSERT INTO public.generic_status (id, dtype, status_value, can_login) VALUES (29.0, 'mediation_record_status', 1.0, NULL);

INSERT INTO public.generic_status (id, dtype, status_value, can_login) VALUES (30.0, 'mediation_record_status', 2.0, NULL);

INSERT INTO public.generic_status (id, dtype, status_value, can_login) VALUES (31.0, 'mediation_record_status', 3.0, NULL);

INSERT INTO public.generic_status (id, dtype, status_value, can_login) VALUES (32.0, 'mediation_record_status', 4.0, NULL);

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23.0, 15.0, 'description', 1.0, 'Mediation Reader');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23.0, 16.0, 'description', 1.0, 'Mediation Processor');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23.0, 21.0, 'description', 1.0, 'Mediation Error Handler');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 32.0, 'description', 1.0, 'This is a reader for the mediation process. It reads records from a text file whose fields are separated by a character (or string).');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 33.0, 'title', 1.0, 'Rules mediation processor');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 33.0, 'description', 1.0, 'This is a rules-based plug-in (see chapter 7). It takes an event record from the mediation process and executes external rules to translate the record into billing meaningful data. This is at the core of the mediation component, see the ?Telecom Guide? document for more information.');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 34.0, 'description', 1.0, 'This is a reader for the mediation process. It reads records from a text file whose fields have fixed positions,and the record has a fixed length.');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 44.0, 'title', 1.0, 'JDBC Mediation Reader.');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 44.0, 'description', 1.0, 'This is a reader for the mediation process. It reads records from a JDBC database source.');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 45.0, 'title', 1.0, 'MySQL Mediation Reader.');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 45.0, 'description', 1.0, 'This is a reader for the mediation process. It is an extension of the JDBC reader, allowing easy configuration of a MySQL database source.');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 79.0, 'title', 1.0, 'Mediation Process Task');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 79.0, 'description', 1.0, 'A scheduled task to execute the Mediation Process.');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 47.0, 'description', 1.0, 'Last read mediation record id.');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 41.0, 'instruction', 1.0, 'Set to ''1'' to allow the usage of the ''main subscription'' flag for orders This flag is read only by the mediation process when determining where to place charges coming from external events.');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 47.0, 'instruction', 1.0, 'ID of the last record read by the mediation process. This is used to determine what records are ''new'' and need to be read.');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 95.0, 'description', 1.0, 'Show mediation menu');

INSERT INTO public.tab (id, message_code, controller_name, access_url, required_role, version, default_order) VALUES (7.0, 'menu.link.mediation', 'mediation', '/mediation/list', '', '1', 7.0);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('jbilling-mediation-2.x-1', 'Vikas Bodani', 'descriptors/database/jbilling-upgrade-4.1.xml', NOW(), 27, '7:7c93a475100ee75099b4f42881c0adc1', 'createTable (x6), addForeignKeyConstraint (x8), insert (x42)', 'This table may exists because it may have gotten created from previous builds', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.1.xml::jbilling-mediation-2.x-2::Vikas Bodani
-- This table may exists because it may have gotten created from previous builds
CREATE TABLE public.cdrentries (id INT NOT NULL, accountcode VARCHAR(20), src VARCHAR(20), dst VARCHAR(20), dcontext VARCHAR(20), clid VARCHAR(20), channel VARCHAR(20), dstchannel VARCHAR(20), lastapp VARCHAR(20), lastdatat VARCHAR(20), start_time TIMESTAMP WITHOUT TIME ZONE, answer TIMESTAMP WITHOUT TIME ZONE, end_time TIMESTAMP WITHOUT TIME ZONE, duration INT, billsec INT, disposition VARCHAR(20), amaflags VARCHAR(20), userfield VARCHAR(100), ts TIMESTAMP WITHOUT TIME ZONE, CONSTRAINT cdrentries_pkey PRIMARY KEY (id));

INSERT INTO public.currency (id, symbol, code, country_code, optlock) VALUES ((select max(c.id)+1 from currency c), '₹', 'INR', 'IN', 0.0);

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4.0, (select max(c.id) from currency c), 'description', 1.0, 'Indian Rupee');

INSERT INTO public.currency_exchange (id, entity_id, currency_id, rate, create_datetime, valid_since, optlock) VALUES ((select max(ce.id)+1 from currency_exchange ce), 0.0, (select max(c.id) from currency c), 66.7431996993, '2015-12-10 00:00:00.000', '1970-01-01', 1.0);

INSERT INTO public.currency (id, symbol, code, country_code, optlock) VALUES ((select max(c.id)+1 from currency c), '¥', 'CNY', 'CN', 0.0);

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4.0, (select max(c.id) from currency c), 'description', 1.0, 'Chinese Yuan');

INSERT INTO public.currency_exchange (id, entity_id, currency_id, rate, create_datetime, valid_since, optlock) VALUES ((select max(ce.id)+1 from currency_exchange ce), 0.0, (select max(c.id) from currency c), 10.3706269649, '2015-12-10 00:00:00.000', '1970-01-01', 1.0);

ALTER TABLE public.item_price ADD start_date date NOT NULL DEFAULT '1970-01-01';

ALTER TABLE public.batch_job_execution_params ALTER COLUMN date_val TYPE TIMESTAMP WITHOUT TIME ZONE;

ALTER TABLE public.meta_field_name ADD is_unique BOOLEAN NOT NULL DEFAULT FALSE;

UPDATE public.pluggable_task_type_category SET interface_name = 'com.sapienter.jbilling.server.pricing.tasks.IPricing' WHERE interface_name = 'com.sapienter.jbilling.server.item.tasks.IPricing';

INSERT INTO public.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES ((select max(t.id)+1 from pluggable_task_type t), 14.0, 'in.webdataconsulting.jbilling.server.pricing.tasks.BasicUsageBasedPricingTask', 0.0);

UPDATE public.jbilling_seqs SET next_id = (select max(t.id)+1 from pluggable_task_type t) WHERE name='pluggable_task_type';

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, (select max(t.id) from pluggable_task_type t), 'title', 1.0, 'Basic Pricing Task');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, (select max(t.id) from pluggable_task_type t), 'description', 1.0, 'This is handles the pricing calculation (default implementation) based on usage of the item.');

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('jbilling-mediation-2.x-2', 'Vikas Bodani', 'descriptors/database/jbilling-upgrade-4.1.xml', NOW(), 28, '7:8a4aad6c76f297046e47ee846ea6a7d1', 'createTable, insert (x6), addColumn, modifyDataType, addColumn, update, insert, update, insert (x2)', 'This table may exists because it may have gotten created from previous builds', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.1.xml::#25012016- Add Plan Order line Type::Ravi Singhal
INSERT INTO public.order_line_type (id, editable) VALUES (6.0, 1.0);

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (18.0, 6.0, 'description', 1.0, 'Plan');

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#25012016- Add Plan Order line Type', 'Ravi Singhal', 'descriptors/database/jbilling-upgrade-4.1.xml', NOW(), 29, '7:4b13b06f970d0eee87d99009b185f2f8', 'insert (x2)', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.1.xml::1 Added missing jbilling-mediation-2.x-1::Manisha Gupta
CREATE INDEX mediation_record_i ON public.mediation_record(id_key, status_id);

INSERT INTO public.jbilling_table (id, name) VALUES ((select max(jt.id)+1 from jbilling_table jt), 'mediation_record');

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1 Added missing jbilling-mediation-2.x-1', 'Manisha Gupta', 'descriptors/database/jbilling-upgrade-4.1.xml', NOW(), 30, '7:e4455b12767f5b86c666340c16a8308b', 'createIndex, insert', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.1.xml::20160118-add-percentage-datespecificprice::Vikas Bodani
ALTER TABLE public.item ADD percentage BOOLEAN DEFAULT FALSE;

ALTER TABLE public.item_dependency ADD period INT;

INSERT INTO public.language (id, code, description) VALUES ((select max(l.id)+1 from language l), 'hi', 'Hindi');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 1, 'description', (select max(l.id) from language l), 'यूनाइटेड स्टेट का डॉलर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 2, 'description', (select max(l.id) from language l), 'कैनेडियन डॉलर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 3, 'description', (select max(l.id) from language l), 'यूरो');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 4, 'description', (select max(l.id) from language l), 'येन');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 5, 'description', (select max(l.id) from language l), 'पौंड स्टर्लिंग');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 6, 'description', (select max(l.id) from language l), 'वोन');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 7, 'description', (select max(l.id) from language l), 'स्विस फ्रैंक');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 8, 'description', (select max(l.id) from language l), 'स्वीडिश क्रोना');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 9, 'description', (select max(l.id) from language l), 'सिंगापुर का डॉलर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 10, 'description', (select max(l.id) from language l), 'मलेशियाई रिंग्गित');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 11, 'description', (select max(l.id) from language l), 'ऑस्ट्रेलियाई डॉलर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 12, 'description', (select max(l.id) from language l), 'भारतीय रुपया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 13, 'description', (select max(l.id) from language l), 'चीनी युवान');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (6, 1, 'description', (select max(l.id) from language l), 'माह');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (6, 2, 'description', (select max(l.id) from language l), 'सप्ताह');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (6, 3, 'description', (select max(l.id) from language l), 'दिन');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (6, 4, 'description', (select max(l.id) from language l), 'साल');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (6, 5, 'description', (select max(l.id) from language l), 'अर्ध मासिक');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (7, 1, 'description', (select max(l.id) from language l), 'ईमेल');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (7, 2, 'description', (select max(l.id) from language l), 'कागज़');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (7, 3, 'description', (select max(l.id) from language l), 'ईमेल + पेपर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9, 1, 'description', (select max(l.id) from language l), 'सक्रिय');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9, 2, 'description', (select max(l.id) from language l), 'बूढ़े दिवस 1');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9, 3, 'description', (select max(l.id) from language l), 'बूढ़े 4 दिन');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9, 4, 'description', (select max(l.id) from language l), 'बूढ़े दिन 5');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9, 5, 'description', (select max(l.id) from language l), 'बूढ़े दिवस 15');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9, 6, 'description', (select max(l.id) from language l), 'बूढ़े 16 दिन');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9, 7, 'description', (select max(l.id) from language l), 'बूढ़े 27 दिन');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9, 8, 'description', (select max(l.id) from language l), 'बूढ़े दिवस 30');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9, 9, 'description', (select max(l.id) from language l), 'बूढ़े डे 31');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9, 10, 'description', (select max(l.id) from language l), 'बूढ़े डे 32');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9, 11, 'description', (select max(l.id) from language l), 'बूढ़े 40 दिन');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9, 12, 'description', (select max(l.id) from language l), 'बूढ़े डे 45');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9, 13, 'description', (select max(l.id) from language l), 'बूढ़े डे 50');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9, 14, 'description', (select max(l.id) from language l), 'बूढ़े डे 55');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9, 15, 'description', (select max(l.id) from language l), 'बूढ़े डे 65');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9, 16, 'description', (select max(l.id) from language l), 'बूढ़े डे 90');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9, 17, 'description', (select max(l.id) from language l), 'बूढ़े डे 180');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 1, 'description', (select max(l.id) from language l), 'नींबू पानी - 1 दिन मासिक पास प्रति');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 2, 'description', (select max(l.id) from language l), 'नींबू पानी - आप सभी मासिक पी सकते हैं');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 3, 'description', (select max(l.id) from language l), 'कॉफी - प्रति दिन एक - मासिक');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 4, 'description', (select max(l.id) from language l), 'ज़हर आइवी रस (ठंड)');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 14, 'description', (select max(l.id) from language l), '10% एल्फ छूट।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 24, 'description', (select max(l.id) from language l), 'शुल्क रद्द');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 240, 'description', (select max(l.id) from language l), 'मुद्रा परीक्षण आइटम');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 250, 'description', (select max(l.id) from language l), 'नींबू पानी योजना');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 251, 'description', (select max(l.id) from language l), 'नींबू पानी योजना - सेटअप शुल्क');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 260, 'description', (select max(l.id) from language l), 'WS से एक आइटम');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 270, 'description', (select max(l.id) from language l), 'देर से भुगतान दंड शुल्क');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 1250, 'description', (select max(l.id) from language l), 'AM-1');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 2600, 'description', (select max(l.id) from language l), 'नींबू पानी - जेनेरिक');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 2601, 'description', (select max(l.id) from language l), 'नींबू पानी - योजना में शामिल');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 2602, 'description', (select max(l.id) from language l), 'नींबू पानी');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 2700, 'description', (select max(l.id) from language l), 'लंबी दूरी की योजना - निर्धारित दर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 2701, 'description', (select max(l.id) from language l), 'लंबी दूरी की योजना B - निर्धारित दर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 2702, 'description', (select max(l.id) from language l), 'लंबी दूरी की योजना - 1000 मिनट शामिल');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 2800, 'description', (select max(l.id) from language l), 'लंबी दूरी की कॉल');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 2801, 'description', (select max(l.id) from language l), 'लंबी दूरी की कॉल - शामिल');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 2900, 'description', (select max(l.id) from language l), 'लंबी दूरी की कॉल - जेनेरिक');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 3000, 'description', (select max(l.id) from language l), 'पागल ब्रायन की छूट योजना');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 3100, 'description', (select max(l.id) from language l), 'प्रतिशत लाइन परीक्षण योजना');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 3101, 'description', (select max(l.id) from language l), 'कूल योजना');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 320100, 'description', (select max(l.id) from language l), 'कॉल 1');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (17, 1, 'description', (select max(l.id) from language l), 'एक बार');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (17, 2, 'description', (select max(l.id) from language l), 'मासिक');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (17, 3, 'description', (select max(l.id) from language l), 'मासिक');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (17, 4, 'description', (select max(l.id) from language l), 'हर 3 महीने');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (17, 5, 'description', (select max(l.id) from language l), 'सभी आदेश');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (17, 6, 'description', (select max(l.id) from language l), 'मासिक');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (18, 1, 'description', (select max(l.id) from language l), 'आइटम');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (18, 2, 'description', (select max(l.id) from language l), 'टैक्स');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (18, 3, 'description', (select max(l.id) from language l), 'दंड');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (18, 4, 'description', (select max(l.id) from language l), 'छूट');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (18, 5, 'description', (select max(l.id) from language l), 'अंशदान');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (18, 6, 'description', (select max(l.id) from language l), 'योजना');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (19, 1, 'description', (select max(l.id) from language l), 'पूर्व भुगतान');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (19, 2, 'description', (select max(l.id) from language l), 'पद का भुगतान');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (20, 1, 'description', (select max(l.id) from language l), 'सक्रिय');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (20, 2, 'description', (select max(l.id) from language l), 'समाप्त');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (20, 3, 'description', (select max(l.id) from language l), 'निलंबित');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (20, 4, 'description', (select max(l.id) from language l), 'निलंबित (ऑटो)');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (20, 400, 'description', (select max(l.id) from language l), 'कसौटी');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 1, 'description', (select max(l.id) from language l), 'आइटम प्रबंधन और व्यवस्था की लाइन की कुल गणना');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 2, 'description', (select max(l.id) from language l), 'बिलिंग प्रक्रिया: आदेश फिल्टर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 3, 'description', (select max(l.id) from language l), 'बिलिंग प्रक्रिया: चालान फिल्टर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 4, 'description', (select max(l.id) from language l), 'चालान प्रस्तुति');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 5, 'description', (select max(l.id) from language l), 'बिलिंग प्रक्रिया: आदेश की अवधि गणना');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 6, 'description', (select max(l.id) from language l), 'भुगतान गेटवे एकीकरण');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 7, 'description', (select max(l.id) from language l), 'सूचनाएं');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 8, 'description', (select max(l.id) from language l), 'भुगतान साधन चयन');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 9, 'description', (select max(l.id) from language l), 'अतिदेय चालान के लिए दंड');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 10, 'description', (select max(l.id) from language l), 'अलार्म एक भुगतान के प्रवेश द्वार के नीचे है जब');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 11, 'description', (select max(l.id) from language l), 'सदस्यता स्थिति मैनेजर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 12, 'description', (select max(l.id) from language l), 'अतुल्यकालिक भुगतान प्रसंस्करण के लिए पैरामीटर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 13, 'description', (select max(l.id) from language l), 'आदेश के लिए एक उत्पाद जोड़ें');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 14, 'description', (select max(l.id) from language l), 'उत्पाद के मूल्य निर्धारण');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 15, 'description', (select max(l.id) from language l), 'मध्यस्थता रीडर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 16, 'description', (select max(l.id) from language l), 'मध्यस्थता प्रोसेसर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 17, 'description', (select max(l.id) from language l), 'जेनेरिक आंतरिक घटनाओं श्रोता');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 19, 'description', (select max(l.id) from language l), 'प्री-पेड संतुलन / क्रेडिट सीमा के खिलाफ खरीद सत्यापन');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 20, 'description', (select max(l.id) from language l), 'बिलिंग प्रक्रिया: ग्राहक चयन');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 21, 'description', (select max(l.id) from language l), 'मध्यस्थता त्रुटि हैंडलर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 22, 'description', (select max(l.id) from language l), 'अनुसूचित प्लग-इन');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 23, 'description', (select max(l.id) from language l), 'नियम जेनरेटर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 24, 'description', (select max(l.id) from language l), 'अतिदेय चालान के साथ ग्राहकों के लिए बूढ़े');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 25, 'description', (select max(l.id) from language l), 'एजेंट कमीशन गणना प्रक्रिया।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 26, 'description', (select max(l.id) from language l), '"दूरस्थ स्थानों के साथ फ़ाइलों के आदान प्रदान, अपलोड और डाउनलोड"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 1, 'description', (select max(l.id) from language l), '"आइटम की कीमतों पर विचार, मात्रा के आदेश कुल और प्रत्येक पंक्ति के लिए कुल गणना करता है और कीमतों प्रतिशत कर रहे हैं या नहीं।"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 1, 'title', (select max(l.id) from language l), 'डिफ़ॉल्ट आदेश योग');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 2, 'description', (select max(l.id) from language l), 'मूल्य वर्धित कर का प्रतिनिधित्व करने के लिए एक प्रतिशत शुल्क के साथ आदेश के लिए एक अतिरिक्त लाइन जोड़ता है।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 2, 'title', (select max(l.id) from language l), 'वैट');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 3, 'description', (select max(l.id) from language l), 'चालान की नियत तारीख तय करता है कि एक बहुत ही सरल कार्यान्वयन। नियत तिथि सिर्फ चालान तिथि करने के लिए समय की अवधि को जोड़कर गणना की है।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 3, 'title', (select max(l.id) from language l), 'बिल की देय तिथि');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 4, 'description', (select max(l.id) from language l), '"इस काम के लिए प्रत्येक आदेश के लिए शामिल की अवधि पर विचार, नए चालान करने के लिए आदेश और चालान पर सभी लाइनों को कॉपी जाएगा, लेकिन समय में से नहीं अंशों। यह करों हैं कि लाइनों की नकल नहीं करेंगे। प्रत्येक पंक्ति की मात्रा और कुल अवधि की राशि से गुणा किया जाएगा। "');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 4, 'title', (select max(l.id) from language l), 'डिफ़ॉल्ट चालान रचना।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 5, 'description', (select max(l.id) from language l), '"एक आदेश किसी भी बिलिंग प्रक्रिया के लिए एक चालान में शामिल किया जाना चाहिए कि अगर फैसला किया। यह सक्रिय बाद से / तक, आदि बिलिंग प्रक्रिया में समय अवधि, आदेश की अवधि, लेने के द्वारा किया जाता है"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 5, 'title', (select max(l.id) from language l), 'स्टैंडर्ड आदेश फिल्टर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 6, 'description', (select max(l.id) from language l), '"हमेशा अतिदेय चालान एक नया चालान करने के लिए खत्म किया जाएगा जिसका अर्थ है कि सच देता है।"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 6, 'title', (select max(l.id) from language l), 'स्टैंडर्ड चालान फ़िल्टर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 7, 'description', (select max(l.id) from language l), '"प्रारंभ और अंत की अवधि एक चालान में शामिल होने के लिए खरीदते हैं। जब तक यह आदि, / बिलिंग प्रक्रिया में समय अवधि, आदेश की अवधि, के बाद से सक्रिय लेने के द्वारा किया जाता है"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 7, 'title', (select max(l.id) from language l), 'डिफ़ॉल्ट आदेश काल');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 8, 'description', (select max(l.id) from language l), 'Authorize.net भुगतान के प्रवेश द्वार के साथ एकीकरण।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 8, 'title', (select max(l.id) from language l), 'Authorize.net भुगतान प्रोसेसर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 9, 'description', (select max(l.id) from language l), 'एक ईमेल भेज कर एक उपयोगकर्ता सूचित करता है। यह पाठ और HTML ईमेल का समर्थन करता है');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 9, 'title', (select max(l.id) from language l), 'स्टैंडर्ड ईमेल अधिसूचना');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 10, 'description', (select max(l.id) from language l), '"क्रेडिट कार्ड के लिए प्राथमिकता दी एक ग्राहक के लिए उपलब्ध एक भुगतान पद्धति की जानकारी पाता है। दूसरे शब्दों में, यह एक ग्राहक या आदेश में कहा कि एसीएच जानकारी के क्रेडिट कार वापस आ जाएगी।"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 10, 'title', (select max(l.id) from language l), 'डिफ़ॉल्ट भुगतान की जानकारी');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 11, 'description', (select max(l.id) from language l), 'प्लग में उपयोगी केवल परीक्षण के लिए');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 11, 'title', (select max(l.id) from language l), 'साथी भुगतान के लिए प्लग में परीक्षण');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 12, 'description', (select max(l.id) from language l), 'एक चालान की एक PDF संस्करण उत्पन्न होगा।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 12, 'title', (select max(l.id) from language l), 'पीडीएफ चालान अधिसूचना');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 14, 'description', (select max(l.id) from language l), '"एक और नए चालान में एक चालान पर ले जाने के लिए कभी नहीं jBilling बनाता है, जो हमेशा गलत देता है।"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 14, 'title', (select max(l.id) from language l), 'कोई चालान पर ले');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 15, 'description', (select max(l.id) from language l), 'एक दंड आइटम के साथ एक नई व्यवस्था का निर्माण करेगा। आइटम कार्य करने के लिए एक पैरामीटर के रूप में लिया जाता है।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 15, 'title', (select max(l.id) from language l), 'डिफ़ॉल्ट ब्याज कार्य');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 16, 'description', (select max(l.id) from language l), '"BasicOrderFilterTask यह डिफ़ॉल्ट फिल्टर का उपयोग करके किया जाएगा से पहले लागू महीने की एक संख्या आदेश बनाने के लिए तारीखों को संशोधित करने, फैली हुई है।"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 16, 'title', (select max(l.id) from language l), 'पूर्वानुमानित आदेश फिल्टर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 17, 'description', (select max(l.id) from language l), '"BasicOrderPeriodTask डिफ़ॉल्ट कार्य का उपयोग करके किया महीने की एक संख्या आईटीडी से पहले आदेश लागू करने के लिए तारीखों को संशोधित करने, फैली हुई है।"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 17, 'title', (select max(l.id) from language l), 'आदेश अवधि की आशा।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 19, 'description', (select max(l.id) from language l), 'भी भुगतान प्रसंस्करण के बाद कंपनी के लिए एक ईमेल भेजने के लिए मानक authorize.net भुगतान प्रोसेसर फैली हुई है।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 19, 'title', (select max(l.id) from language l), 'ईमेल और प्रक्रिया authorize.net');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 20, 'description', (select max(l.id) from language l), 'एक भुगतान के प्रवेश द्वार के नीचे है, जब एक अलार्म के रूप में बिलिंग व्यवस्थापक को एक ईमेल भेजता है।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 20, 'title', (select max(l.id) from language l), 'भुगतान गेटवे नीचे अलार्म');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 21, 'description', (select max(l.id) from language l), 'एक परीक्षण भुगतान प्रोसेसर कार्यान्वयन एक वास्तविक भुगतान गेटवे का उपयोग किए बिना jBillings कार्यों का परीक्षण करने में सक्षम हो।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 21, 'title', (select max(l.id) from language l), 'टेस्ट भुगतान प्रोसेसर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 22, 'description', (select max(l.id) from language l), 'एक ग्राहक एक विशिष्ट भुगतान गेटवे सौंपा जा सकता है। यह एक और प्लगइन के लिए प्रतिनिधियों को फिर वास्तविक भुगतान प्रसंस्करण प्रवेश द्वार की पहचान करने के लिए एक कस्टम संपर्क क्षेत्र की जांच करता है।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 22, 'title', (select max(l.id) from language l), 'कस्टम फील्ड्स पर आधारित रूटर भुगतान प्रोसेसर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 23, 'description', (select max(l.id) from language l), '"भुगतान घटना इसका वर्तमान स्थिति और एक राज्य मशीन पर विचार, एक उपयोगकर्ता की सदस्यता स्थिति को प्रभावित करता है कि कैसे यह निर्धारित करता है।"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 23, 'title', (select max(l.id) from language l), 'डिफ़ॉल्ट सदस्यता स्थिति मैनेजर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 24, 'description', (select max(l.id) from language l), 'एसीएच वाणिज्य भुगतान के प्रवेश द्वार के साथ एकीकरण।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 24, 'title', (select max(l.id) from language l), 'एसीएच वाणिज्य भुगतान प्रोसेसर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 25, 'description', (select max(l.id) from language l), 'अतुल्यकालिक भुगतान प्रसंस्करण के लिए कोई पैरामीटर जोड़ नहीं है कि एक डमी कार्य। यह तयशुदा है।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 25, 'title', (select max(l.id) from language l), 'स्टैंडर्ड अतुल्यकालिक मानकों को');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 26, 'description', (select max(l.id) from language l), 'अतुल्यकालिक भुगतान प्रसंस्करण भुगतान प्रोसेसर के प्रति एक प्रसंस्करण संदेश सेम है करने के लिए इस प्लग में मानकों को कहते हैं। यह रूटर भुगतान प्रोसेसर प्लग-इन के साथ संयोजन में उपयोग किया जाता है।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 26, 'title', (select max(l.id) from language l), 'रूटर अतुल्यकालिक मानकों को');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 28, 'description', (select max(l.id) from language l), '"यह एक आदेश में आइटम जोड़ता है। आइटम क्रम में पहले से ही है, यह केवल मात्रा अद्यतन करता है।"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 28, 'title', (select max(l.id) from language l), 'मानक मद प्रबंधक');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 29, 'description', (select max(l.id) from language l), '"यह ऐसा बुनियादी आइटम प्रबंधक (वास्तव में यह बुला) क्या करता होगा। एक नियम आधारित प्लग में है, लेकिन तब यह रूप में अच्छी तरह से बाहरी नियमों पर अमल करेंगे। ये बाहरी नियमों पूरा नियंत्रण है नया हो रही है कि आदेश को बदलने पर आइटम नहीं है। "');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 29, 'title', (select max(l.id) from language l), 'नियम मद प्रबंधक');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 30, 'description', (select max(l.id) from language l), '"यह एक नियम आधारित प्लग में है। यह बाहरी नियमों के निष्पादन के लिए अनुमति देता है, एक आदेश लाइन के लिए कुल (आमतौर पर इस मात्रा से गुणा कीमत है) खरीदते हैं।"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 30, 'title', (select max(l.id) from language l), 'नियम लाइन कुल');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 31, 'description', (select max(l.id) from language l), 'यह एक नियम आधारित प्लग में है। यह बाहरी नियमों को क्रियान्वित करने से एक आइटम के लिए एक कीमत देता है। तुम तो मूल्य निर्धारण के लिए बाह्य तर्क जोड़ सकते हैं। यह भी मध्यस्थता मूल्य निर्धारण डेटा तक पहुँच होने से मध्यस्थता की प्रक्रिया के साथ एकीकृत है।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 31, 'title', (select max(l.id) from language l), 'नियम मूल्य निर्धारण');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 32, 'description', (select max(l.id) from language l), 'यह मध्यस्थता प्रक्रिया के लिए एक पाठक है। यह जिसका खेतों एक चरित्र (या स्ट्रिंग) से अलग होती है एक पाठ फ़ाइल से रिकॉर्ड पढ़ता है।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 32, 'title', (select max(l.id) from language l), 'सेपरेटर फ़ाइल पाठक');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 33, 'description', (select max(l.id) from language l), '"यह एक नियम आधारित प्लग में (अध्याय 7 देखें)। यह इस मध्यस्थता घटक के मूल में है। बिलिंग सार्थक डेटा में रिकॉर्ड अनुवाद करने के लिए बाहरी नियमों मध्यस्थता प्रक्रिया से एक घटना रिकॉर्ड लेता है और निष्पादित करता है, देखना है अधिक जानकारी के लिए? टेलीकॉम गाइड? दस्तावेज़। "');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 33, 'title', (select max(l.id) from language l), 'मध्यस्थता प्रोसेसर नियम');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 34, 'description', (select max(l.id) from language l), '"यह मध्यस्थता प्रक्रिया के लिए एक पाठक है। यह जिसका क्षेत्रों पदों को तय की है एक पाठ फ़ाइल से रिकॉर्ड पढ़ता है, और रिकॉर्ड एक निश्चित लंबाई है।"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 34, 'title', (select max(l.id) from language l), 'निश्चित लंबाई फ़ाइल पाठक');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 35, 'description', (select max(l.id) from language l), '"यह वास्तव में मानक भुगतान जानकारी कार्य के रूप में एक ही है, फर्क सिर्फ इतना है क्रेडिट कार्ड समाप्त हो गई है, तो यह मान्य नहीं है। आप समाप्त हो गई है क्रेडिट कार्ड के साथ भुगतान प्रस्तुत करना चाहते हैं तभी इस प्लग-इन का प्रयोग करें।"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 35, 'title', (select max(l.id) from language l), 'सत्यापन के बिना भुगतान के बारे में जानकारी');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 36, 'description', (select max(l.id) from language l), '"इस प्लग में केवल परीक्षण प्रयोजनों के लिए प्रयोग किया जाता है। इसके बजाय एक ईमेल (या अन्य अचल अधिसूचना), यह बस emails_sent.txt नाम की एक फ़ाइल में भेजे जाने के लिए पाठ को संग्रहीत भेजने का।"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 36, 'title', (select max(l.id) from language l), 'परीक्षण के लिए अधिसूचना कार्य');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 37, 'description', (select max(l.id) from language l), 'इस प्लगइन आंशिक आदेश की अवधि की गणना करने के लिए ध्यान में आदेशों के क्षेत्र चक्र शुरू होता है लेता है।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 37, 'title', (select max(l.id) from language l), 'आदेश की अवधि के समर्थक रेटिंग के साथ कैलकुलेटर।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 38, 'description', (select max(l.id) from language l), '"एक आदेश से एक चालान बनाने, इस प्लग में होगा समर्थक दर सबसे छोटी बिल इकाई के रूप में लेने के एक दिन की अवधि के किसी भी अंश।"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 38, 'title', (select max(l.id) from language l), 'समर्थक रेटिंग के साथ चालान रचना कार्य (अंश के रूप में दिन)');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 39, 'description', (select max(l.id) from language l), 'Intraanuity भुगतान के प्रवेश द्वार के साथ एकीकरण।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 39, 'title', (select max(l.id) from language l), 'Intraanuity भुगतान के प्रवेश द्वार के लिए भुगतान की प्रक्रिया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 40, 'description', (select max(l.id) from language l), 'इस प्लग में एक आदेश पहले से चालान कर दिया गया है कि एक अवधि के भीतर रद्द कर दिया है जब एक क्रेडिट प्रतिबिंबित करने के लिए एक नकारात्मक मूल्य के साथ एक नई व्यवस्था का निर्माण करेगा।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 40, 'title', (select max(l.id) from language l), 'स्वत: रद्द क्रेडिट।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 42, 'description', (select max(l.id) from language l), 'वास्तविक भुगतान प्रोसेसर तक पहुँचने से भुगतान रोकने के लिए इस्तेमाल किया। आमतौर पर प्रसंस्करण श्रृंखला में पहला भुगतान प्रोसेसर के रूप में विन्यस्त है।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 42, 'title', (select max(l.id) from language l), 'ब्लैकलिस्ट फिल्टर भुगतान प्रोसेसर।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 43, 'description', (select max(l.id) from language l), '"उपयोगकर्ताओं का कारण बनता है और उनकी स्थिति को निलंबित कर दिया या अधिक हो जाता है जब उनके संबंधित विवरण (जैसे, क्रेडिट कार्ड नंबर, फोन नंबर, आदि) काली सूची में डाला जाना है।"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 43, 'title', (select max(l.id) from language l), 'ब्लैकलिस्ट यूजर को अपनी स्थिति को निलंबित कर दिया या अधिक हो जाता है।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 44, 'description', (select max(l.id) from language l), 'यह मध्यस्थता प्रक्रिया के लिए एक पाठक है। यह एक JDBC डेटाबेस स्रोत से रिकॉर्ड पढ़ता है।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 44, 'title', (select max(l.id) from language l), 'जेडीबीसी मध्यस्थता रीडर।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 45, 'description', (select max(l.id) from language l), '"यह मध्यस्थता प्रक्रिया के लिए एक पाठक है। यह एक डाटाबेस स्रोत के आसान विन्यास अनुमति देता है, जेडीबीसी पाठक का एक विस्तार है।"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 45, 'title', (select max(l.id) from language l), 'MySQL के मध्यस्थता रीडर।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 49, 'description', (select max(l.id) from language l), 'प्रतिनिधियों भुगतान की मुद्रा पर आधारित एक और प्लग-इन करने के वास्तविक भुगतान प्रसंस्करण।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 49, 'title', (select max(l.id) from language l), 'मुद्रा रूटर भुगतान प्रोसेसर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 51, 'description', (select max(l.id) from language l), 'इस फिल्टर एक सकारात्मक संतुलन के साथ ही चालान अगले चालान करने के लिए खत्म किया जा करने के लिए होगा।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 51, 'title', (select max(l.id) from language l), 'पर ले जाने के लिए नकारात्मक चालान से बाहर फिल्टर।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 52, 'description', (select max(l.id) from language l), 'यह उत्पन्न चालान प्रति एक लाइन के साथ एक फ़ाइल उत्पन्न होगा।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 52, 'title', (select max(l.id) from language l), 'चालान निर्यातक करें।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 53, 'description', (select max(l.id) from language l), 'एक आंतरिक घटना होता है जब यह नियमों का एक पैकेज से मुलाकात करेंगे।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 53, 'title', (select max(l.id) from language l), 'एक घटना पर नियम फोन करने वाले।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 54, 'description', (select max(l.id) from language l), 'यह (प्री-पेड या क्रेडिट सीमा) को प्रभावित करने की घटनाओं संतुलन होता है जब एक ग्राहक के गतिशील संतुलन को अद्यतन करेगा।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 54, 'title', (select max(l.id) from language l), 'गतिशील संतुलन प्रबंधक');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 55, 'title', (select max(l.id) from language l), 'ग्राहक संतुलन के आधार पर शेष राशि सत्यापनकर्ता।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 56, 'title', (select max(l.id) from language l), 'नियमों के आधार पर शेष राशि सत्यापनकर्ता।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 57, 'description', (select max(l.id) from language l), 'भुगतान गेटवे भुगतान प्रोसेसर के साथ एकीकरण।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 57, 'title', (select max(l.id) from language l), 'भुगतान गेटवे के लिए भुगतान प्रोसेसर है।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 58, 'description', (select max(l.id) from language l), '"बल्कि jBilling डीबी से भुगतान के प्रवेश द्वार में क्रेडिट कार्ड की जानकारी, बचाता है।"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 58, 'title', (select max(l.id) from language l), 'क्रेडिट कार्ड बाह्य जमा हो जाती है।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 59, 'title', (select max(l.id) from language l), 'नियम मद प्रबंधक 2');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 60, 'title', (select max(l.id) from language l), 'नियम लाइन कुल - 2');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 61, 'description', (select max(l.id) from language l), 'यह एक नियम आधारित प्लग में jBilling 2.2.x. की मध्यस्थता के मॉड्यूल के साथ संगत यह बाहरी नियमों को क्रियान्वित करने से एक आइटम के लिए एक कीमत देता है। तुम तो मूल्य निर्धारण के लिए बाह्य तर्क जोड़ सकते हैं। यह भी मध्यस्थता मूल्य निर्धारण डेटा तक पहुँच होने से मध्यस्थता की प्रक्रिया के साथ एकीकृत है।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 61, 'title', (select max(l.id) from language l), 'नियम मूल्य निर्धारण 2');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 63, 'description', (select max(l.id) from language l), 'एक नकली प्लग में बाहर से संग्रहीत किया जाएगा कि भुगतान का परीक्षण करने के लिए।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 63, 'title', (select max(l.id) from language l), 'बाह्य भंडारण के लिए टेस्ट भुगतान प्रोसेसर।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 64, 'description', (select max(l.id) from language l), 'भुगतान प्रोसेसर प्लग में आरबीएस WorldPay के साथ एकीकृत करने के लिए');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 64, 'title', (select max(l.id) from language l), 'WorldPay एकीकरण');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 65, 'description', (select max(l.id) from language l), '"भुगतान प्रोसेसर प्लग में आरबीएस WorldPay के साथ एकीकृत करने के लिए। यह प्रवेश द्वार में क्रेडिट कार्ड की जानकारी (संख्या, आदि) संग्रहीत करता है।"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 65, 'title', (select max(l.id) from language l), 'बाह्य भंडारण के साथ WorldPay एकीकरण');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 66, 'description', (select max(l.id) from language l), '"एक ग्राहक का संतुलन नज़र रखता है और एक सीमा पर पहुंचने पर, यह एक वास्तविक समय भुगतान अनुरोध"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 66, 'title', (select max(l.id) from language l), 'ऑटो पुनर्भरण');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 67, 'description', (select max(l.id) from language l), 'BeanStream भुगतान के प्रवेश द्वार के साथ एकीकरण के लिए भुगतान प्रोसेसर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 67, 'title', (select max(l.id) from language l), 'BeanStream गेटवे एकीकरण');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 68, 'description', (select max(l.id) from language l), 'बाबा भुगतान के प्रवेश द्वार के साथ एकीकरण के लिए भुगतान प्रोसेसर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 68, 'title', (select max(l.id) from language l), 'बाबा भुगतान गेटवे एकीकरण');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 69, 'description', (select max(l.id) from language l), 'बिलिंग प्रक्रिया का मूल्यांकन करने के लिए जो उपयोगकर्ताओं का चयन करने के लिए चलाता है जब कहा जाता है। यह बुनियादी कार्यान्वयन बस निलंबित (या बुरा) की स्थिति में नहीं है कि हर उपयोगकर्ता रिटर्न');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 69, 'title', (select max(l.id) from language l), 'स्टैंडर्ड बिलिंग प्रक्रिया उपयोगकर्ताओं फिल्टर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 70, 'description', (select max(l.id) from language l), 'बिलिंग प्रक्रिया का मूल्यांकन करने के लिए जो उपयोगकर्ताओं का चयन करने के लिए चलाता है जब कहा जाता है। यह केवल पहले बिलिंग प्रक्रिया की तुलना में एक अगले चालान तिथि है कि आदेश के साथ उपयोगकर्ताओं के लिए देता है।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 70, 'title', (select max(l.id) from language l), 'चयनात्मक बिलिंग प्रक्रिया उपयोगकर्ताओं फिल्टर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 71, 'description', (select max(l.id) from language l), 'त्रुटियों के साथ इस घटना को रिकॉर्ड एक फाइल करने से बच रहे हैं');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 73, 'description', (select max(l.id) from language l), 'त्रुटियों के साथ इस घटना को रिकॉर्ड एक डेटाबेस तालिका करने से बच रहे हैं');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 75, 'description', (select max(l.id) from language l), 'के रूप में अच्छी तरह से पेपैल में एक भुगतान के प्रवेश द्वार और दुकानों क्रेडिट कार्ड की जानकारी के रूप में पेपैल के लिए भुगतान को सौंपी');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 75, 'title', (select max(l.id) from language l), 'बाह्य भंडारण के साथ पेपैल एकीकरण');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 76, 'description', (select max(l.id) from language l), 'के रूप में अच्छी तरह से authorize.net में एक भुगतान के प्रवेश द्वार और दुकानों क्रेडिट कार्ड की जानकारी के रूप में authorize.net को भुगतान को सौंपी');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 76, 'title', (select max(l.id) from language l), 'बाह्य भंडारण के साथ Authorize.net एकीकरण');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 77, 'description', (select max(l.id) from language l), 'प्रतिनिधियों भुगतान के भुगतान विधि पर आधारित एक और प्लग-इन करने के वास्तविक भुगतान प्रसंस्करण।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 77, 'title', (select max(l.id) from language l), 'भुगतान विधि रूटर भुगतान प्रोसेसर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 78, 'description', (select max(l.id) from language l), 'गतिशील रूप से एक वेग टेम्पलेट के आधार पर नियमों उत्पन्न करता है।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 78, 'title', (select max(l.id) from language l), 'गतिशील नियमों जनरेटर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 79, 'description', (select max(l.id) from language l), 'एक निर्धारित कार्य मध्यस्थता प्रक्रिया निष्पादित करने के लिए।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 79, 'title', (select max(l.id) from language l), 'मध्यस्थता प्रक्रिया टास्क');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 80, 'description', (select max(l.id) from language l), 'एक निर्धारित कार्य बिलिंग प्रक्रिया निष्पादित करने के लिए।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 80, 'title', (select max(l.id) from language l), 'बिलिंग प्रक्रिया टास्क');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 87, 'description', (select max(l.id) from language l), 'युग के खाते से अपेक्षित है कि दिनों की संख्या के आधार पर एक उपयोगकर्ता।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 87, 'title', (select max(l.id) from language l), 'बेसिक उम्र बढ़ने');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 88, 'description', (select max(l.id) from language l), 'एक निर्धारित कार्य बूढ़े प्रक्रिया निष्पादित करने के लिए।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 88, 'title', (select max(l.id) from language l), 'बूढ़े प्रक्रिया कार्य');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 89, 'description', (select max(l.id) from language l), 'युग के खाते से अपेक्षित है कि (छुट्टियों को छोड़कर) कार्यदिवसों की संख्या के आधार पर एक उपयोगकर्ता।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 89, 'title', (select max(l.id) from language l), 'दिन के कारोबार उम्र बढ़ने');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 90, 'description', (select max(l.id) from language l), 'साथी के देश कोड मिलान किया जाता है तो प्रकार SimpleTaxCompositionTask की एक pluggable कार्य चालान करने के लिए टैक्स मद लागू करने के लिए।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 90, 'title', (select max(l.id) from language l), 'देश कर चालान रचना टास्क');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 91, 'description', (select max(l.id) from language l), 'प्रकार AbstractChargeTask की एक pluggable काम के लिए एक विन्यास दिनों की अवधि से परे एक नियत तारीख होने के एक चालान की सजा पर लागू करने के लिए।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 91, 'title', (select max(l.id) from language l), 'भुगतान की शर्तें जुर्माना टास्क');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 95, 'description', (select max(l.id) from language l), 'प्रकार भुगतान की एक प्लगेबल कार्य जानकारी टास्क कि पहले की जाँच के पसंदीदा विधि के लिए कोई डाटा नहीं है, तो यह विकल्प भुगतान के तरीके के लिए खोज से पसंदीदा भुगतान विधि');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 95, 'title', (select max(l.id) from language l), 'वैकल्पिक भुगतान जानकारी टास्क');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 97, 'description', (select max(l.id) from language l), 'यह कार्य एक अतिदेय चालान पर एक% -age या एक निश्चित राशि की सजा को लागू करने के लिए जिम्मेदार है। यह बिलिंग प्रक्रिया के आदेश एकत्र करता है बस से पहले इस कार्रवाई करता है, क्योंकि यह कार्य शक्तिशाली है।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 97, 'title', (select max(l.id) from language l), 'Overude चालान पर जुर्माना टास्क');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 101, 'description', (select max(l.id) from language l), 'आंतरिक घटना हुई जब घटना आधार पर कस्टम अधिसूचना कार्य सूचना कस्टम सूचना संदेश लेता है और करता है');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 101, 'title', (select max(l.id) from language l), 'घटना आधार पर कस्टम अधिसूचना कार्य');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 102, 'description', (select max(l.id) from language l), 'यह एक नया संपर्क बनाया जाता है जब एक दूरस्थ वेब सेवा का आह्वान एक उदाहरण है कि प्लग में है।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 102, 'title', (select max(l.id) from language l), 'उदाहरण वेब सेवा प्लगइन');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 105, 'description', (select max(l.id) from language l), 'इस प्लगइन Suretax इंजन परामर्श करके चालान करने के लिए कर लाइनों कहते हैं।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 105, 'title', (select max(l.id) from language l), 'Suretax प्लगइन');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 107, 'description', (select max(l.id) from language l), 'इस प्लग में 0 के लिए एक नकारात्मक चालान के संतुलन और कुल की स्थापना की और शेष राशि के लिए एक क्रेडिट भुगतान पैदा करेगा।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 107, 'title', (select max(l.id) from language l), 'नकारात्मक चालान पर क्रेडिट');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 108, 'description', (select max(l.id) from language l), 'उपयोगकर्ताओं को पूर्व-भुगतान संतुलन के लिए एक सीमा के स्तर से नीचे है और सूचनाएं भेज अगर प्रकार InternalEventsTask की एक pluggable कार्य की निगरानी के लिए।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 108, 'title', (select max(l.id) from language l), 'उपयोगकर्ता शेष सीमा अधिसूचना कार्य');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 109, 'description', (select max(l.id) from language l), 'इस प्लग में प्रत्येक स्थिति के लिए भेजा जाना चाहिए कि उपयोगकर्ता स्थिति (उम्र बढ़ने कदम) और सूचनाओं के बीच मानचित्रण प्रदान करता है');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 109, 'title', (select max(l.id) from language l), 'उम्र बढ़ने के निर्देशों के अनुसार कस्टम उपयोगकर्ता सूचनाएं');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 110, 'description', (select max(l.id) from language l), 'इस काम के लिए एक निश्चित समय से फाइलों में पुराने को हटाना होगा।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 110, 'title', (select max(l.id) from language l), 'पुरानी फाइलों को नष्ट');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 111, 'description', (select max(l.id) from language l), 'इस प्लग में जब एक परिसंपत्ति स्थिति परिवर्तन AssetTransitions अद्यतन करेगा।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 111, 'title', (select max(l.id) from language l), 'अपडेट एसेट बदलाव');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 112, 'description', (select max(l.id) from language l), 'से जुड़े आदेश को समाप्त हो रहा है, जब इस प्लग में संपत्ति मालिकों को हटा देगा।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 112, 'title', (select max(l.id) from language l), 'समाप्त आदेश से संपत्ति को निकालें');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 113, 'description', (select max(l.id) from language l), 'प्रकार InternalEventsTask की एक pluggable कार्य की निगरानी के लिए जब एक आदेश के activeUntil परिवर्तन');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 113, 'title', (select max(l.id) from language l), 'आदेश रद्द टास्क');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 117, 'description', (select max(l.id) from language l), 'इस कार्य के कार्यक्रम एजेंट कमीशन की गणना करता है कि प्रक्रिया।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 117, 'title', (select max(l.id) from language l), 'एजेंट कमीशन की गणना');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 118, 'description', (select max(l.id) from language l), 'यह कार्य एजेंट कमीशन की गणना करता है।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 118, 'title', (select max(l.id) from language l), 'बेसिक एजेंट कमीशन कार्य');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 119, 'description', (select max(l.id) from language l), 'भुगतान चालान से एक लिंक रद्द जुड़े हुए हैं जब इस प्लग में भुगतान आयोगों पैदा करेगा।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 119, 'title', (select max(l.id) from language l), 'एजेंटों के लिए भुगतान आयोगों उत्पन्न करता है।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 123, 'description', (select max(l.id) from language l), 'तीसरे पक्ष व्यवस्था के खिलाफ फाइल डाउनलोड / अपलोड ट्रिगर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 123, 'title', (select max(l.id) from language l), 'उत्प्रेरक फ़ाइल डाउनलोड / अपलोड');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 124, 'description', (select max(l.id) from language l), 'प्रकार InternalEventsTask की एक pluggable कार्य उपयोगकर्ताओं को पूर्व-भुगतान संतुलन के लिए एक क्रेडिट सीमा से नीचे है, तो 1 या 2 के स्तर की निगरानी और सूचना भेजने के लिए।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 124, 'title', (select max(l.id) from language l), 'उपयोगकर्ता क्रेडिट सीमा अधिसूचना कार्य');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 125, 'description', (select max(l.id) from language l), 'आदेश परिवर्तन के दौरान व्यवस्था की स्थिति बदल जाएगा इस प्लग में आदेश परिवर्तन में चयनित करने के लिए लागू होते हैं।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 125, 'title', (select max(l.id) from language l), 'लागू आदेश परिवर्तन पर आदेश की स्थिति बदलें');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 126, 'description', (select max(l.id) from language l), 'यह वरीयता 55 में निर्दिष्ट दिनों की संख्या के लिए लॉग-इन और निष्क्रिय करने के लिए वहाँ की स्थिति को अद्यतन नहीं किया गया है कि उपयोगकर्ता में लेता है कि एक अनुसूचित प्लगइन है।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 126, 'title', (select max(l.id) from language l), 'निष्क्रिय उपयोगकर्ता खाता प्रबंधन प्लगइन');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 127, 'description', (select max(l.id) from language l), 'इस मद के उपयोग के आधार पर मूल्य निर्धारण गणना (डिफ़ॉल्ट कार्यान्वयन) संभालती है।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 127, 'title', (select max(l.id) from language l), 'बेसिक मूल्य निर्धारण टास्क');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (28, 2, 'description', (select max(l.id) from language l), 'मुख्य');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (28, 3, 'description', (select max(l.id) from language l), 'मुख्य');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (28, 4, 'description', (select max(l.id) from language l), 'अतिरिक्त संपर्क');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35, 1, 'description', (select max(l.id) from language l), 'चेक');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35, 2, 'description', (select max(l.id) from language l), 'वीज़ा');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35, 3, 'description', (select max(l.id) from language l), 'मास्टर कार्ड');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35, 4, 'description', (select max(l.id) from language l), 'एमेक्स');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35, 5, 'description', (select max(l.id) from language l), 'एसीएच');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35, 6, 'description', (select max(l.id) from language l), 'डिस्कवर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35, 7, 'description', (select max(l.id) from language l), 'डिनर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35, 8, 'description', (select max(l.id) from language l), 'पेपैल');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35, 9, 'description', (select max(l.id) from language l), 'पेमेंट गेटवे कुंजी');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35, 15, 'description', (select max(l.id) from language l), 'श्रेय');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (41, 1, 'description', (select max(l.id) from language l), 'सफल');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (41, 2, 'description', (select max(l.id) from language l), 'विफल');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (41, 3, 'description', (select max(l.id) from language l), 'अनुपलब्ध प्रोसेसर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (41, 4, 'description', (select max(l.id) from language l), 'घुसा');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46, 1, 'description', (select max(l.id) from language l), 'बिलिंग प्रक्रिया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46, 2, 'description', (select max(l.id) from language l), 'उपयोगकर्ता रखरखाव');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46, 3, 'description', (select max(l.id) from language l), 'मद रखरखाव');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46, 4, 'description', (select max(l.id) from language l), 'आइटम प्रकार रखरखाव');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46, 5, 'description', (select max(l.id) from language l), 'मद उपयोगकर्ता कीमत रखरखाव');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46, 6, 'description', (select max(l.id) from language l), 'प्रमोशन रखरखाव');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46, 7, 'description', (select max(l.id) from language l), 'आदेश रखरखाव');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46, 8, 'description', (select max(l.id) from language l), 'क्रेडिट कार्ड रखरखाव');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46, 9, 'description', (select max(l.id) from language l), 'चालान रखरखाव');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 1, 'description', (select max(l.id) from language l), 'एक प्रीपेड आदेश बिलिंग प्रक्रिया की तारीख से पहले unbilled समय है');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 2, 'description', (select max(l.id) from language l), 'आदेश की प्रक्रिया की तारीख में कोई सक्रिय समय दिया है।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 3, 'description', (select max(l.id) from language l), 'कम से कम एक पूरी अवधि के बिल हो गया है।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 4, 'description', (select max(l.id) from language l), 'पहले से ही आज की तारीख के लिए बिल भेजा।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 5, 'description', (select max(l.id) from language l), 'इस आदेश के अंतिम प्रक्रिया में बहिष्कार के लिए चिह्नित किया जा सकता था।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 6, 'description', (select max(l.id) from language l), 'प्री-पेड आदेश इसकी समाप्ति के बाद की प्रक्रिया की जा रही है।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 7, 'description', (select max(l.id) from language l), 'हटाए रूप में एक पंक्ति के रूप में चिह्नित किया गया था।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 8, 'description', (select max(l.id) from language l), 'एक उपयोगकर्ता पासवर्ड बदल दिया गया था।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 9, 'description', (select max(l.id) from language l), 'एक पंक्ति अद्यतन किया गया था।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 10, 'description', (select max(l.id) from language l), '"एक बिलिंग प्रक्रिया चल रही है, लेकिन एक समीक्षा अननुमोदित पाया जाता है।"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 11, 'description', (select max(l.id) from language l), '"एक बिलिंग प्रक्रिया चल रहा है, समीक्षा की आवश्यकता है लेकिन मौजूद नहीं है।"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 12, 'description', (select max(l.id) from language l), 'एक उपयोगकर्ता स्थिति बदल गया था।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 13, 'description', (select max(l.id) from language l), 'एक आदेश स्थिति बदल गया था।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 14, 'description', (select max(l.id) from language l), '"एक उपयोगकर्ता आयु वर्ग किया जा सकता था, लेकिन के लिए कॉन्फ़िगर कोई और अधिक कदम उठाए हैं।"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 15, 'description', (select max(l.id) from language l), '"एक साथी के लिए तैयार एक भुगतान, लेकिन कोई भुगतान साधन है।"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 16, 'description', (select max(l.id) from language l), 'मैन्युअल एक चालान करने के लिए लागू किया गया के रूप में एक खरीद आदेश।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 17, 'description', (select max(l.id) from language l), 'आदेश पंक्ति अद्यतन किया गया है');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 18, 'description', (select max(l.id) from language l), 'आदेश अगले बिलिंग तारीख बदल दिया गया है');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 19, 'description', (select max(l.id) from language l), 'अंतिम API कॉल उपयोगकर्ता सदस्यता स्थिति बदलाव लाने के लिए');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 20, 'description', (select max(l.id) from language l), 'प्रयोक्ता सदस्यता स्थिति बदल गई है');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 21, 'description', (select max(l.id) from language l), 'उपयोगकर्ता खाता अब बंद कर दिया है');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 22, 'description', (select max(l.id) from language l), 'आदेश मुख्य सदस्यता झंडा बदल गया था');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 24, 'description', (select max(l.id) from language l), 'एक वैध भुगतान पद्धति नहीं मिला था। भुगतान अनुरोध को रद्द कर दिया गया था');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 25, 'description', (select max(l.id) from language l), 'एक नई पंक्ति बनाया गया है');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 26, 'description', (select max(l.id) from language l), '"एक चालान के आदेश को रद्द कर दिया गया था, एक क्रेडिट आदेश बनाया गया था"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 27, 'description', (select max(l.id) from language l), 'एक यूजर आईडी काला सूची में जोड़ा गया था');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 28, 'description', (select max(l.id) from language l), 'एक यूजर आईडी काली सूची से हटा दिया गया था');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 32, 'description', (select max(l.id) from language l), 'प्रयोक्ता सदस्यता स्थिति नहीं बदला है');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 33, 'description', (select max(l.id) from language l), 'एक उपयोगकर्ता के गतिशील संतुलन बदल गया है');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 34, 'description', (select max(l.id) from language l), 'बच्चे झंडा बदल गया है, तो चालान');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 35, 'description', (select max(l.id) from language l), 'एक पुनर्विक्रेता आदेश एक बच्चे की इकाई के लिए चालान पीढ़ी के दौरान रूट इकाई के लिए बनाया गया था।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 37, 'description', (select max(l.id) from language l), 'एक असफल लॉगिन प्रयास किया गया था।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 38, 'description', (select max(l.id) from language l), 'प्रयोक्ता को सफलतापूर्वक में लॉग इन');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 39, 'description', (select max(l.id) from language l), 'प्रयोक्ता को सफलतापूर्वक लॉग आउट');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 40, 'description', (select max(l.id) from language l), 'उपयोगकर्ता की वजह से गलत नाम / पासवर्ड में लॉग इन करने में विफल रहा है');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 4, 'description', (select max(l.id) from language l), 'मुहलत');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 4, 'instruction', (select max(l.id) from language l), 'एक अरसे से चालान के साथ एक ग्राहक की उम्र बढ़ने से पहले के दिनों में ग्रेस अवधि।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 13, 'description', (select max(l.id) from language l), 'कागज चालान की स्व वितरण');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 13, 'instruction', (select max(l.id) from language l), 'बिलिंग कंपनी के रूप में ई-मेल के चालान करने के लिए 1 के लिए निर्धारित किया है। JBilling के रूप में चालान देने के लिए 0।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 14, 'description', (select max(l.id) from language l), 'चालान में ग्राहक नोट शामिल हैं');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 14, 'instruction', (select max(l.id) from language l), '", चालान में नोटों को दिखाने के लिए 1 सेट 0 निष्क्रिय करने के लिए।"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 15, 'description', (select max(l.id) from language l), 'आदेश अधिसूचना के लिए समाप्ति से पहले के दिनों');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 15, 'instruction', (select max(l.id) from language l), 'दिनों की तारीख जब तक सक्रिय के आदेश 1 सूचना भेजने के लिए पहले। निष्क्रिय करने के लिए खाली छोड़ दें।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 16, 'description', (select max(l.id) from language l), 'आदेश अधिसूचना 2 के लिए समाप्ति से पहले के दिनों');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 16, 'instruction', (select max(l.id) from language l), 'दिनों की तारीख जब तक सक्रिय के आदेश 2 सूचना भेजने के लिए पहले। निष्क्रिय करने के लिए खाली छोड़ दें।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 17, 'description', (select max(l.id) from language l), 'आदेश अधिसूचना 3 के लिए समाप्ति से पहले के दिनों');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 17, 'instruction', (select max(l.id) from language l), 'दिनों की तारीख जब तक सक्रिय के आदेश 3 सूचना भेजने के लिए पहले। निष्क्रिय करने के लिए खाली छोड़ दें।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 18, 'description', (select max(l.id) from language l), 'चालान नंबर उपसर्ग');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 18, 'instruction', (select max(l.id) from language l), 'उत्पन्न चालान सार्वजनिक नंबरों के लिए उपसर्ग मूल्य।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 19, 'description', (select max(l.id) from language l), 'अगले चालान संख्या');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 19, 'instruction', (select max(l.id) from language l), 'उत्पन्न चालान सार्वजनिक नंबरों के लिए वर्तमान मूल्य। नए चालान इस मूल्य बढ़ाने के द्वारा एक सार्वजनिक नंबर आवंटित किया जाएगा।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 20, 'description', (select max(l.id) from language l), 'मैनुअल चालान विलोपन');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 20, 'instruction', (select max(l.id) from language l), '"चालान, हटाए जाने की अनुमति देने के लिए 1 सेट 0 निष्क्रिय करने के लिए।"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 21, 'description', (select max(l.id) from language l), 'चालान अनुस्मारक का उपयोग');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 21, 'instruction', (select max(l.id) from language l), '", चालान अनुस्मारक सूचनाएं अनुमति देने के लिए 1 सेट 0 निष्क्रिय करने के लिए।"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 22, 'description', (select max(l.id) from language l), 'पहले याद दिलाने के लिए चालान पीढ़ी के बाद के दिनों की संख्या');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 23, 'description', (select max(l.id) from language l), 'अगले याद दिलाने के लिए दिनों की संख्या');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 24, 'description', (select max(l.id) from language l), 'डेटा Fattura ललित Mese');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 24, 'instruction', (select max(l.id) from language l), '", सक्षम करने के लिए एक सेट 0 निष्क्रिय करने के लिए।"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 25, 'description', (select max(l.id) from language l), 'अतिदेय दंड (ब्याज) का प्रयोग करें।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 25, 'instruction', (select max(l.id) from language l), '", अतिदेय भुगतान पर ब्याज की गणना करने के लिए बिलिंग प्रक्रिया को सक्षम करने के लिए एक सेट 0 निष्क्रिय करने के लिए। ब्याज की गणना चयनित दंड प्लग द्वारा नियंत्रित किया जाता है।"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 27, 'description', (select max(l.id) from language l), 'आदेश प्रत्याशा का प्रयोग करें।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 27, 'instruction', (select max(l.id) from language l), '"OrderFilterAnticipateTask" "का उपयोग करने के लिए 1 के लिए सेट" "निष्क्रिय करने के लिए अग्रिम में 0 महीने की एक संख्या चालान करने के लिए। प्लग-इि अलग से विन्यस्त किया जाना चाहिए।"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 28, 'description', (select max(l.id) from language l), 'पेपैल खाते।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 28, 'instruction', (select max(l.id) from language l), 'पेपैल खाते का नाम।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 29, 'description', (select max(l.id) from language l), 'पेपैल बटन यूआरएल।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 29, 'instruction', (select max(l.id) from language l), '"वे एक भुगतान कर रहे हैं जब पेपैल बटन के ग्राफिक रहता है जहां एक URL। बटन ग्राहकों को प्रदर्शित किया जाता है। डिफ़ॉल्ट आमतौर पर एक और भाषा की जरूरत है, को छोड़कर जब सबसे अच्छा विकल्प है।"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 30, 'description', (select max(l.id) from language l), 'HTTP उम्र बढ़ने कॉलबैक के लिए URL।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 30, 'instruction', (select max(l.id) from language l), 'उम्र बढ़ने की प्रक्रिया के लिए एक उपयोगकर्ता की स्थिति में परिवर्तन जब HTTP कॉलबैक के लिए URL आह्वान करने के लिए।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 31, 'description', (select max(l.id) from language l), 'निरंतर चालान तिथियाँ का प्रयोग करें।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 31, 'instruction', (select max(l.id) from language l), '। "खाली चूक यह वरीयता एक तारीख हो गया है (प्रारूप YYYY-MM-DD में उदाहरण:। 2000/01/31), प्रणाली अपने सभी चालान एक वृद्धिशील रास्ते में उनकी तारीखों को यकीन है कि कर देगा किसी भी चालान के साथ। एक बड़ा आईडी इसके अलावा, इस वरीयता का उपयोग करें। दूसरे शब्दों में, एक नया चालान एक मौजूदा (पुराने) चालान से पहले के एक तारीख नहीं कर सकते हैं। एक बड़ा (या बराबर) की तारीख की तारीख के साथ एक स्ट्रिंग के रूप में इसे स्थापित करेगा शुरू करने के लिए है। यह वरीयता "रिक्त है, तो उपयोग नहीं किया जाएगा');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 32, 'description', (select max(l.id) from language l), 'ईमेल सूचना के लिए पीडीएफ चालान संलग्न।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 32, 'instruction', (select max(l.id) from language l), '1 के लिए निर्धारित सभी चालान सूचना ई-मेल करने के लिए चालान की एक PDF संस्करण संलग्न करने के लिए। निष्क्रिय करने के लिए 0।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 33, 'description', (select max(l.id) from language l), 'चालान के अनुसार एक आदेश के लिए बाध्य करें।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 33, 'instruction', (select max(l.id) from language l), '"" अलग चालान में शामिल हैं "दिखाने के लिए एक के लिए सेट" "एक आदेश पर झंडा। 0 निष्क्रिय करने के लिए।"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 35, 'description', (select max(l.id) from language l), 'चालान लाइनों को आदेश क्रमांक जोड़ें।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 35, 'instruction', (select max(l.id) from language l), '"जिसके परिणामस्वरूप चालान पंक्ति का विवरण पाठ में आदेश की आईडी शामिल करने के लिए 1 के लिए सेट करें। निष्क्रिय करने के लिए 0। यह आसानी से जो सटीक आदेश को ट्रैक करने में मदद कर सकते हैं कई विचार है कि एक चालान में एक लाइन के लिए जिम्मेदार है आदेश के एक भी चालान में शामिल किया जा सकता है। "');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 36, 'description', (select max(l.id) from language l), 'ग्राहकों को खुद के संपर्क जानकारी को संपादित करने की अनुमति दें।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 36, 'instruction', (select max(l.id) from language l), 'ग्राहकों को अपने स्वयं संपर्क जानकारी को संपादित करने की अनुमति देने के लिए 1 के लिए निर्धारित किया है। निष्क्रिय करने के लिए 0।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 38, 'description', (select max(l.id) from language l), 'लिंक ग्राहक ग्राहक का दर्जा के लिए उम्र बढ़ने।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 38, 'instruction', (select max(l.id) from language l), 'एक उपयोगकर्ता जब उपयोगकर्ता उम्र की सदस्यता स्थिति बदलने के लिए एक के लिए निर्धारित किया है। निष्क्रिय करने के लिए 0।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 39, 'description', (select max(l.id) from language l), 'लॉक-आउट उपयोगकर्ता विफल लॉगिन प्रयास के बाद।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 39, 'instruction', (select max(l.id) from language l), '"प्रयासों की संख्या को उपयोगकर्ता खाते पर ताला लगा होने से पहले अनुमति देने के लिए। एक बंद उपयोगकर्ता खाते इस लॉकिंग सुविधा को सक्षम करने के लिए वरीयता 68. में निर्दिष्ट मिनट की राशि के लिए बंद कर दिया जाएगा, एक गैर शून्य मान के लिए बहुत जरूरी पसंद 68 की स्थापना।"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 40, 'description', (select max(l.id) from language l), 'दिनों के बाद उपयोगकर्ता पासवर्ड समाप्त।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 40, 'instruction', (select max(l.id) from language l), '"शून्य से अधिक है, यह एक पासवर्ड मान्य है उन दिनों की संख्या का प्रतिनिधित्व करता है। उन दिनों के बाद पासवर्ड समाप्त हो गई है और उपयोगकर्ता इसे बदलने के लिए मजबूर किया जाता है।"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 41, 'description', (select max(l.id) from language l), 'मुख्य सदस्यता के आदेश का प्रयोग करें।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 41, 'instruction', (select max(l.id) from language l), 'बाहरी घटनाओं से आने वाले आरोपों के लिए जगह है, जहां का निर्धारण करते हैं तो यह झंडा केवल मध्यस्थता प्रक्रिया द्वारा पढ़ा जाता है आदेश के लिए मुख्य सदस्यता ध्वज के उपयोग को अनुमति देने के लिए 1 के लिए निर्धारित किया है।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 42, 'description', (select max(l.id) from language l), 'समानुपातिक का प्रयोग करें।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 42, 'instruction', (select max(l.id) from language l), 'एक अवधि के भागों चालान करने के लिए समानुपातिक का उपयोग करने की अनुमति के लिए 1 के लिए निर्धारित किया है। एक आदेश के चक्र विशेषता से पता चलता है। इस सुविधा को पूरी तरह से कार्यशील होने के लिए आप इसी प्लग-इन्स विन्यस्त करने की जरूरत है कि ध्यान दें।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 43, 'description', (select max(l.id) from language l), 'भुगतान काला सूची का प्रयोग करें।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 43, 'instruction', (select max(l.id) from language l), '"भुगतान ब्लैकलिस्ट सुविधा का उपयोग किया जाता है, तो इस PaymentFilterTask प्लग-इन के विन्यास की आईडी को तैयार है। दस्तावेज की ब्लैकलिस्ट अनुभाग देखें।"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 44, 'description', (select max(l.id) from language l), 'नकारात्मक भुगतान की अनुमति दें।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 44, 'instruction', (select max(l.id) from language l), '1 के लिए सेट नकारात्मक भुगतान की अनुमति है। निष्क्रिय करने के लिए 0');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 45, 'description', (select max(l.id) from language l), 'विलंब नकारात्मक चालान भुगतान।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 45, 'instruction', (select max(l.id) from language l), '"अगले चालान को खत्म किया जाना शेष है, जिससे 1 नकारात्मक चालान राशि के भुगतान में देरी करने के लिए सेट करें। उन्हें स्थानांतरित अन्य चालान से नकारात्मक शेष राशि पड़ा है कि चालान तुरंत एक नकारात्मक भुगतान (क्रेडिट) बनाने के लिए अनुमति दी जाती है की जरूरत है।  0 निष्क्रिय करने के लिए। पसंद 44 व 46 को आम तौर पर भी सक्षम हैं। "');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 46, 'description', (select max(l.id) from language l), 'आदेश के बिना चालान की अनुमति दें।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 46, 'instruction', (select max(l.id) from language l), '1 के लिए सेट नकारात्मक संतुलन के साथ चालान अपनी शेष राशि हमेशा जगह लेने के लिए क्रेडिट के लिए एक नया चालान करने के लिए खत्म किया जाएगा, जिससे कि किसी भी आदेश की रचना नहीं है कि एक नया चालान उत्पन्न करने के लिए अनुमति देने के लिए। निष्क्रिय करने के लिए 0। पसंद 44 व 45 को आम तौर पर भी सक्षम हैं।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 47, 'description', (select max(l.id) from language l), 'पिछले पढ़ा मध्यस्थता रिकॉर्ड आईडी।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 47, 'instruction', (select max(l.id) from language l), 'मध्यस्थता प्रक्रिया के द्वारा पढ़ा पिछले रिकॉर्ड की आईडी। इस रिकॉर्ड के नए कर रहे हैं और पढ़ने की आवश्यकता क्या निर्धारित करने के लिए प्रयोग किया जाता है।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 49, 'description', (select max(l.id) from language l), 'स्वत: ग्राहक रिचार्ज दहलीज।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 49, 'instruction', (select max(l.id) from language l), 'स्वचालित भुगतान के लिए सीमा मूल्य। खाते की शेष राशि इस सीमा से नीचे गिर जाता है जब भी एक स्वचालित पुनर्भरण मूल्य सेट के साथ प्री-पेड यूजर्स एक स्वचालित भुगतान उत्पन्न होगा। आप AutoRechargeTask प्लग में इस सुविधा को पूरी तरह से कार्यशील होने के लिए विन्यस्त करने की जरूरत है कि ध्यान दें।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 50, 'description', (select max(l.id) from language l), 'चालान दशमलव गोलाई।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 50, 'instruction', (select max(l.id) from language l), 'दशमलव स्थानों की संख्या चालान पर दिखाया जा सकता है। 2 से चूक।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 51, 'description', (select max(l.id) from language l), 'उम्र बढ़ने की अनदेखी करने के लिए, जिसके लिए न्यूनतम शेष');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 51, 'instruction', (select max(l.id) from language l), '"सेट करते हैं उपयोगकर्ता बूढ़े या अवैतनिक चालान के लिए सूचनाएं प्राप्त करने के लिए जारी करने के लिए पर्याप्त संतुलन है यदि व्यापार एक चालान पर अतिदेय यदि अनदेखी करने के लिए तैयार है, न्यूनतम शेष है।, इस मूल्य का निर्धारण करेगा"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 52, 'description', (select max(l.id) from language l), 'सभी अतिदेय अधिसूचना करने के लिए नवीनतम चालान संलग्न।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 52, 'instruction', (select max(l.id) from language l), '"अतिदेय अधिसूचना अतिदेय 1 2 और सूचना ई-मेल करने के लिए चालान संलग्न नहीं करते। इस वरीयता के साथ डिफ़ॉल्ट रूप से 3, नवीनतम चालान स्वचालित रूप से इस तरह की सूचनाओं को संलग्न किया जा सकता है।"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 53, 'description', (select max(l.id) from language l), 'सेना के अनूठे ईमेल');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 53, 'instruction', (select max(l.id) from language l), 'कंपनी में उपयोगकर्ताओं / ग्राहकों के बीच अनूठे ईमेल के लिए मजबूर करने के क्रम में 1 पर सेट। अन्यथा 0 करने के लिए सेट करें।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 55, 'description', (select max(l.id) from language l), 'अनोखा उत्पाद कोड');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 55, 'instruction', (select max(l.id) from language l), '"एक उत्पाद के उत्पाद कोड या आंतरिक नंबर निर्धारित करते हैं तो अनूठा उत्पाद कोड, / आइटम अद्वितीय होना लागू किया जाएगा अनुमति देता है"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 61, 'description', (select max(l.id) from language l), 'एजेंट कमीशन के प्रकार');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 61, 'instruction', (select max(l.id) from language l), '"इकाई के लिए डिफ़ॉल्ट एजेंट का कमीशन प्रकार परिभाषित करता है, में से एक: चालान, भुगतान"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 63, 'description', (select max(l.id) from language l), 'टेबल के लिए JQGrid का उपयोग करना चाहिए');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 63, 'instruction', (select max(l.id) from language l), 'आम लेआउट का उपयोग करने के लिए 0 सेट या साइट की टेबल पर JQGrid का उपयोग करने के लिए 1 के लिए सेट');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 64, 'description', (select max(l.id) from language l), 'व्यास गंतव्य दायरे');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 64, 'instruction', (select max(l.id) from language l), '"दायरे आरोप लगाए जाने की। यह व्यास संदेशों मार्ग के लिए इस्तेमाल किया जा सकता है, तो एक स्थानीय रूप से विन्यस्त दायरे से मेल खाना चाहिए।"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 65, 'description', (select max(l.id) from language l), 'व्यास कोटा थ्रेसहोल्ड');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 65, 'instruction', (select max(l.id) from language l), 'सेकंड की इस संख्या को फिर से प्राधिकरण से अनुरोध करना चाहिए इकाई से निपटने के कॉल रहता है।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 66, 'description', (select max(l.id) from language l), 'व्यास सत्र ग्रेस पीरियड');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 66, 'instruction', (select max(l.id) from language l), 'व्यास सत्र जबरन बंद हो जाती हैं पहले सेकंड की संख्या में इंतजार करने के लिए।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 67, 'description', (select max(l.id) from language l), 'व्यास इकाइयों गुणक / भाजक');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 67, 'instruction', (select max(l.id) from language l), 'व्यास से प्राप्त इकाइयों मूल्य अन्य समय इकाइयों के लिए इनपुट सेकंड में परिवर्तित करने के लिए इस पहलू से गुणा / बांटा गया है। मूल्यों <1 1 के लिए गुणक निर्धारित किया है।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 68, 'description', (select max(l.id) from language l), 'खाते तालाबंदी समय');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 68, 'instruction', (select max(l.id) from language l), 'एक उपयोगकर्ता के खाते अनुमति प्रयासों की संख्या (वरीयता 39) के बाद बंद कर दिया रहेगा मिनट की संख्या समाप्त हो रहे हैं।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 70, 'description', (select max(l.id) from language l), 'निष्क्रिय खातों के दिनों के बाद समाप्त');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 70, 'instruction', (select max(l.id) from language l), 'दिनों की संख्या, जिसके बाद एक उपयोगकर्ता के खाते निष्क्रिय हो जाएगा। मतलब यह है कि उपयोगकर्ता के लिए jBilling के लिए लॉग इन करने की क्षमता को निष्क्रिय कर देगा।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 71, 'description', (select max(l.id) from language l), 'पासवर्ड भूल गए समाप्ति (घंटे)');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 71, 'instruction', (select max(l.id) from language l), 'घंटे पासवर्ड बदलने के लिए लिंक को समाप्त हो रहा है जब तक।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 75, 'description', (select max(l.id) from language l), 'साख डिफ़ॉल्ट रूप से बनाया जाना चाहिए');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 75, 'instruction', (select max(l.id) from language l), 'उपयोगकर्ता बनाया जाता है जब एक डिफ़ॉल्ट रूप से बनाया साख है। 0 (डिफ़ॉल्ट) क्रेडेंशियल सृजन निर्माण पर अनुरोध किया जा आवश्यकता होती है।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 76, 'description', (select max(l.id) from language l), 'डिफ़ॉल्ट एसेट आरक्षण अवधि');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 76, 'instruction', (select max(l.id) from language l), 'यहाँ डिफ़ॉल्ट एसेट आरक्षण मिनट जोड़ें। उत्पाद परिसंपत्ति सक्षम है, तो यह काम करेगा। (शून्य से अधिक होना चाहिए)');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 1, 'description', (select max(l.id) from language l), 'चालान (ई-मेल)');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 2, 'description', (select max(l.id) from language l), 'प्रयोक्ता पुन: सक्रिय');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 3, 'description', (select max(l.id) from language l), 'अतिदेय उपयोगकर्ता');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 4, 'description', (select max(l.id) from language l), 'उपयोगकर्ता अतिदेय 2');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 5, 'description', (select max(l.id) from language l), 'उपयोगकर्ता अतिदेय 3');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 6, 'description', (select max(l.id) from language l), 'उपयोगकर्ता निलंबित');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 7, 'description', (select max(l.id) from language l), 'प्रयोक्ता 2 निलंबित');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 8, 'description', (select max(l.id) from language l), 'उपयोगकर्ता 3 निलंबित');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 9, 'description', (select max(l.id) from language l), 'प्रयोक्ता हटाए गए');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 12, 'description', (select max(l.id) from language l), 'चालान (कागज)');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 13, 'description', (select max(l.id) from language l), 'समय सीमा समाप्त करने के बारे में आदेश। स्टेप 1');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 14, 'description', (select max(l.id) from language l), 'समय सीमा समाप्त करने के बारे में आदेश। चरण 2');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 15, 'description', (select max(l.id) from language l), 'समय सीमा समाप्त करने के बारे में आदेश। चरण 3');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 16, 'description', (select max(l.id) from language l), 'भुगतान सफल)');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 17, 'description', (select max(l.id) from language l), 'भुगतान असफल हुआ)');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 18, 'description', (select max(l.id) from language l), 'चालान रिमाइंडर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 19, 'description', (select max(l.id) from language l), 'अपडेट क्रेडिट कार्ड');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 20, 'description', (select max(l.id) from language l), 'पासवर्ड खो गया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 21, 'description', (select max(l.id) from language l), 'साख सृजन');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 22, 'description', (select max(l.id) from language l), 'भुगतान में प्रवेश किया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 23, 'description', (select max(l.id) from language l), 'भुगतान (वापसी)');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 24, 'description', (select max(l.id) from language l), 'सीमा से नीचे शेष');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 25, 'description', (select max(l.id) from language l), 'उपयोग पूल की खपत');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 26, 'description', (select max(l.id) from language l), 'क्रेडिट सीमा 1');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 27, 'description', (select max(l.id) from language l), 'क्रेडिट सीमा 2');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 10, 'description', (select max(l.id) from language l), 'ग्राहक बनाएं');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 11, 'description', (select max(l.id) from language l), 'संपादित ग्राहक');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 12, 'description', (select max(l.id) from language l), 'ग्राहक को हटाएँ');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 13, 'description', (select max(l.id) from language l), 'ग्राहक का निरीक्षण');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 14, 'description', (select max(l.id) from language l), 'ब्लैकलिस्ट ग्राहक');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 15, 'description', (select max(l.id) from language l), 'देखें ग्राहक के विवरण');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 16, 'description', (select max(l.id) from language l), 'डाउनलोड ग्राहक सीएसवी');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 17, 'description', (select max(l.id) from language l), 'सभी ग्राहकों को देखें');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 18, 'description', (select max(l.id) from language l), 'देखें ग्राहक उप खातों');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 20, 'description', (select max(l.id) from language l), 'आदेश बनाएं');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 21, 'description', (select max(l.id) from language l), 'संपादित करें आदेश');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 22, 'description', (select max(l.id) from language l), 'आदेश को हटाने');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 23, 'description', (select max(l.id) from language l), 'आदेश के लिए चालान उत्पन्न');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 24, 'description', (select max(l.id) from language l), 'आदेश को विस्तार से देखें');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 25, 'description', (select max(l.id) from language l), 'डाउनलोड आदेश सीएसवी');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 26, 'description', (select max(l.id) from language l), 'संपादित लाइन कीमत');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 27, 'description', (select max(l.id) from language l), 'संपादित लाइन विवरण');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 28, 'description', (select max(l.id) from language l), 'सभी ग्राहकों को देखें');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 29, 'description', (select max(l.id) from language l), 'देखें ग्राहक उप खातों');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 30, 'description', (select max(l.id) from language l), 'भुगतान बनाएं');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 31, 'description', (select max(l.id) from language l), 'संपादित करें भुगतान');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 32, 'description', (select max(l.id) from language l), 'भुगतान मिटायें');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 33, 'description', (select max(l.id) from language l), 'चालान करने के लिए भुगतान लिंक');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 34, 'description', (select max(l.id) from language l), 'देखें भुगतान की जानकारी');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 35, 'description', (select max(l.id) from language l), 'डाउनलोड भुगतान सीएसवी');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 36, 'description', (select max(l.id) from language l), 'सभी ग्राहकों को देखें');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 37, 'description', (select max(l.id) from language l), 'देखें ग्राहक उप खातों');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 40, 'description', (select max(l.id) from language l), 'उत्पाद बनाएँ');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 41, 'description', (select max(l.id) from language l), 'संपादित उत्पाद');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 42, 'description', (select max(l.id) from language l), 'उत्पाद को हटाना');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 43, 'description', (select max(l.id) from language l), 'सारे उत्पाद विवरण');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 44, 'description', (select max(l.id) from language l), 'डाउनलोड उत्पाद सीएसवी');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 50, 'description', (select max(l.id) from language l), 'उत्पाद श्रेणी बनाएं');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 51, 'description', (select max(l.id) from language l), 'संपादित करें उत्पाद की श्रेणी');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 52, 'description', (select max(l.id) from language l), 'उत्पाद श्रेणी हटाएं');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 70, 'description', (select max(l.id) from language l), 'चालान मिटायें');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 71, 'description', (select max(l.id) from language l), 'चालान सूचना भेजें');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 72, 'description', (select max(l.id) from language l), 'देखें चालान विवरण');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 73, 'description', (select max(l.id) from language l), 'डाउनलोड चालान सीएसवी');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 74, 'description', (select max(l.id) from language l), 'सभी ग्राहकों को देखें');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 75, 'description', (select max(l.id) from language l), 'देखें ग्राहक उप खातों');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 80, 'description', (select max(l.id) from language l), '/ अस्वीकृत समीक्षा को मंजूरी');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 90, 'description', (select max(l.id) from language l), 'दिखाएँ ग्राहक मेनू');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 91, 'description', (select max(l.id) from language l), 'दिखाएँ चालान मेनू');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 92, 'description', (select max(l.id) from language l), 'शो आदेश मेनू');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 93, 'description', (select max(l.id) from language l), 'दिखाएँ भुगतान और रिफंड मेनू');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 94, 'description', (select max(l.id) from language l), 'दिखाएँ बिलिंग मेनू');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 95, 'description', (select max(l.id) from language l), 'मध्यस्थता मेनू दिखाएँ');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 96, 'description', (select max(l.id) from language l), 'दिखाएँ मेनू की रिपोर्ट');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 97, 'description', (select max(l.id) from language l), 'दिखाएँ उत्पादों मेनू');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 99, 'description', (select max(l.id) from language l), 'शो विन्यास मेनू');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 100, 'description', (select max(l.id) from language l), 'दिखाएँ एजेंट मेनू');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 101, 'description', (select max(l.id) from language l), 'एजेंट बनाएं');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 102, 'description', (select max(l.id) from language l), 'संपादित एजेंट');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 103, 'description', (select max(l.id) from language l), 'एजेंट मिटायें');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 104, 'description', (select max(l.id) from language l), 'देखें एजेंट विवरण');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 110, 'description', (select max(l.id) from language l), 'उप-खाते स्विच करने के लिए');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 111, 'description', (select max(l.id) from language l), 'किसी भी उपयोगकर्ता स्विच करने के लिए');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 120, 'description', (select max(l.id) from language l), 'वेब सेवा एपीआई पहुँच');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 121, 'description', (select max(l.id) from language l), 'ग्राहक के संपादित बिलिंग चक्र');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 1, 'description', (select max(l.id) from language l), 'सभी अनुमतियों के साथ एक आंतरिक उपयोगकर्ता');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 1, 'title', (select max(l.id) from language l), 'आंतरिक');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 2, 'description', (select max(l.id) from language l), 'एक इकाई के सुपर उपयोगकर्ता');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 2, 'title', (select max(l.id) from language l), 'सुपर उपयोगकर्ता');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 3, 'description', (select max(l.id) from language l), 'एक बिलिंग क्लर्क');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 3, 'title', (select max(l.id) from language l), 'क्लर्क');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 4, 'description', (select max(l.id) from language l), 'ग्राहकों को लाना होगा कि एक एजेंट');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 4, 'title', (select max(l.id) from language l), 'एजेंट');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 5, 'description', (select max(l.id) from language l), 'उसकी / उसके खाते क्वेरी करेगा कि एक ग्राहक');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 5, 'title', (select max(l.id) from language l), 'ग्राहक');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 6, 'description', (select max(l.id) from language l), 'उसकी / उसके खाते क्वेरी करेगा कि एक ग्राहक');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 6, 'title', (select max(l.id) from language l), 'ग्राहक');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 7, 'description', (select max(l.id) from language l), 'एक इकाई के सुपर उपयोगकर्ता');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 7, 'title', (select max(l.id) from language l), 'सुपर उपयोगकर्ता');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 8, 'description', (select max(l.id) from language l), 'एक बिलिंग क्लर्क');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 8, 'title', (select max(l.id) from language l), 'क्लर्क');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 9, 'description', (select max(l.id) from language l), 'एक इकाई के सुपर उपयोगकर्ता');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 9, 'title', (select max(l.id) from language l), 'सुपर उपयोगकर्ता');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 10, 'description', (select max(l.id) from language l), 'एक बिलिंग क्लर्क');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 10, 'title', (select max(l.id) from language l), 'क्लर्क');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 11, 'description', (select max(l.id) from language l), 'उसकी / उसके खाते क्वेरी करेगा कि एक ग्राहक');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 11, 'title', (select max(l.id) from language l), 'ग्राहक');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 12, 'description', (select max(l.id) from language l), 'ग्राहकों को लाना होगा कि एक साथी');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 12, 'title', (select max(l.id) from language l), 'एजेंट');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 1, 'description', (select max(l.id) from language l), 'अफ़ग़ानिस्तान');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 2, 'description', (select max(l.id) from language l), 'अल्बानिया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 3, 'description', (select max(l.id) from language l), 'एलजीरिया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 4, 'description', (select max(l.id) from language l), 'अमेरिकन समोआ');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 5, 'description', (select max(l.id) from language l), 'अंडोरा');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 6, 'description', (select max(l.id) from language l), 'अंगोला');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 7, 'description', (select max(l.id) from language l), 'एंगुइला');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 8, 'description', (select max(l.id) from language l), 'अंटार्कटिका');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 9, 'description', (select max(l.id) from language l), 'अंतिगुया और बार्बूडा');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 10, 'description', (select max(l.id) from language l), 'अर्जेंटीना');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 11, 'description', (select max(l.id) from language l), 'आर्मीनिया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 12, 'description', (select max(l.id) from language l), 'अरूबा');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 13, 'description', (select max(l.id) from language l), 'ऑस्ट्रेलिया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 14, 'description', (select max(l.id) from language l), 'ऑस्ट्रिया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 15, 'description', (select max(l.id) from language l), 'आज़रबाइजान');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 16, 'description', (select max(l.id) from language l), 'बहामा');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 17, 'description', (select max(l.id) from language l), 'बहरीन');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 18, 'description', (select max(l.id) from language l), 'बांग्लादेश');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 19, 'description', (select max(l.id) from language l), 'बारबाडोस');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 20, 'description', (select max(l.id) from language l), 'बेलोरूस');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 21, 'description', (select max(l.id) from language l), 'बेल्जियम');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 22, 'description', (select max(l.id) from language l), 'बेलीज');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 23, 'description', (select max(l.id) from language l), 'बेनिन');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 24, 'description', (select max(l.id) from language l), 'बरमूडा');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 25, 'description', (select max(l.id) from language l), 'भूटान');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 26, 'description', (select max(l.id) from language l), 'बोलीविया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 27, 'description', (select max(l.id) from language l), 'बोस्निया और हर्जेगोविना');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 28, 'description', (select max(l.id) from language l), 'बोत्सवाना');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 29, 'description', (select max(l.id) from language l), 'बुवेत आइलैंड');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 30, 'description', (select max(l.id) from language l), 'ब्राज़िल');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 31, 'description', (select max(l.id) from language l), 'ब्रिटेन और भारतीय समुद्री क्षेत्र');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 32, 'description', (select max(l.id) from language l), 'ब्रुनेई');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 33, 'description', (select max(l.id) from language l), 'बुल्गारिया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 34, 'description', (select max(l.id) from language l), 'बुर्किना फासो');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 35, 'description', (select max(l.id) from language l), 'बुस्र्न्दी');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 36, 'description', (select max(l.id) from language l), 'कंबोडिया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 37, 'description', (select max(l.id) from language l), 'कैमरून');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 38, 'description', (select max(l.id) from language l), 'कनाडा');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 39, 'description', (select max(l.id) from language l), 'केप वर्दे');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 40, 'description', (select max(l.id) from language l), 'केमैन टापू');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 41, 'description', (select max(l.id) from language l), 'केंद्रीय अफ्रीकन गणराज्य');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 42, 'description', (select max(l.id) from language l), 'काग़ज़ का टुकड़ा');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 43, 'description', (select max(l.id) from language l), 'चिली');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 44, 'description', (select max(l.id) from language l), 'चीन');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 45, 'description', (select max(l.id) from language l), 'क्रिसमस द्वीप');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 46, 'description', (select max(l.id) from language l), 'कोकोस (कीलिंग) द्वीप');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 47, 'description', (select max(l.id) from language l), 'कोलम्बिया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 48, 'description', (select max(l.id) from language l), 'कोमोरोस');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 49, 'description', (select max(l.id) from language l), 'कांगो');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 50, 'description', (select max(l.id) from language l), 'कुक द्वीपसमूह');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 51, 'description', (select max(l.id) from language l), 'कोस्टा रिका');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 52, 'description', (select max(l.id) from language l), 'Cï¿½1ï¿½7te डी आइवर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 53, 'description', (select max(l.id) from language l), 'क्रोएशिया (Hrvatska)');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 54, 'description', (select max(l.id) from language l), 'क्यूबा');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 55, 'description', (select max(l.id) from language l), 'साइप्रस');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 56, 'description', (select max(l.id) from language l), 'चेक गणतंत्र');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 57, 'description', (select max(l.id) from language l), 'कांगो (डीआरसी)');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 58, 'description', (select max(l.id) from language l), 'डेनमार्क');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 59, 'description', (select max(l.id) from language l), 'जिबूती');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 60, 'description', (select max(l.id) from language l), 'डोमिनिका');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 61, 'description', (select max(l.id) from language l), 'डोमिनिकन गणराज्य');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 62, 'description', (select max(l.id) from language l), 'पूर्वी तिमोर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 63, 'description', (select max(l.id) from language l), 'इक्वेडोर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 64, 'description', (select max(l.id) from language l), 'मिस्र');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 65, 'description', (select max(l.id) from language l), 'एल साल्वाडोर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 66, 'description', (select max(l.id) from language l), 'भूमध्यवर्ती गिनी');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 67, 'description', (select max(l.id) from language l), 'इरिट्रिया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 68, 'description', (select max(l.id) from language l), 'एस्तोनिया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 69, 'description', (select max(l.id) from language l), 'इथियोपिया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 70, 'description', (select max(l.id) from language l), 'फ़ॉकलैंड द्वीप (इस्लास माल्विनास)');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 71, 'description', (select max(l.id) from language l), 'फ़ैरो द्वीप');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 72, 'description', (select max(l.id) from language l), 'फिजी द्वीप समूह');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 73, 'description', (select max(l.id) from language l), 'फिनलैंड');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 74, 'description', (select max(l.id) from language l), 'फ्रांस');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 75, 'description', (select max(l.id) from language l), 'फ्रेंच गयाना');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 76, 'description', (select max(l.id) from language l), 'फ्रेंच पॉलीनेशिया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 77, 'description', (select max(l.id) from language l), 'फ्रांस के दक्षिणी और अंटार्कटिक भूमि');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 78, 'description', (select max(l.id) from language l), 'गैबॉन');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 79, 'description', (select max(l.id) from language l), 'गाम्बिया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 80, 'description', (select max(l.id) from language l), 'जॉर्जिया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 81, 'description', (select max(l.id) from language l), 'जर्मनी');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 82, 'description', (select max(l.id) from language l), 'घाना');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 83, 'description', (select max(l.id) from language l), 'जिब्राल्टर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 84, 'description', (select max(l.id) from language l), 'ग्रीस');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 85, 'description', (select max(l.id) from language l), 'ग्रीनलैंड');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 86, 'description', (select max(l.id) from language l), 'ग्रेनाडा');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 87, 'description', (select max(l.id) from language l), 'गुआदेलूप');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 88, 'description', (select max(l.id) from language l), 'गुआम');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 89, 'description', (select max(l.id) from language l), 'ग्वाटेमाला');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 90, 'description', (select max(l.id) from language l), 'गिन्नी');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 91, 'description', (select max(l.id) from language l), 'गिनी-बिसाऊ');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 92, 'description', (select max(l.id) from language l), 'गुयाना');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 93, 'description', (select max(l.id) from language l), 'हैती');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 94, 'description', (select max(l.id) from language l), 'हर्ड आइलैंड और मैकडोनाल्ड आइलैंड्स');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 95, 'description', (select max(l.id) from language l), 'होंडुरस');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 96, 'description', (select max(l.id) from language l), 'हांगकांग एसएआर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 97, 'description', (select max(l.id) from language l), 'हंगरी');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 98, 'description', (select max(l.id) from language l), 'आइसलैंड');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 99, 'description', (select max(l.id) from language l), 'इंडिया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 100, 'description', (select max(l.id) from language l), 'इंडोनेशिया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 101, 'description', (select max(l.id) from language l), 'ईरान');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 102, 'description', (select max(l.id) from language l), 'इराक');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 103, 'description', (select max(l.id) from language l), 'आयरलैंड');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 104, 'description', (select max(l.id) from language l), 'इजराइल');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 105, 'description', (select max(l.id) from language l), 'इटली');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 106, 'description', (select max(l.id) from language l), 'जमैका');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 107, 'description', (select max(l.id) from language l), 'जापान');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 108, 'description', (select max(l.id) from language l), 'जॉर्डन');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 109, 'description', (select max(l.id) from language l), 'कजाखस्तान');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 110, 'description', (select max(l.id) from language l), 'केन्या');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 111, 'description', (select max(l.id) from language l), 'किरिबाती');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 112, 'description', (select max(l.id) from language l), 'कोरिया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 113, 'description', (select max(l.id) from language l), 'कुवैट');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 114, 'description', (select max(l.id) from language l), 'किर्गिज़स्तान');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 115, 'description', (select max(l.id) from language l), 'लाओस');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 116, 'description', (select max(l.id) from language l), 'लातविया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 117, 'description', (select max(l.id) from language l), 'लेबनान');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 118, 'description', (select max(l.id) from language l), 'लिसोटो');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 119, 'description', (select max(l.id) from language l), 'लाइबेरिया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 120, 'description', (select max(l.id) from language l), 'लीबिया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 121, 'description', (select max(l.id) from language l), 'लिकटेंस्टीन');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 122, 'description', (select max(l.id) from language l), 'लिथुआनिया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 123, 'description', (select max(l.id) from language l), 'लक्जमबर्ग');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 124, 'description', (select max(l.id) from language l), 'मकाऊ एसएआर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 125, 'description', (select max(l.id) from language l), '"की मैसिडोनिया, पूर्व युगोस्लाव गणराज्य"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 126, 'description', (select max(l.id) from language l), 'मेडागास्कर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 127, 'description', (select max(l.id) from language l), 'मलावी');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 128, 'description', (select max(l.id) from language l), 'मलेशिया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 129, 'description', (select max(l.id) from language l), 'मालदीव');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 130, 'description', (select max(l.id) from language l), 'माली');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 131, 'description', (select max(l.id) from language l), 'माल्टा');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 132, 'description', (select max(l.id) from language l), 'मार्शल द्वीपसमूह');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 133, 'description', (select max(l.id) from language l), 'मार्टीनिक');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 134, 'description', (select max(l.id) from language l), 'मॉरिटानिया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 135, 'description', (select max(l.id) from language l), 'मॉरीशस');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 136, 'description', (select max(l.id) from language l), 'मैयट');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 137, 'description', (select max(l.id) from language l), 'मेक्सिको');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 138, 'description', (select max(l.id) from language l), 'माइक्रोनेशिया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 139, 'description', (select max(l.id) from language l), 'मोलदोवा');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 140, 'description', (select max(l.id) from language l), 'मोनाको');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 141, 'description', (select max(l.id) from language l), 'मंगोलिया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 142, 'description', (select max(l.id) from language l), 'मोंटसेराट');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 143, 'description', (select max(l.id) from language l), 'मोरक्को');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 144, 'description', (select max(l.id) from language l), 'मोजाम्बिक');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 145, 'description', (select max(l.id) from language l), 'म्यांमार');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 146, 'description', (select max(l.id) from language l), 'नामीबिया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 147, 'description', (select max(l.id) from language l), 'नाउरू');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 148, 'description', (select max(l.id) from language l), 'नेपाल');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 149, 'description', (select max(l.id) from language l), 'नीदरलैंड');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 150, 'description', (select max(l.id) from language l), 'नीदरलैंड्स एंटाइल्स');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 151, 'description', (select max(l.id) from language l), 'न्यू कैलेडोनिया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 152, 'description', (select max(l.id) from language l), 'न्यूजीलैंड');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 153, 'description', (select max(l.id) from language l), 'निकारागुआ');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 154, 'description', (select max(l.id) from language l), 'नाइजर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 155, 'description', (select max(l.id) from language l), 'नाइजीरिया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 156, 'description', (select max(l.id) from language l), 'नियू');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 157, 'description', (select max(l.id) from language l), 'नारफोक द्वीप');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 158, 'description', (select max(l.id) from language l), 'उत्तर कोरिया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 159, 'description', (select max(l.id) from language l), 'उत्तरी मारियाना द्वीप');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 160, 'description', (select max(l.id) from language l), 'नॉर्वे');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 161, 'description', (select max(l.id) from language l), 'ओमान');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 162, 'description', (select max(l.id) from language l), 'पाकिस्तान');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 163, 'description', (select max(l.id) from language l), 'पलाऊ');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 164, 'description', (select max(l.id) from language l), 'पनामा');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 165, 'description', (select max(l.id) from language l), 'पापुआ न्यू गिनी');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 166, 'description', (select max(l.id) from language l), 'परागुआ');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 167, 'description', (select max(l.id) from language l), 'पेरू');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 168, 'description', (select max(l.id) from language l), 'फिलीपींस');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 169, 'description', (select max(l.id) from language l), 'पिटकैर्न');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 170, 'description', (select max(l.id) from language l), 'पोलैंड');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 171, 'description', (select max(l.id) from language l), 'पुर्तगाल');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 172, 'description', (select max(l.id) from language l), 'प्यूर्टो रिको');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 173, 'description', (select max(l.id) from language l), 'कतर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 174, 'description', (select max(l.id) from language l), 'पुनर्मिलन');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 175, 'description', (select max(l.id) from language l), 'रोमानिया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 176, 'description', (select max(l.id) from language l), 'रूस');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 177, 'description', (select max(l.id) from language l), 'रवांडा');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 178, 'description', (select max(l.id) from language l), 'समोआ');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 179, 'description', (select max(l.id) from language l), 'सैन मारिनो');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 180, 'description', (select max(l.id) from language l), 'Sï¿½1ï¿½7o Tomï¿½1ï¿½7 और Prï¿½1ï¿½7ncipe');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 181, 'description', (select max(l.id) from language l), 'सऊदी अरब');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 182, 'description', (select max(l.id) from language l), 'सेनेगल');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 183, 'description', (select max(l.id) from language l), 'सर्बिया और मोंटेनेग्रो');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 184, 'description', (select max(l.id) from language l), 'सेशेल्स');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 185, 'description', (select max(l.id) from language l), 'सियरा लिओन');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 186, 'description', (select max(l.id) from language l), 'सिंगापुर');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 187, 'description', (select max(l.id) from language l), 'स्लोवाकिया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 188, 'description', (select max(l.id) from language l), 'स्लोवेनिया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 189, 'description', (select max(l.id) from language l), 'सोलोमन द्वीप');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 190, 'description', (select max(l.id) from language l), 'सोमालिया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 191, 'description', (select max(l.id) from language l), 'दक्षिण अफ्रीका');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 192, 'description', (select max(l.id) from language l), 'दक्षिण जॉर्जिया और साउथ सैंडविच आइलैंड्स');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 193, 'description', (select max(l.id) from language l), 'स्पेन');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 194, 'description', (select max(l.id) from language l), 'श्री लंका');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 195, 'description', (select max(l.id) from language l), 'सेंट हेलेना');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 196, 'description', (select max(l.id) from language l), 'सेंट किट्स और नेविस');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 197, 'description', (select max(l.id) from language l), 'सेंट लुशिया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 198, 'description', (select max(l.id) from language l), 'सेंट पियरे और मिकेलॉन');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 199, 'description', (select max(l.id) from language l), 'सेंट विंसेंट और ग्रेनेडाइंस');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 200, 'description', (select max(l.id) from language l), 'सूडान');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 201, 'description', (select max(l.id) from language l), 'सूरीनाम');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 202, 'description', (select max(l.id) from language l), 'स्वालबार्ड और जैन मायेन');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 203, 'description', (select max(l.id) from language l), 'स्वाजीलैंड');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 204, 'description', (select max(l.id) from language l), 'स्वीडन');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 205, 'description', (select max(l.id) from language l), 'स्विट्जरलैंड');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 206, 'description', (select max(l.id) from language l), 'सीरिया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 207, 'description', (select max(l.id) from language l), 'ताइवान');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 208, 'description', (select max(l.id) from language l), 'तजाकिस्तान');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 209, 'description', (select max(l.id) from language l), 'तंजानिया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 210, 'description', (select max(l.id) from language l), 'थाईलैंड');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 211, 'description', (select max(l.id) from language l), 'जाना');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 212, 'description', (select max(l.id) from language l), 'टोकेलाऊ');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 213, 'description', (select max(l.id) from language l), 'टोंगा');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 214, 'description', (select max(l.id) from language l), 'त्रिनिदाद और टोबैगो');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 215, 'description', (select max(l.id) from language l), 'ट्यूनीशिया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 216, 'description', (select max(l.id) from language l), 'तुर्की');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 217, 'description', (select max(l.id) from language l), 'तुर्कमेनिस्तान');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 218, 'description', (select max(l.id) from language l), 'तुर्क्स और कैकोज़ द्वीपसमूह');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 219, 'description', (select max(l.id) from language l), 'तुवालु');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 220, 'description', (select max(l.id) from language l), 'युगांडा');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 221, 'description', (select max(l.id) from language l), 'यूक्रेन');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 222, 'description', (select max(l.id) from language l), 'संयुक्त अरब अमीरात');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 223, 'description', (select max(l.id) from language l), 'यूनाइटेड किंगडम');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 224, 'description', (select max(l.id) from language l), 'संयुक्त राज्य अमेरिका');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 225, 'description', (select max(l.id) from language l), 'संयुक्त राज्य अमेरिका के छोटे दूरस्थ द्वीपसमूह');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 226, 'description', (select max(l.id) from language l), 'उरुग्वे');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 227, 'description', (select max(l.id) from language l), 'उज़्बेकिस्तान');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 228, 'description', (select max(l.id) from language l), 'वानुअतु');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 229, 'description', (select max(l.id) from language l), 'वेटिकन सिटी');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 230, 'description', (select max(l.id) from language l), 'वेनेजुएला');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 231, 'description', (select max(l.id) from language l), 'वियतनाम');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 232, 'description', (select max(l.id) from language l), 'वर्जिन द्वीप समूह (ब्रिटिश)');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 233, 'description', (select max(l.id) from language l), 'वर्जिन द्वीपसमूह');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 234, 'description', (select max(l.id) from language l), 'वाली और फ़्युटुना');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 235, 'description', (select max(l.id) from language l), 'यमन');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 236, 'description', (select max(l.id) from language l), 'जाम्बिया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 237, 'description', (select max(l.id) from language l), 'जिम्बाब्वे');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (69, 1, 'welcome_message', (select max(l.id) from language l), '"<Div> <br/> <पी शैली = font-size: 19px; फ़ॉन्ट वजन: बोल्ड;>! आपका स्वागत है अकड़नेवाला टट्टू बिलिंग करने के लिए </ p> <br/> <पी शैली = font-size: 14px; text-align = बाईं; padding-left: 15; > यहां से आप अपने नवीनतम चालान की समीक्षा करने और यह तुम भी अपने सभी पिछले चालान और भुगतान देख सकते हैं तुरन्त भुगतान पाने के लिए और स्वचालित भुगतान के लिए प्रणाली स्थापित कर सकते हैं। अपने क्रेडिट कार्ड के साथ </ p> <p शैली = font-size: 14px; padding-left; = बाईं text-align: 15;>। क्या आप आज क्या करना चाहते हैं क्या </ p> <उल शैली = font-size: 13px; padding-left; = बाईं text-align: 25;> <li> बाईं पट्टी पर लिंक का पालन करें, एक क्रेडिट कार्ड भुगतान प्रस्तुत करने के लिए </ li> <li> एक सूची देखने के लिए। अपने चालान की। सूची में पहली बार चालान अपने नवीनतम चालान है। एक ???? Invoicesâ ???? मेनू विकल्प पर क्लिक कर अपने विवरण देखने के लिए उस पर क्लिक करें। </ li> <li> एक सूची देखने के लिए अपने भुगतान की। सूची में पहली बार भुगतान अपने नवीनतम भुगतान है। एक ???? Paymentsâ ???? मेनू विकल्प पर क्लिक कर अपने विवरण देखने के लिए उस पर क्लिक करें। </ li> <li> एक क्रेडिट प्रदान करने के लिए कार्ड और फिर क्रेडिट कार्ड संपादित करें पर, मेनू विकल्प खाता पर क्लिक करें, स्वचालित भुगतान कर सकें। </ li> </ ul> </ div> "');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (69, 2, 'welcome_message', (select max(l.id) from language l), '"<Div> <br/> <पी शैली = font-size: 19px; फ़ॉन्ट वजन: बोल्ड;>! आपका स्वागत है Mordor इंक बिलिंग करने के लिए </ p> <br/> <पी शैली = font-size : 14px; text-align = बाईं; padding-left: 15; > यहां से आप अपने नवीनतम चालान की समीक्षा करने और यह तुम भी अपने सभी पिछले चालान और भुगतान देख सकते हैं तुरन्त भुगतान पाने के लिए और स्वत: के लिए प्रणाली स्थापित कर सकते हैं। । आपके क्रेडिट कार्ड से भुगतान </ p> <p शैली = font-size: 14px; padding-left; = बाईं text-align: 15;> क्या आप आज क्या करना चाहते हैं क्या </ p> <उल शैली = font-size: 13px; padding-left; = बाईं text-align: 25;> <li> बाईं पट्टी पर लिंक का पालन करें, एक क्रेडिट कार्ड भुगतान प्रस्तुत करने के लिए </ li> <li> एक को देखने के लिए। अपने चालान की सूची। सूची में पहली बार चालान अपने नवीनतम चालान है। एक पर ???? Invoicesâ ???? मेनू विकल्प पर क्लिक करें अपने विवरण देखने के लिए उस पर क्लिक करें। </ li> <li> एक को देखने के लिए अपने भुगतान की सूची। सूची में पहली बार भुगतान अपने नवीनतम भुगतान है। एक पर ???? Paymentsâ ???? मेनू विकल्प पर क्लिक करें अपने विवरण देखने के लिए उस पर क्लिक करें। </ li> <li> एक प्रदान करने के लिए क्रेडिट कार्ड और फिर क्रेडिट कार्ड संपादित करें पर, मेनू विकल्प खाता पर क्लिक करें, स्वचालित भुगतान कर सकें। </ li> </ ul> </ div> "');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (73, 1, 'description', (select max(l.id) from language l), 'व्यवस्था');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (73, 2, 'description', (select max(l.id) from language l), 'बीजक');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (73, 3, 'description', (select max(l.id) from language l), 'भुगतान');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (73, 4, 'description', (select max(l.id) from language l), 'धन की वापसी');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (73, 5, 'description', (select max(l.id) from language l), 'ग्राहक');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (73, 6, 'description', (select max(l.id) from language l), 'साथी');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (73, 7, 'description', (select max(l.id) from language l), 'साथी चयनित');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (73, 8, 'description', (select max(l.id) from language l), 'उपयोगकर्ता');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (73, 9, 'description', (select max(l.id) from language l), 'मद');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (81, 1, 'description', (select max(l.id) from language l), 'सक्रिय');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (81, 2, 'description', (select max(l.id) from language l), 'विचाराधीन सदस्यता खत्म');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (81, 3, 'description', (select max(l.id) from language l), 'सदस्यता रद्द');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (81, 4, 'description', (select max(l.id) from language l), 'लंबित समय सीमा समाप्त');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (81, 5, 'description', (select max(l.id) from language l), 'समय सीमा समाप्त');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (81, 6, 'description', (select max(l.id) from language l), 'Nonsubscriber');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (81, 7, 'description', (select max(l.id) from language l), 'बंद');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (88, 1, 'description', (select max(l.id) from language l), 'सक्रिय');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (88, 2, 'description', (select max(l.id) from language l), 'निष्क्रिय');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (88, 3, 'description', (select max(l.id) from language l), 'सक्रिय लंबित');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (88, 4, 'description', (select max(l.id) from language l), 'विचाराधीन निष्क्रिय');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (88, 5, 'description', (select max(l.id) from language l), 'विफल');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (88, 6, 'description', (select max(l.id) from language l), 'अनुपलब्ध');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (89, 1, 'description', (select max(l.id) from language l), 'कोई नहीं');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (89, 2, 'description', (select max(l.id) from language l), 'प्रीपेड बैलेंस');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (89, 3, 'description', (select max(l.id) from language l), 'क्रेडिट सीमा');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (90, 1, 'description', (select max(l.id) from language l), 'भुगतान किया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (90, 2, 'description', (select max(l.id) from language l), 'अवैतनिक');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (90, 3, 'description', (select max(l.id) from language l), 'किया');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (91, 1, 'description', (select max(l.id) from language l), 'डन और बिल');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (91, 2, 'description', (select max(l.id) from language l), 'डन और बिल नहीं');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (91, 3, 'description', (select max(l.id) from language l), 'त्रुटि का पता चला');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (91, 4, 'description', (select max(l.id) from language l), 'त्रुटि घोषित');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (92, 1, 'description', (select max(l.id) from language l), 'रनिंग');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (92, 2, 'description', (select max(l.id) from language l), 'समाप्त: सफल');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (92, 3, 'description', (select max(l.id) from language l), 'समाप्त: विफल रहा है');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (99, 1, 'description', (select max(l.id) from language l), 'परामर्श शुल्क');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (99, 2, 'description', (select max(l.id) from language l), 'भुगतान संसाधक');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (99, 3, 'description', (select max(l.id) from language l), 'आईपी ​​पता');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 1, 'description', (select max(l.id) from language l), 'कुल राशि की अवधि के आधार पर वर्गीकृत चालान।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 2, 'description', (select max(l.id) from language l), 'विस्तृत संतुलन उम्र बढ़ने की रिपोर्ट। उत्कृष्ट ग्राहक शेष राशि की उम्र से पता चलता है।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 3, 'description', (select max(l.id) from language l), 'उपयोगकर्ताओं की संख्या एक विशेष उत्पाद के लिए सदस्यता ली।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 4, 'description', (select max(l.id) from language l), 'कुल भुगतान राशि की अवधि के आधार पर वर्गीकृत प्राप्त किया।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 5, 'description', (select max(l.id) from language l), 'एक अवधि के भीतर बनाया ग्राहकों की संख्या।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 6, 'description', (select max(l.id) from language l), 'प्रति ग्राहक कुल राजस्व (प्राप्त भुगतान की राशि)।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 7, 'description', (select max(l.id) from language l), 'सरल खातों चालू खाते में शेष राशि दिखा प्राप्य रिपोर्ट।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 8, 'description', (select max(l.id) from language l), 'दिए गए दिन के लिए सभी चालान आरोपों के सामान्य खाता विवरण।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 9, 'description', (select max(l.id) from language l), '"आइटम प्रकार से वर्गीकृत किया दिए गए दिन के लिए सभी चालान आरोपों के सामान्य खाता सारांश।"');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 11, 'description', (select max(l.id) from language l), 'कुल उत्पाद की श्रेणी के आधार पर वर्गीकृत प्रति ग्राहक चालान।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 12, 'description', (select max(l.id) from language l), 'कुल वर्ष के आधार पर वर्गीकृत पिछले कुछ वर्षों में प्रति ग्राहक चालान।');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 13, 'description', (select max(l.id) from language l), 'दिनों की निर्धारित संख्या के भीतर उपयोगकर्ता गतिविधि के वक्तव्य');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (101, 1, 'description', (select max(l.id) from language l), 'चालान रिपोर्ट');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (101, 2, 'description', (select max(l.id) from language l), 'आदेश रिपोर्टें');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (101, 3, 'description', (select max(l.id) from language l), 'भुगतान रिपोर्ट');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (101, 4, 'description', (select max(l.id) from language l), 'ग्राहक रिपोर्टों');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (104, 1, 'description', (select max(l.id) from language l), 'चालान');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (104, 2, 'description', (select max(l.id) from language l), 'आदेश');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (104, 3, 'description', (select max(l.id) from language l), 'भुगतान');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (104, 4, 'description', (select max(l.id) from language l), 'उपयोगकर्ता');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (104, 5, 'description', (select max(l.id) from language l), 'कस्टम सूचनाएं');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (108, 1, 'description', (select max(l.id) from language l), 'समूह के सदस्य');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (108, 101, 'description', (select max(l.id) from language l), 'DefaultStatus');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (108, 102, 'description', (select max(l.id) from language l), 'AddToOrderStatus');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (108, 103, 'description', (select max(l.id) from language l), 'Available2');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (108, 104, 'description', (select max(l.id) from language l), 'UnAvailable2');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (111, 1, 'description', (select max(l.id) from language l), 'बुनियादी');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (111, 2, 'description', (select max(l.id) from language l), 'बुनियादी');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (111, 3, 'description', (select max(l.id) from language l), 'प्राइवेट');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (111, 4, 'description', (select max(l.id) from language l), 'व्यापार');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (111, 5, 'description', (select max(l.id) from language l), 'प्राइवेट');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (113, 19, 'errorMessage', (select max(l.id) from language l), 'मान्य नहीं ईमेल');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (113, 37, 'errorMessage', (select max(l.id) from language l), 'मान्य नहीं ईमेल');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (113, 57, 'errorMessage', (select max(l.id) from language l), 'मान्य नहीं ईमेल');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (113, 58, 'errorMessage', (select max(l.id) from language l), 'मान्य नहीं ईमेल');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (113, 71, 'errorMessage', (select max(l.id) from language l), 'मान्य नहीं ईमेल');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (113, 80, 'errorMessage', (select max(l.id) from language l), 'मान्य नहीं ईमेल');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 7, 'errorMessage', (select max(l.id) from language l), 'भुगतान कार्ड नंबर मान्य नहीं है');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 8, 'errorMessage', (select max(l.id) from language l), 'समाप्ति की तारीख प्रारूप माह / वर्ष में होना चाहिए');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 9, 'errorMessage', (select max(l.id) from language l), 'ए.बी.ए. रूटिंग या बैंक खाता संख्या केवल अंक हो सकता है');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 10, 'errorMessage', (select max(l.id) from language l), 'भुगतान कार्ड नंबर मान्य नहीं है');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 11, 'errorMessage', (select max(l.id) from language l), 'समाप्ति की तारीख प्रारूप माह / वर्ष में होना चाहिए');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 12, 'errorMessage', (select max(l.id) from language l), 'ए.बी.ए. रूटिंग या बैंक खाता संख्या केवल अंक हो सकता है');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 13, 'errorMessage', (select max(l.id) from language l), 'भुगतान कार्ड नंबर मान्य नहीं है');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 14, 'errorMessage', (select max(l.id) from language l), 'समाप्ति की तारीख प्रारूप माह / वर्ष में होना चाहिए');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 15, 'errorMessage', (select max(l.id) from language l), 'विफल लॉगिन प्रयास अधिक से अधिक 6 नहीं किया जा सकता');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 16, 'errorMessage', (select max(l.id) from language l), 'पासवर्डों 90 दिन से पहले समाप्त हो जाना चाहिए');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 17, 'errorMessage', (select max(l.id) from language l), 'निष्क्रिय खाता चेकों को जल्दी से कम 90 दिनों के लिए किया जाना चाहिए');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 18, 'errorMessage', (select max(l.id) from language l), 'आरक्षण अवधि 0 और 600000 के बीच होना चाहिए');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (115, 1, 'description', (select max(l.id) from language l), 'लंबित');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (115, 2, 'description', (select max(l.id) from language l), 'त्रुटि लागू');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (115, 3, 'description', (select max(l.id) from language l), 'आवेदन');

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('20160118-add-percentage-datespecificprice', 'Vikas Bodani', 'descriptors/database/jbilling-upgrade-4.1.xml', NOW(), 31, '7:3751fa4264e3b67af5490ed02210bf83', 'addColumn (x2), insert, sql', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.1.xml::Chinese Translation Texts::Manisha Gupta
INSERT INTO public.language (id, code, description) VALUES ((select max(l.id)+1 from language l), 'zh', 'Chinese');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 1, 'description', (select max(l.id) from language l), '美国美元');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 2, 'description', (select max(l.id) from language l), '加拿大元');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 3, 'description', (select max(l.id) from language l), '欧元');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 4, 'description', (select max(l.id) from language l), '日元');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 5, 'description', (select max(l.id) from language l), '英镑');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 6, 'description', (select max(l.id) from language l), '韩元');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 7, 'description', (select max(l.id) from language l), '瑞士法郎');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 8, 'description', (select max(l.id) from language l), '瑞典克朗');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 9, 'description', (select max(l.id) from language l), '新加坡元');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 10, 'description', (select max(l.id) from language l), '马来西亚林吉特');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 11, 'description', (select max(l.id) from language l), '澳大利亚元');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 12, 'description', (select max(l.id) from language l), '印度卢比');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 13, 'description', (select max(l.id) from language l), '中国人民币');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (6, 1, 'description', (select max(l.id) from language l), '月');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (6, 2, 'description', (select max(l.id) from language l), '周');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (6, 3, 'description', (select max(l.id) from language l), '日');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (6, 4, 'description', (select max(l.id) from language l), '年');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (6, 5, 'description', (select max(l.id) from language l), '半月刊');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (7, 1, 'description', (select max(l.id) from language l), '电子邮件');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (7, 2, 'description', (select max(l.id) from language l), '纸');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (7, 3, 'description', (select max(l.id) from language l), '电子邮件+纸');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9, 1, 'description', (select max(l.id) from language l), '活性');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9, 2, 'description', (select max(l.id) from language l), '老龄化第1天');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9, 3, 'description', (select max(l.id) from language l), '4老化日');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9, 4, 'description', (select max(l.id) from language l), '5老化日');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9, 5, 'description', (select max(l.id) from language l), '老龄化15天');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9, 6, 'description', (select max(l.id) from language l), '老化日16');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9, 7, 'description', (select max(l.id) from language l), '老龄化27天');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9, 8, 'description', (select max(l.id) from language l), '老龄化30天');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9, 9, 'description', (select max(l.id) from language l), '老龄化31天');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9, 10, 'description', (select max(l.id) from language l), '老龄化32天');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9, 11, 'description', (select max(l.id) from language l), '老化日40');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9, 12, 'description', (select max(l.id) from language l), '老化日45');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9, 13, 'description', (select max(l.id) from language l), '老化日50');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9, 14, 'description', (select max(l.id) from language l), '老化日55');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9, 15, 'description', (select max(l.id) from language l), '老化日65');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9, 16, 'description', (select max(l.id) from language l), '老化日90');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9, 17, 'description', (select max(l.id) from language l), '老化日180');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 1, 'description', (select max(l.id) from language l), '柠檬水 - 每天1次月票');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 2, 'description', (select max(l.id) from language l), '柠檬水 - 所有你能每月喝');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 3, 'description', (select max(l.id) from language l), '咖啡 - 每天一 - 每月');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 4, 'description', (select max(l.id) from language l), '毒藤汁（冷）');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 14, 'description', (select max(l.id) from language l), '10％精灵的折扣。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 24, 'description', (select max(l.id) from language l), '取消手续费');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 240, 'description', (select max(l.id) from language l), '货币测试项目');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 250, 'description', (select max(l.id) from language l), '柠檬水计划');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 251, 'description', (select max(l.id) from language l), '柠檬水计划 - 安装费');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 260, 'description', (select max(l.id) from language l), '从WS项目');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 270, 'description', (select max(l.id) from language l), '逾期付款违约金');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 1250, 'description', (select max(l.id) from language l), 'AM-1');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 2600, 'description', (select max(l.id) from language l), '柠檬水 - 通用');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 2601, 'description', (select max(l.id) from language l), '柠檬水 - 包括在计划');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 2602, 'description', (select max(l.id) from language l), '柠檬水');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 2700, 'description', (select max(l.id) from language l), '长途A计划 - 固定利率');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 2701, 'description', (select max(l.id) from language l), '长途B计划 - 固定利率');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 2702, 'description', (select max(l.id) from language l), '长途计划 - 包括1000分钟');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 2800, 'description', (select max(l.id) from language l), '长途电话');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 2801, 'description', (select max(l.id) from language l), '长途电话 - 包括');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 2900, 'description', (select max(l.id) from language l), '长途电话 - 通用');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 3000, 'description', (select max(l.id) from language l), '疯狂Brian的优惠计划');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 3100, 'description', (select max(l.id) from language l), '百分比线测试计划');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 3101, 'description', (select max(l.id) from language l), '酷计划');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (14, 320100, 'description', (select max(l.id) from language l), 'CALL 1');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (17, 1, 'description', (select max(l.id) from language l), '一次');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (17, 2, 'description', (select max(l.id) from language l), '每月一次');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (17, 3, 'description', (select max(l.id) from language l), '每月一次');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (17, 4, 'description', (select max(l.id) from language l), '每3个月');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (17, 5, 'description', (select max(l.id) from language l), '所有订单');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (17, 6, 'description', (select max(l.id) from language l), '每月一次');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (18, 1, 'description', (select max(l.id) from language l), '项目');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (18, 2, 'description', (select max(l.id) from language l), '税');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (18, 3, 'description', (select max(l.id) from language l), '罚款');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (18, 4, 'description', (select max(l.id) from language l), '折扣');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (18, 5, 'description', (select max(l.id) from language l), '订阅');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (18, 6, 'description', (select max(l.id) from language l), '计划');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (19, 1, 'description', (select max(l.id) from language l), '预付费');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (19, 2, 'description', (select max(l.id) from language l), '后付费');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (20, 1, 'description', (select max(l.id) from language l), '活性');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (20, 2, 'description', (select max(l.id) from language l), '完成');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (20, 3, 'description', (select max(l.id) from language l), '暂停');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (20, 4, 'description', (select max(l.id) from language l), '暂停（自动）');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (20, 400, 'description', (select max(l.id) from language l), '测试');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 1, 'description', (select max(l.id) from language l), '项目管理和订单行的总计算');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 2, 'description', (select max(l.id) from language l), '计费流程：阶滤波器');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 3, 'description', (select max(l.id) from language l), '开票过程：发票过滤器');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 4, 'description', (select max(l.id) from language l), '发票介绍');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 5, 'description', (select max(l.id) from language l), '计费流程：订单周期计算');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 6, 'description', (select max(l.id) from language l), '支付网关整合');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 7, 'description', (select max(l.id) from language l), '通知');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 8, 'description', (select max(l.id) from language l), '支付工具的选择');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 9, 'description', (select max(l.id) from language l), '处罚逾期发票');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 10, 'description', (select max(l.id) from language l), '当一个支付网关关闭警报');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 11, 'description', (select max(l.id) from language l), '订阅状态管理器');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 12, 'description', (select max(l.id) from language l), '异步支付处理参数');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 13, 'description', (select max(l.id) from language l), '添加一个产品订购');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 14, 'description', (select max(l.id) from language l), '产品价格');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 15, 'description', (select max(l.id) from language l), '调解器');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 16, 'description', (select max(l.id) from language l), '调解处理器');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 17, 'description', (select max(l.id) from language l), '通用内部事件监听器');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 19, 'description', (select max(l.id) from language l), '对预付费余额/授信额度购买验证');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 20, 'description', (select max(l.id) from language l), '计费流程：客户选择');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 21, 'description', (select max(l.id) from language l), '调解错误处理程序');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 22, 'description', (select max(l.id) from language l), '计划插件');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 23, 'description', (select max(l.id) from language l), '规则发电机');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 24, 'description', (select max(l.id) from language l), '老龄化，为客户提供过期发票');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 25, 'description', (select max(l.id) from language l), '代理佣金的计算过程。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 26, 'description', (select max(l.id) from language l), '“与远程位置的文件交换，上传和下载”');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 1, 'description', (select max(l.id) from language l), '“计算订单总额和总的每一行，考虑到项目的价格，数量和价格是否是个与否。”');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 1, 'title', (select max(l.id) from language l), '默认订单总计');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 2, 'description', (select max(l.id) from language l), '增加了额外的线路，以与一定百分比的电荷以便表示增值税。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 2, 'title', (select max(l.id) from language l), '增值税');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 3, 'description', (select max(l.id) from language l), '一个非常简单的实现，设置发票的到期日。截止日期是刚刚加入的时间内，以发票日期开始计算。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 3, 'title', (select max(l.id) from language l), '发票到期日');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 4, 'description', (select max(l.id) from language l), '“这个任务将复制在订单和发票到新发票的所有线路，考虑到涉及每个订单的期间，但期间不是馏分。它不会复制是税收的线路。每行的数量和总将通过的周期量相乘。“');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 4, 'title', (select max(l.id) from language l), '默认发票组成。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 5, 'description', (select max(l.id) from language l), '“决定如果订单应包括在发票对于给定的记帐过程，这是通过采取记帐过程的时间跨度，顺序期间，活性自/至等做”');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 5, 'title', (select max(l.id) from language l), '标准阶滤波器');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 6, 'description', (select max(l.id) from language l), '“始终返回true，这意味着逾期发票将结转到一个新的发票。”');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 6, 'title', (select max(l.id) from language l), '标准发票过滤器');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 7, 'description', (select max(l.id) from language l), '“计算要被包括在发票的开始和结束时期。这是通过采取记帐过程的时间跨度，顺序期间，因为活性完成/直到等。”');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 7, 'title', (select max(l.id) from language l), '默认排序期');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 8, 'description', (select max(l.id) from language l), '集成与authorize.net支付网关。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 8, 'title', (select max(l.id) from language l), 'Authorize.net支付处理器');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 9, 'description', (select max(l.id) from language l), '通知通过发送电子邮件的用户。它支持文本和HTML电子邮件');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 9, 'title', (select max(l.id) from language l), '标准的电子邮件通知');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 10, 'description', (select max(l.id) from language l), '“查找的支付方法提供给顾客的信息，优先的信用卡。换言之，将返回的信用汽车客户或在该顺序的ACH的信息”。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 10, 'title', (select max(l.id) from language l), '默认的付款信息');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 11, 'description', (select max(l.id) from language l), '插件仅用于测试');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 11, 'title', (select max(l.id) from language l), '对于合作伙伴的付款测试插件');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 12, 'description', (select max(l.id) from language l), '将生成一个发票的PDF版本。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 12, 'title', (select max(l.id) from language l), 'PDF发票的通知');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 14, 'description', (select max(l.id) from language l), '“返回总是假的，这使得jBilling永远延续发票到另一个新的发票。”');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 14, 'title', (select max(l.id) from language l), '没有发票结转');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 15, 'description', (select max(l.id) from language l), '将创建一个新的秩序带罚项。该项目被取为参数的任务。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 15, 'title', (select max(l.id) from language l), '罚息任务');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 16, 'description', (select max(l.id) from language l), '“扩展BasicOrderFilterTask，修改日期，使订单适用的数月之前，这将是使用默认过滤器。”');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 16, 'title', (select max(l.id) from language l), '预期阶滤波器');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 17, 'description', (select max(l.id) from language l), '“扩展BasicOrderPeriodTask，修改日期，使订单适用的数月之前，ITD是通过使用默认的任务。”');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 17, 'title', (select max(l.id) from language l), '预计订单周期。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 19, 'description', (select max(l.id) from language l), '扩展了标准authorize.net支付处理也处理了付款后发电子邮件至本公司。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 19, 'title', (select max(l.id) from language l), '电子邮件和工艺authorize.net');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 20, 'description', (select max(l.id) from language l), '当一个支付网关关闭发送电子邮件到计费管理员为报警信号。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 20, 'title', (select max(l.id) from language l), '支付网关下来报警');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 21, 'description', (select max(l.id) from language l), '测试付款处理器执行方案能够在不使用真实的支付网关测试jBillings功能。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 21, 'title', (select max(l.id) from language l), '测试付款处理器');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 22, 'description', (select max(l.id) from language l), '允许顾客被指定一个特定的支付网关。它检查自定义联系人字段来标识的网关，然后代表实际的支付处理到另一个插件。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 22, 'title', (select max(l.id) from language l), '基于自定义字段路由器付​​款处理器');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 23, 'description', (select max(l.id) from language l), '“它决定如何的支付事件影响的用户的预订状态，考虑到其当前状态和一个状态机。”');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 23, 'title', (select max(l.id) from language l), '默认订阅状态经理');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 24, 'description', (select max(l.id) from language l), '集成与ACH电子商务支付网关。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 24, 'title', (select max(l.id) from language l), 'ACH商务部付款处理器');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 25, 'description', (select max(l.id) from language l), '一个虚拟的任务，不用于异步支付处理添加任何参数。这是默认的。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 25, 'title', (select max(l.id) from language l), '标准的异步参数');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 26, 'description', (select max(l.id) from language l), '这个插件增加了参数异步支付处理让每个支付处理一个处理消息的bean。这是用在组合与路由器付款处理器插件。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 26, 'title', (select max(l.id) from language l), '路由器异步参数');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 28, 'description', (select max(l.id) from language l), '“它增加了项目的订单。如果该项目已经在命令，它仅更新的数量。”');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 28, 'title', (select max(l.id) from language l), '标准项目经理');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 29, 'description', (select max(l.id) from language l), '“这是一个以规则为基础的插件，它会做基本的项目经理做（实际上是调用它），但随后会执行外部规则。这些外部的规则有完全的控制上的改变是获得新订单项目“。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 29, 'title', (select max(l.id) from language l), '规则项目经理');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 30, 'description', (select max(l.id) from language l), '“这是一个以规则为基础的插件，它的总的订单行（通常这是价格乘以数量）计算，允许对外部规则的执行。”');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 30, 'title', (select max(l.id) from language l), '规则线路总');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 31, 'description', (select max(l.id) from language l), '这是一个以规则为基础的插件。它通过执行外部规则给出了价格的项目。然后，您可以在外部添加逻辑定价。它也由具有访问中介的定价数据集成与中介过程。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 31, 'title', (select max(l.id) from language l), '规则定价');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 32, 'description', (select max(l.id) from language l), '这是一个阅读器调解过程。它从一个文本文件，其字段一个字符（或字符串）是分开的读取记录。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 32, 'title', (select max(l.id) from language l), '分离文件阅读器');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 33, 'description', (select max(l.id) from language l), '“这是一个以规则为基础的插件（见第七章）。这需要一个事件的记录，从调解程序并执行外部规则翻译战绩进入计费有意义的数据。这是中介组件的核心，看？电信指南？获得更多的帮助。“');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 33, 'title', (select max(l.id) from language l), '规则调解处理器');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 34, 'description', (select max(l.id) from language l), '“这是一个阅读器的调解过程，它从一个文本文件，其字段位置固定读取记录，并且记录具有固定的长度。”');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 34, 'title', (select max(l.id) from language l), '固定长度的文件阅读器');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 35, 'description', (select max(l.id) from language l), '“这是完全一样的标准支付信息的任务，唯一的区别是，它不验证，如果信用卡过期。只有当你想提交付款使用过期的信用卡使用此插件。”');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 35, 'title', (select max(l.id) from language l), '未经验证付款信息');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 36, 'description', (select max(l.id) from language l), '“这个插件只用于测试目的，而是发送电子邮件（或其他实际通知），它只是存储在一个名为emails_sent.txt文件要发送的文字。”');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 36, 'title', (select max(l.id) from language l), '通知任务进行测试');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 37, 'description', (select max(l.id) from language l), '这个插件考虑到外地周期的订单开始计算分数阶段。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 37, 'title', (select max(l.id) from language l), '订单周期计算器亲的评级。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 38, 'description', (select max(l.id) from language l), '“当从订单生成发票时，该插件将有利于利率一段时间服用，每日为最小计费单位的任何部分。”');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 38, 'title', (select max(l.id) from language l), '与亲评级发票组成任务（一天分数）');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 39, 'description', (select max(l.id) from language l), '集成与Intraanuity支付网关。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 39, 'title', (select max(l.id) from language l), '支付过程的Intraanuity支付网关');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 40, 'description', (select max(l.id) from language l), '这个插件将创建一个新的秩序具有负价，以反映信贷当订单已经已开发票的期间内取消。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 40, 'title', (select max(l.id) from language l), '自动取消信贷。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 42, 'description', (select max(l.id) from language l), '用于到达真正的第三方支付机构的阻止付款。典型的配置是在处理链首付款处理器。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 42, 'title', (select max(l.id) from language l), '黑名单过滤付款处理器。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 43, 'description', (select max(l.id) from language l), '“导致用户及其相关的详细信息（如信用卡号，电话号码等）的时候他们的状态将暂停或更高列入黑名单。”');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 43, 'title', (select max(l.id) from language l), '当他们的状态将暂停或更高黑名单用户。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 44, 'description', (select max(l.id) from language l), '这是一个阅读器调解过程。它从一个JDBC数据库源读取记录。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 44, 'title', (select max(l.id) from language l), 'JDBC调解器。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 45, 'description', (select max(l.id) from language l), '“这是一个阅读器的调解过程，它是JDBC阅读器的扩展，允许一个MySQL数据库源的轻松配置。”');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 45, 'title', (select max(l.id) from language l), 'MySQL的调解器。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 49, 'description', (select max(l.id) from language l), '代表们以支付货币的实际支付处理另一个插件。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 49, 'title', (select max(l.id) from language l), '货币路由器付款处理器');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 51, 'description', (select max(l.id) from language l), '该过滤器将只与一个积极平衡的发票可结转到下一发票。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 51, 'title', (select max(l.id) from language l), '筛选出的结转负的发票。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 52, 'description', (select max(l.id) from language l), '它会产生与每个生成的发票一行的文件。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 52, 'title', (select max(l.id) from language l), '文件发票出口国。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 53, 'description', (select max(l.id) from language l), '它会调用一个包的规则，当一个内部事件发生。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 53, 'title', (select max(l.id) from language l), '规则呼叫者的事件。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 54, 'description', (select max(l.id) from language l), '这将更新客户的动态平衡（预付费或信用额度），当事件影响的平衡发生。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 54, 'title', (select max(l.id) from language l), '动态余额管理');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 55, 'title', (select max(l.id) from language l), '根据客户的账面余额验证。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 56, 'title', (select max(l.id) from language l), '根据规则，平衡验证。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 57, 'description', (select max(l.id) from language l), '集成的支付网关支付处理。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 57, 'title', (select max(l.id) from language l), '付款处理器，用于支付网关。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 58, 'description', (select max(l.id) from language l), '“保存在支付网关的信用卡信息，而不是jBilling DB”。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 58, 'title', (select max(l.id) from language l), '信用卡在外部存储。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 59, 'title', (select max(l.id) from language l), '规则项目经理2');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 60, 'title', (select max(l.id) from language l), '规则线共计 - 2');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 61, 'description', (select max(l.id) from language l), '这是一个以规则为基础的插件与jBilling 2.2.x中的中介模块兼容它通过执行外部规则给出了价格的项目。然后，您可以在外部添加逻辑定价。它也由具有访问中介的定价数据集成与中介过程。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 61, 'title', (select max(l.id) from language l), '规则定价2');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 63, 'description', (select max(l.id) from language l), '一个假插件测试，将存储在外部付款。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 63, 'title', (select max(l.id) from language l), '用于外部存储测试付款处理器。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 64, 'description', (select max(l.id) from language l), '付款处理器插件与RBS WorldPay的整合');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 64, 'title', (select max(l.id) from language l), 'WorldPay的整合');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 65, 'description', (select max(l.id) from language l), '“付款处理器插件与RBS WorldPay的集成，它存储信用卡信息（号码等）的网关。”');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 65, 'title', (select max(l.id) from language l), '与外部存储WorldPay的整合');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 66, 'description', (select max(l.id) from language l), '“监控客户的平衡，在达到一个极限，它要求一个实时支付”');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 66, 'title', (select max(l.id) from language l), '自动充值');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 67, 'description', (select max(l.id) from language l), '对于与Beanstream支付网关集成付款处理器');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 67, 'title', (select max(l.id) from language l), 'Beanstream网关整合');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 68, 'description', (select max(l.id) from language l), '与圣人支付网关集成付款处理器');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 68, 'title', (select max(l.id) from language l), '贤者支付网关集成');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 69, 'description', (select max(l.id) from language l), '在开票过程中运行到选择评估哪些用户调用。这种基本实现返回每个用户未在暂停（或更糟）状态');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 69, 'title', (select max(l.id) from language l), '标准计费过程用户过滤器');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 70, 'description', (select max(l.id) from language l), '在开票过程中运行到选择评估哪些用户调用。这仅返回用户有下一个发票日期早于结算处理订单。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 70, 'title', (select max(l.id) from language l), '选择开票过程中的用户过滤器');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 71, 'description', (select max(l.id) from language l), '事件记录有错误被保存到一个文件');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 73, 'description', (select max(l.id) from language l), '事件记录有错误被保存到数据库表');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 75, 'description', (select max(l.id) from language l), '提交支付给贝宝作为贝宝支付网关和存储信用卡信息，以及');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 75, 'title', (select max(l.id) from language l), '与外部存储贝宝集成');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 76, 'description', (select max(l.id) from language l), '提交支付authorize.net在authorize.net支付网关和存储信用卡信息，以及');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 76, 'title', (select max(l.id) from language l), '与外部存储Authorize.net整合');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 77, 'description', (select max(l.id) from language l), '代表们根据付款的付款方式实际支付处理另一个插件。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 77, 'title', (select max(l.id) from language l), '付款方式的路由器付款处理器');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 78, 'description', (select max(l.id) from language l), '动态生成基于Velocity模板规则。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 78, 'title', (select max(l.id) from language l), '动态规则生成器');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 79, 'description', (select max(l.id) from language l), '计划的任务执行调解程序。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 79, 'title', (select max(l.id) from language l), '调解过程任务');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 80, 'description', (select max(l.id) from language l), '计划的任务来执行结算过程。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 80, 'title', (select max(l.id) from language l), '开票过程任务');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 87, 'description', (select max(l.id) from language l), '年龄基于天数该帐户是过期的用户。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 87, 'title', (select max(l.id) from language l), '基本衰老');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 88, 'description', (select max(l.id) from language l), '计划的任务要执行的衰老过程。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 88, 'title', (select max(l.id) from language l), '老龄化进程的任务');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 89, 'description', (select max(l.id) from language l), '中世纪的基础上个工作日（节假日除外）的数量用户的帐户已经过期。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 89, 'title', (select max(l.id) from language l), '营业日老化');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 90, 'description', (select max(l.id) from language l), '类型SimpleTaxCompositionTask的可插入任务税目适用于发票，如果合作伙伴的国家代码相匹配。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 90, 'title', (select max(l.id) from language l), '国家税务发票组成任务');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 91, 'description', (select max(l.id) from language l), '类型AbstractChargeTask的可插入任务点球适用于有超过一个可配置的天期限到期日的发票。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 91, 'title', (select max(l.id) from language l), '付款方式惩罚任务');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 95, 'description', (select max(l.id) from language l), '类型的支付可插拔任务信息的任务，首先检查比，如果没有数据的首选方法是搜索其他付款方式首选付款方式');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 95, 'title', (select max(l.id) from language l), '替代付款方式任务');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 97, 'description', (select max(l.id) from language l), '这个任务是负责应用％-age或固定数额罚款的过期发票。这个任务是强大的，因为它执行此操作之前的计费过程中收集的订单。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 97, 'title', (select max(l.id) from language l), '点球任务的Overude发票');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 101, 'description', (select max(l.id) from language l), '在为本次活动自定义通知任务需要定制通知消息，并执行通知时，内部事件发生');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 101, 'title', (select max(l.id) from language l), '基于事件的自定义通知任务');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 102, 'description', (select max(l.id) from language l), '这是一个例子插件创建一个新的联系人时调用一个远程Web服务。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 102, 'title', (select max(l.id) from language l), '示例Web服务插件');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 105, 'description', (select max(l.id) from language l), '这个插件通过咨询Suretax引擎增加税收行的发票。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 105, 'title', (select max(l.id) from language l), 'Suretax插件');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 107, 'description', (select max(l.id) from language l), '这个插件将设置一个负数发票的平衡，总为0，创造一个信用支付剩余金额。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 107, 'title', (select max(l.id) from language l), '信用列入负面发票');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 108, 'description', (select max(l.id) from language l), 'InternalEventsTask的这种类型的可插式任务并监控如果用户预付费余额低于阈值电平并发送通知。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 108, 'title', (select max(l.id) from language l), '用户平衡值通知任务');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 109, 'description', (select max(l.id) from language l), '该插件提供了需要发送的每一个状态的用户状态（老化步骤），并通知之间的映射');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 109, 'title', (select max(l.id) from language l), '每个老化步骤定制用户通知');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 110, 'description', (select max(l.id) from language l), '此任务将删除超过一定时间的旧文件。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 110, 'title', (select max(l.id) from language l), '删除旧文件');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 111, 'description', (select max(l.id) from language l), '这个插件将更新AssetTransitions当一个资产状态更改。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 111, 'title', (select max(l.id) from language l), '更新资产转换');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 112, 'description', (select max(l.id) from language l), '当连接顺序合同期满该插件将消除资产所有者。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 112, 'title', (select max(l.id) from language l), '除去资产没有完订单');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 113, 'description', (select max(l.id) from language l), '类型InternalEventsTask的可插入任务监控，当订单的activeUntil变化');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 113, 'title', (select max(l.id) from language l), '订单取消任务');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 117, 'description', (select max(l.id) from language l), '该任务计划，计算代理的佣金的过程。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 117, 'title', (select max(l.id) from language l), '计算代理人的佣金');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 118, 'description', (select max(l.id) from language l), '这个任务计算代理“委员会。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 118, 'title', (select max(l.id) from language l), '基本代理人的佣金任务');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 119, 'description', (select max(l.id) from language l), '这个插件将创建支付佣金时，款项将发票联未链接。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 119, 'title', (select max(l.id) from language l), '生成支付佣金代理商。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 123, 'description', (select max(l.id) from language l), '触发文件下载/上传对抗第三方系统');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 123, 'title', (select max(l.id) from language l), '触发文件下载/上传');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 124, 'description', (select max(l.id) from language l), 'InternalEventsTask类型的可插入任务监控，如果用户预付费余额低于信贷限制1级或2级和发送通知。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 124, 'title', (select max(l.id) from language l), '用户金额限制通知任务');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 125, 'description', (select max(l.id) from language l), '这个插件将顺序更改过程中更改订单状态适用于为了改变选择。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 125, 'title', (select max(l.id) from language l), '更改订单更改订单状态的申请');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 126, 'description', (select max(l.id) from language l), '这是一个计划的插件，需要在尚未登录的为优先55指定的天数和更新存在状态，未激活用户。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 126, 'title', (select max(l.id) from language l), '不活跃的用户帐户管理插件');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 127, 'description', (select max(l.id) from language l), '这是处理基础上的项目使用的价格计算（缺省实现）。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 127, 'title', (select max(l.id) from language l), '基本定价任务');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (28, 2, 'description', (select max(l.id) from language l), '主');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (28, 3, 'description', (select max(l.id) from language l), '主');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (28, 4, 'description', (select max(l.id) from language l), '额外的联系');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35, 1, 'description', (select max(l.id) from language l), '支票');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35, 2, 'description', (select max(l.id) from language l), '签证');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35, 3, 'description', (select max(l.id) from language l), '万事达');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35, 4, 'description', (select max(l.id) from language l), 'AMEX');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35, 5, 'description', (select max(l.id) from language l), 'ACH');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35, 6, 'description', (select max(l.id) from language l), '发现');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35, 7, 'description', (select max(l.id) from language l), '食客');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35, 8, 'description', (select max(l.id) from language l), '贝宝');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35, 9, 'description', (select max(l.id) from language l), '支付网关键');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35, 15, 'description', (select max(l.id) from language l), '信用');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (41, 1, 'description', (select max(l.id) from language l), '成功');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (41, 2, 'description', (select max(l.id) from language l), '失败');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (41, 3, 'description', (select max(l.id) from language l), '处理器不可用');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (41, 4, 'description', (select max(l.id) from language l), '进入');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46, 1, 'description', (select max(l.id) from language l), '结算流程');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46, 2, 'description', (select max(l.id) from language l), '用户维护');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46, 3, 'description', (select max(l.id) from language l), '项目维护');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46, 4, 'description', (select max(l.id) from language l), '项目类型维护');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46, 5, 'description', (select max(l.id) from language l), '项目用户维修价格');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46, 6, 'description', (select max(l.id) from language l), '推广维护');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46, 7, 'description', (select max(l.id) from language l), '秩序维护');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46, 8, 'description', (select max(l.id) from language l), '信用卡维修');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46, 9, 'description', (select max(l.id) from language l), '发票维护');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 1, 'description', (select max(l.id) from language l), '预付费订单未付款的时间计费过程日期之前');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 2, 'description', (select max(l.id) from language l), '命令在过程的日期没有活动的时间。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 3, 'description', (select max(l.id) from language l), '至少有一个完整的周期已被计费。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 4, 'description', (select max(l.id) from language l), '已经记帐的当前日期。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 5, 'description', (select max(l.id) from language l), '这个命令必须maked排除在最后一道工序。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 6, 'description', (select max(l.id) from language l), '预付费订单到期后，被处理。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 7, 'description', (select max(l.id) from language l), '一排被标记为删除。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 8, 'description', (select max(l.id) from language l), '用户密码已更改。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 9, 'description', (select max(l.id) from language l), '一排已更新。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 10, 'description', (select max(l.id) from language l), '“运行计费过程，但审查发现未经批准的。”');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 11, 'description', (select max(l.id) from language l), '“运行计费过程，需要检讨，但不存在。”');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 12, 'description', (select max(l.id) from language l), '用户状态更改。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 13, 'description', (select max(l.id) from language l), '订单状态被改变。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 14, 'description', (select max(l.id) from language l), '“用户不得不被老化，但也有配置没有更多的步骤”。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 15, 'description', (select max(l.id) from language l), '“一个合作伙伴有支付准备好了，但没有支付工具。”');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 16, 'description', (select max(l.id) from language l), '采购订单的手动应用到发票。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 17, 'description', (select max(l.id) from language l), '该命令行已更新');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 18, 'description', (select max(l.id) from language l), '订单下一个结算日期已更改');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 19, 'description', (select max(l.id) from language l), '最后API调用来获取用户订阅状态转变');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 20, 'description', (select max(l.id) from language l), '用户订阅状态已经改变');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 21, 'description', (select max(l.id) from language l), '用户帐户被锁定');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 22, 'description', (select max(l.id) from language l), '该命令主要认购标志被改变');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 24, 'description', (select max(l.id) from language l), '未找到有效的付款方式。付款请求已被取消');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 25, 'description', (select max(l.id) from language l), '一个新行已创建');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 26, 'description', (select max(l.id) from language l), '“一个发票的订单被取消，信用为了创建”');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 27, 'description', (select max(l.id) from language l), '用户ID添加到黑名单');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 28, 'description', (select max(l.id) from language l), '用户ID被从黑名单中删除');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 32, 'description', (select max(l.id) from language l), '用户订阅地位并没有改变');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 33, 'description', (select max(l.id) from language l), '一个用户的动态的平衡已经改变');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 34, 'description', (select max(l.id) from language l), '如果孩子标志已更改发票');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 35, 'description', (select max(l.id) from language l), '经销商订购了发票产生的子实体中的根实体创建的。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 37, 'description', (select max(l.id) from language l), '失败的登录尝试。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 38, 'description', (select max(l.id) from language l), '用户登录成功');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 39, 'description', (select max(l.id) from language l), '用户注销成功');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 40, 'description', (select max(l.id) from language l), '用户登录失败是由于不正确的用户名/密码');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 4, 'description', (select max(l.id) from language l), '宽限期');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 4, 'instruction', (select max(l.id) from language l), '宽限期天老客户有逾期发票前。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 13, 'description', (select max(l.id) from language l), '自递纸发票');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 13, 'instruction', (select max(l.id) from language l), '设置为“1”，以电子邮件的发票作为记账公司。 “0”提供发票的jBilling。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 14, 'description', (select max(l.id) from language l), '包括客户笔记发票');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 14, 'instruction', (select max(l.id) from language l), '“设置为”1“，在发票显示的笔记，”0“禁用”。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 15, 'description', (select max(l.id) from language l), '到期前的天数为订单通知');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 15, 'instruction', (select max(l.id) from language l), '前几天的命令“有效，直到”日发送第一通知。留空将禁用。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 16, 'description', (select max(l.id) from language l), '到期前的天数为订单通知2');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 16, 'instruction', (select max(l.id) from language l), '前几天的命令“有效，直到”日发送第二通知。留空将禁用。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 17, 'description', (select max(l.id) from language l), '到期前的天数为订单通知3');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 17, 'instruction', (select max(l.id) from language l), '前几天的命令“有效，直到”日送3日通知。留空将禁用。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 18, 'description', (select max(l.id) from language l), '发票号码前缀');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 18, 'instruction', (select max(l.id) from language l), '对于产生的发票公用号前缀值。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 19, 'description', (select max(l.id) from language l), '下一步发票号码');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 19, 'instruction', (select max(l.id) from language l), '的当前值生成发票公用号。新发票将通过增加此值被分配一个公共号码。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 20, 'description', (select max(l.id) from language l), '手工发票缺失');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 20, 'instruction', (select max(l.id) from language l), '“设置为”1“，以允许发票被删除，”0“以禁止”。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 21, 'description', (select max(l.id) from language l), '使用发票的催');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 21, 'instruction', (select max(l.id) from language l), '“设置为”1“，使发票的提醒通知，”0“禁用”。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 22, 'description', (select max(l.id) from language l), '天数发票代的第一次提醒后，');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 23, 'description', (select max(l.id) from language l), '明年提醒天数');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 24, 'description', (select max(l.id) from language l), '数据Fattura精细MESE');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 24, 'instruction', (select max(l.id) from language l), '“设置为”1“启用，”0“禁用”。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 25, 'description', (select max(l.id) from language l), '使用过期罚款（利息）。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 25, 'instruction', (select max(l.id) from language l), '“设置为”1“，使收费过程来计算逾期付款利息，”0“为禁用。利息的计算是由选定的处罚插件处理。”');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 27, 'description', (select max(l.id) from language l), '使用顺序期待。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 27, 'instruction', (select max(l.id) from language l), '“设置为”1“用”“OrderFilterAnticipateTask”“要发票数月提前，”0“为禁用。插件必须单独配置。”');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 28, 'description', (select max(l.id) from language l), '贝宝帐户。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 28, 'instruction', (select max(l.id) from language l), 'PayPal帐户名称。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 29, 'description', (select max(l.id) from language l), 'PayPal按钮的URL。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 29, 'instruction', (select max(l.id) from language l), '“那里的PayPal按钮的图形所在的URL，显示的按钮，客户在他们正在付款，默认通常是最好的选择，除非是必要的另一种语言。”');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 30, 'description', (select max(l.id) from language l), '网址HTTP老化回调。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 30, 'instruction', (select max(l.id) from language l), '网址为HTTP回调调用时老化过程改变的用户的状态。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 31, 'description', (select max(l.id) from language l), '连续使用发票日期。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 31, 'instruction', (select max(l.id) from language l), '“默认为空这首已经是一个日期（格式为YYYY-MM-DD例如：2000-01-31），该系统将确保所有的发票都有其日期增量方式的任何发票。一个更大的“ID”也将有较大的（或等于）日期。换句话说，一个新的发票不能有一个更早的日期比现有的（旧的）发票。要使用此首选项，将其设置为一个字符串的日期从哪里开始。这种偏好将不会被使用，如果空白“');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 32, 'description', (select max(l.id) from language l), '附加PDF发票的电子邮件通知。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 32, 'instruction', (select max(l.id) from language l), '设置为“1”附上发票的PDF版本的所有发票的通知邮件。 “0”为禁用。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 33, 'description', (select max(l.id) from language l), '强制每张发票一个数量级。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 33, 'instruction', (select max(l.id) from language l), '“设置为”1“以显示”，“包括在单独的发票”，“标志的量级。”0“以禁止”。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 35, 'description', (select max(l.id) from language l), '添加订单ID为发票行。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 35, 'instruction', (select max(l.id) from language l), '“设置为”1“，包括在所产生的发票行的描述文本的顺序的编号。”0“为禁用。这可以帮助轻松地跟踪它的确切订单，负责在发票行，考虑到许多命令可以包括在单个发票“。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 36, 'description', (select max(l.id) from language l), '让客户修改自己的联系信息。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 36, 'instruction', (select max(l.id) from language l), '设置为“1”，让客户编辑自己的联系信息。 “0”为禁用。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 38, 'description', (select max(l.id) from language l), '链接老化客户的用户状态。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 38, 'instruction', (select max(l.id) from language l), '设置为1来改变用户的年龄在用户的预订状态。 “0”为禁用。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 39, 'description', (select max(l.id) from language l), '锁定用户的登录尝试失败之后。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 39, 'instruction', (select max(l.id) from language l), '“重试次数，以便锁定用户帐户之前，锁定的用户帐户将被锁定在偏好68.要启用此锁定功能指定的分钟数，设置首选项68到非零值是必须的。”');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 40, 'description', (select max(l.id) from language l), '天后过期用户密码。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 40, 'instruction', (select max(l.id) from language l), '“如果大于零，它代表的天数，一个口令是有效的。这些天之后，密码已过期，用户被强制改变它。”');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 41, 'description', (select max(l.id) from language l), '使用的主要认购订单。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 41, 'instruction', (select max(l.id) from language l), '设置为1，以允许“主订阅标志的使用订单时确定在哪里放置电荷从外部事件即将此标志只读由中介过程。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 42, 'description', (select max(l.id) from language l), '利用Pro评级。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 42, 'instruction', (select max(l.id) from language l), '设置为“1”，以允许使用亲评级发票一段分数。显示了顺序的“循环”属性。请注意，您需要配置相应的插件，此功能才能充分发挥作用。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 43, 'description', (select max(l.id) from language l), '使用支付黑名单。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 43, 'instruction', (select max(l.id) from language l), '“如果支付黑名单功能时，该设定为PaymentFilterTask插件配置的ID，请参阅文件的黑名单部分。”');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 44, 'description', (select max(l.id) from language l), '允许负付款。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 44, 'instruction', (select max(l.id) from language l), '设置为“1”允许负付款。 “0”来禁用');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 45, 'description', (select max(l.id) from language l), '延迟负数发票付款。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 45, 'instruction', (select max(l.id) from language l), '“设置为”1“拖延付款的负面发票金额，导致平衡被结转到下一张发票。从转移到他们的其他发票的，有负面的余额发票被允许立即做出负面支付（信用卡），如果必要的。“0”来禁用。偏好44 46通常也被激活。“');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 46, 'description', (select max(l.id) from language l), '允许发票没有订单。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 46, 'instruction', (select max(l.id) from language l), '设置为“1”，使发票负余额产生不是由任何订单，使他们的余额总是会得到结转到一个新的发票的信用发生了新的发票。 “0”为禁用。偏好44 45通常也被激活。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 47, 'description', (select max(l.id) from language l), '最近读调解记录ID。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 47, 'instruction', (select max(l.id) from language l), '在调解过程中读取的最后一条记录的ID。这被用来确定哪些记录是“新的”，需要进行读取。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 49, 'description', (select max(l.id) from language l), '自动客户充值门槛。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 49, 'instruction', (select max(l.id) from language l), '自动付款的阈值。预付费用户提供了一个自动充值值集将产生一个自动付款时账户余额低于这个门槛。请注意，您需要配置AutoRechargeTask插件，此功能才能充分发挥作用。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 50, 'description', (select max(l.id) from language l), '发票小数四舍五入。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 50, 'instruction', (select max(l.id) from language l), '要显示在发票上的小数位数。默认为2。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 51, 'description', (select max(l.id) from language l), '为此忽略衰老最低余额');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 51, 'instruction', (select max(l.id) from language l), '“最低余额，该企业是愿意，如果逾期发票，不容忽视。如果设置，该值将确定用户是否有足够的余额继续老化或接收通知未付发票”');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 52, 'description', (select max(l.id) from language l), '安装最新的发票给所有逾期通知。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 52, 'instruction', (select max(l.id) from language l), '“逾期通知逾期1 2 3默认情况下不重视发票的通知邮件。通过此偏好，最新的发票可以自动连接到这样的通知。”');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 53, 'description', (select max(l.id) from language l), '力独特的电子邮件');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 53, 'instruction', (select max(l.id) from language l), '为了迫使之间的用户/客户提供独特的邮件进入公司设置为1。设置为0。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 55, 'description', (select max(l.id) from language l), '唯一的产品代码');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 55, 'instruction', (select max(l.id) from language l), '“允许唯一的产品代码，如果设置了产品代码或一个产品的内部编号/项目将被强制为独特的”');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 61, 'description', (select max(l.id) from language l), '代理佣金类型');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 61, 'instruction', (select max(l.id) from language l), '“定义默认的代理人的佣金类型的实体之一：发票，付款”');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 63, 'description', (select max(l.id) from language l), '应该使用jqGrid的对表');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 63, 'instruction', (select max(l.id) from language l), '设置为0以使用公共布局或设置为1以使用jqGrid的网站上的表');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 64, 'description', (select max(l.id) from language l), '直径目的地境界');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 64, 'instruction', (select max(l.id) from language l), '“该领域进行充电。这可以用于路由Diameter消息，因此应该与本地配置的领域。”');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 65, 'description', (select max(l.id) from language l), '直径配额阈值');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 65, 'instruction', (select max(l.id) from language l), '当秒数仍是呼叫处理单元应要求重新授权。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 66, 'description', (select max(l.id) from language l), '直径会议宽限期');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 66, 'instruction', (select max(l.id) from language l), '几秒钟之前等待的直径会话强制关闭。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 67, 'description', (select max(l.id) from language l), '直径单位乘数/除数');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 67, 'instruction', (select max(l.id) from language l), '从直径接收的单位值被划分/乘以该系数输入秒转换成其他时间单位。值<1设定倍频为1。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 68, 'description', (select max(l.id) from language l), '帐户锁定时间');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 68, 'instruction', (select max(l.id) from language l), '分用户的帐户将继续允许的重试次数（39首）后锁定的数量已耗尽。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 70, 'description', (select max(l.id) from language l), '到期不活动的帐户天后');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 70, 'instruction', (select max(l.id) from language l), '天数之后，用户的帐户将变为无效。这将禁用登录到jBilling该用户的能力。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 71, 'description', (select max(l.id) from language l), '忘记密码到期（小时）');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 71, 'instruction', (select max(l.id) from language l), '小时，直到链接，密码更改到期。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 75, 'description', (select max(l.id) from language l), '如果证书被默认创建');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 75, 'instruction', (select max(l.id) from language l), '在创建用户时1有默认创建的凭据。 0（默认值），要求在创建凭证创建请求。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 76, 'description', (select max(l.id) from language l), '默认资产预约时间');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 76, 'instruction', (select max(l.id) from language l), '在这里添加默认的资产保留分钟。它会工作，如果产品是资产启用。 （必须大于零）');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 1, 'description', (select max(l.id) from language l), '发票（电子邮件）');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 2, 'description', (select max(l.id) from language l), '用户重新激活');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 3, 'description', (select max(l.id) from language l), '用户逾期');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 4, 'description', (select max(l.id) from language l), '用户逾期2');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 5, 'description', (select max(l.id) from language l), '用户逾期3');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 6, 'description', (select max(l.id) from language l), '用户暂停');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 7, 'description', (select max(l.id) from language l), '用户暂停2');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 8, 'description', (select max(l.id) from language l), '用户暂停3');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 9, 'description', (select max(l.id) from language l), '用户已删除');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 12, 'description', (select max(l.id) from language l), '发票（纸）');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 13, 'description', (select max(l.id) from language l), '订购即将到期。步骤1');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 14, 'description', (select max(l.id) from language l), '订购即将到期。第2步');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 15, 'description', (select max(l.id) from language l), '订购即将到期。第3步');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 16, 'description', (select max(l.id) from language l), '付款（成功）');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 17, 'description', (select max(l.id) from language l), '支付失败）');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 18, 'description', (select max(l.id) from language l), '发票提示');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 19, 'description', (select max(l.id) from language l), '更新信用卡');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 20, 'description', (select max(l.id) from language l), '密码丢失');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 21, 'description', (select max(l.id) from language l), '证书创建');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 22, 'description', (select max(l.id) from language l), '支付进入');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 23, 'description', (select max(l.id) from language l), '付款（退款）');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 24, 'description', (select max(l.id) from language l), '余额低于阈值');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 25, 'description', (select max(l.id) from language l), '用法池消费');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 26, 'description', (select max(l.id) from language l), '信贷限制1');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 27, 'description', (select max(l.id) from language l), '信贷限制2');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 10, 'description', (select max(l.id) from language l), '创建客户');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 11, 'description', (select max(l.id) from language l), '编辑客户');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 12, 'description', (select max(l.id) from language l), '删除用户');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 13, 'description', (select max(l.id) from language l), '检查客户');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 14, 'description', (select max(l.id) from language l), '黑名单客户');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 15, 'description', (select max(l.id) from language l), '查看客户详细信息');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 16, 'description', (select max(l.id) from language l), '下载客户CSV');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 17, 'description', (select max(l.id) from language l), '查看所有客户');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 18, 'description', (select max(l.id) from language l), '查看客户子帐户');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 20, 'description', (select max(l.id) from language l), '创建订单');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 21, 'description', (select max(l.id) from language l), '编辑订单');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 22, 'description', (select max(l.id) from language l), '删除订单');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 23, 'description', (select max(l.id) from language l), '生成发票订单');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 24, 'description', (select max(l.id) from language l), '查看订单详情');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 25, 'description', (select max(l.id) from language l), '为了下载CSV');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 26, 'description', (select max(l.id) from language l), '编辑线价格');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 27, 'description', (select max(l.id) from language l), '编辑线路描述');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 28, 'description', (select max(l.id) from language l), '查看所有客户');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 29, 'description', (select max(l.id) from language l), '查看客户子帐户');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 30, 'description', (select max(l.id) from language l), '创建付款');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 31, 'description', (select max(l.id) from language l), '编辑付款');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 32, 'description', (select max(l.id) from language l), '删除付款');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 33, 'description', (select max(l.id) from language l), '链接付款发票');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 34, 'description', (select max(l.id) from language l), '查看付款细节');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 35, 'description', (select max(l.id) from language l), '下载支付CSV');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 36, 'description', (select max(l.id) from language l), '查看所有客户');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 37, 'description', (select max(l.id) from language l), '查看客户子帐户');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 40, 'description', (select max(l.id) from language l), '创建产品');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 41, 'description', (select max(l.id) from language l), '编辑产品');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 42, 'description', (select max(l.id) from language l), '删除产品');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 43, 'description', (select max(l.id) from language l), '查看产品详细');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 44, 'description', (select max(l.id) from language l), '下载产品CSV');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 50, 'description', (select max(l.id) from language l), '创建产品类别');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 51, 'description', (select max(l.id) from language l), '编辑产品类别');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 52, 'description', (select max(l.id) from language l), '删除产品类别');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 70, 'description', (select max(l.id) from language l), '删除发票');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 71, 'description', (select max(l.id) from language l), '发送发票通知');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 72, 'description', (select max(l.id) from language l), '查看发票明细');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 73, 'description', (select max(l.id) from language l), '下载发票CSV');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 74, 'description', (select max(l.id) from language l), '查看所有客户');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 75, 'description', (select max(l.id) from language l), '查看客户子帐户');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 80, 'description', (select max(l.id) from language l), '批准/不赞成审查');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 90, 'description', (select max(l.id) from language l), '显示客户菜单');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 91, 'description', (select max(l.id) from language l), '显示发票菜单');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 92, 'description', (select max(l.id) from language l), '为了显示菜单');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 93, 'description', (select max(l.id) from language l), '显示付款和退款菜单');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 94, 'description', (select max(l.id) from language l), '显示计费菜单');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 95, 'description', (select max(l.id) from language l), '显示调解菜单');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 96, 'description', (select max(l.id) from language l), '展会报道菜单');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 97, 'description', (select max(l.id) from language l), '显示产品菜单');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 99, 'description', (select max(l.id) from language l), '显示配置菜单');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 100, 'description', (select max(l.id) from language l), '展会代理菜单');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 101, 'description', (select max(l.id) from language l), '创建代理');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 102, 'description', (select max(l.id) from language l), '编辑代理');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 103, 'description', (select max(l.id) from language l), '删除代理');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 104, 'description', (select max(l.id) from language l), '查看代理商的详细信息');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 110, 'description', (select max(l.id) from language l), '切换到子账户');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 111, 'description', (select max(l.id) from language l), '切换到的任何用户');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 120, 'description', (select max(l.id) from language l), 'Web服务API访问');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 121, 'description', (select max(l.id) from language l), '客户修改结算周期');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 1, 'description', (select max(l.id) from language l), '所有的权限的内部用户');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 1, 'title', (select max(l.id) from language l), '内部');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 2, 'description', (select max(l.id) from language l), '一个实体的超级用户');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 2, 'title', (select max(l.id) from language l), '超级用户');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 3, 'description', (select max(l.id) from language l), '记帐业务员');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 3, 'title', (select max(l.id) from language l), '文员');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 4, 'description', (select max(l.id) from language l), '这将为客户带来A剂');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 4, 'title', (select max(l.id) from language l), '经纪人');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 5, 'description', (select max(l.id) from language l), '一位顾客会询问他/她的帐户');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 5, 'title', (select max(l.id) from language l), '顾客');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 6, 'description', (select max(l.id) from language l), '一位顾客会询问他/她的帐户');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 6, 'title', (select max(l.id) from language l), '顾客');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 7, 'description', (select max(l.id) from language l), '一个实体的超级用户');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 7, 'title', (select max(l.id) from language l), '超级用户');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 8, 'description', (select max(l.id) from language l), '记帐业务员');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 8, 'title', (select max(l.id) from language l), '文员');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 9, 'description', (select max(l.id) from language l), '一个实体的超级用户');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 9, 'title', (select max(l.id) from language l), '超级用户');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 10, 'description', (select max(l.id) from language l), '记帐业务员');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 10, 'title', (select max(l.id) from language l), '文员');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 11, 'description', (select max(l.id) from language l), '一位顾客会询问他/她的帐户');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 11, 'title', (select max(l.id) from language l), '顾客');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 12, 'description', (select max(l.id) from language l), '一个合作伙伴，将为客户带来');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 12, 'title', (select max(l.id) from language l), '经纪人');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 1, 'description', (select max(l.id) from language l), '阿富汗');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 2, 'description', (select max(l.id) from language l), '阿尔巴尼亚');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 3, 'description', (select max(l.id) from language l), '阿尔及利亚');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 4, 'description', (select max(l.id) from language l), '美属萨摩亚');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 5, 'description', (select max(l.id) from language l), '安道​​尔');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 6, 'description', (select max(l.id) from language l), '安哥拉');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 7, 'description', (select max(l.id) from language l), '安圭拉');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 8, 'description', (select max(l.id) from language l), '南极洲');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 9, 'description', (select max(l.id) from language l), '安提瓜和巴布达');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 10, 'description', (select max(l.id) from language l), '阿根廷');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 11, 'description', (select max(l.id) from language l), '亚美尼亚');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 12, 'description', (select max(l.id) from language l), '阿鲁巴岛');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 13, 'description', (select max(l.id) from language l), '澳大利亚');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 14, 'description', (select max(l.id) from language l), '奥地利');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 15, 'description', (select max(l.id) from language l), '阿塞拜疆');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 16, 'description', (select max(l.id) from language l), '巴哈马');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 17, 'description', (select max(l.id) from language l), '巴林');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 18, 'description', (select max(l.id) from language l), '孟加拉国');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 19, 'description', (select max(l.id) from language l), '巴巴多斯');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 20, 'description', (select max(l.id) from language l), '白俄罗斯');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 21, 'description', (select max(l.id) from language l), '比利时');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 22, 'description', (select max(l.id) from language l), '伯利兹');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 23, 'description', (select max(l.id) from language l), '贝宁');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 24, 'description', (select max(l.id) from language l), '百慕大');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 25, 'description', (select max(l.id) from language l), '不丹');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 26, 'description', (select max(l.id) from language l), '玻利维亚');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 27, 'description', (select max(l.id) from language l), '波斯尼亚和黑塞哥维那');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 28, 'description', (select max(l.id) from language l), '博茨瓦纳');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 29, 'description', (select max(l.id) from language l), '布维岛');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 30, 'description', (select max(l.id) from language l), '巴西');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 31, 'description', (select max(l.id) from language l), '英属印度洋领地');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 32, 'description', (select max(l.id) from language l), '文莱');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 33, 'description', (select max(l.id) from language l), '保加利亚');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 34, 'description', (select max(l.id) from language l), '布基纳法索');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 35, 'description', (select max(l.id) from language l), '布隆迪');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 36, 'description', (select max(l.id) from language l), '柬埔寨');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 37, 'description', (select max(l.id) from language l), '喀麦隆');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 38, 'description', (select max(l.id) from language l), '加拿大');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 39, 'description', (select max(l.id) from language l), '佛得角');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 40, 'description', (select max(l.id) from language l), '开曼群岛');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 41, 'description', (select max(l.id) from language l), '中非共和国');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 42, 'description', (select max(l.id) from language l), '乍得');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 43, 'description', (select max(l.id) from language l), '智利');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 44, 'description', (select max(l.id) from language l), '中国');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 45, 'description', (select max(l.id) from language l), '圣诞岛');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 46, 'description', (select max(l.id) from language l), '科科斯群岛');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 47, 'description', (select max(l.id) from language l), '哥伦比亚');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 48, 'description', (select max(l.id) from language l), '科摩罗');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 49, 'description', (select max(l.id) from language l), '刚果');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 50, 'description', (select max(l.id) from language l), '库克群岛');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 51, 'description', (select max(l.id) from language l), '哥斯达黎加');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 52, 'description', (select max(l.id) from language l), 'Cï¿½1ï¿½7te科特迪瓦');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 53, 'description', (select max(l.id) from language l), '克罗地亚（赫尔瓦次卡）');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 54, 'description', (select max(l.id) from language l), '古巴');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 55, 'description', (select max(l.id) from language l), '塞浦路斯');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 56, 'description', (select max(l.id) from language l), '捷克共和国');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 57, 'description', (select max(l.id) from language l), '刚果（金）');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 58, 'description', (select max(l.id) from language l), '丹麦');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 59, 'description', (select max(l.id) from language l), '吉布提');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 60, 'description', (select max(l.id) from language l), '多米尼加');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 61, 'description', (select max(l.id) from language l), '多明尼加共和国');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 62, 'description', (select max(l.id) from language l), '东帝汶');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 63, 'description', (select max(l.id) from language l), '厄瓜多尔');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 64, 'description', (select max(l.id) from language l), '埃及');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 65, 'description', (select max(l.id) from language l), '萨尔瓦多');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 66, 'description', (select max(l.id) from language l), '赤道几内亚');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 67, 'description', (select max(l.id) from language l), '厄立特里亚');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 68, 'description', (select max(l.id) from language l), '爱沙尼亚');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 69, 'description', (select max(l.id) from language l), '埃塞俄比亚');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 70, 'description', (select max(l.id) from language l), '福克兰群岛（马尔维纳斯群岛）');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 71, 'description', (select max(l.id) from language l), '法罗群岛');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 72, 'description', (select max(l.id) from language l), '斐济群岛');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 73, 'description', (select max(l.id) from language l), '芬兰');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 74, 'description', (select max(l.id) from language l), '法国');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 75, 'description', (select max(l.id) from language l), '法属圭亚那');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 76, 'description', (select max(l.id) from language l), '法属波利尼西亚');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 77, 'description', (select max(l.id) from language l), '法国南部和南极土地');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 78, 'description', (select max(l.id) from language l), '加蓬');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 79, 'description', (select max(l.id) from language l), '冈比亚');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 80, 'description', (select max(l.id) from language l), '格鲁吉亚');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 81, 'description', (select max(l.id) from language l), '德国');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 82, 'description', (select max(l.id) from language l), '加纳');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 83, 'description', (select max(l.id) from language l), '直布罗陀');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 84, 'description', (select max(l.id) from language l), '希腊');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 85, 'description', (select max(l.id) from language l), '格陵兰');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 86, 'description', (select max(l.id) from language l), '格林纳达');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 87, 'description', (select max(l.id) from language l), '瓜德罗普岛');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 88, 'description', (select max(l.id) from language l), '关岛');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 89, 'description', (select max(l.id) from language l), '危地马拉');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 90, 'description', (select max(l.id) from language l), '几内亚');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 91, 'description', (select max(l.id) from language l), '几内亚比绍');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 92, 'description', (select max(l.id) from language l), '圭亚那');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 93, 'description', (select max(l.id) from language l), '海地');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 94, 'description', (select max(l.id) from language l), '赫德岛和麦当劳群岛');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 95, 'description', (select max(l.id) from language l), '洪都拉斯');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 96, 'description', (select max(l.id) from language l), '香港特区');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 97, 'description', (select max(l.id) from language l), '匈牙利');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 98, 'description', (select max(l.id) from language l), '冰岛');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 99, 'description', (select max(l.id) from language l), '印度');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 100, 'description', (select max(l.id) from language l), '印度尼西亚');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 101, 'description', (select max(l.id) from language l), '伊朗');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 102, 'description', (select max(l.id) from language l), '伊拉克');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 103, 'description', (select max(l.id) from language l), '爱尔兰');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 104, 'description', (select max(l.id) from language l), '以色列');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 105, 'description', (select max(l.id) from language l), '意大利');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 106, 'description', (select max(l.id) from language l), '牙买加');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 107, 'description', (select max(l.id) from language l), '日本');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 108, 'description', (select max(l.id) from language l), '约旦');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 109, 'description', (select max(l.id) from language l), '哈萨克斯坦');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 110, 'description', (select max(l.id) from language l), '肯尼亚');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 111, 'description', (select max(l.id) from language l), '基里巴斯');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 112, 'description', (select max(l.id) from language l), '韩国');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 113, 'description', (select max(l.id) from language l), '科威特');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 114, 'description', (select max(l.id) from language l), '吉');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 115, 'description', (select max(l.id) from language l), '老挝');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 116, 'description', (select max(l.id) from language l), '拉脱维亚');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 117, 'description', (select max(l.id) from language l), '黎巴嫩');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 118, 'description', (select max(l.id) from language l), '莱索托');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 119, 'description', (select max(l.id) from language l), '利比里亚');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 120, 'description', (select max(l.id) from language l), '利比亚');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 121, 'description', (select max(l.id) from language l), '列支敦士登');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 122, 'description', (select max(l.id) from language l), '立陶宛');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 123, 'description', (select max(l.id) from language l), '卢森堡');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 124, 'description', (select max(l.id) from language l), '澳门特别行政区');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 125, 'description', (select max(l.id) from language l), '“马其顿，前南斯拉夫共和国”');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 126, 'description', (select max(l.id) from language l), '马达加斯加');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 127, 'description', (select max(l.id) from language l), '马拉维');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 128, 'description', (select max(l.id) from language l), '马来西亚');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 129, 'description', (select max(l.id) from language l), '马尔代夫');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 130, 'description', (select max(l.id) from language l), '马里');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 131, 'description', (select max(l.id) from language l), '马耳他');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 132, 'description', (select max(l.id) from language l), '马绍尔群岛');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 133, 'description', (select max(l.id) from language l), '马提尼克');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 134, 'description', (select max(l.id) from language l), '毛里塔尼亚');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 135, 'description', (select max(l.id) from language l), '毛里求斯');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 136, 'description', (select max(l.id) from language l), '马约特');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 137, 'description', (select max(l.id) from language l), '墨西哥');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 138, 'description', (select max(l.id) from language l), '密克罗尼西亚');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 139, 'description', (select max(l.id) from language l), '摩尔多瓦');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 140, 'description', (select max(l.id) from language l), '摩纳哥');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 141, 'description', (select max(l.id) from language l), '蒙古');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 142, 'description', (select max(l.id) from language l), '蒙特塞拉特');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 143, 'description', (select max(l.id) from language l), '摩洛哥');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 144, 'description', (select max(l.id) from language l), '莫桑比克');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 145, 'description', (select max(l.id) from language l), '缅甸');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 146, 'description', (select max(l.id) from language l), '纳米比亚');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 147, 'description', (select max(l.id) from language l), '瑙鲁');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 148, 'description', (select max(l.id) from language l), '尼泊尔');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 149, 'description', (select max(l.id) from language l), '荷兰');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 150, 'description', (select max(l.id) from language l), '荷属安的列斯');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 151, 'description', (select max(l.id) from language l), '新喀里多尼亚');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 152, 'description', (select max(l.id) from language l), '新西兰');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 153, 'description', (select max(l.id) from language l), '尼加拉瓜');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 154, 'description', (select max(l.id) from language l), '尼日尔');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 155, 'description', (select max(l.id) from language l), '尼日利亚');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 156, 'description', (select max(l.id) from language l), '纽埃');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 157, 'description', (select max(l.id) from language l), '诺福克岛');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 158, 'description', (select max(l.id) from language l), '北朝鲜');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 159, 'description', (select max(l.id) from language l), '北马里亚纳群岛');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 160, 'description', (select max(l.id) from language l), '挪威');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 161, 'description', (select max(l.id) from language l), '阿曼');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 162, 'description', (select max(l.id) from language l), '巴基斯坦');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 163, 'description', (select max(l.id) from language l), '帕劳');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 164, 'description', (select max(l.id) from language l), '巴拿马');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 165, 'description', (select max(l.id) from language l), '巴布亚新几内亚');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 166, 'description', (select max(l.id) from language l), '巴拉圭');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 167, 'description', (select max(l.id) from language l), '秘鲁');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 168, 'description', (select max(l.id) from language l), '菲律宾');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 169, 'description', (select max(l.id) from language l), '皮特凯恩群岛');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 170, 'description', (select max(l.id) from language l), '波兰');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 171, 'description', (select max(l.id) from language l), '葡萄牙');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 172, 'description', (select max(l.id) from language l), '波多黎各');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 173, 'description', (select max(l.id) from language l), '卡塔尔');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 174, 'description', (select max(l.id) from language l), '团圆');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 175, 'description', (select max(l.id) from language l), '罗马尼亚');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 176, 'description', (select max(l.id) from language l), '俄国');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 177, 'description', (select max(l.id) from language l), '卢旺达');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 178, 'description', (select max(l.id) from language l), '萨摩亚');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 179, 'description', (select max(l.id) from language l), '圣马力诺');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 180, 'description', (select max(l.id) from language l), 'Sï¿½1ï¿½7oTomï¿½1ï¿½7和Prï¿½1ï¿½7ncipe');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 181, 'description', (select max(l.id) from language l), '沙特阿拉伯');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 182, 'description', (select max(l.id) from language l), '塞内加尔');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 183, 'description', (select max(l.id) from language l), '塞尔维亚和黑山');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 184, 'description', (select max(l.id) from language l), '塞舌尔');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 185, 'description', (select max(l.id) from language l), '塞拉利昂');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 186, 'description', (select max(l.id) from language l), '新加坡');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 187, 'description', (select max(l.id) from language l), '斯洛伐克');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 188, 'description', (select max(l.id) from language l), '斯洛文尼亚');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 189, 'description', (select max(l.id) from language l), '所罗门群岛');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 190, 'description', (select max(l.id) from language l), '索马里');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 191, 'description', (select max(l.id) from language l), '南非');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 192, 'description', (select max(l.id) from language l), '南乔治亚岛和南桑威奇群岛');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 193, 'description', (select max(l.id) from language l), '西班牙');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 194, 'description', (select max(l.id) from language l), '斯里兰卡');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 195, 'description', (select max(l.id) from language l), '圣赫勒拿');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 196, 'description', (select max(l.id) from language l), '圣基茨和尼维斯');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 197, 'description', (select max(l.id) from language l), '圣卢西亚');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 198, 'description', (select max(l.id) from language l), '圣皮埃尔和密克隆');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 199, 'description', (select max(l.id) from language l), '圣文森特和格林纳丁斯');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 200, 'description', (select max(l.id) from language l), '苏丹');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 201, 'description', (select max(l.id) from language l), '苏里南');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 202, 'description', (select max(l.id) from language l), '斯瓦尔巴群岛和扬马延');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 203, 'description', (select max(l.id) from language l), '斯威士兰');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 204, 'description', (select max(l.id) from language l), '瑞典');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 205, 'description', (select max(l.id) from language l), '瑞士');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 206, 'description', (select max(l.id) from language l), '叙利亚');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 207, 'description', (select max(l.id) from language l), '台湾');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 208, 'description', (select max(l.id) from language l), '塔吉克斯坦');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 209, 'description', (select max(l.id) from language l), '坦桑尼亚');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 210, 'description', (select max(l.id) from language l), '泰国');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 211, 'description', (select max(l.id) from language l), '多哥');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 212, 'description', (select max(l.id) from language l), '托克劳');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 213, 'description', (select max(l.id) from language l), '汤加');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 214, 'description', (select max(l.id) from language l), '特立尼达和多巴哥');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 215, 'description', (select max(l.id) from language l), '突尼斯');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 216, 'description', (select max(l.id) from language l), '火鸡');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 217, 'description', (select max(l.id) from language l), '土库曼斯坦');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 218, 'description', (select max(l.id) from language l), '特克斯和凯科斯群岛');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 219, 'description', (select max(l.id) from language l), '图瓦卢');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 220, 'description', (select max(l.id) from language l), '乌干达');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 221, 'description', (select max(l.id) from language l), '乌克兰');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 222, 'description', (select max(l.id) from language l), '阿拉伯联合酋长国');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 223, 'description', (select max(l.id) from language l), '英国');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 224, 'description', (select max(l.id) from language l), '美国');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 225, 'description', (select max(l.id) from language l), '美国本土外小岛屿');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 226, 'description', (select max(l.id) from language l), '乌拉圭');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 227, 'description', (select max(l.id) from language l), '乌兹别克斯坦');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 228, 'description', (select max(l.id) from language l), '瓦努阿图');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 229, 'description', (select max(l.id) from language l), '梵蒂冈城');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 230, 'description', (select max(l.id) from language l), '委内瑞拉');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 231, 'description', (select max(l.id) from language l), '越南');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 232, 'description', (select max(l.id) from language l), '维尔京群岛（英国）');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 233, 'description', (select max(l.id) from language l), '英属维尔京群岛');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 234, 'description', (select max(l.id) from language l), '瓦利斯和富图纳群岛');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 235, 'description', (select max(l.id) from language l), '也门');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 236, 'description', (select max(l.id) from language l), '赞比亚');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 237, 'description', (select max(l.id) from language l), '津巴布韦');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (69, 1, 'welcome_message', (select max(l.id) from language l), '“<DIV> <BR/> <p风格=”字体大小：19px;字体重量：大胆;“>！欢迎来到跃马结算</ P> <BR/> <p风格=字体大小： 14px的;文本对齐=左;填充左：15;“>在这里，您可以查看最新发票，并得到它支付的瞬间，您还可以查看所有以前的发票和付款，并建立了系统自动付款。您的信用卡</ p> <p风格=“字体大小：14px的;文本对齐=左;填充左：15;>？请问您今天想做</ P> <UL风格= “字体大小：13px的;文本对齐=左;填充左：25;”> <li>要提交信用卡付款，请在左边栏中的链接</ li> <li>要查看列表。您的发票，用点击A ????Invoicesâ????菜单选项。名单上的第一张发票是最新发票，点击它，看看它的细节。</ li> <li>要查看列表你付款，点击对A ????Paymentsâ????菜单选项。名单上的首付款上一次付款，点击它，看看它的细节。</ li> <li>要提供信用卡卡启用自动付款，点击菜单选项“帐户”，然后在“编辑信用卡”。</ li> </ ul> </ DIV>“');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (69, 2, 'welcome_message', (select max(l.id) from language l), '“<DIV> <BR/> <p风格=”字体大小：19px;字体重量：大胆;“>！欢迎来到魔多公司结算</ P> <BR/> <p风格=字体大小：14px的;文本对齐=左;填充左：15;“>在这里，您可以查看最新发票，并得到它支付的瞬间，您还可以查看所有以前的发票和付款，并设置系统自动。 。支付与您的信用卡</ p> <p风格=“字体大小：14px的;文本对齐=左;填充左：15;>？请问您今天想做</ P> <UL风格=“字体大小：13px的;文本对齐=左;填充左：25;”> <li>要提交信用卡付款，请在左边栏中的链接</ li> <li>要查看。发票的列表中，单击在A ????Invoicesâ????菜单选项。名单上的第一张发票是最新发票，点击它，看看它的细节。</ li> <li>要查看付款的列表，单击对A ????Paymentsâ????菜单选项。名单上的首付款上一次付款，点击它，看看它的细节。</ li> <li>要提供信用卡启用自动付款，点击菜单选项“帐户”，然后在“编辑信用卡”。</ li> </ ul> </ DIV>“');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (73, 1, 'description', (select max(l.id) from language l), '订购');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (73, 2, 'description', (select max(l.id) from language l), '发票');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (73, 3, 'description', (select max(l.id) from language l), '付款');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (73, 4, 'description', (select max(l.id) from language l), '退款');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (73, 5, 'description', (select max(l.id) from language l), '顾客');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (73, 6, 'description', (select max(l.id) from language l), '伙伴');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (73, 7, 'description', (select max(l.id) from language l), '合作伙伴选择');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (73, 8, 'description', (select max(l.id) from language l), '用户');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (73, 9, 'description', (select max(l.id) from language l), '项目');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (81, 1, 'description', (select max(l.id) from language l), '活性');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (81, 2, 'description', (select max(l.id) from language l), '等待退订');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (81, 3, 'description', (select max(l.id) from language l), '退订');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (81, 4, 'description', (select max(l.id) from language l), '即将到期');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (81, 5, 'description', (select max(l.id) from language l), '过期');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (81, 6, 'description', (select max(l.id) from language l), '非订户');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (81, 7, 'description', (select max(l.id) from language l), '停产');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (88, 1, 'description', (select max(l.id) from language l), '活性');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (88, 2, 'description', (select max(l.id) from language l), '非活动');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (88, 3, 'description', (select max(l.id) from language l), '待活动');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (88, 4, 'description', (select max(l.id) from language l), '待无效');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (88, 5, 'description', (select max(l.id) from language l), '失败');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (88, 6, 'description', (select max(l.id) from language l), '不可用');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (89, 1, 'description', (select max(l.id) from language l), '无');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (89, 2, 'description', (select max(l.id) from language l), '预付费余额');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (89, 3, 'description', (select max(l.id) from language l), '信用额度');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (90, 1, 'description', (select max(l.id) from language l), '付费');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (90, 2, 'description', (select max(l.id) from language l), '未付');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (90, 3, 'description', (select max(l.id) from language l), '携带的');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (91, 1, 'description', (select max(l.id) from language l), '完成和计费');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (91, 2, 'description', (select max(l.id) from language l), '完成，而不是计费');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (91, 3, 'description', (select max(l.id) from language l), '检测到的错误');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (91, 4, 'description', (select max(l.id) from language l), '错误申报');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (92, 1, 'description', (select max(l.id) from language l), '运行');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (92, 2, 'description', (select max(l.id) from language l), '完成：成功');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (92, 3, 'description', (select max(l.id) from language l), '表面处理：失败');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (99, 1, 'description', (select max(l.id) from language l), '介绍费');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (99, 2, 'description', (select max(l.id) from language l), '付款处理器');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (99, 3, 'description', (select max(l.id) from language l), 'IP地址');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 1, 'description', (select max(l.id) from language l), '总金额发票按期间分组。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 2, 'description', (select max(l.id) from language l), '详细余额账龄报告。显示了出色的客户余额岁。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 3, 'description', (select max(l.id) from language l), '用户数量订阅了特定的产品。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 4, 'description', (select max(l.id) from language l), '收到时期分组总付款金额。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 5, 'description', (select max(l.id) from language l), '一段时间内创建的客户数量。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 6, 'description', (select max(l.id) from language l), '每个客户的总收入（收到的付款的总和）。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 7, 'description', (select max(l.id) from language l), '简单的账目显示当前账户余额账款报告。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 8, 'description', (select max(l.id) from language l), '所有发票费用为一天总账细节。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 9, 'description', (select max(l.id) from language l), '“所有的发票费用的某一天，按项目类型分组的总账汇总。”');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 11, 'description', (select max(l.id) from language l), '每个客户按产品类别分组共开具发票。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 12, 'description', (select max(l.id) from language l), '每个客户开具发票合计多年来逐年分组。');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 13, 'description', (select max(l.id) from language l), '对用户活动中指定天数的声明');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (101, 1, 'description', (select max(l.id) from language l), '发票报告');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (101, 2, 'description', (select max(l.id) from language l), '订单报告');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (101, 3, 'description', (select max(l.id) from language l), '付款报告');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (101, 4, 'description', (select max(l.id) from language l), '客户报告');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (104, 1, 'description', (select max(l.id) from language l), '发票');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (104, 2, 'description', (select max(l.id) from language l), '订单');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (104, 3, 'description', (select max(l.id) from language l), '付款');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (104, 4, 'description', (select max(l.id) from language l), '用户');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (104, 5, 'description', (select max(l.id) from language l), '自定义通知');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (108, 1, 'description', (select max(l.id) from language l), '集团成员');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (108, 101, 'description', (select max(l.id) from language l), 'DefaultStatus');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (108, 102, 'description', (select max(l.id) from language l), 'AddToOrderStatus');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (108, 103, 'description', (select max(l.id) from language l), 'Available2');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (108, 104, 'description', (select max(l.id) from language l), '无2');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (111, 1, 'description', (select max(l.id) from language l), '基');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (111, 2, 'description', (select max(l.id) from language l), '基');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (111, 3, 'description', (select max(l.id) from language l), '私人');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (111, 4, 'description', (select max(l.id) from language l), '商业');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (111, 5, 'description', (select max(l.id) from language l), '私人');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (113, 19, 'errorMessage', (select max(l.id) from language l), '电子邮件无效');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (113, 37, 'errorMessage', (select max(l.id) from language l), '电子邮件无效');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (113, 57, 'errorMessage', (select max(l.id) from language l), '电子邮件无效');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (113, 58, 'errorMessage', (select max(l.id) from language l), '电子邮件无效');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (113, 71, 'errorMessage', (select max(l.id) from language l), '电子邮件无效');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (113, 80, 'errorMessage', (select max(l.id) from language l), '电子邮件无效');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 7, 'errorMessage', (select max(l.id) from language l), '支付卡号码是无效');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 8, 'errorMessage', (select max(l.id) from language l), '到期日期应该是在格式MM / YYYY');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 9, 'errorMessage', (select max(l.id) from language l), 'ABA路由或银行账号只能是数字');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 10, 'errorMessage', (select max(l.id) from language l), '支付卡号码是无效');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 11, 'errorMessage', (select max(l.id) from language l), '到期日期应该是在格式MM / YYYY');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 12, 'errorMessage', (select max(l.id) from language l), 'ABA路由或银行账号只能是数字');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 13, 'errorMessage', (select max(l.id) from language l), '支付卡号码是无效');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 14, 'errorMessage', (select max(l.id) from language l), '到期日期应该是在格式MM / YYYY');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 15, 'errorMessage', (select max(l.id) from language l), '失败的登录尝试不超过6');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 16, 'errorMessage', (select max(l.id) from language l), '密码必须前90天内到期');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 17, 'errorMessage', (select max(l.id) from language l), '非活动账户的检查必须做到快超过90天');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 18, 'errorMessage', (select max(l.id) from language l), '预约时间应介于0和60万');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (115, 1, 'description', (select max(l.id) from language l), 'PENDING');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (115, 2, 'description', (select max(l.id) from language l), '适用错误');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (115, 3, 'description', (select max(l.id) from language l), '应用');

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('Chinese Translation Texts', 'Manisha Gupta', 'descriptors/database/jbilling-upgrade-4.1.xml', NOW(), 32, '7:08ad6ef3feca098d4e14163ce6b11bd1', 'insert, sql', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.1.xml::Update next_id::Web Data
UPDATE public.jbilling_seqs SET next_id = (select coalesce( (max(t.id)/10 + 1), 1) from item_type t) WHERE name='item_type';

UPDATE public.jbilling_seqs SET next_id = (select coalesce( (max(t.id)/10 + 1), 1) from item t) WHERE name='item';

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('Update next_id', 'Web Data', 'descriptors/database/jbilling-upgrade-4.1.xml', NOW(), 33, '7:683b11496fa25a092f054db7a22bcfd5', 'update (x2)', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.1.xml::Updating column name in jb_host_master table::Vikas Bodani
ALTER TABLE public.jb_host_master RENAME COLUMN jb_last_git_commit TO jb_tag_name;

ALTER TABLE public.jb_host_master ALTER COLUMN jb_tag_name TYPE CHAR(50);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('Updating column name in jb_host_master table', 'Vikas Bodani', 'descriptors/database/jbilling-upgrade-4.1.xml', NOW(), 34, '7:0ee5ffd62e398290161bc6ccdb33a737', 'renameColumn, modifyDataType', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.1.xml::Updating 20151102-host-preferences::Vikas Bodani
UPDATE public.jb_host_master SET jb_tag_name = 'community-4.1.2', jb_version = 'CE-4.1.2' WHERE jb_version='CE-4.1.1';

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('Updating 20151102-host-preferences', 'Vikas Bodani', 'descriptors/database/jbilling-upgrade-4.1.xml', NOW(), 35, '7:871bbc664080e3cd61320532e3626d8c', 'update', '', 'EXECUTED', '3.2.2');

-- Release Database Lock
