-- Changeset descriptors/database/jbilling-upgrade-3.3.xml::#3173 - Create a New Payment Method 'Credit'::Oscar Bidabehere
INSERT INTO public.payment_method (id) VALUES (15.0);

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35.0, 15.0, 'description', 1.0, 'Credit');

INSERT INTO public.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES ((select max(p.id)+1 from pluggable_task_type p), 17.0, 'com.sapienter.jbilling.server.invoice.task.ApplyNegativeInvoiceToPaymentTask', 0.0);

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, (select max(p.id) from pluggable_task_type p), 'title', 1.0, 'Credit on negative invoice');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, (select max(p.id) from pluggable_task_type p), 'description', 1.0, 'This plug-in will set the balance and total of a negative invoice to 0 and create a ''credit'' payment for the remaining amount.');

UPDATE public.jbilling_seqs SET next_id = (select max(p.id)+1 from pluggable_task_type p) WHERE name='pluggable_task_type';

INSERT INTO pluggable_task (id, entity_id, type_id, processing_order, optlock)
               select (select max(p.id)+1 from pluggable_task p) + (select count(*) from entity e2 where e1.id > e2.id and e2.id <> e1.id),
                      e1.id,
                      (select max(p.id) from pluggable_task_type p),
                      1,
                      1
               from entity e1
               order by e1.id;

UPDATE public.jbilling_seqs SET next_id = coalesce((select max(p.id)+1 from pluggable_task p), 1) WHERE name='pluggable_task';

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#3173 - Create a New Payment Method ''Credit''', 'Oscar Bidabehere', 'descriptors/database/jbilling-upgrade-3.3.xml', NOW(), 1, '7:d4c0e5904753ca7ba863f5791c6fdd3b', 'insert (x5), update, sql, update', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.3.xml::#4781 - Dynamic tab configuration::Gerhard Maree
CREATE TABLE public.tab (id INT NOT NULL, message_code VARCHAR(50), controller_name VARCHAR(50), access_url VARCHAR(50), required_role VARCHAR(50), version INT NOT NULL, CONSTRAINT tab_pkey PRIMARY KEY (id));

CREATE TABLE public.tab_configuration (id INT NOT NULL, user_id INT, version INT NOT NULL, CONSTRAINT tab_configuration_pkey PRIMARY KEY (id));

ALTER TABLE public.tab_configuration ADD CONSTRAINT tab_configuration_fk_1 FOREIGN KEY (user_id) REFERENCES public.base_user (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

CREATE TABLE public.tab_configuration_tab (id INT NOT NULL, tab_id INT, tab_configuration_id INT, display_order INT, visible BOOLEAN, version INT NOT NULL, CONSTRAINT tab_configuration_tab_pkey PRIMARY KEY (id));

ALTER TABLE public.tab_configuration_tab ADD CONSTRAINT tab_configuration_tab_fk_1 FOREIGN KEY (tab_id) REFERENCES public.tab (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE public.tab_configuration_tab ADD CONSTRAINT tab_configuration_tab_fk_2 FOREIGN KEY (tab_configuration_id) REFERENCES public.tab_configuration (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.tab (id, message_code, controller_name, access_url, required_role, version) VALUES (1.0, 'menu.link.customers', 'customer', '/customer/list', '', '1');

INSERT INTO public.tab (id, message_code, controller_name, access_url, required_role, version) VALUES (2.0, 'menu.link.partners', 'partner', '/partner/list', '', '1');

INSERT INTO public.tab (id, message_code, controller_name, access_url, required_role, version) VALUES (3.0, 'menu.link.invoices', 'invoice', '/invoice/list', '', '1');

INSERT INTO public.tab (id, message_code, controller_name, access_url, required_role, version) VALUES (4.0, 'menu.link.payments.refunds', 'payment', '/payment/list', '', '1');

INSERT INTO public.tab (id, message_code, controller_name, access_url, required_role, version) VALUES (5.0, 'menu.link.orders', 'order', '/order/list', '', '1');

INSERT INTO public.tab (id, message_code, controller_name, access_url, required_role, version) VALUES (6.0, 'menu.link.billing', 'billing', '/billing/list', '', '1');

INSERT INTO public.tab (id, message_code, controller_name, access_url, required_role, version) VALUES (8.0, 'menu.link.reports', 'report', '/report/list', '', '1');

INSERT INTO public.tab (id, message_code, controller_name, access_url, required_role, version) VALUES (9.0, 'menu.link.products', 'product', '/product/list', '', '1');

INSERT INTO public.tab (id, message_code, controller_name, access_url, required_role, version) VALUES (10.0, 'menu.link.plans', 'plan', '/plan/list', '', '1');

INSERT INTO public.tab (id, message_code, controller_name, access_url, required_role, version) VALUES (11.0, 'menu.link.configuration', 'config', '/config/index', '', '1');

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#4781 - Dynamic tab configuration', 'Gerhard Maree', 'descriptors/database/jbilling-upgrade-3.3.xml', NOW(), 2, '7:e18000d07a6fa96fefa9e6ed6499c28f', 'createTable (x2), addForeignKeyConstraint, createTable, addForeignKeyConstraint (x2), insert (x10)', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.3.xml::#4781 - Dynamic tab configuration - Discounts menu item::Gerhard Maree
ALTER TABLE public.tab ADD default_order INT;

UPDATE public.tab SET default_order = id WHERE (default_order = 0 OR default_order IS NULL) AND id < 9;

UPDATE public.tab SET default_order = id+1 WHERE (default_order = 0 OR default_order IS NULL) AND id >= 9;

INSERT INTO public.tab (id, message_code, controller_name, access_url, required_role, version, default_order) VALUES (12.0, 'menu.link.discounts', 'discount', '/discount/list', '', '1', 9.0);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#4781 - Dynamic tab configuration - Discounts menu item', 'Gerhard Maree', 'descriptors/database/jbilling-upgrade-3.3.xml', NOW(), 3, '7:491a8a91b812e15cdc356ec9e6d6f794', 'addColumn, update (x2), insert', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.3.xml::#1905 - Reset password::Oscar Bidabehere
-- Default configuration
-- id = maxMessageId + count
-- message_id = maxMessageId - count
-- message_id = maxMessageId - count
-- message_id = maxMessageId - count
-- message_section_id = (maxSectionId + 1 - (3 * entityCant)) + count
-- message_section_id = (maxSectionId + 1 - (2 * entityCant)) + count
-- message_section_id = (maxSectionId + 1 - (1 * entityCant)) + count
CREATE TABLE public.reset_password_code (base_user_id INT, date_created TIMESTAMP WITHOUT TIME ZONE, token VARCHAR(32) NOT NULL, new_password VARCHAR(40), CONSTRAINT PK_RESET_PASSWORD_CODE PRIMARY KEY (token), UNIQUE (base_user_id));

INSERT INTO notification_message (entity_id, id, language_id, notify_admin, notify_all_parents, notify_parent, notify_partner, optlock, type_id, use_flag)
                select e1.id, (select coalesce(max(p.id), 0) +1 from notification_message p) + (select count(*) from entity e2 where e1.id > e2.id and e2.id <> e1.id), 1, 0, 0, 0, 0, 1, 20, 1
                from entity e1
                order by e1.id;

UPDATE public.jbilling_seqs SET next_id = coalesce((select max(p.id)+1 from notification_message p), 1) WHERE name='notification_message';

INSERT INTO notification_message_section (id, message_id, section, optlock)
                select (select coalesce(max(p.id), 0) +1 from notification_message_section p) + (select count(*) from entity e2 where e1.id > e2.id and e2.id <> e1.id),
                       (select coalesce(max(p.id), 0) from notification_message p) - (select count(*) from entity e2 where e1.id > e2.id and e2.id <> e1.id),
                       1,
                       1
                from entity e1
                order by e1.id;

INSERT INTO notification_message_section (id, message_id, section, optlock)
                select (select coalesce(max(p.id), 0) +1 from notification_message_section p) + (select count(*) from entity e2 where e1.id > e2.id and e2.id <> e1.id),
                       (select coalesce(max(p.id), 0) from notification_message p) - (select count(*) from entity e2 where e1.id > e2.id and e2.id <> e1.id),
                       2,
                       1
                from entity e1
                order by e1.id;

INSERT INTO notification_message_section (id, message_id, section, optlock)
                select (select coalesce(max(p.id), 0) +1 from notification_message_section p) + (select count(*) from entity e2 where e1.id > e2.id and e2.id <> e1.id),
                       (select coalesce(max(p.id), 0) from notification_message p) - (select count(*) from entity e2 where e1.id > e2.id and e2.id <> e1.id),
                       3,
                       1
                from entity e1
                order by e1.id;

UPDATE public.jbilling_seqs SET next_id = coalesce((select max(p.id)+1 from notification_message_section p), 1) WHERE name='notification_message_section';

INSERT INTO notification_message_line (id, message_section_id, content, optlock)
                select (select coalesce(max(p.id), 0) +1 from notification_message_line p) + (select count(*) from entity e2 where e1.id > e2.id and e2.id <> e1.id),
                       (select coalesce(max(p.id), 0) +1 from notification_message_section p) - (select count(*) * 3 from entity ecant) + (select count(*) from entity e2 where e1.id > e2.id and e2.id <> e1.id),
                       'Reset password request',
                       1
                from entity e1
                order by e1.id;

INSERT INTO notification_message_line (id, message_section_id, content, optlock)
                select (select coalesce(max(p.id), 0) +1 from notification_message_line p) + (select count(*) from entity e2 where e1.id > e2.id and e2.id <> e1.id),
                       (select coalesce(max(p.id), 0) +1 from notification_message_section p) - (select count(*) * 2 from entity ecant) + (select count(*) from entity e2 where e1.id > e2.id and e2.id <> e1.id),
                       'Hello  $first_name $last_name,\r\n\r\nYou (or someone pretending to be you) requested a password reset of your account.\r\n\r\nIf you access the following link your password will be changed to: $newPassword\r\n\r\n$newPasswordLink',
                       1
                from entity e1
                order by e1.id;

INSERT INTO notification_message_line (id, message_section_id, content, optlock)
                select (select coalesce(max(p.id), 0) +1 from notification_message_line p) + (select count(*) from entity e2 where e1.id > e2.id and e2.id <> e1.id),
                       (select coalesce(max(p.id), 0) +1 from notification_message_section p) - (select count(*) * 1 from entity ecant) + (select count(*) from entity e2 where e1.id > e2.id and e2.id <> e1.id),
                       '&lt;p&gt;Hello $first_name $last_name,&lt;/p&gt;&lt;p&gt;You (or someone pretending to be you) requested a password reset of your account.&lt;/p&gt;&lt;p&gt;If you access the following link your password will be changed to: &lt;strong&gt;$newPassword&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;&lt;a href=&quot;$newPasswordLink&quot;&gt;$newPasswordLink&lt;/a&gt;&lt;/p&gt;',
                       1
                from entity e1
                order by e1.id;

UPDATE public.jbilling_seqs SET next_id = coalesce((select max(p.id)+1 from notification_message_line p), 1) WHERE name='notification_message_line';

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#1905 - Reset password', 'Oscar Bidabehere', 'descriptors/database/jbilling-upgrade-3.3.xml', NOW(), 4, '7:97686600f147d2bf90e3cf499aaefa00', 'createTable, sql, update, sql (x3), update, sql (x3), update', 'Default configuration
id = maxMessageId + count
message_id = maxMessageId - count
message_id = maxMessageId - count
message_id = maxMessageId - count
message_section_id = (maxSectionId + 1 - (3 * entityCant)) + count
message_section_id = (maxSecti...', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.3.xml::20121231-#2488,BalanceBelowThresholdNotificationTask-1::Shweta Gupta
INSERT INTO public.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES ((select max(ptt.id)+1 from pluggable_task_type ptt), 17.0, 'com.sapienter.jbilling.server.user.tasks.BalanceThresholdNotificationTask', 1.0);

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, (select max(ptt.id) from pluggable_task_type ptt), 'title', 1.0, 'User Balance threshold notification task');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, (select max(ptt.id) from pluggable_task_type ptt), 'description', 1.0, 'A pluggable task of the type InternalEventsTask to monitor if users pre-paid balance is below a threshold level and send notifications.');

INSERT INTO public.notification_category (id) VALUES ((select max(nc.id)+1 from notification_category nc));

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (104.0, (select max(id) from notification_category), 'description', 1.0, 'Custom Notifications');

INSERT INTO public.notification_message_type (id, category_id, optlock) VALUES ((select max(nmt.id)+1 from notification_message_type nmt), (select max(id) from notification_category), 0.0);

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, (select max(nmt.id) from notification_message_type nmt), 'description', 1.0, 'Balance Below Threshold');

UPDATE public.jbilling_seqs SET next_id = coalesce((select round(max(id)/100)+1 from notification_message_type), 1) WHERE name = 'notification_message_type';

UPDATE public.jbilling_seqs SET next_id = coalesce((select round(max(id)/10)+1 from notification_category), 1) WHERE name = 'notification_category';

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('20121231-#2488,BalanceBelowThresholdNotificationTask-1', 'Shweta Gupta', 'descriptors/database/jbilling-upgrade-3.3.xml', NOW(), 5, '7:6fadc677d51171b6542fb9f68b67ce3f', 'insert (x7), update (x2)', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.3.xml::#3374-Ageing improvements::Panche Isajeski
-- #3374-Separate auto payment retry from the billing process
-- Migration scripts
-- New UserAgeingNotificationTask for mapping between notifications and user statuses
CREATE TABLE public.user_status (id INT NOT NULL, can_login SMALLINT, CONSTRAINT user_status_pkey PRIMARY KEY (id));

INSERT INTO public.user_status (id, can_login) VALUES (1.0, 1.0);

ALTER TABLE public.ageing_entity_step ADD retry_payment SMALLINT NOT NULL DEFAULT 0;

ALTER TABLE public.ageing_entity_step ADD suspend SMALLINT NOT NULL DEFAULT 0;

ALTER TABLE public.ageing_entity_step ADD send_notification SMALLINT NOT NULL DEFAULT 0;

insert into user_status
            (select aes.id, gs.can_login from ageing_entity_step aes, generic_status gs
                where aes.status_id > 1 and gs.dtype='user_status' and aes.status_id = gs.status_value);

UPDATE public.base_user SET status_id = (select us.id from user_status us, ageing_entity_step aes where aes.id=us.id and aes.status_id=base_user.status_id) WHERE status_id > 1;

ALTER TABLE public.base_user ADD CONSTRAINT base_user_fk_6 FOREIGN KEY (status_id) REFERENCES public.user_status (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

create table ageing_entity_step_copy as (select * from ageing_entity_step);

update ageing_entity_step us1
                set days =
                    (select sum(us2.days) from ageing_entity_step_copy us2
                        where us2.id < us1.id and us2.entity_id = us1.entity_id)
                where us1.status_id <> 1;

drop table ageing_entity_step_copy;

CREATE TABLE international_description_statuses
            AS (select * from international_description where table_id=9 and foreign_id > 1);

delete from international_description where table_id=9 and foreign_id > 1;

insert into international_description
            select 9, aes.id, 'description', 1, id1.content
            from international_description_statuses id1, ageing_entity_step aes
            where id1.table_id=9
            and id1.foreign_id=aes.status_id
            and aes.status_id > 1;

DROP TABLE international_description_statuses;

DELETE FROM public.ageing_entity_step  WHERE status_id=1;

UPDATE public.ageing_entity_step SET status_id = id;

UPDATE public.ageing_entity_step SET suspend = (select (1-can_login) from user_status where ageing_entity_step.status_id = user_status.id);

DELETE FROM public.generic_status  WHERE dtype='user_status';

ALTER TABLE public.ageing_entity_step ADD CONSTRAINT entity_step_days UNIQUE (entity_id, days);

INSERT INTO public.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES ((select max(p.id)+1 from pluggable_task_type p), 17.0, 'com.sapienter.jbilling.server.user.tasks.UserAgeingNotificationTask', 0.0);

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, (select max(p.id) from pluggable_task_type p), 'title', 1.0, 'Custom user notifications per ageing steps');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, (select max(p.id) from pluggable_task_type p), 'description', 1.0, 'This plug-in provides mapping between the user status(ageing steps) and notifications that needs to be sent for each status');

UPDATE public.jbilling_seqs SET next_id = (select max(p.id)+1 from pluggable_task_type p) WHERE name='pluggable_task_type';

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#3374-Ageing improvements', 'Panche Isajeski', 'descriptors/database/jbilling-upgrade-3.3.xml', NOW(), 6, '7:fd918e5b1d85c2d803a60d48659e0b1f', 'createTable, insert, addColumn, sql, update, addForeignKeyConstraint, sql (x7), delete, update (x2), delete, addUniqueConstraint, insert (x3), update', '#3374-Separate auto payment retry from the billing process
Migration scripts
New UserAgeingNotificationTask for mapping between notifications and user statuses', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.3.xml::20130305 - #3307::Shweta Gupta 
-- Add New Preference - Unique Product Code
INSERT INTO public.preference_type (id, def_value) VALUES (55.0, '0');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 55.0, 'description', 1.0, 'Unique product code');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 55.0, 'instruction', 1.0, 'Allows unique product code, If set the product code or internal number of a product/item would be enforced to be unique');

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('20130305 - #3307', 'Shweta Gupta ', 'descriptors/database/jbilling-upgrade-3.3.xml', NOW(), 7, '7:ee1b60bd538330b881d7754ca296756a', 'insert (x3)', 'Add New Preference - Unique Product Code', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.3.xml::20121207-#4042-add-parent-item-type-column::Vladimir Carevski
-- Dec 07, 2012 - #4042, Adds column for parent item type id
ALTER TABLE public.item_type ADD parent_id INT;

ALTER TABLE public.item_type ADD CONSTRAINT parent_id_fk FOREIGN KEY (parent_id) REFERENCES public.item_type (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('20121207-#4042-add-parent-item-type-column', 'Vladimir Carevski', 'descriptors/database/jbilling-upgrade-3.3.xml', NOW(), 8, '7:f8ef413e9a2c9bb407408497d5abbb86', 'addColumn, addForeignKeyConstraint', 'Dec 07, 2012 - #4042, Adds column for parent item type id', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.3.xml::#7623, Configure password rules::Rohit
ALTER TABLE public.base_user ADD change_password_date date;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#7623, Configure password rules', 'Rohit', 'descriptors/database/jbilling-upgrade-3.3.xml', NOW(), 9, '7:7530bbe34c559ca4d74ef84b11b6217c', 'addColumn', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.3.xml::#8043, add column in item table::Rohit
ALTER TABLE public.item ADD price_manual INT;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#8043, add column in item table', 'Rohit', 'descriptors/database/jbilling-upgrade-3.3.xml', NOW(), 10, '7:408ea8eb15a4583cf2fa2e0d2f881992', 'addColumn', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.3.xml::20141112-correcting sequences::Manisha Gupta
UPDATE public.jbilling_seqs SET next_id = (select coalesce(max(p.id), 0) +1 from pluggable_task_parameter p) WHERE name='pluggable_task_parameter';

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('20141112-correcting sequences', 'Manisha Gupta', 'descriptors/database/jbilling-upgrade-3.3.xml', NOW(), 11, '7:633a3f89bd3692aeb80f99645cc3e5c8', 'update', '', 'EXECUTED', '3.2.2');

-- Release Database Lock
