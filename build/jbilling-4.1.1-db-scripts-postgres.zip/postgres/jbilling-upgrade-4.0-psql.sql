-- Changeset descriptors/database/jbilling-upgrade-4.0.xml::add diameter entities::Emir Calabuch
-- Tables used for managing charge sessions and reservations
CREATE TABLE public.charge_sessions (id INT, user_id INT, session_token VARCHAR(150), ts_started TIMESTAMP WITHOUT TIME ZONE, ts_last_access TIMESTAMP WITHOUT TIME ZONE);

CREATE TABLE public.reserved_amounts (id INT, session_id INT, ts_created TIMESTAMP WITHOUT TIME ZONE, currency_id INT, reserved_amount numeric(22, 10), item_id INT);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('add diameter entities', 'Emir Calabuch', 'descriptors/database/jbilling-upgrade-4.0.xml', NOW(), 1, '7:7474da8657492a7d568d0f2d67df1ed7', 'createTable (x2)', 'Tables used for managing charge sessions and reservations', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.0.xml::add diameter constraints::Emir Calabuch
ALTER TABLE public.charge_sessions ADD PRIMARY KEY (id);

ALTER TABLE public.reserved_amounts ADD PRIMARY KEY (id);

ALTER TABLE public.reserved_amounts ADD CONSTRAINT fk_reservations_session FOREIGN KEY (session_id) REFERENCES public.charge_sessions (id);

ALTER TABLE public.charge_sessions ADD CONSTRAINT fk_sessions_user FOREIGN KEY (user_id) REFERENCES public.base_user (id);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('add diameter constraints', 'Emir Calabuch', 'descriptors/database/jbilling-upgrade-4.0.xml', NOW(), 2, '7:7eee27f2b9788785fde64962a409734c', 'addPrimaryKey (x2), addForeignKeyConstraint (x2)', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.0.xml::#4184 - Implement 'Start Session' API call::Sergio Liendo
-- Preference diameter destination realm
-- Preference diameter quota threshold
-- Preference diameter session grace period seconds
INSERT INTO public.preference_type (id, def_value) VALUES ((select max(p.id) + 1 from preference_type p), 'realm');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, (select max(id) from preference_type), 'description', 1.0, 'Diameter Destination Realm');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, (select max(id) from preference_type), 'instruction', 1.0, 'The realm to be charged. This can be used for routing Diameter messages, so should match a locally-configured realm.');

INSERT INTO public.preference_type (id, def_value) VALUES ((select max(id) + 1 from preference_type p), '0');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, (select max(id) from preference_type), 'description', 1.0, 'Diameter Quota Threshold');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, (select max(id) from preference_type), 'instruction', 1.0, 'When this number of seconds remains the call handling unit should request re-authorisation.');

INSERT INTO public.preference_type (id, def_value) VALUES ((select max(id) + 1 from preference_type p), '0');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, (select max(id) from preference_type p), 'description', 1.0, 'Diameter Session Grace Period');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, (select max(id) from preference_type), 'instruction', 1.0, 'Number of seconds to wait before Diameter sessions are forcibly closed.');

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#4184 - Implement ''Start Session'' API call', 'Sergio Liendo', 'descriptors/database/jbilling-upgrade-4.0.xml', NOW(), 3, '7:c5c3d38f8ce0d5cae43f534a7780aad4', 'insert (x9)', 'Preference diameter destination realm
Preference diameter quota threshold
Preference diameter session grace period seconds', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.0.xml::add data column to reserved_amounts table::Oscar Bidabehere
ALTER TABLE public.reserved_amounts ADD data TEXT;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('add data column to reserved_amounts table', 'Oscar Bidabehere', 'descriptors/database/jbilling-upgrade-4.0.xml', NOW(), 4, '7:ac3c9368641cd88fcfafeab62b275e20', 'addColumn', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.0.xml::add quantity column to reserved amounts table::Emir Calabuch
ALTER TABLE public.reserved_amounts ADD quantity numeric(22, 10);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('add quantity column to reserved amounts table', 'Emir Calabuch', 'descriptors/database/jbilling-upgrade-4.0.xml', NOW(), 5, '7:716885f9c1ae83d8e2e9582867f88c2d', 'addColumn', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.0.xml::add quantity multiplier::Emir Calabuch
-- Preference diameter unit multiplier/divisor
INSERT INTO public.preference_type (id, def_value) VALUES ((select max(id) + 1 from preference_type p), '1');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, (select max(id) from preference_type), 'description', 1.0, 'Diameter units multiplier/divisor');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, (select max(id) from preference_type), 'instruction', 1.0, 'The units value received from Diameter is divided/multiplied by this factor to convert input seconds to other time units. Values < 1 set the multiplier to 1.');

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('add quantity multiplier', 'Emir Calabuch', 'descriptors/database/jbilling-upgrade-4.0.xml', NOW(), 6, '7:2b0a54d788cfc1457414a4e8174b3f12', 'insert (x3)', 'Preference diameter unit multiplier/divisor', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.0.xml::Add 'Subscriber URI' metafield::Oscar Bidabehere
INSERT INTO meta_field_name (id, entity_id, name, entity_type, data_type, is_disabled, is_mandatory, display_order, optlock)
                select (select COALESCE(max(p.id),0)+1 from meta_field_name p) + (select COALESCE(count(*),0) from entity e2 where e1.id > e2.id and e2.id <> e1.id),
                       e1.id,
                       'Subscriber URI',
                       'CUSTOMER',
                       'STRING',
                       false,
                       false,
                       1,
                       1
                from entity e1
                order by e1.id;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('Add ''Subscriber URI'' metafield', 'Oscar Bidabehere', 'descriptors/database/jbilling-upgrade-4.0.xml', NOW(), 7, '7:3ead37c84a2a4d6ad932bbf47b697c83', 'sql', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.0.xml::#4430 - Call details in order line item::Oscar Bidabehere
ALTER TABLE public.order_line ADD sip_uri VARCHAR(255);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#4430 - Call details in order line item', 'Oscar Bidabehere', 'descriptors/database/jbilling-upgrade-4.0.xml', NOW(), 8, '7:2ded88547e96ce18fd37bc03d6ad5359', 'addColumn', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.0.xml::Requirements #4501 - Per-customer automatic top-up parameters::Oscar Bidabehere
ALTER TABLE public.customer ADD recharge_threshold numeric(22, 10);

ALTER TABLE public.customer ADD monthly_limit numeric(22, 10);

ALTER TABLE public.customer ADD current_monthly_amount numeric(22, 10);

ALTER TABLE public.customer ADD current_month TIMESTAMP WITHOUT TIME ZONE;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('Requirements #4501 - Per-customer automatic top-up parameters', 'Oscar Bidabehere', 'descriptors/database/jbilling-upgrade-4.0.xml', NOW(), 9, '7:44a56451dbd82dc5a22e7cf955c37e02', 'addColumn', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.0.xml::add carried_units column to charge_sessions table::Oscar bidabehere
ALTER TABLE public.charge_sessions ADD carried_units numeric(22, 10);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('add carried_units column to charge_sessions table', 'Oscar bidabehere', 'descriptors/database/jbilling-upgrade-4.0.xml', NOW(), 10, '7:065b32fae40e53e3bb00586ff1d93359', 'addColumn', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.0.xml::20130510-#4989-customer-notes::Rahul Asthana
CREATE TABLE public.customer_notes (id INT NOT NULL, note_title VARCHAR(50), note_content VARCHAR(1000), creation_time TIMESTAMP WITHOUT TIME ZONE, entity_id INT, user_id INT, customer_id INT, CONSTRAINT PK_CUSTOMER_NOTES PRIMARY KEY (id));

ALTER TABLE public.customer_notes ADD CONSTRAINT "customer_notes_entity_id_FK" FOREIGN KEY (entity_id) REFERENCES public.entity (id);

ALTER TABLE public.customer_notes ADD CONSTRAINT "customer_notes_user_id_FK" FOREIGN KEY (user_id) REFERENCES public.base_user (id);

ALTER TABLE public.customer_notes ADD CONSTRAINT "customer_notes_customer_id_FK" FOREIGN KEY (customer_id) REFERENCES public.customer (id);

ALTER TABLE public.customer DROP COLUMN notes;

INSERT INTO public.jbilling_seqs (name, next_id) VALUES ('customer_notes', 1.0);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('20130510-#4989-customer-notes', 'Rahul Asthana', 'descriptors/database/jbilling-upgrade-4.0.xml', NOW(), 11, '7:542267d600932a00e7833f1129895744', 'createTable, addForeignKeyConstraint (x3), dropColumn, insert', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.0.xml::20130520-#4962-customer-notes::Rahul Asthana
ALTER TABLE public.customer DROP COLUMN balance_type;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('20130520-#4962-customer-notes', 'Rahul Asthana', 'descriptors/database/jbilling-upgrade-4.0.xml', NOW(), 12, '7:f7cd7541be674333464e0fb502bf55fe', 'dropColumn', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.0.xml::20130820-add-rating-unit::Panche Isajeski
CREATE TABLE public.rating_unit (id INT NOT NULL, name VARCHAR(50) NOT NULL, entity_id INT NOT NULL, price_unit_name VARCHAR(50), increment_unit_name VARCHAR(50), increment_unit_quantity numeric(22, 10), can_be_deleted BOOLEAN DEFAULT TRUE, optlock INT NOT NULL, CONSTRAINT PK_RATING_UNIT PRIMARY KEY (id));

ALTER TABLE public.rating_unit ADD CONSTRAINT "rating_unit_entity_id_FK" FOREIGN KEY (entity_id) REFERENCES public.entity (id);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('20130820-add-rating-unit', 'Panche Isajeski', 'descriptors/database/jbilling-upgrade-4.0.xml', NOW(), 13, '7:f825b9ce1cfb3164a9aeb9ae51e788e5', 'createTable, addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.0.xml::20130820-default-rating-unit-rate-card::Panche Isajeski
insert into rating_unit
                    (id, name, entity_id, price_unit_name, increment_unit_name, increment_unit_quantity,
                    can_be_deleted, optlock)
                select (select COALESCE(max(r.id),0)+1 from rating_unit r) + (select count(*) from entity e2 where e1.id > e2.id and e2.id <> e1.id),
                'Time',e1.id,'Minute','Seconds',60.0,false,0
                from entity e1;

INSERT INTO public.jbilling_seqs (name, next_id) VALUES ('rating_unit', (select COALESCE(max(r.id),0)+1 from rating_unit r));

UPDATE public.jbilling_seqs SET next_id = (select COALESCE(max(m.id),0)+1 from matching_field m) WHERE name='matching_field';

INSERT INTO public.jbilling_seqs (name, next_id) VALUES ('route', (select COALESCE(max(r.id),0)+1 from route r));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('20130820-default-rating-unit-rate-card', 'Panche Isajeski', 'descriptors/database/jbilling-upgrade-4.0.xml', NOW(), 14, '7:f6e1a99e5e987c5b000f24664961e211', 'sql, insert, update, insert', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.0.xml::hierarchical_routing::Vladimir Carevski
ALTER TABLE public.route ADD root_table BOOLEAN DEFAULT FALSE;

ALTER TABLE public.route ADD output_field_name VARCHAR(150);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('hierarchical_routing', 'Vladimir Carevski', 'descriptors/database/jbilling-upgrade-4.0.xml', NOW(), 15, '7:54470187053a8dd94f3b546408606bd7', 'addColumn', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.0.xml::20131024 hierarchical_routing - default_route::Gerhard Maree
ALTER TABLE public.route ADD default_route VARCHAR(255);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('20131024 hierarchical_routing - default_route', 'Gerhard Maree', 'descriptors/database/jbilling-upgrade-4.0.xml', NOW(), 16, '7:73a67ef5edeefe72c11797d250df3f65', 'addColumn', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.0.xml::20140220 #7520 - Order Changes Type::Alexander Aksenov
CREATE TABLE public.order_change_type (id INT NOT NULL, name VARCHAR(255) NOT NULL, entity_id INT, default_type BOOLEAN DEFAULT FALSE NOT NULL, allow_order_status_change BOOLEAN DEFAULT FALSE NOT NULL, optlock INT NOT NULL, CONSTRAINT order_change_type_pkey PRIMARY KEY (id));

ALTER TABLE public.order_change_type ADD CONSTRAINT order_change_type_entity_id_fk FOREIGN KEY (entity_id) REFERENCES public.entity (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.jbilling_table (id, name) VALUES ((select max(t.id)+1 from jbilling_table t), 'order_change_type');

INSERT INTO public.jbilling_seqs (name, next_id) VALUES ('order_change_type', 2.0);

CREATE TABLE public.order_change_type_item_type_map (order_change_type_id INT NOT NULL, item_type_id INT NOT NULL);

ALTER TABLE public.order_change_type_item_type_map ADD CONSTRAINT order_change_type_item_type_map_change_type_id_fk FOREIGN KEY (order_change_type_id) REFERENCES public.order_change_type (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE public.order_change_type_item_type_map ADD CONSTRAINT order_change_type_item_type_map_item_type_id_fk FOREIGN KEY (item_type_id) REFERENCES public.item_type (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

CREATE TABLE public.order_change_type_meta_field_map (order_change_type_id INT NOT NULL, meta_field_id INT NOT NULL);

ALTER TABLE public.order_change_type_meta_field_map ADD CONSTRAINT order_change_type_meta_field_map_change_type_id_fk FOREIGN KEY (order_change_type_id) REFERENCES public.order_change_type (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE public.order_change_type_meta_field_map ADD CONSTRAINT order_change_type_meta_field_map_meta_field_id_fk FOREIGN KEY (meta_field_id) REFERENCES public.meta_field_name (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.order_change_type (id, name, optlock, default_type, allow_order_status_change) VALUES (1.0, 'Default', 0.0, TRUE, FALSE);

ALTER TABLE public.order_change ADD order_change_type_id INT;

ALTER TABLE public.order_change ADD order_status_id INT;

UPDATE public.order_change SET order_change_type_id = 1.0;

ALTER TABLE public.order_change ALTER COLUMN  order_change_type_id SET NOT NULL;

ALTER TABLE public.order_change ADD CONSTRAINT order_change_order_change_type_id_fk FOREIGN KEY (order_change_type_id) REFERENCES public.order_change_type (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE public.order_change ADD CONSTRAINT order_change_order_status_id_fk FOREIGN KEY (order_status_id) REFERENCES public.order_status (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('20140220 #7520 - Order Changes Type', 'Alexander Aksenov', 'descriptors/database/jbilling-upgrade-4.0.xml', NOW(), 17, '7:8d04933074b145c09fe06565971e099d', 'createTable, addForeignKeyConstraint, insert (x2), createTable, addForeignKeyConstraint (x2), createTable, addForeignKeyConstraint (x2), insert, addColumn (x2), update, addNotNullConstraint, addForeignKeyConstraint (x2)', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.0.xml::20140227 #7520 Order Changes Type plugin for orderStatus change::Alexander Aksenov
INSERT INTO public.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES ((select max(p.id)+1 from pluggable_task_type p), 17.0, 'com.sapienter.jbilling.server.order.task.OrderChangeApplyOrderStatusTask', 0.0);

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, (select max(p.id) from pluggable_task_type p), 'title', 1.0, 'Change order status on order change apply');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, (select max(p.id) from pluggable_task_type p), 'description', 1.0, 'This plug-in will change the status of order during order change apply to selected in order change.');

UPDATE public.jbilling_seqs SET next_id = (select max(p.id)+1 from pluggable_task_type p) WHERE name='pluggable_task_type';

INSERT INTO pluggable_task (id, entity_id, type_id, processing_order, optlock)
                   select (select max(p.id)+1 from pluggable_task p) + (select count(*) from entity e2 where e1.id > e2.id and e2.id <> e1.id),
                          e1.id,
                          (select max(p.id) from pluggable_task_type p),
                          1,
                          1
                   from entity e1
                   order by e1.id;

UPDATE public.jbilling_seqs SET next_id = coalesce((select max(p.id)+1 from pluggable_task p), 1) WHERE name='pluggable_task';

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('20140227 #7520 Order Changes Type plugin for orderStatus change', 'Alexander Aksenov', 'descriptors/database/jbilling-upgrade-4.0.xml', NOW(), 18, '7:fc39c0bba8b433d4e4516d9325f43546', 'insert (x3), update, sql, update', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.0.xml::#7870:fix-product-id-in-route-tables::Marco Manzi
CREATE function temp_for_fix() RETURNS VOID AS
                     $$
                    DECLARE t record;
                    BEGIN
                        FOR t IN SELECT table_name FROM route LOOP
                            EXECUTE 'ALTER TABLE public.' || quote_ident(t.table_name) || ' ALTER COLUMN product TYPE VARCHAR(50)';
                        END LOOP; END;
                    $$ LANGUAGE plpgsql;
                    SELECT temp_for_fix();
                    DROP function temp_for_fix();

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#7870:fix-product-id-in-route-tables', 'Marco Manzi', 'descriptors/database/jbilling-upgrade-4.0.xml', NOW(), 19, '7:7c21f0dc9ff599fa785adc9cdcadd3c3', 'sql', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.0.xml::#7899 - Subscription Products::Khobab Chaudhary
INSERT INTO public.order_line_type (id, editable) VALUES (5.0, 1.0);

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES ((select id from jbilling_table where name = 'order_line_type'), 5.0, 'description', 1.0, 'Subscription');

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#7899 - Subscription Products', 'Khobab Chaudhary', 'descriptors/database/jbilling-upgrade-4.0.xml', NOW(), 20, '7:5d7de50b28e1f805ddcb8148bd2d4953', 'insert (x2)', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.0.xml::#8330:reassign_the_same_asset_for_terminated_order::Marco Manzi
ALTER TABLE public.asset_transition ADD start_date TIMESTAMP WITHOUT TIME ZONE;

ALTER TABLE public.asset_transition ADD end_date TIMESTAMP WITHOUT TIME ZONE;

ALTER TABLE public.asset_transition ADD order_line_id INT;

insert into asset_transition
                (id, create_datetime, start_date, asset_id, user_id, new_status_id, order_line_id)
                (select tmp.at_id, tmp.create_datetime, tmp.start_date, tmp.asset_id, tmp.user_id, tmp.status_id, tmp.order_line_id
                from
                (select (select coalesce(max(id),0)+a.id from asset_transition ) as at_id,
                    coalesce(
                        (select oc.application_date
                            from order_change oc
                            where oc.application_date is not null
                                and oc.status_id in (select gs.id from generic_status gs where gs.dtype='order_change_status' and attribute1='YES'))
                        ,
                        (select oc.application_date
                            from order_change oc
                            inner join order_change_asset_map ocam on oc.id = ocam.order_change_id
                            where ocam.asset_id = a.id
                                and oc.status_id in (select gs.id from generic_status gs where gs.dtype='order_change_status' and attribute1='YES'))
                    ) as create_datetime,
                    coalesce(
                        (select oc.application_date
                            from order_change oc
                            where oc.application_date is not null
                                and oc.status_id in (select gs.id from generic_status gs where gs.dtype='order_change_status' and attribute1='YES'))
                        ,
                        (select oc.application_date
                            from order_change oc
                            inner join order_change_asset_map ocam on oc.id = ocam.order_change_id
                            where ocam.asset_id = a.id
                                and oc.status_id in (select gs.id from generic_status gs where gs.dtype='order_change_status' and attribute1='YES'))
                    ) as start_date,
                    (a.id) as asset_id,
                    (select o.user_id from purchase_order o where exists (select * from order_line ol where ol.order_id = o.id and ol.id = a.order_line_id)) as user_id,
                    (a.status_id) as status_id,
                    (a.order_line_id) as order_line_id
                from asset a where order_line_id is not null) as tmp
                where tmp.create_datetime is not null
                    and tmp.start_date is not null);

ALTER TABLE public.asset DROP CONSTRAINT asset_fk_2;

ALTER TABLE public.asset DROP COLUMN order_line_id;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#8330:reassign_the_same_asset_for_terminated_order', 'Marco Manzi', 'descriptors/database/jbilling-upgrade-4.0.xml', NOW(), 21, '7:a337a286ffcf639932590b433f868335', 'addColumn (x3), sql, dropForeignKeyConstraint, dropColumn', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.0.xml::#8330:start_date_not_null::Marco Manzi
ALTER TABLE public.asset_transition ALTER COLUMN  start_date SET NOT NULL;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#8330:start_date_not_null', 'Marco Manzi', 'descriptors/database/jbilling-upgrade-4.0.xml', NOW(), 22, '7:23eba83d9ae158c19673a99d25d04d1a', 'addNotNullConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.0.xml::#8330:asset_transition_seqs::Marco Manzi
UPDATE public.jbilling_seqs SET next_id = (SELECT coalesce(max(id),0) FROM asset_transition) WHERE name='asset_transition';

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#8330:asset_transition_seqs', 'Marco Manzi', 'descriptors/database/jbilling-upgrade-4.0.xml', NOW(), 23, '7:b75bbdc1a0aa2ba7e186eec7ca08be08', 'update', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.0.xml::20140131-7219-save-nested-search-entities::Gerhard Maree
CREATE TABLE public.data_table_query_entry (id INT NOT NULL, route_id INT NOT NULL, columns VARCHAR(250) NOT NULL, next_entry_id INT, optlock INT NOT NULL, CONSTRAINT PK_DATA_TABLE_QUERY_ENTRY PRIMARY KEY (id));

ALTER TABLE public.data_table_query_entry ADD CONSTRAINT "data_table_query_entry_next_FK" FOREIGN KEY (next_entry_id) REFERENCES public.data_table_query_entry (id);

INSERT INTO public.jbilling_seqs (name, next_id) VALUES ('data_table_query_entry', (select COALESCE(max(r.id),0)+1 from data_table_query_entry r));

CREATE TABLE public.data_table_query (id INT NOT NULL, name VARCHAR(50) NOT NULL, route_id INT NOT NULL, global INT NOT NULL, root_entry_id INT NOT NULL, user_id INT NOT NULL, optlock INT NOT NULL, CONSTRAINT PK_DATA_TABLE_QUERY PRIMARY KEY (id));

ALTER TABLE public.data_table_query ADD CONSTRAINT "data_table_query_next_FK" FOREIGN KEY (root_entry_id) REFERENCES public.data_table_query_entry (id);

INSERT INTO public.jbilling_seqs (name, next_id) VALUES ('data_table_query', (select COALESCE(max(r.id),0)+1 from data_table_query r));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('20140131-7219-save-nested-search-entities', 'Gerhard Maree', 'descriptors/database/jbilling-upgrade-4.0.xml', NOW(), 24, '7:b6933951ebfbed9db734706d9cb5fa88', 'createTable, addForeignKeyConstraint, insert, createTable, addForeignKeyConstraint, insert', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.0.xml::#7045-data_tables-set_it_as_route_table_or_not::Juan Vidal
ALTER TABLE public.route ADD route_table BOOLEAN DEFAULT FALSE;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#7045-data_tables-set_it_as_route_table_or_not', 'Juan Vidal', 'descriptors/database/jbilling-upgrade-4.0.xml', NOW(), 25, '7:4cb57fd508df0b3a0fc71f3a61a701a3', 'addColumn', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.0.xml::#10045:reverting_the_asset_transition_history::Marco Manzi
ALTER TABLE public.asset ADD order_line_id INT;

ALTER TABLE public.asset ADD CONSTRAINT asset_fk_2 FOREIGN KEY (order_line_id) REFERENCES public.order_line (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

update asset a set order_line_id = (SELECT order_line_id
			from asset_transition where start_date is not null
			AND end_date is null
			AND asset_id = a.id);

ALTER TABLE public.asset_transition DROP COLUMN start_date;

ALTER TABLE public.asset_transition DROP COLUMN end_date;

ALTER TABLE public.asset_transition DROP COLUMN order_line_id;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#10045:reverting_the_asset_transition_history', 'Marco Manzi', 'descriptors/database/jbilling-upgrade-4.0.xml', NOW(), 26, '7:39af65a616fa06660e7b74ae0e23a5f7', 'addColumn, addForeignKeyConstraint, sql, dropColumn (x3)', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.0.xml::requirement # 9831 - global assets::Rohit Gupta
ALTER TABLE public.asset ADD global BOOLEAN NOT NULL DEFAULT FALSE;

CREATE TABLE public.asset_entity_map (asset_id INT NOT NULL, entity_id INT NOT NULL);

ALTER TABLE public.asset_entity_map ADD CONSTRAINT asset_entity_map_fk1 FOREIGN KEY (entity_id) REFERENCES public.entity (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE public.asset_entity_map ADD CONSTRAINT asset_entity_map_fk2 FOREIGN KEY (asset_id) REFERENCES public.asset (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE public.asset_entity_map ADD CONSTRAINT asset_entity_map_uc_1 UNIQUE (asset_id, entity_id);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('requirement # 9831 - global assets', 'Rohit Gupta', 'descriptors/database/jbilling-upgrade-4.0.xml', NOW(), 27, '7:63938f5b0e754adaa49f994eb2b85fe6', 'addColumn, createTable, addForeignKeyConstraint (x2), addUniqueConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.0.xml::20141104-#10343 - entity_id should not be null::Aman Goel
ALTER TABLE public.item_type ALTER COLUMN  entity_id SET NOT NULL;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('20141104-#10343 - entity_id should not be null', 'Aman Goel', 'descriptors/database/jbilling-upgrade-4.0.xml', NOW(), 28, '7:3668a67b8bb39013dae8514af6fd12dd', 'addNotNullConstraint', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.0.xml::20141124-rename-partner-to-Agent::Vikas Bodani
-- Preference Types 5 through 12 should not being used anywhere. Partner is replaced with Agent.
UPDATE public.international_description SET content = 'Agent' WHERE table_id = (select id from jbilling_table where name ='role') and content='Partner';

DELETE FROM public.preference  WHERE type_id in (5,6,7,8,9,10,11,12);

DELETE FROM public.international_description  WHERE table_id = (select id from jbilling_table where name ='preference_type') and foreign_id in (5,6,7,8,9,10,11,12);

DELETE FROM public.preference_type  WHERE id in (5,6,7,8,9,10,11,12);

DELETE FROM public.notification_message_type  WHERE category_id = 3 and id in (10,11);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('20141124-rename-partner-to-Agent', 'Vikas Bodani', 'descriptors/database/jbilling-upgrade-4.0.xml', NOW(), 29, '7:4859237ad017f452ef2155abda6b4464', 'update, delete (x4)', 'Preference Types 5 through 12 should not being used anywhere. Partner is replaced with Agent.', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.0.xml::20141126-rename-ForeignKeyConstraint::Manisha Gupta
ALTER TABLE public.meta_field_group DROP CONSTRAINT "account_type_main_subscription_period_FK2";

ALTER TABLE public.meta_field_group ADD CONSTRAINT "meta_field_group_account_type_FK2" FOREIGN KEY (account_type_id) REFERENCES public.account_type (id);

ALTER TABLE public.meta_field_group ADD CONSTRAINT "meta_field_group_entity_FK1" FOREIGN KEY (entity_id) REFERENCES public.entity (id);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('20141126-rename-ForeignKeyConstraint', 'Manisha Gupta', 'descriptors/database/jbilling-upgrade-4.0.xml', NOW(), 30, '7:fda82f25a00179dedcf9f67836402b07', 'dropForeignKeyConstraint, addForeignKeyConstraint (x2)', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.0.xml::10632-event_base_custom_notification_fix::Marco Manzi
UPDATE public.pluggable_task_type SET min_parameters = '0' WHERE class_name = 'com.sapienter.jbilling.server.user.tasks.EventBasedCustomNotificationTask' AND category_id = 17;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('10632-event_base_custom_notification_fix', 'Marco Manzi', 'descriptors/database/jbilling-upgrade-4.0.xml', NOW(), 31, '7:1f7f8b0812a4163b203762c36a11ea5c', 'update', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.0.xml::#9977:Partner-To-Agent-Fix-demo-data::Marco Manzi
UPDATE public.international_description SET content = 'Create agent' WHERE table_id = 59 AND psudo_column='description' AND foreign_id=101
                AND language_id=1 AND content='Create partner';

UPDATE public.international_description SET content = 'Create agent' WHERE table_id = 59 AND psudo_column='description' AND foreign_id=101
                AND language_id=1 AND content='Create partner';

UPDATE public.international_description SET content = 'Edit agent' WHERE table_id = 59 AND psudo_column='description' AND foreign_id=102
                AND language_id=1 AND content='Edit partner';

UPDATE public.international_description SET content = 'Delete agent' WHERE table_id = 59 AND psudo_column='description' AND foreign_id=103
                AND language_id=1 AND content='Delete partner';

UPDATE public.international_description SET content = 'View agent details' WHERE table_id = 59 AND psudo_column='description' AND foreign_id=104
                AND language_id=1 AND content='View partner details';

UPDATE public.international_description SET content = 'A agent that will bring customers' WHERE table_id = 60 AND psudo_column='description' AND foreign_id=4
                AND language_id=1 AND content='A partner that will bring customers';

UPDATE public.international_description SET content = 'Agent' WHERE table_id = 60 AND psudo_column='title' AND foreign_id=4
                AND language_id=1 AND content='Partner';

UPDATE public.international_description SET content = 'A agent that will bring customers' WHERE table_id = 60 AND psudo_column='description' AND foreign_id=63
                AND language_id=1 AND content='A partner that will bring customers';

UPDATE public.international_description SET content = 'Agent' WHERE table_id = 60 AND psudo_column='title' AND foreign_id=63
                AND language_id=1 AND content='Partner';

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#9977:Partner-To-Agent-Fix-demo-data', 'Marco Manzi', 'descriptors/database/jbilling-upgrade-4.0.xml', NOW(), 32, '7:60627975097a4d3abe0e1b0b175846c7', 'update (x9)', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.0.xml::#10901-Replacing Partner to Agents in Permissions page::Anand Kushwaha
UPDATE public.international_description SET content = 'Show agent menu' WHERE content='Show partner menu';

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#10901-Replacing Partner to Agents in Permissions page', 'Anand Kushwaha', 'descriptors/database/jbilling-upgrade-4.0.xml', NOW(), 33, '7:7c98ed064910d41ca61e8868af0a2ff2', 'update', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.0.xml::Rename MENU_93::Manisha Gupta
UPDATE public.international_description SET content = 'Show payments and refunds menu' WHERE table_id = 59 and foreign_id = 93;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('Rename MENU_93', 'Manisha Gupta', 'descriptors/database/jbilling-upgrade-4.0.xml', NOW(), 34, '7:bf1ad825a0ea3e5c9311a5f597535a50', 'update', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.0.xml::#11172-show-category-metafields::Prashant Gupta
CREATE TABLE public.item_type_meta_field_map (item_type_id INT NOT NULL, meta_field_value_id INT NOT NULL);

ALTER TABLE public.item_type_meta_field_map ADD CONSTRAINT item_type_meta_field_type_fk FOREIGN KEY (item_type_id) REFERENCES public.item_type (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE public.item_type_meta_field_map ADD CONSTRAINT item_type_meta_field_value_fk FOREIGN KEY (meta_field_value_id) REFERENCES public.meta_field_value (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#11172-show-category-metafields', 'Prashant Gupta', 'descriptors/database/jbilling-upgrade-4.0.xml', NOW(), 35, '7:ec5dfc56eb7419cb522aa6bb6c3b624e', 'createTable, addForeignKeyConstraint (x2)', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.0.xml::#10442 Adding All Account TypecheckboxinpaymentMethodType edit::Anand Kushwaha
ALTER TABLE public.payment_method_type ADD all_account_type BOOLEAN NOT NULL DEFAULT FALSE;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#10442 Adding All Account TypecheckboxinpaymentMethodType edit', 'Anand Kushwaha', 'descriptors/database/jbilling-upgrade-4.0.xml', NOW(), 36, '7:81128e7021979b4ec0fcf54a7b4c8bd6', 'addColumn', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.0.xml::20150114 - late guided usage delete order::Vikas Bodani
ALTER TABLE public.purchase_order ADD deleted_date date;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('20150114 - late guided usage delete order', 'Vikas Bodani', 'descriptors/database/jbilling-upgrade-4.0.xml', NOW(), 37, '7:3682052d466ffa1aa85a045098bd8347', 'addColumn', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.0.xml::11565-added-invoice-reminder-name::Prashant Gupta
INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, 18.0, 'description', 1.0, 'Invoice Reminder');

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('11565-added-invoice-reminder-name', 'Prashant Gupta', 'descriptors/database/jbilling-upgrade-4.0.xml', NOW(), 38, '7:229e007d8500b0b5648cc728c5b1ba0a', 'insert', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.0.xml::#12690-index-on_parent_id-customer-table::Prashant Gupta
CREATE INDEX ix_parent_customer_id ON public.customer(parent_id);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#12690-index-on_parent_id-customer-table', 'Prashant Gupta', 'descriptors/database/jbilling-upgrade-4.0.xml', NOW(), 39, '7:60d91cf9ee88b4c8a882cac11c530057', 'createIndex', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-4.0.xml::#12691-Add field_usage column::Ravi Singhal
-- Drop table metafield_type_map. One meta field can have only one usage type.
ALTER TABLE public.meta_field_name ADD field_usage VARCHAR(50);

update meta_field_name as name set field_usage = 'BANK_ACCOUNT_NUMBER' where name = 'ach.account.number';

update meta_field_name as name set field_usage = 'BANK_ACCOUNT_TYPE'  where name = 'ach.account.type';

update meta_field_name as name set field_usage = 'BANK_NAME'          where name = 'ach.bank.name';

update meta_field_name as name set field_usage = 'TITLE'              where name = 'ach.customer.name';

update meta_field_name as name set field_usage = 'GATEWAY_KEY'        where name = 'ach.gateway.key';

update meta_field_name as name set field_usage = 'BANK_ROUTING_NUMBER' where name = 'ach.routing.number';

update meta_field_name as name set field_usage = 'TITLE'              where name = 'cc.cardholder.name';

update meta_field_name as name set field_usage = 'DATE'               where name = 'cc.expiry.date';

update meta_field_name as name set field_usage = 'GATEWAY_KEY'        where name = 'cc.gateway.key';

update meta_field_name as name set field_usage = 'PAYMENT_CARD_NUMBER' where name = 'cc.number';

update meta_field_name as name set field_usage = 'CC_TYPE'            where name = 'cc.type';

update meta_field_name as name set field_usage = 'BANK_NAME'          where name = 'cheque.bank.name';

update meta_field_name as name set field_usage = 'DATE'               where name = 'cheque.date';

update meta_field_name as name set field_usage = 'CHEQUE_NUMBER'      where name = 'cheque.number';

update meta_field_name as name set field_usage = 'ADDRESS1'           where name = 'contact.address1';

update meta_field_name as name set field_usage = 'ADDRESS2'           where name = 'contact.address2';

update meta_field_name as name set field_usage = 'EMAIL'              where name = 'contact.alt.email';

update meta_field_name as name set field_usage = 'CITY'               where name = 'contact.city';

update meta_field_name as name set field_usage = 'COUNTRY_CODE'       where name = 'contact.country.code';

update meta_field_name as name set field_usage = 'EMAIL'              where name = 'contact.email';

update meta_field_name as name set field_usage = 'FAX_AREA_CODE'      where name = 'contact.fax.area.code';

update meta_field_name as name set field_usage = 'FAX_COUNTRY_CODE'   where name = 'contact.fax.country.code';

update meta_field_name as name set field_usage = 'FAX_NUMBER'         where name = 'contact.fax.number';

update meta_field_name as name set field_usage = 'FIRST_NAME'         where name = 'contact.first.name';

update meta_field_name as name set field_usage = 'INITIAL'            where name = 'contact.initial';

update meta_field_name as name set field_usage = 'LAST_NAME'          where name = 'contact.last.name';

update meta_field_name as name set field_usage = 'ORGANIZATION'       where name = 'contact.organization';

update meta_field_name as name set field_usage = 'PHONE_AREA_CODE'    where name = 'contact.phone.area.code';

update meta_field_name as name set field_usage = 'PHONE_COUNTRY_CODE' where name = 'contact.phone.country.code';

update meta_field_name as name set field_usage = 'PHONE_NUMBER'       where name = 'contact.phone.number';

update meta_field_name as name set field_usage = 'POSTAL_CODE'        where name = 'contact.postal.code';

update meta_field_name as name set field_usage = 'STATE_PROVINCE'     where name = 'contact.state.province';

update meta_field_name as name set field_usage = 'TITLE'              where name = 'contact.title';

update meta_field_name as name set field_usage = 'FIRST_NAME'         where name = 'first.name';

update meta_field_name as name set field_usage = 'LAST_NAME'          where name = 'last.name';

DROP TABLE public.metafield_type_map;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#12691-Add field_usage column', 'Ravi Singhal', 'descriptors/database/jbilling-upgrade-4.0.xml', NOW(), 40, '7:cc6b1aa2818dcbdf1c153cd86797ed63', 'addColumn, sql, dropTable', 'Drop table metafield_type_map. One meta field can have only one usage type.', 'EXECUTED', '3.2.2');

-- Release Database Lock
