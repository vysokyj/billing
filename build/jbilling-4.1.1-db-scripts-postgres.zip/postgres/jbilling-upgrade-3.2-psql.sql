-- Changeset descriptors/database/jbilling-upgrade-3.2.xml::min-balance-to-ignore-ageing::Panche Isajeski
-- March 27, 2012 Redmine #2486 New Preference - Min Balance to ignore Ageing/Overdue Notifications
INSERT INTO public.preference_type (id, def_value) VALUES (51.0, '0');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 51.0, 'description', 1.0, 'Minimum Balance for which to ignore ageing');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 51.0, 'instruction', 1.0, 'Minimum Balance that the business is willing to ignore if overdue on an Invoice. If set, this value will determine if the User has enough balance to continue to Ageing or receive Notifications for Unpaid Invoices');

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('min-balance-to-ignore-ageing', 'Panche Isajeski', 'descriptors/database/jbilling-upgrade-3.2.xml', NOW(), 1, '7:2c3823a513867c4974079fccc4787df3', 'insert (x3)', 'March 27, 2012 Redmine #2486 New Preference - Min Balance to ignore Ageing/Overdue Notifications', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.2.xml::eliminate-main-order_alter-columns::Emiliano Conde
-- April 23, 2012 - Redmine #922 - Eliminate Main Order
ALTER TABLE public.customer ADD main_subscription_order_period_id INT;

ALTER TABLE public.customer ADD next_invoice_day_of_period INT;

UPDATE public.customer SET main_subscription_order_period_id = (select distinct period_id from purchase_order p where customer.current_order_id = p.id and p.is_current=1);

UPDATE public.customer SET main_subscription_order_period_id = (select distinct o.id from order_period o, base_user b where customer.user_id = b.id and b.entity_id = o.entity_id and o.unit_id=1 and o.value=1)  WHERE main_subscription_order_period_id is null;

ALTER TABLE public.customer ADD CONSTRAINT "customer_main_subscription_period_FK" FOREIGN KEY (main_subscription_order_period_id) REFERENCES public.order_period (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE public.billing_process_configuration DROP CONSTRAINT billing_proc_configtn_fk_1;

ALTER TABLE public.billing_process_configuration DROP COLUMN period_unit_id;

ALTER TABLE public.billing_process_configuration DROP COLUMN period_value;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('eliminate-main-order_alter-columns', 'Emiliano Conde', 'descriptors/database/jbilling-upgrade-3.2.xml', NOW(), 2, '7:00b76184f13f90864b269dade8f8b524', 'addColumn, update (x2), addForeignKeyConstraint, dropForeignKeyConstraint, dropColumn (x2)', 'April 23, 2012 - Redmine #922 - Eliminate Main Order', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.2.xml::eliminate-main-order_update-data-psql::Emiliano Conde
-- April 23, 2012 - Redmine #922 - Eliminate Main Order
UPDATE public.customer SET next_invoice_day_of_period = (select EXTRACT(DAY FROM p.active_since) from purchase_order p where customer.current_order_id = p.id and p.is_current=1);

UPDATE public.customer SET next_invoice_day_of_period = 1.0 WHERE next_invoice_day_of_period is null;

ALTER TABLE public.customer DROP COLUMN current_order_id;

ALTER TABLE public.purchase_order DROP COLUMN is_current;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('eliminate-main-order_update-data-psql', 'Emiliano Conde', 'descriptors/database/jbilling-upgrade-3.2.xml', NOW(), 3, '7:bd17e924a4b0dbf9d818efef7914cb75', 'update (x2), dropColumn (x2)', 'April 23, 2012 - Redmine #922 - Eliminate Main Order', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.2.xml::fix-min_params_SimpleTaxCompositionTask::Emiliano Conde
-- April 24, 2012 - Fix to SimpleTaxCompositionTask
UPDATE public.pluggable_task_type SET min_parameters = 1.0 WHERE class_name='com.sapienter.jbilling.server.process.task.SimpleTaxCompositionTask';

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('fix-min_params_SimpleTaxCompositionTask', 'Emiliano Conde', 'descriptors/database/jbilling-upgrade-3.2.xml', NOW(), 4, '7:fe9e061efc641247abdd965f5ab02e5b', 'update', 'April 24, 2012 - Fix to SimpleTaxCompositionTask', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.2.xml::clear-empty-meta_fields::Emiliano Conde
-- May 22, 2012 - Remove empty string metafields
DELETE FROM public.customer_meta_field_map  WHERE meta_field_value_id in (select id from meta_field_value where dtype='string' and length(string_value)=0);

DELETE FROM public.meta_field_value  WHERE dtype='string' and length(string_value)=0;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('clear-empty-meta_fields', 'Emiliano Conde', 'descriptors/database/jbilling-upgrade-3.2.xml', NOW(), 5, '7:c03db8bd29d2054324c086e03f30c4d3', 'delete (x2)', 'May 22, 2012 - Remove empty string metafields', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.2.xml::notification-message::Panche Isajeski
-- May 28, 2012 - Adding notification messages
ALTER TABLE public.notification_message ADD attachment_type VARCHAR(20);

ALTER TABLE public.notification_message ADD include_attachment INT;

ALTER TABLE public.notification_message ADD attachment_design VARCHAR(100);

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, 22.0, 'description', 1.0, 'Payment Entered');

INSERT INTO public.notification_message_type (id, category_id, optlock) VALUES (22.0, 3.0, 1.0);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('notification-message', 'Panche Isajeski', 'descriptors/database/jbilling-upgrade-3.2.xml', NOW(), 6, '7:8b28a3fb0056977c21990000adeefab4', 'addColumn (x3), insert (x2)', 'May 28, 2012 - Adding notification messages', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.2.xml::attach-overdue-invoices-to-notifications::Panche Isajeski
-- May 31, 2012 Redmine #2718 Attach Invoices to all Overdue Notifications
INSERT INTO public.preference_type (id, def_value) VALUES (52.0, '0');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 52.0, 'description', 1.0, 'Attach latest Invoice to all Overdue Notification.');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 52.0, 'instruction', 1.0, 'Overdue Notification Overdue 1 2 and 3 by default do not attach Invoices to the notification email. With this preference, the latest Invoice can be attached to such notifications automatically.');

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('attach-overdue-invoices-to-notifications', 'Panche Isajeski', 'descriptors/database/jbilling-upgrade-3.2.xml', NOW(), 7, '7:e7e15513c4239eb838787f550dcd5d06', 'insert (x3)', 'May 31, 2012 Redmine #2718 Attach Invoices to all Overdue Notifications', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.2.xml::20120608-#2725-notification-category::Vikas Bodani
-- June 15, Redmine #2725 - Custom Notification Category
INSERT INTO public.jbilling_seqs (name, next_id) VALUES ('notification_category', 2.0);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('20120608-#2725-notification-category', 'Vikas Bodani', 'descriptors/database/jbilling-upgrade-3.2.xml', NOW(), 8, '7:90397ac5f5c6af71ceb30284faa51ede', 'insert', 'June 15, Redmine #2725 - Custom Notification Category', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.2.xml::custom-notification-feature::Shweta Gupta
-- June 20, 2012 Redmine #2725 Custom Notification Feature
ALTER TABLE public.notification_message ADD notify_admin INT;

ALTER TABLE public.notification_message ADD notify_partner INT;

ALTER TABLE public.notification_message ADD notify_parent INT;

ALTER TABLE public.notification_message ADD notify_all_parents INT;

UPDATE public.notification_message SET notify_admin = 0.0;

UPDATE public.notification_message SET notify_partner = 0.0;

UPDATE public.notification_message SET notify_parent = 0.0;

UPDATE public.notification_message SET notify_all_parents = 0.0;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('custom-notification-feature', 'Shweta Gupta', 'descriptors/database/jbilling-upgrade-3.2.xml', NOW(), 9, '7:696537b57591f8cbf39624fefbb60676', 'addColumn (x4), update (x4)', 'June 20, 2012 Redmine #2725 Custom Notification Feature', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.2.xml::20120606-2718-overdue-invoice-penalty-order-task::Vikas Bodani
-- Overdue Invoice penalties plug-in - new feature
INSERT INTO public.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (97.0, 17.0, 'com.sapienter.jbilling.server.pluggableTask.OverdueInvoicePenaltyTask', 1.0);

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 97.0, 'title', 1.0, 'Penalty Task on Overude Invoice');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 97.0, 'description', 1.0, 'This task is responsible for applying a %-age or a fixed amount penalty on an Overdue Invoice. This task is powerful because it performs this action just before the Billing process collects orders.');

UPDATE public.jbilling_seqs SET next_id = 98.0 WHERE name='pluggable_task_type';

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('20120606-2718-overdue-invoice-penalty-order-task', 'Vikas Bodani', 'descriptors/database/jbilling-upgrade-3.2.xml', NOW(), 10, '7:85ff1cd4b3f3b3e21b2a84d55ba4383a', 'insert (x3), update', 'Overdue Invoice penalties plug-in - new feature', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.2.xml::remove-rules-generator-task::Brian Cowdery
-- July 8, 2012 Redmine # 3023 Remove rules generator API
DELETE FROM public.pluggable_task_parameter  WHERE task_id=6040;

DELETE FROM public.pluggable_task  WHERE id=6040;

DELETE FROM public.pluggable_task_type  WHERE id=78;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('remove-rules-generator-task', 'Brian Cowdery', 'descriptors/database/jbilling-upgrade-3.2.xml', NOW(), 11, '7:24c6b80505bf3a623c3189f300e5805f', 'delete (x3)', 'July 8, 2012 Redmine # 3023 Remove rules generator API', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.2.xml::add-event-based-custom-notification-task::Panche Isajeski
-- Jul 12, 2012 - #2725 - Custom notifications
INSERT INTO public.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (101.0, 17.0, 'com.sapienter.jbilling.server.user.tasks.EventBasedCustomNotificationTask', 1.0);

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 101.0, 'title', 1.0, 'Event based custom notification task');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 101.0, 'description', 1.0, 'The event based custom notification task takes the custom notification message and does the notification when the internal event occurred');

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('add-event-based-custom-notification-task', 'Panche Isajeski', 'descriptors/database/jbilling-upgrade-3.2.xml', NOW(), 12, '7:c912f82eb7120badbcbb45504d2cadc4', 'insert (x3)', 'Jul 12, 2012 - #2725 - Custom notifications', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.2.xml::3990 - Made order_id persistent to invoiceLineDTO::Vikas Bodani
-- Requirement 3990 - Added order_id to the Invoice_Line table.
ALTER TABLE public.invoice_line ADD order_id INT DEFAULT null;

ALTER TABLE public.invoice_line ADD CONSTRAINT invoice_line_fk_4 FOREIGN KEY (order_id) REFERENCES public.purchase_order (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('3990 - Made order_id persistent to invoiceLineDTO', 'Vikas Bodani', 'descriptors/database/jbilling-upgrade-3.2.xml', NOW(), 13, '7:37fb18bd6a347d0468c08992bf68a934', 'addColumn, addForeignKeyConstraint', 'Requirement 3990 - Added order_id to the Invoice_Line table.', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.2.xml::2006 - Force Unique Emails Preference::Vladimir Carevski
-- Bugs #2006 - Option to force unique emails in the company
INSERT INTO public.preference_type (id, def_value) VALUES (53.0, '0');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 53.0, 'description', 1.0, 'Force Unique Emails');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 53.0, 'instruction', 1.0, 'Set to 1 in order to force unique emails among the users/customers into the company. Set to 0 otherwise.');

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('2006 - Force Unique Emails Preference', 'Vladimir Carevski', 'descriptors/database/jbilling-upgrade-3.2.xml', NOW(), 14, '7:f4c6c02953c9021414768dad5dfc73c7', 'insert (x3)', 'Bugs #2006 - Option to force unique emails in the company', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.2.xml::4474 - Entity to be deletable.::Amol Gadre
-- Requirement #4474 - Added deleted column in entity to allow for soft deletion.
ALTER TABLE public.entity ADD deleted INT NOT NULL DEFAULT 0;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('4474 - Entity to be deletable.', 'Amol Gadre', 'descriptors/database/jbilling-upgrade-3.2.xml', NOW(), 15, '7:9bfe1c0e1bcb165d49966db06c6543e3', 'addColumn', 'Requirement #4474 - Added deleted column in entity to allow for soft deletion.', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.2.xml::change-category-for-penalty-task::Panche Isajeski
UPDATE public.pluggable_task_type SET category_id = 17.0 WHERE class_name='com.sapienter.jbilling.server.pluggableTask.BasicPenaltyTask';

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('change-category-for-penalty-task', 'Panche Isajeski', 'descriptors/database/jbilling-upgrade-3.2.xml', NOW(), 16, '7:34f5913c5a3f26d196cb99777fe7e376', 'update', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.2.xml::add-new-suretax-engine-base::Amol Gadre
-- Jun 24, 2013 - Add Suretax Processing
INSERT INTO public.jbilling_seqs (name, next_id) VALUES ('sure_tax_txn_log_seq', 2.0);

CREATE TABLE public.sure_tax_txn_log (id INT NOT NULL, txn_id VARCHAR(20) NOT NULL, txn_type VARCHAR(10) NOT NULL, txn_data TEXT NOT NULL, txn_date TIMESTAMP WITHOUT TIME ZONE NOT NULL, resp_trans_id INT, request_type VARCHAR(10), CONSTRAINT sure_tax_txn_log_pkey PRIMARY KEY (id));

INSERT INTO public.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (105.0, 4.0, 'com.sapienter.jbilling.server.process.task.SureTaxCompositionTask', 0.0);

INSERT INTO public.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES ((select max(ptt.id) + 1 from pluggable_task_type ptt), 17.0, 'com.sapienter.jbilling.server.process.task.SuretaxDeleteInvoiceTask', 0.0);

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 105.0, 'title', 1.0, 'Suretax Plugin');

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 105.0, 'description', 1.0, 'This plugin adds tax lines to invoice by consulting the Suretax Engine.');

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('add-new-suretax-engine-base', 'Amol Gadre', 'descriptors/database/jbilling-upgrade-3.2.xml', NOW(), 17, '7:b537cd361acb0cf41e6f617f4e4525ab', 'insert, createTable, insert (x4)', 'Jun 24, 2013 - Add Suretax Processing', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.2.xml::20121120 #3304 Jbilling Core Changes for Discounts::Amol Gadre
-- 20121120 #3304 Jbilling Core Changes for Discounts: Added new tables related to discounts functionality.
CREATE TABLE public.discount (id INT NOT NULL, code VARCHAR(20) NOT NULL, discount_type VARCHAR(25) NOT NULL, rate numeric(22, 10), start_date date, end_date date, entity_id INT, CONSTRAINT discount_pkey PRIMARY KEY (id));

CREATE TABLE public.discount_attribute (discount_id INT NOT NULL, attribute_name VARCHAR(255) NOT NULL, attribute_value VARCHAR(255));

ALTER TABLE public.discount_attribute ADD CONSTRAINT discount_attribute_pkey PRIMARY KEY (discount_id, attribute_name);

ALTER TABLE public.discount_attribute ADD CONSTRAINT discount_attr_id_fk FOREIGN KEY (discount_id) REFERENCES public.discount (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE public.discount ADD CONSTRAINT discount_entity_id_fk FOREIGN KEY (entity_id) REFERENCES public.entity (id);

CREATE TABLE public.discount_line (id INT NOT NULL, discount_id INT NOT NULL, item_id INT, order_id INT NOT NULL, discount_order_line_id INT, order_line_amount numeric(22, 10), description VARCHAR(1000) NOT NULL, CONSTRAINT discount_line_pkey PRIMARY KEY (id));

ALTER TABLE public.discount_line ADD CONSTRAINT discount_line_discount_id_fk FOREIGN KEY (discount_id) REFERENCES public.discount (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE public.discount_line ADD CONSTRAINT discount_line_item_id_fk FOREIGN KEY (item_id) REFERENCES public.item (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE public.discount_line ADD CONSTRAINT discount_line_order_id_fk FOREIGN KEY (order_id) REFERENCES public.purchase_order (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE public.discount_line ADD CONSTRAINT discount_line_order_line_id_fk FOREIGN KEY (discount_order_line_id) REFERENCES public.order_line (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.jbilling_seqs (name, next_id) VALUES ('discount', 2.0);

INSERT INTO public.jbilling_seqs (name, next_id) VALUES ('discount_attribute', 0.0);

INSERT INTO public.jbilling_seqs (name, next_id) VALUES ('discount_line', 1.0);

INSERT INTO public.order_line_type (id, editable) VALUES (4.0, 0.0);

INSERT INTO public.jbilling_table (name, id) VALUES ('discount', (select max(id) + 1 from jbilling_table j));

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('20121120 #3304 Jbilling Core Changes for Discounts', 'Amol Gadre', 'descriptors/database/jbilling-upgrade-3.2.xml', NOW(), 18, '7:df9c63a9e4d4462edc9bff8e759d0d74', 'createTable (x2), addPrimaryKey, addForeignKeyConstraint (x2), createTable, addForeignKeyConstraint (x4), insert (x5)', '20121120 #3304 Jbilling Core Changes for Discounts: Added new tables related to discounts functionality.', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.2.xml::20121213 #3452 Last Updated date time added on Discount::Amol Gadre
-- 20121213 #3452 Last Updated date time added on Discount.
ALTER TABLE public.discount ADD last_update_datetime TIMESTAMP WITHOUT TIME ZONE;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('20121213 #3452 Last Updated date time added on Discount', 'Amol Gadre', 'descriptors/database/jbilling-upgrade-3.2.xml', NOW(), 19, '7:8b8068ba80ae36348ad0be3e89da803b', 'addColumn', '20121213 #3452 Last Updated date time added on Discount.', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.2.xml::20121031 #3530 Merchant Account Relationships::Amol Gadre
-- #3530 - Added new column to purchase order called primary order id to link the orders while creating a plan order.
ALTER TABLE public.purchase_order ADD primary_order_id INT;

ALTER TABLE public.purchase_order ADD CONSTRAINT order_primary_order_fk_1 FOREIGN KEY (primary_order_id) REFERENCES public.purchase_order (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('20121031 #3530 Merchant Account Relationships', 'Amol Gadre', 'descriptors/database/jbilling-upgrade-3.2.xml', NOW(), 20, '7:438e0417fcb7e10e5bfe5972dbfcff60', 'addColumn, addForeignKeyConstraint', '#3530 - Added new column to purchase order called primary order id to link the orders while creating a plan order.', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.2.xml::4933 - Invoice Date and Invoice Due Date are Incorrect::Maruthi
UPDATE public.international_description SET content = 'Default blank. This preference has to be a date (In the format yyyy-mm-dd. Example: 2000-01-31), the system will make sure that all your invoices have their dates in an incremental way. Any invoice with a greater ''ID'' will also have a greater (or equal) date. In other words, a new invoice can not have an earlier date than an existing (older) invoice. To use this preference, set it as a string with the date where to start. This preference will not be used if blank' WHERE table_id=50 and foreign_id=31 and language_id=1 and psudo_column='instruction';

UPDATE public.preference_type SET def_value = '' WHERE id=31;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('4933 - Invoice Date and Invoice Due Date are Incorrect', 'Maruthi', 'descriptors/database/jbilling-upgrade-3.2.xml', NOW(), 21, '7:3681aa0a29b8bdec4aa7ef5ca86cb256', 'update (x2)', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.2.xml::fix-column-name-length::Juan Vidal
-- Fix to rename the column name to less than 30 characters to avoid errors in Oracle.
ALTER TABLE public.customer DROP CONSTRAINT "customer_main_subscription_period_FK";

ALTER TABLE public.customer RENAME COLUMN main_subscription_order_period_id TO main_subscript_order_period_id;

ALTER TABLE public.customer ADD CONSTRAINT "customer_main_subscription_period_FK" FOREIGN KEY (main_subscript_order_period_id) REFERENCES public.order_period (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('fix-column-name-length', 'Juan Vidal', 'descriptors/database/jbilling-upgrade-3.2.xml', NOW(), 22, '7:66ba15060609eee70a014cc0849cdd52', 'dropForeignKeyConstraint, renameColumn, addForeignKeyConstraint', 'Fix to rename the column name to less than 30 characters to avoid errors in Oracle.', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.2.xml::Requirement-5461::Rahul Asthana
-- Fix Unable to create new enumerations.
UPDATE public.jbilling_seqs SET next_id = 100.0 WHERE name='enumeration';

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('Requirement-5461', 'Rahul Asthana', 'descriptors/database/jbilling-upgrade-3.2.xml', NOW(), 23, '7:d0deb14443f14c174b966b7f11391ae6', 'update', 'Fix Unable to create new enumerations.', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.2.xml::#6076-add-notification-for-refunds::Juan Vidal
INSERT INTO public.notification_message_type (id, category_id, optlock) VALUES (23.0, 3.0, 1.0);

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, 23.0, 'description', 1.0, 'Payment (refund)');

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#6076-add-notification-for-refunds', 'Juan Vidal', 'descriptors/database/jbilling-upgrade-3.2.xml', NOW(), 24, '7:46495a67401a323908715262572724ba', 'insert (x2)', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.2.xml::#6250-Tables-without-primary-keys::maruthi
DROP SEQUENCE IF EXISTS filter_set_filter_id_seq CASCADE;

DROP SEQUENCE IF EXISTS user_credit_card_map_id_seq CASCADE;

DROP SEQUENCE IF EXISTS list_meta_field_values_id_seq CASCADE;

DELETE FROM public.jbilling_seqs  WHERE name='notification_category';

INSERT INTO public.jbilling_seqs (name, next_id) VALUES ('notification_category', 2.0);

ALTER TABLE public.jbilling_seqs ADD CONSTRAINT jbilling_seqs_pk PRIMARY KEY (name);

CREATE SEQUENCE public.filter_set_filter_id_seq START WITH 1 INCREMENT BY 1;

ALTER TABLE public.filter_set_filter ADD id INT DEFAULT nextval('filter_set_filter_id_seq');

CREATE SEQUENCE public.user_credit_card_map_id_seq START WITH 1 INCREMENT BY 1;

ALTER TABLE public.user_credit_card_map ADD id INT DEFAULT nextval('user_credit_card_map_id_seq');

CREATE SEQUENCE public.list_meta_field_values_id_seq START WITH 1 INCREMENT BY 1;

ALTER TABLE public.list_meta_field_values ADD id INT DEFAULT nextval('list_meta_field_values_id_seq');

ALTER TABLE public.currency_entity_map ADD CONSTRAINT currency_entity_map_compositekey PRIMARY KEY (currency_id, entity_id);

ALTER TABLE public.customer_meta_field_map ADD CONSTRAINT customer_meta_field_map_compositekey PRIMARY KEY (customer_id, meta_field_value_id);

ALTER TABLE public.entity_delivery_method_map ADD CONSTRAINT entity_delivery_method_map_compositekey PRIMARY KEY (method_id, entity_id);

ALTER TABLE public.entity_payment_method_map ADD CONSTRAINT entity_payment_method_map_compositekey PRIMARY KEY (entity_id, payment_method_id);

ALTER TABLE public.entity_report_map ADD CONSTRAINT entity_report_map_compositekey PRIMARY KEY (report_id, entity_id);

ALTER TABLE public.invoice_meta_field_map ADD CONSTRAINT invoice_meta_field_map_compositekey PRIMARY KEY (invoice_id, meta_field_value_id);

ALTER TABLE public.item_meta_field_map ADD CONSTRAINT item_meta_field_map_compositekey PRIMARY KEY (item_id, meta_field_value_id);

ALTER TABLE public.item_type_map ADD CONSTRAINT item_type_map_compositekey PRIMARY KEY (item_id, type_id);

ALTER TABLE public.order_meta_field_map ADD CONSTRAINT order_meta_field_map_compositekey PRIMARY KEY (order_id, meta_field_value_id);

ALTER TABLE public.partner_meta_field_map ADD CONSTRAINT partner_meta_field_map_compositekey PRIMARY KEY (partner_id, meta_field_value_id);

ALTER TABLE public.payment_meta_field_map ADD CONSTRAINT payment_meta_field_map_compositekey PRIMARY KEY (payment_id, meta_field_value_id);

ALTER TABLE public.promotion_user_map ADD CONSTRAINT promotion_user_map_compositekey PRIMARY KEY (user_id, promotion_id);

ALTER TABLE public.user_role_map ADD CONSTRAINT user_role_map_compositekey PRIMARY KEY (user_id, role_id);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#6250-Tables-without-primary-keys', 'maruthi', 'descriptors/database/jbilling-upgrade-3.2.xml', NOW(), 25, '7:8f1d3152721f2838206cde44ff8707d6', 'sql (x3), delete, insert, addPrimaryKey, createSequence, addColumn, createSequence, addColumn, createSequence, addColumn, addPrimaryKey (x13)', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.2.xml::#6183-credit-card-transaction-report-renamed-cc::Juan Vidal
UPDATE public.international_description SET content = 'Discover' WHERE content = 'Discovery' and table_id = 35;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#6183-credit-card-transaction-report-renamed-cc', 'Juan Vidal', 'descriptors/database/jbilling-upgrade-3.2.xml', NOW(), 26, '7:fa8164800bdcd87f01715f68281a6aad', 'update', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.2.xml::#6250-Tables-without-primary-keys - correction - 3::Vikas Bodani
UPDATE public.jbilling_seqs SET next_id = coalesce((select max(p.id)+1 from notification_category p), 1) WHERE name='notification_category';

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#6250-Tables-without-primary-keys - correction - 3', 'Vikas Bodani', 'descriptors/database/jbilling-upgrade-3.2.xml', NOW(), 27, '7:c908088e56120afca458636804c41bc1', 'update', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.2.xml::#7339 - Added to fix the null value in category Type dropdown::Vishwajeet Borade
-- Added to fix the null value in category Type dropdown
INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (18.0, 4.0, 'description', 1.0, 'Discount');

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#7339 - Added to fix the null value in category Type dropdown', 'Vishwajeet Borade', 'descriptors/database/jbilling-upgrade-3.2.xml', NOW(), 28, '7:a4f7eff5e35244954275ae4f40bc23ee', 'insert', 'Added to fix the null value in category Type dropdown', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.2.xml::#8469-billing-process-invoice-date-simplified::Ashok Kale
-- Requirement Add Customer level Next Invoice date
ALTER TABLE public.customer ADD next_inovice_date date;

ALTER TABLE public.billing_process_configuration ADD period_unit_id INT NOT NULL DEFAULT 1;

ALTER TABLE public.billing_process_configuration ADD CONSTRAINT billing_proc_configtn_fk_1 FOREIGN KEY (period_unit_id) REFERENCES public.period_unit (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#8469-billing-process-invoice-date-simplified', 'Ashok Kale', 'descriptors/database/jbilling-upgrade-3.2.xml', NOW(), 29, '7:f31c45d9cd97b60b26ee578660caf3d3', 'addColumn (x2), addForeignKeyConstraint', 'Requirement Add Customer level Next Invoice date', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.2.xml::#8469-Log-next-invoice-date-update.::Ashok Kale
INSERT INTO public.event_log_message (id) VALUES (35.0);

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#8469-Log-next-invoice-date-update.', 'Ashok Kale', 'descriptors/database/jbilling-upgrade-3.2.xml', NOW(), 30, '7:96b6f6b6610bbf7d3125ccd46d4b7b80', 'insert', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.2.xml::#8469-billing-process-semi-monthly-period-unit::Amol Gadre
-- Requirement Add new semi-monthly period for billing process
INSERT INTO public.period_unit (id) VALUES (5.0);

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (6.0, 5.0, 'description', 1.0, 'Semi-Monthly');

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#8469-billing-process-semi-monthly-period-unit', 'Amol Gadre', 'descriptors/database/jbilling-upgrade-3.2.xml', NOW(), 31, '7:51e84dff9db24846b0d6d27f9cc8ca14', 'insert (x2)', 'Requirement Add new semi-monthly period for billing process', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.2.xml::#8469-Add-New-flag-last-day-of-invoice::Ashok Kale
ALTER TABLE public.billing_process_configuration ADD last_day_of_month BOOLEAN NOT NULL DEFAULT FALSE;

INSERT INTO public.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 121.0, 'description', 1.0, 'Edit billing cycle of customer');

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#8469-Add-New-flag-last-day-of-invoice', 'Ashok Kale', 'descriptors/database/jbilling-upgrade-3.2.xml', NOW(), 32, '7:6c6d5a3e7496441006daff7a3ab18534', 'addColumn, insert', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.2.xml::#8469-Add-prorating-options::Ashok Kale
ALTER TABLE public.billing_process_configuration ADD prorating_type VARCHAR(50) DEFAULT 'PRORATING_AUTO_OFF';

ALTER TABLE public.purchase_order ADD prorate_flag BOOLEAN NOT NULL DEFAULT FALSE;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#8469-Add-prorating-options', 'Ashok Kale', 'descriptors/database/jbilling-upgrade-3.2.xml', NOW(), 33, '7:1958a9aa62c52aad9c7338da0836efd1', 'addColumn (x2)', '', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.2.xml::#8469-remove-pro-rate-tasks::Ashok Kale
-- June 10, 2014 Redmine # 8469 Remove ProRateOrderPeriodTask Plugin
-- June 10, 2014 Redmine # 8469 Remove DailyProRateCompositionTask Plugin
DELETE FROM public.pluggable_task  WHERE type_id = (select id from pluggable_task_type where class_name = 'com.sapienter.jbilling.server.process.task.ProRateOrderPeriodTask');

DELETE FROM public.pluggable_task_type  WHERE class_name = 'com.sapienter.jbilling.server.process.task.ProRateOrderPeriodTask';

DELETE FROM public.pluggable_task  WHERE type_id = (select id from pluggable_task_type where class_name = 'com.sapienter.jbilling.server.process.task.DailyProRateCompositionTask');

DELETE FROM public.pluggable_task_type  WHERE class_name = 'com.sapienter.jbilling.server.process.task.DailyProRateCompositionTask';

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#8469-remove-pro-rate-tasks', 'Ashok Kale', 'descriptors/database/jbilling-upgrade-3.2.xml', NOW(), 34, '7:b5de1ee40993b77c87eb2ef6adbb55f4', 'delete (x4)', 'June 10, 2014 Redmine # 8469 Remove ProRateOrderPeriodTask Plugin
June 10, 2014 Redmine # 8469 Remove DailyProRateCompositionTask Plugin', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.2.xml::#10005-Last Day of Month not Behaving as Expected::Manish Bansod
-- # 10005 Delete Use Prorating preference
DELETE FROM public.preference_type  WHERE id = 42;

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#10005-Last Day of Month not Behaving as Expected', 'Manish Bansod', 'descriptors/database/jbilling-upgrade-3.2.xml', NOW(), 35, '7:16383077db84e9d6f56752447c661cb9', 'delete', '# 10005 Delete Use Prorating preference', 'EXECUTED', '3.2.2');

-- Changeset descriptors/database/jbilling-upgrade-3.2.xml::20141211 - correcting next_ids::Rohit Gupta
UPDATE public.jbilling_seqs SET next_id = (select coalesce( (max(t.id)/100 + 1), 1) from pluggable_task_parameter t) WHERE name='pluggable_task_parameter';

INSERT INTO public.databasechangelog (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('20141211 - correcting next_ids', 'Rohit Gupta', 'descriptors/database/jbilling-upgrade-3.2.xml', NOW(), 36, '7:75d374236ddd2a1db3a6dc078729e93b', 'update', '', 'EXECUTED', '3.2.2');

-- Release Database Lock
