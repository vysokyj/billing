--  Changeset descriptors/database/jbilling-init_data.xml::1337972683141-1::aristokrates (generated)
INSERT INTO jbilling_test.order_line_type (id, editable) VALUES (1.0, 1.0);

INSERT INTO jbilling_test.order_line_type (id, editable) VALUES (2.0, 0.0);

INSERT INTO jbilling_test.order_line_type (id, editable) VALUES (3.0, 0.0);

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337972683141-1', 'aristokrates (generated)', 'descriptors/database/jbilling-init_data.xml', NOW(), 1, '7:892b03dadc233acca2db7ec13f101c85', 'insert (x3)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-init_data.xml::1337972683141-2::aristokrates (generated)
INSERT INTO jbilling_test.notification_category (id) VALUES (1.0);

INSERT INTO jbilling_test.notification_category (id) VALUES (2.0);

INSERT INTO jbilling_test.notification_category (id) VALUES (3.0);

INSERT INTO jbilling_test.notification_category (id) VALUES (4.0);

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337972683141-2', 'aristokrates (generated)', 'descriptors/database/jbilling-init_data.xml', NOW(), 2, '7:fa9c382ea1b19e50f152621cb197c200', 'insert (x4)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-init_data.xml::1337972683141-3::aristokrates (generated)
INSERT INTO jbilling_test.order_period (id, entity_id, value, unit_id, optlock) VALUES (1.0, NULL, NULL, NULL, 1.0);

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337972683141-3', 'aristokrates (generated)', 'descriptors/database/jbilling-init_data.xml', NOW(), 3, '7:f886238981f23b68d125e8b28549baec', 'insert', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-init_data.xml::1337972683141-4::aristokrates (generated)
INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('enumeration', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('enumeration_values', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('entity_delivery_method_map', 4.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('contact_field_type', 10.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('user_role_map', 13.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('entity_payment_method_map', 26.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('currency_entity_map', 10.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('user_credit_card_map', 5.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('contact_map', 6780.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('period_unit', 5.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('invoice_delivery_method', 4.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('user_status', 9.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('order_line_type', 4.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('order_billing_type', 3.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('order_status', 5.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('pluggable_task_type_category', 22.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('pluggable_task_type', 91.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('invoice_line_type', 6.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('currency', 11.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('payment_method', 9.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('payment_result', 5.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('event_log_module', 10.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('event_log_message', 17.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('preference_type', 37.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('notification_message_type', 20.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('role', 6.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('country', 238.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('currency_exchange', 25.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('pluggable_task_parameter', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('billing_process_configuration', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('order_period', 2.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('partner_range', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('item_price', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('partner', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('entity', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('contact_type', 2.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('promotion', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('pluggable_task', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('ach', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('payment_info_cheque', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('partner_payout', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('process_run_total_pm', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('payment_authorization', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('billing_process', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('process_run', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('process_run_total', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('paper_invoice_batch', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('preference', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('notification_message', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('notification_message_section', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('notification_message_line', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('ageing_entity_step', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('item_type', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('item', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('event_log', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('purchase_order', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('order_line', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('invoice', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('invoice_line', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('order_process', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('payment', 2.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('notification_message_arch', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('notification_message_arch_line', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('base_user', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('customer', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('contact', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('contact_field', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('credit_card', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('language', 2.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('payment_invoice', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('subscriber_status', 7.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('blacklist', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('generic_status', 26.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('balance_type', 0.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('price_model_attribute', 0.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('filter', 0.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('filter_set', 0.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('recent_item', 0.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('breadcrumb', 0.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('shortcut', 0.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('report', 0.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('report_type', 0.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('report_parameter', 0.0);

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337972683141-4', 'aristokrates (generated)', 'descriptors/database/jbilling-init_data.xml', NOW(), 4, '7:97ded74d9eedc78b89fb935c72d16c55', 'insert (x83)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-init_data.xml::1337972683141-5::aristokrates (generated)
INSERT INTO jbilling_test.report_type (id, name, optlock) VALUES (1.0, 'invoice', 0.0);

INSERT INTO jbilling_test.report_type (id, name, optlock) VALUES (2.0, 'order', 0.0);

INSERT INTO jbilling_test.report_type (id, name, optlock) VALUES (3.0, 'payment', 0.0);

INSERT INTO jbilling_test.report_type (id, name, optlock) VALUES (4.0, 'user', 0.0);

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337972683141-5', 'aristokrates (generated)', 'descriptors/database/jbilling-init_data.xml', NOW(), 5, '7:143fed48a07ca57c1daceb6153602a88', 'insert (x4)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-init_data.xml::1337972683141-8::aristokrates (generated)
INSERT INTO jbilling_test.generic_status_type (id) VALUES ('order_status');

INSERT INTO jbilling_test.generic_status_type (id) VALUES ('subscriber_status');

INSERT INTO jbilling_test.generic_status_type (id) VALUES ('user_status');

INSERT INTO jbilling_test.generic_status_type (id) VALUES ('invoice_status');

INSERT INTO jbilling_test.generic_status_type (id) VALUES ('process_run_status');

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337972683141-8', 'aristokrates (generated)', 'descriptors/database/jbilling-init_data.xml', NOW(), 6, '7:d43b88bf94e8b3c8f4062eb2a6fc7f94', 'insert (x5)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-init_data.xml::1337972683141-9::aristokrates (generated)
INSERT INTO jbilling_test.pluggable_task_type_category (id, interface_name) VALUES (1.0, 'com.sapienter.jbilling.server.pluggableTask.OrderProcessingTask');

INSERT INTO jbilling_test.pluggable_task_type_category (id, interface_name) VALUES (2.0, 'com.sapienter.jbilling.server.pluggableTask.OrderFilterTask');

INSERT INTO jbilling_test.pluggable_task_type_category (id, interface_name) VALUES (3.0, 'com.sapienter.jbilling.server.pluggableTask.InvoiceFilterTask');

INSERT INTO jbilling_test.pluggable_task_type_category (id, interface_name) VALUES (4.0, 'com.sapienter.jbilling.server.pluggableTask.InvoiceCompositionTask');

INSERT INTO jbilling_test.pluggable_task_type_category (id, interface_name) VALUES (5.0, 'com.sapienter.jbilling.server.pluggableTask.OrderPeriodTask');

INSERT INTO jbilling_test.pluggable_task_type_category (id, interface_name) VALUES (6.0, 'com.sapienter.jbilling.server.pluggableTask.PaymentTask');

INSERT INTO jbilling_test.pluggable_task_type_category (id, interface_name) VALUES (7.0, 'com.sapienter.jbilling.server.pluggableTask.NotificationTask');

INSERT INTO jbilling_test.pluggable_task_type_category (id, interface_name) VALUES (8.0, 'com.sapienter.jbilling.server.pluggableTask.PaymentInfoTask');

INSERT INTO jbilling_test.pluggable_task_type_category (id, interface_name) VALUES (9.0, 'com.sapienter.jbilling.server.pluggableTask.PenaltyTask');

INSERT INTO jbilling_test.pluggable_task_type_category (id, interface_name) VALUES (10.0, 'com.sapienter.jbilling.server.pluggableTask.ProcessorAlarm');

INSERT INTO jbilling_test.pluggable_task_type_category (id, interface_name) VALUES (11.0, 'com.sapienter.jbilling.server.user.tasks.ISubscriptionStatusManager');

INSERT INTO jbilling_test.pluggable_task_type_category (id, interface_name) VALUES (12.0, 'com.sapienter.jbilling.server.payment.tasks.IAsyncPaymentParameters');

INSERT INTO jbilling_test.pluggable_task_type_category (id, interface_name) VALUES (13.0, 'com.sapienter.jbilling.server.item.tasks.IItemPurchaseManager');

INSERT INTO jbilling_test.pluggable_task_type_category (id, interface_name) VALUES (14.0, 'com.sapienter.jbilling.server.pricing.tasks.IPricing');

INSERT INTO jbilling_test.pluggable_task_type_category (id, interface_name) VALUES (17.0, 'com.sapienter.jbilling.server.system.event.task.IInternalEventsTask');

INSERT INTO jbilling_test.pluggable_task_type_category (id, interface_name) VALUES (19.0, 'com.sapienter.jbilling.server.user.tasks.IValidatePurchaseTask');

INSERT INTO jbilling_test.pluggable_task_type_category (id, interface_name) VALUES (20.0, 'com.sapienter.jbilling.server.process.task.IBillingProcessFilterTask');

INSERT INTO jbilling_test.pluggable_task_type_category (id, interface_name) VALUES (22.0, 'com.sapienter.jbilling.server.process.task.IScheduledTask');

INSERT INTO jbilling_test.pluggable_task_type_category (id, interface_name) VALUES (23.0, 'com.sapienter.jbilling.server.rule.task.IRulesGenerator');

INSERT INTO jbilling_test.pluggable_task_type_category (id, interface_name) VALUES (24.0, 'com.sapienter.jbilling.server.process.task.IAgeingTask');

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337972683141-9', 'aristokrates (generated)', 'descriptors/database/jbilling-init_data.xml', NOW(), 7, '7:8a0707eaf545f2e38d11839b42c8f12b', 'insert (x20)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-init_data.xml::1337972683141-10::aristokrates (generated)
INSERT INTO jbilling_test.role (id, role_type_id, entity_id) VALUES (2.0, 2.0, NULL);

INSERT INTO jbilling_test.role (id, role_type_id, entity_id) VALUES (3.0, 3.0, NULL);

INSERT INTO jbilling_test.role (id, role_type_id, entity_id) VALUES (4.0, 4.0, NULL);

INSERT INTO jbilling_test.role (id, role_type_id, entity_id) VALUES (5.0, 5.0, NULL);

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337972683141-10', 'aristokrates (generated)', 'descriptors/database/jbilling-init_data.xml', NOW(), 8, '7:b80f83026687ae7d0d1375e6c26a20f1', 'insert (x4)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-init_data.xml::1337972683141-11::aristokrates (generated)
INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (3.0, 'language');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (4.0, 'currency');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (5.0, 'entity');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (6.0, 'period_unit');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (7.0, 'invoice_delivery_method');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (8.0, 'entity_delivery_method_map');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (9.0, 'user_status');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (10.0, 'base_user');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (11.0, 'partner');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (12.0, 'customer');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (13.0, 'item_type');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (14.0, 'item');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (15.0, 'item_price');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (17.0, 'order_period');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (18.0, 'order_line_type');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (19.0, 'order_billing_type');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (20.0, 'order_status');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (21.0, 'purchase_order');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (22.0, 'order_line');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (23.0, 'pluggable_task_type_category');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (24.0, 'pluggable_task_type');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (25.0, 'pluggable_task');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (26.0, 'pluggable_task_parameter');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (27.0, 'contact');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (28.0, 'contact_type');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (29.0, 'contact_map');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (30.0, 'invoice_line_type');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (31.0, 'paper_invoice_batch');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (32.0, 'billing_process');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (33.0, 'process_run');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (34.0, 'billing_process_configuration');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (35.0, 'payment_method');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (36.0, 'entity_payment_method_map');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (37.0, 'process_run_total');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (38.0, 'process_run_total_pm');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (39.0, 'invoice');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (40.0, 'invoice_line');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (41.0, 'payment_result');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (42.0, 'payment');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (43.0, 'payment_info_cheque');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (44.0, 'credit_card');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (45.0, 'user_credit_card_map');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (46.0, 'event_log_module');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (47.0, 'event_log_message');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (48.0, 'event_log');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (49.0, 'order_process');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (50.0, 'preference_type');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (51.0, 'preference');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (52.0, 'notification_message_type');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (53.0, 'notification_message');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (54.0, 'notification_message_section');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (55.0, 'notification_message_line');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (56.0, 'notification_message_arch');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (57.0, 'notification_message_arch_line');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (60.0, 'role');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (62.0, 'user_role_map');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (64.0, 'country');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (65.0, 'promotion');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (66.0, 'payment_authorization');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (67.0, 'currency_exchange');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (68.0, 'currency_entity_map');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (69.0, 'ageing_entity_step');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (70.0, 'partner_payout');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (75.0, 'ach');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (76.0, 'contact_field');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (79.0, 'partner_range');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (80.0, 'payment_invoice');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (81.0, 'subscriber_status');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (85.0, 'blacklist');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (87.0, 'generic_status');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (89.0, 'balance_type');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (90.0, 'invoice_status');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (92.0, 'process_run_status');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (99.0, 'contact_field_type');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (100.0, 'report');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (101.0, 'report_type');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (102.0, 'report_parameter');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (104.0, 'notification_category');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (105.0, 'enumeration');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES (106.0, 'enumeration_values');

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337972683141-11', 'aristokrates (generated)', 'descriptors/database/jbilling-init_data.xml', NOW(), 9, '7:e7b708ef395bc6dd9f9182435ed4188d', 'insert (x80)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-init_data.xml::1337972683141-12::aristokrates (generated)
INSERT INTO jbilling_test.order_billing_type (id) VALUES (1.0);

INSERT INTO jbilling_test.order_billing_type (id) VALUES (2.0);

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337972683141-12', 'aristokrates (generated)', 'descriptors/database/jbilling-init_data.xml', NOW(), 10, '7:b903c29c915d7d299113ad0d4e61d824', 'insert (x2)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-init_data.xml::1337972683141-13::aristokrates (generated)
INSERT INTO jbilling_test.language (id, code, description) VALUES (1.0, 'en', 'English');

INSERT INTO jbilling_test.language (id, code, description) VALUES (2.0, 'pt', 'Portuguese');

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337972683141-13', 'aristokrates (generated)', 'descriptors/database/jbilling-init_data.xml', NOW(), 11, '7:f7a782164e04f7b3f15d629567ce768d', 'insert (x2)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-init_data.xml::1337972683141-14::aristokrates (generated)
INSERT INTO jbilling_test.country (id, code) VALUES (1.0, 'AF');

INSERT INTO jbilling_test.country (id, code) VALUES (2.0, 'AL');

INSERT INTO jbilling_test.country (id, code) VALUES (3.0, 'DZ');

INSERT INTO jbilling_test.country (id, code) VALUES (4.0, 'AS');

INSERT INTO jbilling_test.country (id, code) VALUES (5.0, 'AD');

INSERT INTO jbilling_test.country (id, code) VALUES (6.0, 'AO');

INSERT INTO jbilling_test.country (id, code) VALUES (7.0, 'AI');

INSERT INTO jbilling_test.country (id, code) VALUES (8.0, 'AQ');

INSERT INTO jbilling_test.country (id, code) VALUES (9.0, 'AG');

INSERT INTO jbilling_test.country (id, code) VALUES (10.0, 'AR');

INSERT INTO jbilling_test.country (id, code) VALUES (11.0, 'AM');

INSERT INTO jbilling_test.country (id, code) VALUES (12.0, 'AW');

INSERT INTO jbilling_test.country (id, code) VALUES (13.0, 'AU');

INSERT INTO jbilling_test.country (id, code) VALUES (14.0, 'AT');

INSERT INTO jbilling_test.country (id, code) VALUES (15.0, 'AZ');

INSERT INTO jbilling_test.country (id, code) VALUES (16.0, 'BS');

INSERT INTO jbilling_test.country (id, code) VALUES (17.0, 'BH');

INSERT INTO jbilling_test.country (id, code) VALUES (18.0, 'BD');

INSERT INTO jbilling_test.country (id, code) VALUES (19.0, 'BB');

INSERT INTO jbilling_test.country (id, code) VALUES (20.0, 'BY');

INSERT INTO jbilling_test.country (id, code) VALUES (21.0, 'BE');

INSERT INTO jbilling_test.country (id, code) VALUES (22.0, 'BZ');

INSERT INTO jbilling_test.country (id, code) VALUES (23.0, 'BJ');

INSERT INTO jbilling_test.country (id, code) VALUES (24.0, 'BM');

INSERT INTO jbilling_test.country (id, code) VALUES (25.0, 'BT');

INSERT INTO jbilling_test.country (id, code) VALUES (26.0, 'BO');

INSERT INTO jbilling_test.country (id, code) VALUES (27.0, 'BA');

INSERT INTO jbilling_test.country (id, code) VALUES (28.0, 'BW');

INSERT INTO jbilling_test.country (id, code) VALUES (29.0, 'BV');

INSERT INTO jbilling_test.country (id, code) VALUES (30.0, 'BR');

INSERT INTO jbilling_test.country (id, code) VALUES (31.0, 'IO');

INSERT INTO jbilling_test.country (id, code) VALUES (32.0, 'BN');

INSERT INTO jbilling_test.country (id, code) VALUES (33.0, 'BG');

INSERT INTO jbilling_test.country (id, code) VALUES (34.0, 'BF');

INSERT INTO jbilling_test.country (id, code) VALUES (35.0, 'BI');

INSERT INTO jbilling_test.country (id, code) VALUES (36.0, 'KH');

INSERT INTO jbilling_test.country (id, code) VALUES (37.0, 'CM');

INSERT INTO jbilling_test.country (id, code) VALUES (38.0, 'CA');

INSERT INTO jbilling_test.country (id, code) VALUES (39.0, 'CV');

INSERT INTO jbilling_test.country (id, code) VALUES (40.0, 'KY');

INSERT INTO jbilling_test.country (id, code) VALUES (41.0, 'CF');

INSERT INTO jbilling_test.country (id, code) VALUES (42.0, 'TD');

INSERT INTO jbilling_test.country (id, code) VALUES (43.0, 'CL');

INSERT INTO jbilling_test.country (id, code) VALUES (44.0, 'CN');

INSERT INTO jbilling_test.country (id, code) VALUES (45.0, 'CX');

INSERT INTO jbilling_test.country (id, code) VALUES (46.0, 'CC');

INSERT INTO jbilling_test.country (id, code) VALUES (47.0, 'CO');

INSERT INTO jbilling_test.country (id, code) VALUES (48.0, 'KM');

INSERT INTO jbilling_test.country (id, code) VALUES (49.0, 'CG');

INSERT INTO jbilling_test.country (id, code) VALUES (50.0, 'CK');

INSERT INTO jbilling_test.country (id, code) VALUES (51.0, 'CR');

INSERT INTO jbilling_test.country (id, code) VALUES (52.0, 'CI');

INSERT INTO jbilling_test.country (id, code) VALUES (53.0, 'HR');

INSERT INTO jbilling_test.country (id, code) VALUES (54.0, 'CU');

INSERT INTO jbilling_test.country (id, code) VALUES (55.0, 'CY');

INSERT INTO jbilling_test.country (id, code) VALUES (56.0, 'CZ');

INSERT INTO jbilling_test.country (id, code) VALUES (57.0, 'CD');

INSERT INTO jbilling_test.country (id, code) VALUES (58.0, 'DK');

INSERT INTO jbilling_test.country (id, code) VALUES (59.0, 'DJ');

INSERT INTO jbilling_test.country (id, code) VALUES (60.0, 'DM');

INSERT INTO jbilling_test.country (id, code) VALUES (61.0, 'DO');

INSERT INTO jbilling_test.country (id, code) VALUES (62.0, 'TP');

INSERT INTO jbilling_test.country (id, code) VALUES (63.0, 'EC');

INSERT INTO jbilling_test.country (id, code) VALUES (64.0, 'EG');

INSERT INTO jbilling_test.country (id, code) VALUES (65.0, 'SV');

INSERT INTO jbilling_test.country (id, code) VALUES (66.0, 'GQ');

INSERT INTO jbilling_test.country (id, code) VALUES (67.0, 'ER');

INSERT INTO jbilling_test.country (id, code) VALUES (68.0, 'EE');

INSERT INTO jbilling_test.country (id, code) VALUES (69.0, 'ET');

INSERT INTO jbilling_test.country (id, code) VALUES (70.0, 'FK');

INSERT INTO jbilling_test.country (id, code) VALUES (71.0, 'FO');

INSERT INTO jbilling_test.country (id, code) VALUES (72.0, 'FJ');

INSERT INTO jbilling_test.country (id, code) VALUES (73.0, 'FI');

INSERT INTO jbilling_test.country (id, code) VALUES (74.0, 'FR');

INSERT INTO jbilling_test.country (id, code) VALUES (75.0, 'GF');

INSERT INTO jbilling_test.country (id, code) VALUES (76.0, 'PF');

INSERT INTO jbilling_test.country (id, code) VALUES (77.0, 'TF');

INSERT INTO jbilling_test.country (id, code) VALUES (78.0, 'GA');

INSERT INTO jbilling_test.country (id, code) VALUES (79.0, 'GM');

INSERT INTO jbilling_test.country (id, code) VALUES (80.0, 'GE');

INSERT INTO jbilling_test.country (id, code) VALUES (81.0, 'DE');

INSERT INTO jbilling_test.country (id, code) VALUES (82.0, 'GH');

INSERT INTO jbilling_test.country (id, code) VALUES (83.0, 'GI');

INSERT INTO jbilling_test.country (id, code) VALUES (84.0, 'GR');

INSERT INTO jbilling_test.country (id, code) VALUES (85.0, 'GL');

INSERT INTO jbilling_test.country (id, code) VALUES (86.0, 'GD');

INSERT INTO jbilling_test.country (id, code) VALUES (87.0, 'GP');

INSERT INTO jbilling_test.country (id, code) VALUES (88.0, 'GU');

INSERT INTO jbilling_test.country (id, code) VALUES (89.0, 'GT');

INSERT INTO jbilling_test.country (id, code) VALUES (90.0, 'GN');

INSERT INTO jbilling_test.country (id, code) VALUES (91.0, 'GW');

INSERT INTO jbilling_test.country (id, code) VALUES (92.0, 'GY');

INSERT INTO jbilling_test.country (id, code) VALUES (93.0, 'HT');

INSERT INTO jbilling_test.country (id, code) VALUES (94.0, 'HM');

INSERT INTO jbilling_test.country (id, code) VALUES (95.0, 'HN');

INSERT INTO jbilling_test.country (id, code) VALUES (96.0, 'HK');

INSERT INTO jbilling_test.country (id, code) VALUES (97.0, 'HU');

INSERT INTO jbilling_test.country (id, code) VALUES (98.0, 'IS');

INSERT INTO jbilling_test.country (id, code) VALUES (99.0, 'IN');

INSERT INTO jbilling_test.country (id, code) VALUES (100.0, 'ID');

INSERT INTO jbilling_test.country (id, code) VALUES (101.0, 'IR');

INSERT INTO jbilling_test.country (id, code) VALUES (102.0, 'IQ');

INSERT INTO jbilling_test.country (id, code) VALUES (103.0, 'IE');

INSERT INTO jbilling_test.country (id, code) VALUES (104.0, 'IL');

INSERT INTO jbilling_test.country (id, code) VALUES (105.0, 'IT');

INSERT INTO jbilling_test.country (id, code) VALUES (106.0, 'JM');

INSERT INTO jbilling_test.country (id, code) VALUES (107.0, 'JP');

INSERT INTO jbilling_test.country (id, code) VALUES (108.0, 'JO');

INSERT INTO jbilling_test.country (id, code) VALUES (109.0, 'KZ');

INSERT INTO jbilling_test.country (id, code) VALUES (110.0, 'KE');

INSERT INTO jbilling_test.country (id, code) VALUES (111.0, 'KI');

INSERT INTO jbilling_test.country (id, code) VALUES (112.0, 'KR');

INSERT INTO jbilling_test.country (id, code) VALUES (113.0, 'KW');

INSERT INTO jbilling_test.country (id, code) VALUES (114.0, 'KG');

INSERT INTO jbilling_test.country (id, code) VALUES (115.0, 'LA');

INSERT INTO jbilling_test.country (id, code) VALUES (116.0, 'LV');

INSERT INTO jbilling_test.country (id, code) VALUES (117.0, 'LB');

INSERT INTO jbilling_test.country (id, code) VALUES (118.0, 'LS');

INSERT INTO jbilling_test.country (id, code) VALUES (119.0, 'LR');

INSERT INTO jbilling_test.country (id, code) VALUES (120.0, 'LY');

INSERT INTO jbilling_test.country (id, code) VALUES (121.0, 'LI');

INSERT INTO jbilling_test.country (id, code) VALUES (122.0, 'LT');

INSERT INTO jbilling_test.country (id, code) VALUES (123.0, 'LU');

INSERT INTO jbilling_test.country (id, code) VALUES (124.0, 'MO');

INSERT INTO jbilling_test.country (id, code) VALUES (125.0, 'MK');

INSERT INTO jbilling_test.country (id, code) VALUES (126.0, 'MG');

INSERT INTO jbilling_test.country (id, code) VALUES (127.0, 'MW');

INSERT INTO jbilling_test.country (id, code) VALUES (128.0, 'MY');

INSERT INTO jbilling_test.country (id, code) VALUES (129.0, 'MV');

INSERT INTO jbilling_test.country (id, code) VALUES (130.0, 'ML');

INSERT INTO jbilling_test.country (id, code) VALUES (131.0, 'MT');

INSERT INTO jbilling_test.country (id, code) VALUES (132.0, 'MH');

INSERT INTO jbilling_test.country (id, code) VALUES (133.0, 'MQ');

INSERT INTO jbilling_test.country (id, code) VALUES (134.0, 'MR');

INSERT INTO jbilling_test.country (id, code) VALUES (135.0, 'MU');

INSERT INTO jbilling_test.country (id, code) VALUES (136.0, 'YT');

INSERT INTO jbilling_test.country (id, code) VALUES (137.0, 'MX');

INSERT INTO jbilling_test.country (id, code) VALUES (138.0, 'FM');

INSERT INTO jbilling_test.country (id, code) VALUES (139.0, 'MD');

INSERT INTO jbilling_test.country (id, code) VALUES (140.0, 'MC');

INSERT INTO jbilling_test.country (id, code) VALUES (141.0, 'MN');

INSERT INTO jbilling_test.country (id, code) VALUES (142.0, 'MS');

INSERT INTO jbilling_test.country (id, code) VALUES (143.0, 'MA');

INSERT INTO jbilling_test.country (id, code) VALUES (144.0, 'MZ');

INSERT INTO jbilling_test.country (id, code) VALUES (145.0, 'MM');

INSERT INTO jbilling_test.country (id, code) VALUES (146.0, 'NA');

INSERT INTO jbilling_test.country (id, code) VALUES (147.0, 'NR');

INSERT INTO jbilling_test.country (id, code) VALUES (148.0, 'NP');

INSERT INTO jbilling_test.country (id, code) VALUES (149.0, 'NL');

INSERT INTO jbilling_test.country (id, code) VALUES (150.0, 'AN');

INSERT INTO jbilling_test.country (id, code) VALUES (151.0, 'NC');

INSERT INTO jbilling_test.country (id, code) VALUES (152.0, 'NZ');

INSERT INTO jbilling_test.country (id, code) VALUES (153.0, 'NI');

INSERT INTO jbilling_test.country (id, code) VALUES (154.0, 'NE');

INSERT INTO jbilling_test.country (id, code) VALUES (155.0, 'NG');

INSERT INTO jbilling_test.country (id, code) VALUES (156.0, 'NU');

INSERT INTO jbilling_test.country (id, code) VALUES (157.0, 'NF');

INSERT INTO jbilling_test.country (id, code) VALUES (158.0, 'KP');

INSERT INTO jbilling_test.country (id, code) VALUES (159.0, 'MP');

INSERT INTO jbilling_test.country (id, code) VALUES (160.0, 'NO');

INSERT INTO jbilling_test.country (id, code) VALUES (161.0, 'OM');

INSERT INTO jbilling_test.country (id, code) VALUES (162.0, 'PK');

INSERT INTO jbilling_test.country (id, code) VALUES (163.0, 'PW');

INSERT INTO jbilling_test.country (id, code) VALUES (164.0, 'PA');

INSERT INTO jbilling_test.country (id, code) VALUES (165.0, 'PG');

INSERT INTO jbilling_test.country (id, code) VALUES (166.0, 'PY');

INSERT INTO jbilling_test.country (id, code) VALUES (167.0, 'PE');

INSERT INTO jbilling_test.country (id, code) VALUES (168.0, 'PH');

INSERT INTO jbilling_test.country (id, code) VALUES (169.0, 'PN');

INSERT INTO jbilling_test.country (id, code) VALUES (170.0, 'PL');

INSERT INTO jbilling_test.country (id, code) VALUES (171.0, 'PT');

INSERT INTO jbilling_test.country (id, code) VALUES (172.0, 'PR');

INSERT INTO jbilling_test.country (id, code) VALUES (173.0, 'QA');

INSERT INTO jbilling_test.country (id, code) VALUES (174.0, 'RE');

INSERT INTO jbilling_test.country (id, code) VALUES (175.0, 'RO');

INSERT INTO jbilling_test.country (id, code) VALUES (176.0, 'RU');

INSERT INTO jbilling_test.country (id, code) VALUES (177.0, 'RW');

INSERT INTO jbilling_test.country (id, code) VALUES (178.0, 'WS');

INSERT INTO jbilling_test.country (id, code) VALUES (179.0, 'SM');

INSERT INTO jbilling_test.country (id, code) VALUES (180.0, 'ST');

INSERT INTO jbilling_test.country (id, code) VALUES (181.0, 'SA');

INSERT INTO jbilling_test.country (id, code) VALUES (182.0, 'SN');

INSERT INTO jbilling_test.country (id, code) VALUES (183.0, 'YU');

INSERT INTO jbilling_test.country (id, code) VALUES (184.0, 'SC');

INSERT INTO jbilling_test.country (id, code) VALUES (185.0, 'SL');

INSERT INTO jbilling_test.country (id, code) VALUES (186.0, 'SG');

INSERT INTO jbilling_test.country (id, code) VALUES (187.0, 'SK');

INSERT INTO jbilling_test.country (id, code) VALUES (188.0, 'SI');

INSERT INTO jbilling_test.country (id, code) VALUES (189.0, 'SB');

INSERT INTO jbilling_test.country (id, code) VALUES (190.0, 'SO');

INSERT INTO jbilling_test.country (id, code) VALUES (191.0, 'ZA');

INSERT INTO jbilling_test.country (id, code) VALUES (192.0, 'GS');

INSERT INTO jbilling_test.country (id, code) VALUES (193.0, 'ES');

INSERT INTO jbilling_test.country (id, code) VALUES (194.0, 'LK');

INSERT INTO jbilling_test.country (id, code) VALUES (195.0, 'SH');

INSERT INTO jbilling_test.country (id, code) VALUES (196.0, 'KN');

INSERT INTO jbilling_test.country (id, code) VALUES (197.0, 'LC');

INSERT INTO jbilling_test.country (id, code) VALUES (198.0, 'PM');

INSERT INTO jbilling_test.country (id, code) VALUES (199.0, 'VC');

INSERT INTO jbilling_test.country (id, code) VALUES (200.0, 'SD');

INSERT INTO jbilling_test.country (id, code) VALUES (201.0, 'SR');

INSERT INTO jbilling_test.country (id, code) VALUES (202.0, 'SJ');

INSERT INTO jbilling_test.country (id, code) VALUES (203.0, 'SZ');

INSERT INTO jbilling_test.country (id, code) VALUES (204.0, 'SE');

INSERT INTO jbilling_test.country (id, code) VALUES (205.0, 'CH');

INSERT INTO jbilling_test.country (id, code) VALUES (206.0, 'SY');

INSERT INTO jbilling_test.country (id, code) VALUES (207.0, 'TW');

INSERT INTO jbilling_test.country (id, code) VALUES (208.0, 'TJ');

INSERT INTO jbilling_test.country (id, code) VALUES (209.0, 'TZ');

INSERT INTO jbilling_test.country (id, code) VALUES (210.0, 'TH');

INSERT INTO jbilling_test.country (id, code) VALUES (211.0, 'TG');

INSERT INTO jbilling_test.country (id, code) VALUES (212.0, 'TK');

INSERT INTO jbilling_test.country (id, code) VALUES (213.0, 'TO');

INSERT INTO jbilling_test.country (id, code) VALUES (214.0, 'TT');

INSERT INTO jbilling_test.country (id, code) VALUES (215.0, 'TN');

INSERT INTO jbilling_test.country (id, code) VALUES (216.0, 'TR');

INSERT INTO jbilling_test.country (id, code) VALUES (217.0, 'TM');

INSERT INTO jbilling_test.country (id, code) VALUES (218.0, 'TC');

INSERT INTO jbilling_test.country (id, code) VALUES (219.0, 'TV');

INSERT INTO jbilling_test.country (id, code) VALUES (220.0, 'UG');

INSERT INTO jbilling_test.country (id, code) VALUES (221.0, 'UA');

INSERT INTO jbilling_test.country (id, code) VALUES (222.0, 'AE');

INSERT INTO jbilling_test.country (id, code) VALUES (223.0, 'UK');

INSERT INTO jbilling_test.country (id, code) VALUES (224.0, 'US');

INSERT INTO jbilling_test.country (id, code) VALUES (225.0, 'UM');

INSERT INTO jbilling_test.country (id, code) VALUES (226.0, 'UY');

INSERT INTO jbilling_test.country (id, code) VALUES (227.0, 'UZ');

INSERT INTO jbilling_test.country (id, code) VALUES (228.0, 'VU');

INSERT INTO jbilling_test.country (id, code) VALUES (229.0, 'VA');

INSERT INTO jbilling_test.country (id, code) VALUES (230.0, 'VE');

INSERT INTO jbilling_test.country (id, code) VALUES (231.0, 'VN');

INSERT INTO jbilling_test.country (id, code) VALUES (232.0, 'VG');

INSERT INTO jbilling_test.country (id, code) VALUES (233.0, 'VI');

INSERT INTO jbilling_test.country (id, code) VALUES (234.0, 'WF');

INSERT INTO jbilling_test.country (id, code) VALUES (235.0, 'YE');

INSERT INTO jbilling_test.country (id, code) VALUES (236.0, 'ZM');

INSERT INTO jbilling_test.country (id, code) VALUES (237.0, 'ZW');

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337972683141-14', 'aristokrates (generated)', 'descriptors/database/jbilling-init_data.xml', NOW(), 12, '7:4a46f7ce9e8137ec22ed274f4ecfebfa', 'insert (x237)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-init_data.xml::1337972683141-15::aristokrates (generated)
INSERT INTO jbilling_test.payment_result (id) VALUES (1.0);

INSERT INTO jbilling_test.payment_result (id) VALUES (2.0);

INSERT INTO jbilling_test.payment_result (id) VALUES (3.0);

INSERT INTO jbilling_test.payment_result (id) VALUES (4.0);

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337972683141-15', 'aristokrates (generated)', 'descriptors/database/jbilling-init_data.xml', NOW(), 13, '7:87037e224619b9533ce9439b6f1a1a06', 'insert (x4)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-init_data.xml::1337972683141-16::aristokrates (generated)
INSERT INTO jbilling_test.currency (id, symbol, code, country_code, optlock) VALUES (1.0, 'US$', 'USD', 'US', 0.0);

INSERT INTO jbilling_test.currency (id, symbol, code, country_code, optlock) VALUES (2.0, 'C$', 'CAD', 'CA', 0.0);

INSERT INTO jbilling_test.currency (id, symbol, code, country_code, optlock) VALUES (3.0, '&#8364;', 'EUR', 'EU', 0.0);

INSERT INTO jbilling_test.currency (id, symbol, code, country_code, optlock) VALUES (4.0, '&#165;', 'JPY', 'JP', 0.0);

INSERT INTO jbilling_test.currency (id, symbol, code, country_code, optlock) VALUES (5.0, '&#163;', 'GBP', 'UK', 0.0);

INSERT INTO jbilling_test.currency (id, symbol, code, country_code, optlock) VALUES (6.0, '&#8361;', 'KRW', 'KR', 0.0);

INSERT INTO jbilling_test.currency (id, symbol, code, country_code, optlock) VALUES (7.0, 'Sf', 'CHF', 'CH', 0.0);

INSERT INTO jbilling_test.currency (id, symbol, code, country_code, optlock) VALUES (8.0, 'SeK', 'SEK', 'SE', 0.0);

INSERT INTO jbilling_test.currency (id, symbol, code, country_code, optlock) VALUES (9.0, 'S$', 'SGD', 'SG', 0.0);

INSERT INTO jbilling_test.currency (id, symbol, code, country_code, optlock) VALUES (10.0, 'M$', 'MYR', 'MY', 0.0);

INSERT INTO jbilling_test.currency (id, symbol, code, country_code, optlock) VALUES (11.0, '$', 'AUD', 'AU', 0.0);

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337972683141-16', 'aristokrates (generated)', 'descriptors/database/jbilling-init_data.xml', NOW(), 14, '7:b7d69d8fff2530a2f1de1a7cb15f716e', 'insert (x11)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-init_data.xml::1337972683141-18::aristokrates (generated)
INSERT INTO jbilling_test.report (id, type_id, name, file_name, optlock) VALUES (1.0, 1.0, 'total_invoiced', 'total_invoiced.jasper', 0.0);

INSERT INTO jbilling_test.report (id, type_id, name, file_name, optlock) VALUES (2.0, 1.0, 'ageing_balance', 'ageing_balance.jasper', 0.0);

INSERT INTO jbilling_test.report (id, type_id, name, file_name, optlock) VALUES (3.0, 2.0, 'product_subscribers', 'product_subscribers.jasper', 0.0);

INSERT INTO jbilling_test.report (id, type_id, name, file_name, optlock) VALUES (4.0, 3.0, 'total_payments', 'total_payments.jasper', 0.0);

INSERT INTO jbilling_test.report (id, type_id, name, file_name, optlock) VALUES (5.0, 4.0, 'user_signups', 'user_signups.jasper', 0.0);

INSERT INTO jbilling_test.report (id, type_id, name, file_name, optlock) VALUES (6.0, 4.0, 'top_customers', 'top_customers.jasper', 0.0);

INSERT INTO jbilling_test.report (id, type_id, name, file_name, optlock) VALUES (7.0, 1.0, 'accounts_receivable', 'accounts_receivable.jasper', 0.0);

INSERT INTO jbilling_test.report (id, type_id, name, file_name, optlock) VALUES (8.0, 1.0, 'gl_detail', 'gl_detail.jasper', 0.0);

INSERT INTO jbilling_test.report (id, type_id, name, file_name, optlock) VALUES (9.0, 1.0, 'gl_summary', 'gl_summary.jasper', 0.0);

INSERT INTO jbilling_test.report (id, type_id, name, file_name, optlock) VALUES (11.0, 4.0, 'total_invoiced_per_customer', 'total_invoiced_per_customer.jasper', 0.0);

INSERT INTO jbilling_test.report (id, type_id, name, file_name, optlock) VALUES (12.0, 4.0, 'total_invoiced_per_customer_over_years', 'total_invoiced_per_customer_over_years.jasper', 0.0);

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337972683141-18', 'aristokrates (generated)', 'descriptors/database/jbilling-init_data.xml', NOW(), 15, '7:fe0ae9a150a7d52b241b3c985f08fe87', 'insert (x11)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-init_data.xml::1337972683141-19::aristokrates (generated)
INSERT INTO jbilling_test.invoice_line_type (id, description, order_position) VALUES (1.0, 'item recurring', 2.0);

INSERT INTO jbilling_test.invoice_line_type (id, description, order_position) VALUES (2.0, 'tax', 6.0);

INSERT INTO jbilling_test.invoice_line_type (id, description, order_position) VALUES (3.0, 'due invoice', 1.0);

INSERT INTO jbilling_test.invoice_line_type (id, description, order_position) VALUES (4.0, 'interests', 4.0);

INSERT INTO jbilling_test.invoice_line_type (id, description, order_position) VALUES (5.0, 'sub account', 5.0);

INSERT INTO jbilling_test.invoice_line_type (id, description, order_position) VALUES (6.0, 'item one-time', 3.0);

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337972683141-19', 'aristokrates (generated)', 'descriptors/database/jbilling-init_data.xml', NOW(), 16, '7:c8c6f8a9710886e7afc788b605cb9334', 'insert (x6)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-init_data.xml::1337972683141-20::aristokrates (generated)
INSERT INTO jbilling_test.event_log_message (id) VALUES (1.0);

INSERT INTO jbilling_test.event_log_message (id) VALUES (2.0);

INSERT INTO jbilling_test.event_log_message (id) VALUES (3.0);

INSERT INTO jbilling_test.event_log_message (id) VALUES (4.0);

INSERT INTO jbilling_test.event_log_message (id) VALUES (5.0);

INSERT INTO jbilling_test.event_log_message (id) VALUES (6.0);

INSERT INTO jbilling_test.event_log_message (id) VALUES (7.0);

INSERT INTO jbilling_test.event_log_message (id) VALUES (8.0);

INSERT INTO jbilling_test.event_log_message (id) VALUES (9.0);

INSERT INTO jbilling_test.event_log_message (id) VALUES (10.0);

INSERT INTO jbilling_test.event_log_message (id) VALUES (11.0);

INSERT INTO jbilling_test.event_log_message (id) VALUES (12.0);

INSERT INTO jbilling_test.event_log_message (id) VALUES (13.0);

INSERT INTO jbilling_test.event_log_message (id) VALUES (14.0);

INSERT INTO jbilling_test.event_log_message (id) VALUES (15.0);

INSERT INTO jbilling_test.event_log_message (id) VALUES (16.0);

INSERT INTO jbilling_test.event_log_message (id) VALUES (17.0);

INSERT INTO jbilling_test.event_log_message (id) VALUES (18.0);

INSERT INTO jbilling_test.event_log_message (id) VALUES (19.0);

INSERT INTO jbilling_test.event_log_message (id) VALUES (20.0);

INSERT INTO jbilling_test.event_log_message (id) VALUES (21.0);

INSERT INTO jbilling_test.event_log_message (id) VALUES (22.0);

INSERT INTO jbilling_test.event_log_message (id) VALUES (23.0);

INSERT INTO jbilling_test.event_log_message (id) VALUES (24.0);

INSERT INTO jbilling_test.event_log_message (id) VALUES (25.0);

INSERT INTO jbilling_test.event_log_message (id) VALUES (26.0);

INSERT INTO jbilling_test.event_log_message (id) VALUES (27.0);

INSERT INTO jbilling_test.event_log_message (id) VALUES (28.0);

INSERT INTO jbilling_test.event_log_message (id) VALUES (29.0);

INSERT INTO jbilling_test.event_log_message (id) VALUES (30.0);

INSERT INTO jbilling_test.event_log_message (id) VALUES (31.0);

INSERT INTO jbilling_test.event_log_message (id) VALUES (32.0);

INSERT INTO jbilling_test.event_log_message (id) VALUES (33.0);

INSERT INTO jbilling_test.event_log_message (id) VALUES (34.0);

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337972683141-20', 'aristokrates (generated)', 'descriptors/database/jbilling-init_data.xml', NOW(), 17, '7:82e0c8279a94a8a793dbd80504fd1926', 'insert (x34)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-init_data.xml::1337972683141-21::aristokrates (generated)
INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (1.0, 1.0, 'com.sapienter.jbilling.server.pluggableTask.BasicLineTotalTask', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (13.0, 4.0, 'com.sapienter.jbilling.server.pluggableTask.CalculateDueDateDfFm', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (3.0, 4.0, 'com.sapienter.jbilling.server.pluggableTask.CalculateDueDate', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (4.0, 4.0, 'com.sapienter.jbilling.server.pluggableTask.BasicCompositionTask', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (5.0, 2.0, 'com.sapienter.jbilling.server.pluggableTask.BasicOrderFilterTask', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (6.0, 3.0, 'com.sapienter.jbilling.server.pluggableTask.BasicInvoiceFilterTask', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (7.0, 5.0, 'com.sapienter.jbilling.server.pluggableTask.BasicOrderPeriodTask', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (8.0, 6.0, 'com.sapienter.jbilling.server.pluggableTask.PaymentAuthorizeNetTask', 2.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (14.0, 3.0, 'com.sapienter.jbilling.server.pluggableTask.NoInvoiceFilterTask', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (10.0, 8.0, 'com.sapienter.jbilling.server.pluggableTask.BasicPaymentInfoTask', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (11.0, 6.0, 'com.sapienter.jbilling.server.pluggableTask.PaymentPartnerTestTask', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (12.0, 7.0, 'com.sapienter.jbilling.server.pluggableTask.PaperInvoiceNotificationTask', 1.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (2.0, 1.0, 'com.sapienter.jbilling.server.pluggableTask.GSTTaxTask', 2.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (15.0, 9.0, 'com.sapienter.jbilling.server.pluggableTask.BasicPenaltyTask', 1.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (16.0, 2.0, 'com.sapienter.jbilling.server.pluggableTask.OrderFilterAnticipatedTask', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (9.0, 7.0, 'com.sapienter.jbilling.server.pluggableTask.BasicEmailNotificationTask', 6.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (17.0, 5.0, 'com.sapienter.jbilling.server.pluggableTask.OrderPeriodAnticipateTask', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (19.0, 6.0, 'com.sapienter.jbilling.server.pluggableTask.PaymentEmailAuthorizeNetTask', 1.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (20.0, 10.0, 'com.sapienter.jbilling.server.pluggableTask.ProcessorEmailAlarmTask', 3.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (21.0, 6.0, 'com.sapienter.jbilling.server.pluggableTask.PaymentFakeTask', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (22.0, 6.0, 'com.sapienter.jbilling.server.payment.tasks.PaymentRouterCCFTask', 2.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (23.0, 11.0, 'com.sapienter.jbilling.server.user.tasks.BasicSubscriptionStatusManagerTask', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (24.0, 6.0, 'com.sapienter.jbilling.server.user.tasks.PaymentACHCommerceTask', 5.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (25.0, 12.0, 'com.sapienter.jbilling.server.payment.tasks.NoAsyncParameters', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (26.0, 12.0, 'com.sapienter.jbilling.server.payment.tasks.RouterAsyncParameters', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (28.0, 13.0, 'com.sapienter.jbilling.server.item.tasks.BasicItemManager', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (29.0, 13.0, 'com.sapienter.jbilling.server.item.tasks.RulesItemManager', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (30.0, 1.0, 'com.sapienter.jbilling.server.order.task.RulesLineTotalTask', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (31.0, 14.0, 'com.sapienter.jbilling.server.item.tasks.RulesPricingTask', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (35.0, 8.0, 'com.sapienter.jbilling.server.user.tasks.PaymentInfoNoValidateTask', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (36.0, 7.0, 'com.sapienter.jbilling.server.notification.task.TestNotificationTask', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (37.0, 5.0, 'com.sapienter.jbilling.server.process.task.ProRateOrderPeriodTask', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (38.0, 4.0, 'com.sapienter.jbilling.server.process.task.DailyProRateCompositionTask', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (39.0, 6.0, 'com.sapienter.jbilling.server.payment.tasks.PaymentAtlasTask', 5.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (40.0, 17.0, 'com.sapienter.jbilling.server.order.task.RefundOnCancelTask', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (41.0, 17.0, 'com.sapienter.jbilling.server.order.task.CancellationFeeRulesTask', 1.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (42.0, 6.0, 'com.sapienter.jbilling.server.payment.tasks.PaymentFilterTask', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (43.0, 17.0, 'com.sapienter.jbilling.server.payment.blacklist.tasks.BlacklistUserStatusTask', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (49.0, 6.0, 'com.sapienter.jbilling.server.payment.tasks.PaymentRouterCurrencyTask', 2.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (51.0, 3.0, 'com.sapienter.jbilling.server.invoice.task.NegativeBalanceInvoiceFilterTask', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (52.0, 17.0, 'com.sapienter.jbilling.server.invoice.task.FileInvoiceExportTask', 1.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (53.0, 17.0, 'com.sapienter.jbilling.server.system.event.task.InternalEventsRulesTask', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (54.0, 17.0, 'com.sapienter.jbilling.server.user.balance.DynamicBalanceManagerTask', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (55.0, 19.0, 'com.sapienter.jbilling.server.user.tasks.UserBalanceValidatePurchaseTask', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (56.0, 19.0, 'com.sapienter.jbilling.server.user.tasks.RulesValidatePurchaseTask', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (57.0, 6.0, 'com.sapienter.jbilling.server.payment.tasks.PaymentsGatewayTask', 4.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (58.0, 17.0, 'com.sapienter.jbilling.server.payment.tasks.SaveCreditCardExternallyTask', 1.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (59.0, 13.0, 'com.sapienter.jbilling.server.order.task.RulesItemManager2', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (60.0, 1.0, 'com.sapienter.jbilling.server.order.task.RulesLineTotalTask2', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (61.0, 14.0, 'com.sapienter.jbilling.server.item.tasks.RulesPricingTask2', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (62.0, 17.0, 'com.sapienter.jbilling.server.payment.tasks.SaveCreditCardExternallyTask', 1.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (63.0, 6.0, 'com.sapienter.jbilling.server.pluggableTask.PaymentFakeExternalStorage', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (64.0, 6.0, 'com.sapienter.jbilling.server.payment.tasks.PaymentWorldPayTask', 3.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (65.0, 6.0, 'com.sapienter.jbilling.server.payment.tasks.PaymentWorldPayExternalTask', 3.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (66.0, 17.0, 'com.sapienter.jbilling.server.user.tasks.AutoRechargeTask', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (67.0, 6.0, 'com.sapienter.jbilling.server.payment.tasks.PaymentBeanstreamTask', 3.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (68.0, 6.0, 'com.sapienter.jbilling.server.payment.tasks.PaymentSageTask', 2.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (69.0, 20.0, 'com.sapienter.jbilling.server.process.task.BasicBillingProcessFilterTask', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (70.0, 20.0, 'com.sapienter.jbilling.server.process.task.BillableUsersBillingProcessFilterTask', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (75.0, 6.0, 'com.sapienter.jbilling.server.payment.tasks.PaymentPaypalExternalTask', 3.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (76.0, 6.0, 'com.sapienter.jbilling.server.payment.tasks.PaymentAuthorizeNetCIMTask', 2.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (77.0, 6.0, 'com.sapienter.jbilling.server.payment.tasks.PaymentMethodRouterTask', 4.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (78.0, 23.0, 'com.sapienter.jbilling.server.rule.task.VelocityRulesGeneratorTask', 2.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (82.0, 22.0, 'com.sapienter.jbilling.server.billing.task.BillingProcessTask', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (83.0, 22.0, 'com.sapienter.jbilling.server.process.task.ScpUploadTask', 4.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (84.0, 17.0, 'com.sapienter.jbilling.server.payment.tasks.SaveACHExternallyTask', 1.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (85.0, 20.0, 'com.sapienter.jbilling.server.process.task.BillableUserOrdersBillingProcessFilterTask', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (87.0, 24.0, 'com.sapienter.jbilling.server.process.task.BasicAgeingTask', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (88.0, 22.0, 'com.sapienter.jbilling.server.process.task.AgeingProcessTask', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (89.0, 24.0, 'com.sapienter.jbilling.server.process.task.BusinessDayAgeingTask', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (90.0, 4.0, 'com.sapienter.jbilling.server.process.task.SimpleTaxCompositionTask', 1.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (91.0, 4.0, 'com.sapienter.jbilling.server.process.task.CountryTaxCompositionTask', 2.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (92.0, 4.0, 'com.sapienter.jbilling.server.process.task.PaymentTermPenaltyTask', 2.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (93.0, 17.0, 'com.sapienter.jbilling.server.order.task.CancellationFeeTask', 2.0);

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337972683141-21', 'aristokrates (generated)', 'descriptors/database/jbilling-init_data.xml', NOW(), 18, '7:14fb39b005d5c3342b044d602b33f89c', 'insert (x74)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-init_data.xml::1337972683141-22::aristokrates (generated)
INSERT INTO jbilling_test.payment_method (id) VALUES (1.0);

INSERT INTO jbilling_test.payment_method (id) VALUES (2.0);

INSERT INTO jbilling_test.payment_method (id) VALUES (3.0);

INSERT INTO jbilling_test.payment_method (id) VALUES (4.0);

INSERT INTO jbilling_test.payment_method (id) VALUES (5.0);

INSERT INTO jbilling_test.payment_method (id) VALUES (6.0);

INSERT INTO jbilling_test.payment_method (id) VALUES (7.0);

INSERT INTO jbilling_test.payment_method (id) VALUES (8.0);

INSERT INTO jbilling_test.payment_method (id) VALUES (9.0);

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337972683141-22', 'aristokrates (generated)', 'descriptors/database/jbilling-init_data.xml', NOW(), 19, '7:1109e20657343a92a7125e944a3fc388', 'insert (x9)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-init_data.xml::1337972683141-23::aristokrates (generated)
INSERT INTO jbilling_test.invoice_delivery_method (id) VALUES (1.0);

INSERT INTO jbilling_test.invoice_delivery_method (id) VALUES (2.0);

INSERT INTO jbilling_test.invoice_delivery_method (id) VALUES (3.0);

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337972683141-23', 'aristokrates (generated)', 'descriptors/database/jbilling-init_data.xml', NOW(), 20, '7:164fb555c85034315a8989521b5f5b12', 'insert (x3)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-init_data.xml::1337972683141-24::aristokrates (generated)
INSERT INTO jbilling_test.contact_type (id, entity_id, is_primary, optlock) VALUES (1.0, NULL, NULL, 0.0);

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337972683141-24', 'aristokrates (generated)', 'descriptors/database/jbilling-init_data.xml', NOW(), 21, '7:79edf8a3a5506853f064eb79bd1bb30a', 'insert', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-init_data.xml::1337972683141-25::aristokrates (generated)
INSERT INTO jbilling_test.period_unit (id) VALUES (1.0);

INSERT INTO jbilling_test.period_unit (id) VALUES (2.0);

INSERT INTO jbilling_test.period_unit (id) VALUES (3.0);

INSERT INTO jbilling_test.period_unit (id) VALUES (4.0);

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337972683141-25', 'aristokrates (generated)', 'descriptors/database/jbilling-init_data.xml', NOW(), 22, '7:6681820783c4b007b05a8a91bcec3da3', 'insert (x4)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-init_data.xml::1337972683141-26::aristokrates (generated)
INSERT INTO jbilling_test.report_parameter (id, report_id, dtype, name) VALUES (1.0, 1.0, 'date', 'start_date');

INSERT INTO jbilling_test.report_parameter (id, report_id, dtype, name) VALUES (2.0, 1.0, 'date', 'end_date');

INSERT INTO jbilling_test.report_parameter (id, report_id, dtype, name) VALUES (3.0, 1.0, 'integer', 'period');

INSERT INTO jbilling_test.report_parameter (id, report_id, dtype, name) VALUES (4.0, 3.0, 'integer', 'item_id');

INSERT INTO jbilling_test.report_parameter (id, report_id, dtype, name) VALUES (5.0, 4.0, 'date', 'start_date');

INSERT INTO jbilling_test.report_parameter (id, report_id, dtype, name) VALUES (6.0, 4.0, 'date', 'end_date');

INSERT INTO jbilling_test.report_parameter (id, report_id, dtype, name) VALUES (7.0, 4.0, 'integer', 'period');

INSERT INTO jbilling_test.report_parameter (id, report_id, dtype, name) VALUES (8.0, 5.0, 'date', 'start_date');

INSERT INTO jbilling_test.report_parameter (id, report_id, dtype, name) VALUES (9.0, 5.0, 'date', 'end_date');

INSERT INTO jbilling_test.report_parameter (id, report_id, dtype, name) VALUES (10.0, 5.0, 'integer', 'period');

INSERT INTO jbilling_test.report_parameter (id, report_id, dtype, name) VALUES (11.0, 6.0, 'date', 'start_date');

INSERT INTO jbilling_test.report_parameter (id, report_id, dtype, name) VALUES (12.0, 6.0, 'date', 'end_date');

INSERT INTO jbilling_test.report_parameter (id, report_id, dtype, name) VALUES (13.0, 8.0, 'date', 'date');

INSERT INTO jbilling_test.report_parameter (id, report_id, dtype, name) VALUES (14.0, 9.0, 'date', 'date');

INSERT INTO jbilling_test.report_parameter (id, report_id, dtype, name) VALUES (18.0, 11.0, 'date', 'start_date');

INSERT INTO jbilling_test.report_parameter (id, report_id, dtype, name) VALUES (19.0, 11.0, 'date', 'end_date');

INSERT INTO jbilling_test.report_parameter (id, report_id, dtype, name) VALUES (20.0, 12.0, 'string', 'start_year');

INSERT INTO jbilling_test.report_parameter (id, report_id, dtype, name) VALUES (21.0, 12.0, 'string', 'end_year');

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337972683141-26', 'aristokrates (generated)', 'descriptors/database/jbilling-init_data.xml', NOW(), 23, '7:587d53226acce3a9ddddd2471e6b4492', 'insert (x18)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-init_data.xml::1337972683141-27::aristokrates (generated)
INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (4.0, NULL);

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (5.0, NULL);

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (6.0, NULL);

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (7.0, NULL);

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (8.0, NULL);

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (9.0, NULL);

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (10.0, NULL);

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (11.0, NULL);

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (12.0, NULL);

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (13.0, NULL);

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (14.0, NULL);

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (15.0, NULL);

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (16.0, NULL);

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (17.0, NULL);

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (18.0, NULL);

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (19.0, '1');

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (20.0, '1');

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (21.0, '0');

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (22.0, NULL);

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (23.0, NULL);

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (24.0, '0');

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (25.0, '0');

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (27.0, '0');

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (28.0, NULL);

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (29.0, 'https://www.paypal.com/en_US/i/btn/x-click-but6.gif');

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (30.0, NULL);

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (31.0, '');

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (32.0, '0');

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (33.0, '0');

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (35.0, '0');

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (36.0, '1');

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (37.0, '0');

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (38.0, '1');

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (39.0, '0');

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (40.0, '0');

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (41.0, '0');

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (42.0, '0');

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (43.0, '0');

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (44.0, '0');

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (45.0, '0');

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (46.0, '0');

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (47.0, '0');

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (48.0, '1');

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (49.0, NULL);

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (50.0, '2');

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337972683141-27', 'aristokrates (generated)', 'descriptors/database/jbilling-init_data.xml', NOW(), 24, '7:289e035c8f1e23c982cfab688581c87e', 'insert (x45)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-init_data.xml::1337972683141-28::aristokrates (generated)
INSERT INTO jbilling_test.currency_exchange (id, entity_id, currency_id, rate, create_datetime, valid_since, optlock) VALUES (1.0, 0.0, 2.0, 1.325, '2004-03-09 00:00:00.000', '1970-01-01', 1.0);

INSERT INTO jbilling_test.currency_exchange (id, entity_id, currency_id, rate, create_datetime, valid_since, optlock) VALUES (2.0, 0.0, 3.0, 0.8118, '2004-03-09 00:00:00.000', '1970-01-01', 1.0);

INSERT INTO jbilling_test.currency_exchange (id, entity_id, currency_id, rate, create_datetime, valid_since, optlock) VALUES (3.0, 0.0, 4.0, 111.4, '2004-03-09 00:00:00.000', '1970-01-01', 1.0);

INSERT INTO jbilling_test.currency_exchange (id, entity_id, currency_id, rate, create_datetime, valid_since, optlock) VALUES (4.0, 0.0, 5.0, 0.5479, '2004-03-09 00:00:00.000', '1970-01-01', 1.0);

INSERT INTO jbilling_test.currency_exchange (id, entity_id, currency_id, rate, create_datetime, valid_since, optlock) VALUES (5.0, 0.0, 6.0, 1171.0, '2004-03-09 00:00:00.000', '1970-01-01', 1.0);

INSERT INTO jbilling_test.currency_exchange (id, entity_id, currency_id, rate, create_datetime, valid_since, optlock) VALUES (6.0, 0.0, 7.0, 1.23, '2004-07-06 00:00:00.000', '1970-01-01', 1.0);

INSERT INTO jbilling_test.currency_exchange (id, entity_id, currency_id, rate, create_datetime, valid_since, optlock) VALUES (7.0, 0.0, 8.0, 7.47, '2004-07-06 00:00:00.000', '1970-01-01', 1.0);

INSERT INTO jbilling_test.currency_exchange (id, entity_id, currency_id, rate, create_datetime, valid_since, optlock) VALUES (10.0, 0.0, 9.0, 1.68, '2004-10-12 00:00:00.000', '1970-01-01', 1.0);

INSERT INTO jbilling_test.currency_exchange (id, entity_id, currency_id, rate, create_datetime, valid_since, optlock) VALUES (11.0, 0.0, 10.0, 3.8, '2004-10-12 00:00:00.000', '1970-01-01', 1.0);

INSERT INTO jbilling_test.currency_exchange (id, entity_id, currency_id, rate, create_datetime, valid_since, optlock) VALUES (12.0, 0.0, 11.0, 1.288, '2007-01-25 00:00:00.000', '1970-01-01', 1.0);

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337972683141-28', 'aristokrates (generated)', 'descriptors/database/jbilling-init_data.xml', NOW(), 25, '7:eadba725b9996268cc5b7acda1fd8012', 'insert (x10)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-init_data.xml::1337972683141-29::aristokrates (generated)
INSERT INTO jbilling_test.event_log_module (id) VALUES (1.0);

INSERT INTO jbilling_test.event_log_module (id) VALUES (2.0);

INSERT INTO jbilling_test.event_log_module (id) VALUES (3.0);

INSERT INTO jbilling_test.event_log_module (id) VALUES (4.0);

INSERT INTO jbilling_test.event_log_module (id) VALUES (5.0);

INSERT INTO jbilling_test.event_log_module (id) VALUES (6.0);

INSERT INTO jbilling_test.event_log_module (id) VALUES (7.0);

INSERT INTO jbilling_test.event_log_module (id) VALUES (8.0);

INSERT INTO jbilling_test.event_log_module (id) VALUES (9.0);

INSERT INTO jbilling_test.event_log_module (id) VALUES (10.0);

INSERT INTO jbilling_test.event_log_module (id) VALUES (11.0);

INSERT INTO jbilling_test.event_log_module (id) VALUES (12.0);

INSERT INTO jbilling_test.event_log_module (id) VALUES (13.0);

INSERT INTO jbilling_test.event_log_module (id) VALUES (14.0);

INSERT INTO jbilling_test.event_log_module (id) VALUES (15.0);

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337972683141-29', 'aristokrates (generated)', 'descriptors/database/jbilling-init_data.xml', NOW(), 26, '7:21c89970a65dd49d28d95da673e6e328', 'insert (x15)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-init_data.xml::1337972683141-30::aristokrates (generated)
INSERT INTO jbilling_test.notification_message_type (id, category_id, optlock) VALUES (1.0, 1.0, 1.0);

INSERT INTO jbilling_test.notification_message_type (id, category_id, optlock) VALUES (2.0, 4.0, 1.0);

INSERT INTO jbilling_test.notification_message_type (id, category_id, optlock) VALUES (3.0, 4.0, 1.0);

INSERT INTO jbilling_test.notification_message_type (id, category_id, optlock) VALUES (4.0, 4.0, 1.0);

INSERT INTO jbilling_test.notification_message_type (id, category_id, optlock) VALUES (5.0, 4.0, 1.0);

INSERT INTO jbilling_test.notification_message_type (id, category_id, optlock) VALUES (6.0, 4.0, 1.0);

INSERT INTO jbilling_test.notification_message_type (id, category_id, optlock) VALUES (7.0, 4.0, 1.0);

INSERT INTO jbilling_test.notification_message_type (id, category_id, optlock) VALUES (8.0, 4.0, 1.0);

INSERT INTO jbilling_test.notification_message_type (id, category_id, optlock) VALUES (9.0, 4.0, 1.0);

INSERT INTO jbilling_test.notification_message_type (id, category_id, optlock) VALUES (12.0, 1.0, 1.0);

INSERT INTO jbilling_test.notification_message_type (id, category_id, optlock) VALUES (13.0, 2.0, 1.0);

INSERT INTO jbilling_test.notification_message_type (id, category_id, optlock) VALUES (14.0, 2.0, 1.0);

INSERT INTO jbilling_test.notification_message_type (id, category_id, optlock) VALUES (15.0, 2.0, 1.0);

INSERT INTO jbilling_test.notification_message_type (id, category_id, optlock) VALUES (16.0, 3.0, 1.0);

INSERT INTO jbilling_test.notification_message_type (id, category_id, optlock) VALUES (17.0, 3.0, 1.0);

INSERT INTO jbilling_test.notification_message_type (id, category_id, optlock) VALUES (18.0, 1.0, 1.0);

INSERT INTO jbilling_test.notification_message_type (id, category_id, optlock) VALUES (19.0, 4.0, 1.0);

INSERT INTO jbilling_test.notification_message_type (id, category_id, optlock) VALUES (20.0, 4.0, 1.0);

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337972683141-30', 'aristokrates (generated)', 'descriptors/database/jbilling-init_data.xml', NOW(), 27, '7:466725d303d2465d862b3a7d6a440c51', 'insert (x18)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-init_data.xml::1337972683141-31::aristokrates (generated)
INSERT INTO jbilling_test.generic_status (id, dtype, status_value, can_login) VALUES (1.0, 'user_status', 1.0, 1.0);

INSERT INTO jbilling_test.generic_status (id, dtype, status_value, can_login) VALUES (2.0, 'user_status', 2.0, 1.0);

INSERT INTO jbilling_test.generic_status (id, dtype, status_value, can_login) VALUES (3.0, 'user_status', 3.0, 1.0);

INSERT INTO jbilling_test.generic_status (id, dtype, status_value, can_login) VALUES (4.0, 'user_status', 4.0, 1.0);

INSERT INTO jbilling_test.generic_status (id, dtype, status_value, can_login) VALUES (5.0, 'user_status', 5.0, 0.0);

INSERT INTO jbilling_test.generic_status (id, dtype, status_value, can_login) VALUES (6.0, 'user_status', 6.0, 0.0);

INSERT INTO jbilling_test.generic_status (id, dtype, status_value, can_login) VALUES (7.0, 'user_status', 7.0, 0.0);

INSERT INTO jbilling_test.generic_status (id, dtype, status_value, can_login) VALUES (8.0, 'user_status', 8.0, 0.0);

INSERT INTO jbilling_test.generic_status (id, dtype, status_value, can_login) VALUES (9.0, 'subscriber_status', 1.0, NULL);

INSERT INTO jbilling_test.generic_status (id, dtype, status_value, can_login) VALUES (10.0, 'subscriber_status', 2.0, NULL);

INSERT INTO jbilling_test.generic_status (id, dtype, status_value, can_login) VALUES (11.0, 'subscriber_status', 3.0, NULL);

INSERT INTO jbilling_test.generic_status (id, dtype, status_value, can_login) VALUES (12.0, 'subscriber_status', 4.0, NULL);

INSERT INTO jbilling_test.generic_status (id, dtype, status_value, can_login) VALUES (13.0, 'subscriber_status', 5.0, NULL);

INSERT INTO jbilling_test.generic_status (id, dtype, status_value, can_login) VALUES (14.0, 'subscriber_status', 6.0, NULL);

INSERT INTO jbilling_test.generic_status (id, dtype, status_value, can_login) VALUES (15.0, 'subscriber_status', 7.0, NULL);

INSERT INTO jbilling_test.generic_status (id, dtype, status_value, can_login) VALUES (16.0, 'order_status', 1.0, NULL);

INSERT INTO jbilling_test.generic_status (id, dtype, status_value, can_login) VALUES (17.0, 'order_status', 2.0, NULL);

INSERT INTO jbilling_test.generic_status (id, dtype, status_value, can_login) VALUES (18.0, 'order_status', 3.0, NULL);

INSERT INTO jbilling_test.generic_status (id, dtype, status_value, can_login) VALUES (19.0, 'order_status', 4.0, NULL);

INSERT INTO jbilling_test.generic_status (id, dtype, status_value, can_login) VALUES (26.0, 'invoice_status', 1.0, NULL);

INSERT INTO jbilling_test.generic_status (id, dtype, status_value, can_login) VALUES (27.0, 'invoice_status', 2.0, NULL);

INSERT INTO jbilling_test.generic_status (id, dtype, status_value, can_login) VALUES (28.0, 'invoice_status', 3.0, NULL);

INSERT INTO jbilling_test.generic_status (id, dtype, status_value, can_login) VALUES (33.0, 'process_run_status', 1.0, NULL);

INSERT INTO jbilling_test.generic_status (id, dtype, status_value, can_login) VALUES (34.0, 'process_run_status', 2.0, NULL);

INSERT INTO jbilling_test.generic_status (id, dtype, status_value, can_login) VALUES (35.0, 'process_run_status', 3.0, NULL);

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337972683141-31', 'aristokrates (generated)', 'descriptors/database/jbilling-init_data.xml', NOW(), 28, '7:ea46f4ee8be7507c55bfeddceb274a72', 'insert (x25)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-init_data.xml::1337972683141-32::aristokrates (generated)
INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 20.0, 'description', 1.0, 'Manual invoice deletion');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46.0, 9.0, 'description', 1.0, 'Invoice maintenance');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46.0, 11.0, 'description', 1.0, 'Pluggable tasks maintenance');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 16.0, 'description', 1.0, 'A purchase order as been manually applied to an invoice.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, 17.0, 'description', 1.0, 'Payment (failed)');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, 16.0, 'description', 1.0, 'Payment (successful)');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35.0, 6.0, 'description', 1.0, 'Discovery');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35.0, 7.0, 'description', 1.0, 'Diners');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 16.0, 'description', 1.0, 'Days before expiration for order notification 2');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 17.0, 'description', 1.0, 'Days before expiration for order notification 3');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, 13.0, 'description', 1.0, 'Order about to expire. Step 1');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, 14.0, 'description', 1.0, 'Order about to expire. Step 2');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, 15.0, 'description', 1.0, 'Order about to expire. Step 3');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35.0, 4.0, 'description', 1.0, 'AMEX');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35.0, 5.0, 'description', 1.0, 'ACH');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 14.0, 'description', 1.0, 'Include customer notes in invoice');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 18.0, 'description', 1.0, 'Invoice number prefix');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 234.0, 'description', 1.0, 'Wallis and Futuna');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 235.0, 'description', 1.0, 'Yemen');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 236.0, 'description', 1.0, 'Zambia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 237.0, 'description', 1.0, 'Zimbabwe');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 15.0, 'description', 1.0, 'Days before expiration for order notification');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 21.0, 'description', 1.0, 'Use invoice reminders');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 22.0, 'description', 1.0, 'Number of days after the invoice generation for the first reminder');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 23.0, 'description', 1.0, 'Number of days for next reminder');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 227.0, 'description', 1.0, 'Uzbekistan');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 147.0, 'description', 1.0, 'Nauru');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 148.0, 'description', 1.0, 'Nepal');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 149.0, 'description', 1.0, 'Netherlands');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 150.0, 'description', 1.0, 'Netherlands Antilles');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 151.0, 'description', 1.0, 'New Caledonia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 152.0, 'description', 1.0, 'New Zealand');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 153.0, 'description', 1.0, 'Nicaragua');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 154.0, 'description', 1.0, 'Niger');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 155.0, 'description', 1.0, 'Nigeria');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 156.0, 'description', 1.0, 'Niue');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 157.0, 'description', 1.0, 'Norfolk Island');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 158.0, 'description', 1.0, 'North Korea');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 159.0, 'description', 1.0, 'Northern Mariana Islands');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 160.0, 'description', 1.0, 'Norway');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 161.0, 'description', 1.0, 'Oman');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 162.0, 'description', 1.0, 'Pakistan');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 163.0, 'description', 1.0, 'Palau');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 164.0, 'description', 1.0, 'Panama');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 165.0, 'description', 1.0, 'Papua New Guinea');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 166.0, 'description', 1.0, 'Paraguay');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 167.0, 'description', 1.0, 'Peru');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 168.0, 'description', 1.0, 'Philippines');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 169.0, 'description', 1.0, 'Pitcairn Islands');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 170.0, 'description', 1.0, 'Poland');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 171.0, 'description', 1.0, 'Portugal');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 172.0, 'description', 1.0, 'Puerto Rico');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 173.0, 'description', 1.0, 'Qatar');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 174.0, 'description', 1.0, 'Reunion');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 175.0, 'description', 1.0, 'Romania');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 176.0, 'description', 1.0, 'Russia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 177.0, 'description', 1.0, 'Rwanda');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 178.0, 'description', 1.0, 'Samoa');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 179.0, 'description', 1.0, 'San Marino');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 180.0, 'description', 1.0, 'Sao Tome and Principe');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 181.0, 'description', 1.0, 'Saudi Arabia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 182.0, 'description', 1.0, 'Senegal');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 183.0, 'description', 1.0, 'Serbia and Montenegro');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 184.0, 'description', 1.0, 'Seychelles');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 185.0, 'description', 1.0, 'Sierra Leone');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 186.0, 'description', 1.0, 'Singapore');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 187.0, 'description', 1.0, 'Slovakia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 188.0, 'description', 1.0, 'Slovenia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 189.0, 'description', 1.0, 'Solomon Islands');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 190.0, 'description', 1.0, 'Somalia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 191.0, 'description', 1.0, 'South Africa');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 192.0, 'description', 1.0, 'South Georgia and the South Sandwich Islands');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 193.0, 'description', 1.0, 'Spain');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 194.0, 'description', 1.0, 'Sri Lanka');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 195.0, 'description', 1.0, 'St. Helena');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 196.0, 'description', 1.0, 'St. Kitts and Nevis');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 197.0, 'description', 1.0, 'St. Lucia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 198.0, 'description', 1.0, 'St. Pierre and Miquelon');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 199.0, 'description', 1.0, 'St. Vincent and the Grenadines');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 200.0, 'description', 1.0, 'Sudan');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 201.0, 'description', 1.0, 'Suriname');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 202.0, 'description', 1.0, 'Svalbard and Jan Mayen');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 203.0, 'description', 1.0, 'Swaziland');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 204.0, 'description', 1.0, 'Sweden');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 205.0, 'description', 1.0, 'Switzerland');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 206.0, 'description', 1.0, 'Syria');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 207.0, 'description', 1.0, 'Taiwan');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 208.0, 'description', 1.0, 'Tajikistan');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 209.0, 'description', 1.0, 'Tanzania');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 210.0, 'description', 1.0, 'Thailand');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 211.0, 'description', 1.0, 'Togo');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 212.0, 'description', 1.0, 'Tokelau');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 213.0, 'description', 1.0, 'Tonga');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 214.0, 'description', 1.0, 'Trinidad and Tobago');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 215.0, 'description', 1.0, 'Tunisia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 216.0, 'description', 1.0, 'Turkey');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 217.0, 'description', 1.0, 'Turkmenistan');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 218.0, 'description', 1.0, 'Turks and Caicos Islands');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 219.0, 'description', 1.0, 'Tuvalu');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 220.0, 'description', 1.0, 'Uganda');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 221.0, 'description', 1.0, 'Ukraine');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 222.0, 'description', 1.0, 'United Arab Emirates');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 223.0, 'description', 1.0, 'United Kingdom');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 224.0, 'description', 1.0, 'United States');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 225.0, 'description', 1.0, 'United States Minor Outlying Islands');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 226.0, 'description', 1.0, 'Uruguay');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 228.0, 'description', 1.0, 'Vanuatu');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 229.0, 'description', 1.0, 'Vatican City');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 230.0, 'description', 1.0, 'Venezuela');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 231.0, 'description', 1.0, 'Viet Nam');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 232.0, 'description', 1.0, 'Virgin Islands - British');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 233.0, 'description', 1.0, 'Virgin Islands');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 57.0, 'description', 1.0, 'Congo - DRC');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 58.0, 'description', 1.0, 'Denmark');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 59.0, 'description', 1.0, 'Djibouti');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 60.0, 'description', 1.0, 'Dominica');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 61.0, 'description', 1.0, 'Dominican Republic');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 62.0, 'description', 1.0, 'East Timor');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 63.0, 'description', 1.0, 'Ecuador');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 64.0, 'description', 1.0, 'Egypt');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 65.0, 'description', 1.0, 'El Salvador');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 66.0, 'description', 1.0, 'Equatorial Guinea');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 67.0, 'description', 1.0, 'Eritrea');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 68.0, 'description', 1.0, 'Estonia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 69.0, 'description', 1.0, 'Ethiopia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 70.0, 'description', 1.0, 'Malvinas Islands');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 71.0, 'description', 1.0, 'Faroe Islands');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 72.0, 'description', 1.0, 'Fiji Islands');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 73.0, 'description', 1.0, 'Finland');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 74.0, 'description', 1.0, 'France');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 75.0, 'description', 1.0, 'French Guiana');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 76.0, 'description', 1.0, 'French Polynesia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 77.0, 'description', 1.0, 'French Southern and Antarctic Lands');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 78.0, 'description', 1.0, 'Gabon');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 79.0, 'description', 1.0, 'Gambia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 80.0, 'description', 1.0, 'Georgia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 81.0, 'description', 1.0, 'Germany');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 82.0, 'description', 1.0, 'Ghana');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 83.0, 'description', 1.0, 'Gibraltar');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 84.0, 'description', 1.0, 'Greece');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 85.0, 'description', 1.0, 'Greenland');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 86.0, 'description', 1.0, 'Grenada');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 87.0, 'description', 1.0, 'Guadeloupe');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 88.0, 'description', 1.0, 'Guam');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 89.0, 'description', 1.0, 'Guatemala');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 90.0, 'description', 1.0, 'Guinea');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 91.0, 'description', 1.0, 'Guinea-Bissau');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 92.0, 'description', 1.0, 'Guyana');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 93.0, 'description', 1.0, 'Haiti');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 94.0, 'description', 1.0, 'Heard Island and McDonald Islands');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 95.0, 'description', 1.0, 'Honduras');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 96.0, 'description', 1.0, 'Hong Kong SAR');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 97.0, 'description', 1.0, 'Hungary');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 98.0, 'description', 1.0, 'Iceland');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 99.0, 'description', 1.0, 'India');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 100.0, 'description', 1.0, 'Indonesia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 101.0, 'description', 1.0, 'Iran');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 102.0, 'description', 1.0, 'Iraq');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 103.0, 'description', 1.0, 'Ireland');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 104.0, 'description', 1.0, 'Israel');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 105.0, 'description', 1.0, 'Italy');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 106.0, 'description', 1.0, 'Jamaica');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 107.0, 'description', 1.0, 'Japan');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 108.0, 'description', 1.0, 'Jordan');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 109.0, 'description', 1.0, 'Kazakhstan');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 110.0, 'description', 1.0, 'Kenya');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 111.0, 'description', 1.0, 'Kiribati');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 112.0, 'description', 1.0, 'Korea');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 113.0, 'description', 1.0, 'Kuwait');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 114.0, 'description', 1.0, 'Kyrgyzstan');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 115.0, 'description', 1.0, 'Laos');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 116.0, 'description', 1.0, 'Latvia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 117.0, 'description', 1.0, 'Lebanon');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 118.0, 'description', 1.0, 'Lesotho');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 119.0, 'description', 1.0, 'Liberia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 120.0, 'description', 1.0, 'Libya');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 121.0, 'description', 1.0, 'Liechtenstein');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 122.0, 'description', 1.0, 'Lithuania');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 123.0, 'description', 1.0, 'Luxembourg');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 124.0, 'description', 1.0, 'Macao SAR');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 125.0, 'description', 1.0, 'Macedonia, Former Yugoslav Republic of');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 126.0, 'description', 1.0, 'Madagascar');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 127.0, 'description', 1.0, 'Malawi');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 128.0, 'description', 1.0, 'Malaysia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 129.0, 'description', 1.0, 'Maldives');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 130.0, 'description', 1.0, 'Mali');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 131.0, 'description', 1.0, 'Malta');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 132.0, 'description', 1.0, 'Marshall Islands');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 133.0, 'description', 1.0, 'Martinique');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 134.0, 'description', 1.0, 'Mauritania');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 135.0, 'description', 1.0, 'Mauritius');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 136.0, 'description', 1.0, 'Mayotte');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 137.0, 'description', 1.0, 'Mexico');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 138.0, 'description', 1.0, 'Micronesia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 139.0, 'description', 1.0, 'Moldova');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 140.0, 'description', 1.0, 'Monaco');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 141.0, 'description', 1.0, 'Mongolia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 142.0, 'description', 1.0, 'Montserrat');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 143.0, 'description', 1.0, 'Morocco');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 144.0, 'description', 1.0, 'Mozambique');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 145.0, 'description', 1.0, 'Myanmar');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 146.0, 'description', 1.0, 'Namibia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 1.0, 'description', 1.0, 'Afghanistan');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 2.0, 'description', 1.0, 'Albania');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 3.0, 'description', 1.0, 'Algeria');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 4.0, 'description', 1.0, 'American Samoa');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 5.0, 'description', 1.0, 'Andorra');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 6.0, 'description', 1.0, 'Angola');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 7.0, 'description', 1.0, 'Anguilla');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 8.0, 'description', 1.0, 'Antarctica');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 9.0, 'description', 1.0, 'Antigua and Barbuda');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 10.0, 'description', 1.0, 'Argentina');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 11.0, 'description', 1.0, 'Armenia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 12.0, 'description', 1.0, 'Aruba');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 13.0, 'description', 1.0, 'Australia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 14.0, 'description', 1.0, 'Austria');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 15.0, 'description', 1.0, 'Azerbaijan');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 16.0, 'description', 1.0, 'Bahamas');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 17.0, 'description', 1.0, 'Bahrain');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 18.0, 'description', 1.0, 'Bangladesh');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 19.0, 'description', 1.0, 'Barbados');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 20.0, 'description', 1.0, 'Belarus');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 21.0, 'description', 1.0, 'Belgium');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 22.0, 'description', 1.0, 'Belize');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 23.0, 'description', 1.0, 'Benin');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 24.0, 'description', 1.0, 'Bermuda');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 25.0, 'description', 1.0, 'Bhutan');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 26.0, 'description', 1.0, 'Bolivia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 27.0, 'description', 1.0, 'Bosnia and Herzegovina');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 28.0, 'description', 1.0, 'Botswana');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 29.0, 'description', 1.0, 'Bouvet Island');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 30.0, 'description', 1.0, 'Brazil');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 31.0, 'description', 1.0, 'British Indian Ocean Territory');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 32.0, 'description', 1.0, 'Brunei');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 33.0, 'description', 1.0, 'Bulgaria');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 34.0, 'description', 1.0, 'Burkina Faso');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 35.0, 'description', 1.0, 'Burundi');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 36.0, 'description', 1.0, 'Cambodia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 37.0, 'description', 1.0, 'Cameroon');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 38.0, 'description', 1.0, 'Canada');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 39.0, 'description', 1.0, 'Cape Verde');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 40.0, 'description', 1.0, 'Cayman Islands');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 41.0, 'description', 1.0, 'Central African Republic');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 42.0, 'description', 1.0, 'Chad');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 43.0, 'description', 1.0, 'Chile');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 44.0, 'description', 1.0, 'China');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 45.0, 'description', 1.0, 'Christmas Island');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 46.0, 'description', 1.0, 'Cocos - Keeling Islands');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 47.0, 'description', 1.0, 'Colombia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 48.0, 'description', 1.0, 'Comoros');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 49.0, 'description', 1.0, 'Congo');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 50.0, 'description', 1.0, 'Cook Islands');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 51.0, 'description', 1.0, 'Costa Rica');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 52.0, 'description', 1.0, 'Cote d Ivoire');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 53.0, 'description', 1.0, 'Croatia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 54.0, 'description', 1.0, 'Cuba');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 55.0, 'description', 1.0, 'Cyprus');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 56.0, 'description', 1.0, 'Czech Republic');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4.0, 1.0, 'description', 1.0, 'United States Dollar');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4.0, 2.0, 'description', 1.0, 'Canadian Dollar');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4.0, 3.0, 'description', 1.0, 'Euro');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4.0, 4.0, 'description', 1.0, 'Yen');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4.0, 5.0, 'description', 1.0, 'Pound Sterling');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4.0, 6.0, 'description', 1.0, 'Won');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4.0, 7.0, 'description', 1.0, 'Swiss Franc');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4.0, 8.0, 'description', 1.0, 'Swedish Krona');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (6.0, 1.0, 'description', 1.0, 'Month');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (6.0, 2.0, 'description', 1.0, 'Week');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (6.0, 3.0, 'description', 1.0, 'Day');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (6.0, 4.0, 'description', 1.0, 'Year');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (7.0, 1.0, 'description', 1.0, 'Email');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (7.0, 2.0, 'description', 1.0, 'Paper');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9.0, 1.0, 'description', 1.0, 'Active');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9.0, 2.0, 'description', 1.0, 'Overdue');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9.0, 3.0, 'description', 1.0, 'Overdue 2');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9.0, 4.0, 'description', 1.0, 'Overdue 3');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9.0, 5.0, 'description', 1.0, 'Suspended');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9.0, 6.0, 'description', 1.0, 'Suspended 2');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9.0, 7.0, 'description', 1.0, 'Suspended 3');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9.0, 8.0, 'description', 1.0, 'Deleted');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (81.0, 1.0, 'description', 1.0, 'Active');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (81.0, 2.0, 'description', 1.0, 'Pending Unsubscription');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (81.0, 3.0, 'description', 1.0, 'Unsubscribed');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (81.0, 4.0, 'description', 1.0, 'Pending Expiration');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (81.0, 5.0, 'description', 1.0, 'Expired');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (81.0, 6.0, 'description', 1.0, 'Nonsubscriber');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (81.0, 7.0, 'description', 1.0, 'Discontinued');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60.0, 1.0, 'description', 1.0, 'An internal user with all the permissions');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60.0, 1.0, 'title', 1.0, 'Internal');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60.0, 2.0, 'description', 1.0, 'The super user of an entity');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60.0, 2.0, 'title', 1.0, 'Super user');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60.0, 3.0, 'description', 1.0, 'A billing clerk');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60.0, 3.0, 'title', 1.0, 'Clerk');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60.0, 4.0, 'description', 1.0, 'A partner that will bring customers');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60.0, 4.0, 'title', 1.0, 'Partner');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60.0, 5.0, 'description', 1.0, 'A customer that will query his/her account');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60.0, 5.0, 'title', 1.0, 'Customer');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (17.0, 1.0, 'description', 1.0, 'One time');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (18.0, 1.0, 'description', 1.0, 'Items');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (18.0, 2.0, 'description', 1.0, 'Tax');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (19.0, 1.0, 'description', 1.0, 'pre paid');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (19.0, 2.0, 'description', 1.0, 'post paid');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (20.0, 1.0, 'description', 1.0, 'Active');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (20.0, 2.0, 'description', 1.0, 'Finished');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (20.0, 3.0, 'description', 1.0, 'Suspended');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35.0, 1.0, 'description', 1.0, 'Cheque');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35.0, 2.0, 'description', 1.0, 'Visa');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35.0, 3.0, 'description', 1.0, 'MasterCard');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (41.0, 1.0, 'description', 1.0, 'Successful');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (41.0, 2.0, 'description', 1.0, 'Failed');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (41.0, 3.0, 'description', 1.0, 'Processor unavailable');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (41.0, 4.0, 'description', 1.0, 'Entered');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46.0, 1.0, 'description', 1.0, 'Billing Process');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46.0, 2.0, 'description', 1.0, 'User maintenance');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46.0, 3.0, 'description', 1.0, 'Item maintenance');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46.0, 4.0, 'description', 1.0, 'Item type maintenance');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46.0, 5.0, 'description', 1.0, 'Item user price maintenance');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46.0, 6.0, 'description', 1.0, 'Promotion maintenance');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46.0, 7.0, 'description', 1.0, 'Order maintenance');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46.0, 8.0, 'description', 1.0, 'Credit card maintenance');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 1.0, 'description', 1.0, 'A prepaid order has unbilled time before the billing process date');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 2.0, 'description', 1.0, 'Order has no active time at the date of process.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 3.0, 'description', 1.0, 'At least one complete period has to be billable.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 4.0, 'description', 1.0, 'Already billed for the current date.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 5.0, 'description', 1.0, 'This order had to be maked for exclusion in the last process.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 6.0, 'description', 1.0, 'Pre-paid order is being process after its expiration.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 7.0, 'description', 1.0, 'A row was marked as deleted.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 8.0, 'description', 1.0, 'A user password was changed.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 9.0, 'description', 1.0, 'A row was updated.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 10.0, 'description', 1.0, 'Running a billing process, but a review is found unapproved.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 11.0, 'description', 1.0, 'Running a billing process, review is required but not present.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 12.0, 'description', 1.0, 'A user status was changed.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 13.0, 'description', 1.0, 'An order status was changed.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 14.0, 'description', 1.0, 'A user had to be aged, but there''s no more steps configured.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 15.0, 'description', 1.0, 'A partner has a payout ready, but no payment instrument.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 1.0, 'description', 1.0, 'Process payment with billing process');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 2.0, 'description', 1.0, 'URL of CSS file');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 3.0, 'description', 1.0, 'URL of logo graphic');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 4.0, 'description', 1.0, 'Grace period');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 5.0, 'description', 1.0, 'Partner percentage rate');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 6.0, 'description', 1.0, 'Partner referral fee');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 7.0, 'description', 1.0, 'Partner one time payout');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 8.0, 'description', 1.0, 'Partner period unit payout');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 9.0, 'description', 1.0, 'Partner period value payout');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 10.0, 'description', 1.0, 'Partner automatic payout');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 11.0, 'description', 1.0, 'User in charge of partners ');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 12.0, 'description', 1.0, 'Partner fee currency');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 13.0, 'description', 1.0, 'Self delivery of paper invoices');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, 1.0, 'description', 1.0, 'Invoice (email)');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, 2.0, 'description', 1.0, 'User Reactivated');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, 3.0, 'description', 1.0, 'User Overdue');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, 4.0, 'description', 1.0, 'User Overdue 2');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, 5.0, 'description', 1.0, 'User Overdue 3');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, 6.0, 'description', 1.0, 'User Suspended');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, 7.0, 'description', 1.0, 'User Suspended 2');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, 8.0, 'description', 1.0, 'User Suspended 3');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, 9.0, 'description', 1.0, 'User Deleted');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, 12.0, 'description', 1.0, 'Invoice (paper)');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 24.0, 'description', 1.0, 'Data Fattura Fine Mese');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4.0, 9.0, 'description', 1.0, 'Singapore Dollar');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4.0, 10.0, 'description', 1.0, 'Malaysian Ringgit');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4.0, 11.0, 'description', 1.0, 'Australian Dollar');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 19.0, 'description', 1.0, 'Next invoice number');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (7.0, 3.0, 'description', 1.0, 'Email + Paper');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35.0, 8.0, 'description', 1.0, 'PayPal');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, 19.0, 'description', 1.0, 'Update Credit Card');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (20.0, 4.0, 'description', 1.0, 'Suspended (auto)');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (18.0, 3.0, 'description', 1.0, 'Penalty');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, 20.0, 'description', 1.0, 'Lost password');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (88.0, 1.0, 'description', 1.0, 'Active');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (88.0, 2.0, 'description', 1.0, 'Inactive');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (88.0, 3.0, 'description', 1.0, 'Pending Active');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (88.0, 4.0, 'description', 1.0, 'Pending Inactive');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (88.0, 5.0, 'description', 1.0, 'Failed');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (88.0, 6.0, 'description', 1.0, 'Unavailable');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 20.0, 'description', 2.0, 'Eliminação manual de facturas');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46.0, 9.0, 'description', 2.0, 'Manutenção de facturas');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46.0, 11.0, 'description', 2.0, 'Manutenção de tarefas de plug-ins');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 16.0, 'description', 2.0, 'Uma ordem de compra foi aplicada manualmente a uma factura.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, 17.0, 'description', 2.0, 'Payment (sem sucesso)');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, 16.0, 'description', 2.0, 'Payment (com sucesso)');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35.0, 6.0, 'description', 2.0, 'Discovery');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35.0, 7.0, 'description', 2.0, 'Diners');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 16.0, 'description', 2.0, 'Dias antes da expiração para notificação de ordens 2');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 17.0, 'description', 2.0, 'Dias antes da expiração para notificação de ordens 3');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, 13.0, 'description', 2.0, 'Ordem de compra a expirar. Passo 1');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, 14.0, 'description', 2.0, 'Ordem de compra a expirar. Passo 2');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, 15.0, 'description', 2.0, 'Ordem de compra a expirar. Passo 3');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35.0, 4.0, 'description', 2.0, 'AMEX');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35.0, 5.0, 'description', 2.0, 'CCA');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 14.0, 'description', 2.0, 'Incluir notas do cliente na factura');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 18.0, 'description', 2.0, 'NÚmero de prefixo da factura');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 234.0, 'description', 2.0, 'Wallis and Futuna');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 235.0, 'description', 2.0, 'Yemen');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 236.0, 'description', 2.0, 'Zâmbia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 237.0, 'description', 2.0, 'Zimbabwe');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 15.0, 'description', 2.0, 'Dias antes da expiração para notificação de ordens');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 21.0, 'description', 2.0, 'Usar os lembretes de factura');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 22.0, 'description', 2.0, 'NÚmero de dias após a geração da factura para o primeiro lembrete');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 23.0, 'description', 2.0, 'NÚmero de dias para o próximo lembrete');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 227.0, 'description', 2.0, 'Uzbekistão');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 147.0, 'description', 2.0, 'Nauru');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 148.0, 'description', 2.0, 'Nepal');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 149.0, 'description', 2.0, 'Holanda');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 150.0, 'description', 2.0, 'Antilhas Holandesas');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 151.0, 'description', 2.0, 'Nova Caledônia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 152.0, 'description', 2.0, 'Nova Zelândia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 153.0, 'description', 2.0, 'Nicarágua');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 154.0, 'description', 2.0, 'Niger');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 155.0, 'description', 2.0, 'Nigéria');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 156.0, 'description', 2.0, 'Niue');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 157.0, 'description', 2.0, 'Ilhas Norfolk');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 158.0, 'description', 2.0, 'Coreia do Norte');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 159.0, 'description', 2.0, 'Ilhas Mariana do Norte');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 160.0, 'description', 2.0, 'Noruega');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 161.0, 'description', 2.0, 'Oman');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 162.0, 'description', 2.0, 'Pakistão');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 163.0, 'description', 2.0, 'Palau');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 164.0, 'description', 2.0, 'Panama');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 165.0, 'description', 2.0, 'Papua Nova Guiné');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 166.0, 'description', 2.0, 'Paraguai');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 167.0, 'description', 2.0, 'Perú');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 168.0, 'description', 2.0, 'Filipinas');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 169.0, 'description', 2.0, 'Ilhas Pitcairn');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 170.0, 'description', 2.0, 'Polônia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 171.0, 'description', 2.0, 'Portugal');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 172.0, 'description', 2.0, 'Porto Rico');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 173.0, 'description', 2.0, 'Qatar');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 174.0, 'description', 2.0, 'Reunião');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 175.0, 'description', 2.0, 'Romênia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 176.0, 'description', 2.0, 'Rússia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 177.0, 'description', 2.0, 'Rwanda');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 178.0, 'description', 2.0, 'Samoa');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 179.0, 'description', 2.0, 'São Marino');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 180.0, 'description', 2.0, 'São Tomé e Princepe');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 181.0, 'description', 2.0, 'Arábia Saudita');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 182.0, 'description', 2.0, 'Senegal');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 183.0, 'description', 2.0, 'Sérvia e Montenegro');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 184.0, 'description', 2.0, 'Seychelles');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 185.0, 'description', 2.0, 'Serra Leoa');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 186.0, 'description', 2.0, 'Singapure');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 187.0, 'description', 2.0, 'Eslováquia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 188.0, 'description', 2.0, 'Eslovenia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 189.0, 'description', 2.0, 'Ilhas Salomão');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 190.0, 'description', 2.0, 'Somália');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 191.0, 'description', 2.0, 'África do Sul');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 192.0, 'description', 2.0, 'Georgia do Sul e Ilhas Sandwich South');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 193.0, 'description', 2.0, 'Espanha');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 194.0, 'description', 2.0, 'Sri Lanka');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 195.0, 'description', 2.0, 'Sta. Helena');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 196.0, 'description', 2.0, 'Sta. Kitts e Nevis');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 197.0, 'description', 2.0, 'Sta. Lucia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 198.0, 'description', 2.0, 'Sta. Pierre e Miquelon');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 199.0, 'description', 2.0, 'Sto. Vicente e Grenadines');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 200.0, 'description', 2.0, 'Sudão');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 201.0, 'description', 2.0, 'Suriname');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 202.0, 'description', 2.0, 'Svalbard e Jan Mayen');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 203.0, 'description', 2.0, 'Suazilândia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 204.0, 'description', 2.0, 'Suécia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 205.0, 'description', 2.0, 'Suíça');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 206.0, 'description', 2.0, 'Síria');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 207.0, 'description', 2.0, 'Taiwan');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 208.0, 'description', 2.0, 'Tajikistão');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 209.0, 'description', 2.0, 'Tanzânia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 210.0, 'description', 2.0, 'Tailândia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 211.0, 'description', 2.0, 'Togo');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 212.0, 'description', 2.0, 'Tokelau');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 213.0, 'description', 2.0, 'Tonga');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 214.0, 'description', 2.0, 'Trinidade e Tobago');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 215.0, 'description', 2.0, 'Tunísia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 216.0, 'description', 2.0, 'Turquia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 217.0, 'description', 2.0, 'Turkmenistão');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 218.0, 'description', 2.0, 'Ilhas Turks e Caicos');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 219.0, 'description', 2.0, 'Tuvalu');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 220.0, 'description', 2.0, 'Uganda');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 221.0, 'description', 2.0, 'Ucrânia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 222.0, 'description', 2.0, 'Emiados Árabes Unidos');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 223.0, 'description', 2.0, 'Reino Unido');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 224.0, 'description', 2.0, 'Estados Unidos');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 225.0, 'description', 2.0, 'Estados Unidos e Ilhas Menores Circundantes');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 226.0, 'description', 2.0, 'Uruguai');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 228.0, 'description', 2.0, 'Vanuatu');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 229.0, 'description', 2.0, 'Cidade do Vaticano');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 230.0, 'description', 2.0, 'Venezuela');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 231.0, 'description', 2.0, 'Vietname');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 232.0, 'description', 2.0, 'Ilhas Virgens Britânicas');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 233.0, 'description', 2.0, 'Ilhas Virgens');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 57.0, 'description', 2.0, 'República Democrática do Congo');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 58.0, 'description', 2.0, 'Dinamarca');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 59.0, 'description', 2.0, 'Djibouti');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 60.0, 'description', 2.0, 'Dominica');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 61.0, 'description', 2.0, 'República Dominicana');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 62.0, 'description', 2.0, 'Timor Leste');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 63.0, 'description', 2.0, 'Ecuador');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 64.0, 'description', 2.0, 'Egipto');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 65.0, 'description', 2.0, 'El Salvador');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 66.0, 'description', 2.0, 'Guiné Equatorial');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 67.0, 'description', 2.0, 'Eritreia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 68.0, 'description', 2.0, 'Estônia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 69.0, 'description', 2.0, 'Etiopia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 70.0, 'description', 2.0, 'Ilhas Malvinas');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 71.0, 'description', 2.0, 'Ilhas Faroé');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 72.0, 'description', 2.0, 'Ilhas Fiji');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 73.0, 'description', 2.0, 'Finlândia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 74.0, 'description', 2.0, 'França');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 75.0, 'description', 2.0, 'Guiana Francesa');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 76.0, 'description', 2.0, 'Polinésia Francesa');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 77.0, 'description', 2.0, 'Terras Antárticas e do Sul Francesas');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 78.0, 'description', 2.0, 'Gabão');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 79.0, 'description', 2.0, 'Gâmbia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 80.0, 'description', 2.0, 'Georgia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 81.0, 'description', 2.0, 'Alemanha');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 82.0, 'description', 2.0, 'Gana');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 83.0, 'description', 2.0, 'Gibraltar');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 84.0, 'description', 2.0, 'Grécia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 85.0, 'description', 2.0, 'Gronelândia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 86.0, 'description', 2.0, 'Granada');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 87.0, 'description', 2.0, 'Guadalupe');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 88.0, 'description', 2.0, 'Guantanamo');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 89.0, 'description', 2.0, 'Guatemala');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 90.0, 'description', 2.0, 'Guiné');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 91.0, 'description', 2.0, 'Guiné-Bissau');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 92.0, 'description', 2.0, 'Guiana');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 93.0, 'description', 2.0, 'Haiti');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 94.0, 'description', 2.0, 'Ilhas Heard e McDonald');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 95.0, 'description', 2.0, 'Honduras');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 96.0, 'description', 2.0, 'Hong Kong SAR');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 97.0, 'description', 2.0, 'Hungria');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 98.0, 'description', 2.0, 'Islândia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 99.0, 'description', 2.0, 'Índia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 100.0, 'description', 2.0, 'Indonésia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 101.0, 'description', 2.0, 'Irâo');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 102.0, 'description', 2.0, 'Iraque');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 103.0, 'description', 2.0, 'Irlanda');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 104.0, 'description', 2.0, 'Israel');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 105.0, 'description', 2.0, 'Itália');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 106.0, 'description', 2.0, 'Jamaica');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 107.0, 'description', 2.0, 'Japão');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 108.0, 'description', 2.0, 'Jordânia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 109.0, 'description', 2.0, 'Kazaquistão');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 110.0, 'description', 2.0, 'Kênia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 111.0, 'description', 2.0, 'Kiribati');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 112.0, 'description', 2.0, 'Coreia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 113.0, 'description', 2.0, 'Kuwait');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 114.0, 'description', 2.0, 'Kirgistão');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 115.0, 'description', 2.0, 'Laos');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 116.0, 'description', 2.0, 'Latvia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 117.0, 'description', 2.0, 'Líbano');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 118.0, 'description', 2.0, 'Lesoto');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 119.0, 'description', 2.0, 'Libéria');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 120.0, 'description', 2.0, 'Líbia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 121.0, 'description', 2.0, 'Liechtenstein');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 122.0, 'description', 2.0, 'Lituânia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 123.0, 'description', 2.0, 'Luxemburgo');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 124.0, 'description', 2.0, 'Macau SAR');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 125.0, 'description', 2.0, 'Macedónia, Antiga República Jugoslava da');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 126.0, 'description', 2.0, 'Madagáscar');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 127.0, 'description', 2.0, 'Malaui');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 128.0, 'description', 2.0, 'Malásia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 129.0, 'description', 2.0, 'Maldivas');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 130.0, 'description', 2.0, 'Mali');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 131.0, 'description', 2.0, 'Malta');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 132.0, 'description', 2.0, 'Ilhas Marshall');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 133.0, 'description', 2.0, 'Martinica');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 134.0, 'description', 2.0, 'Mauritânia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 135.0, 'description', 2.0, 'Maurícias');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 136.0, 'description', 2.0, 'Maiote');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 137.0, 'description', 2.0, 'México');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 138.0, 'description', 2.0, 'Micronésia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 139.0, 'description', 2.0, 'Moldova');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 140.0, 'description', 2.0, 'Mônaco');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 141.0, 'description', 2.0, 'Mongólia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 142.0, 'description', 2.0, 'Monserrate');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 143.0, 'description', 2.0, 'Marrocos');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 144.0, 'description', 2.0, 'Moçambique');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 145.0, 'description', 2.0, 'Mianmar');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 146.0, 'description', 2.0, 'Namíbia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 1.0, 'description', 2.0, 'Afganistão');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 2.0, 'description', 2.0, 'Albânia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 3.0, 'description', 2.0, 'Algéria');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 4.0, 'description', 2.0, 'Samoa Americana');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 5.0, 'description', 2.0, 'Andorra');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 6.0, 'description', 2.0, 'Angola');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 7.0, 'description', 2.0, 'Anguilha');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 8.0, 'description', 2.0, 'Antártida');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 9.0, 'description', 2.0, 'Antigua e Barbuda');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 10.0, 'description', 2.0, 'Argentina');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 11.0, 'description', 2.0, 'Armênia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 12.0, 'description', 2.0, 'Aruba');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 13.0, 'description', 2.0, 'Austrália');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 14.0, 'description', 2.0, 'Áustria');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 15.0, 'description', 2.0, 'Azerbaijão');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 16.0, 'description', 2.0, 'Bahamas');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 17.0, 'description', 2.0, 'Bahrain');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 18.0, 'description', 2.0, 'Bangladesh');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 19.0, 'description', 2.0, 'Barbados');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 20.0, 'description', 2.0, 'Belarus');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 21.0, 'description', 2.0, 'Bélgica');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 22.0, 'description', 2.0, 'Belize');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 23.0, 'description', 2.0, 'Benin');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 24.0, 'description', 2.0, 'Bermuda');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 25.0, 'description', 2.0, 'Butão');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 26.0, 'description', 2.0, 'Bolívia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 27.0, 'description', 2.0, 'Bosnia e Herzegovina');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 28.0, 'description', 2.0, 'Botswana');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 29.0, 'description', 2.0, 'Ilha Bouvet');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 30.0, 'description', 2.0, 'Brasil');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 31.0, 'description', 2.0, 'Território Britânico do Oceano Índico');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 32.0, 'description', 2.0, 'Brunei');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 33.0, 'description', 2.0, 'Bulgária');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 34.0, 'description', 2.0, 'Burquina Faso');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 35.0, 'description', 2.0, 'Burundi');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 36.0, 'description', 2.0, 'Cambodia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 37.0, 'description', 2.0, 'Camarões');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 38.0, 'description', 2.0, 'Canada');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 39.0, 'description', 2.0, 'Cabo Verde');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 40.0, 'description', 2.0, 'Ilhas Caimáo');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 41.0, 'description', 2.0, 'República Centro Africana');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 42.0, 'description', 2.0, 'Chade');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 43.0, 'description', 2.0, 'Chile');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 44.0, 'description', 2.0, 'China');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 45.0, 'description', 2.0, 'Ilha Natal');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 46.0, 'description', 2.0, 'Ilha Cocos e Keeling');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 47.0, 'description', 2.0, 'Colômbia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 48.0, 'description', 2.0, 'Comoros');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 49.0, 'description', 2.0, 'Congo');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 50.0, 'description', 2.0, 'Ilhas Cook');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 51.0, 'description', 2.0, 'Costa Rica');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 52.0, 'description', 2.0, 'Costa do Marfim');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 53.0, 'description', 2.0, 'Croácia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 54.0, 'description', 2.0, 'Cuba');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 55.0, 'description', 2.0, 'Chipre');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64.0, 56.0, 'description', 2.0, 'República Checa');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4.0, 1.0, 'description', 2.0, 'DÓlares Norte Americanos');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4.0, 2.0, 'description', 2.0, 'DÓlares Canadianos');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4.0, 3.0, 'description', 2.0, 'Euro');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4.0, 4.0, 'description', 2.0, 'Ien');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4.0, 5.0, 'description', 2.0, 'Libras Estrelinas');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4.0, 6.0, 'description', 2.0, 'Won');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4.0, 7.0, 'description', 2.0, 'Franco Suíço');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4.0, 8.0, 'description', 2.0, 'Coroa Sueca');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (6.0, 1.0, 'description', 2.0, 'Mês');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (6.0, 2.0, 'description', 2.0, 'Semana');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (6.0, 3.0, 'description', 2.0, 'Dia');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (6.0, 4.0, 'description', 2.0, 'Ano');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (7.0, 1.0, 'description', 2.0, 'Email');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (7.0, 2.0, 'description', 2.0, 'Papel');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9.0, 1.0, 'description', 2.0, 'Activo');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9.0, 2.0, 'description', 2.0, 'Em aberto');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9.0, 3.0, 'description', 2.0, 'Em aberto 2');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9.0, 4.0, 'description', 2.0, 'Em aberto 3');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9.0, 5.0, 'description', 2.0, 'Suspensa');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9.0, 6.0, 'description', 2.0, 'Suspensa 2');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9.0, 7.0, 'description', 2.0, 'Suspensa 3');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9.0, 8.0, 'description', 2.0, 'Eliminado');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60.0, 1.0, 'description', 2.0, 'Um utilizador interno com todas as permissões');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60.0, 1.0, 'title', 2.0, 'Interno');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60.0, 2.0, 'description', 2.0, 'O super utilizador de uma entidade');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60.0, 2.0, 'title', 2.0, 'Super utilizador');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60.0, 3.0, 'description', 2.0, 'Um operador de facturação');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60.0, 3.0, 'title', 2.0, 'Operador');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60.0, 4.0, 'description', 2.0, 'Um parceiro que vai angariar clientes');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60.0, 4.0, 'title', 2.0, 'Parceiro');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60.0, 5.0, 'description', 2.0, 'Um cliente que vai fazer pesquisas na sua conta');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60.0, 5.0, 'title', 2.0, 'Cliente');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (17.0, 1.0, 'description', 2.0, 'uma vez');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (18.0, 1.0, 'description', 2.0, 'Items');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (18.0, 2.0, 'description', 2.0, 'Imposto');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (19.0, 1.0, 'description', 2.0, 'Pré pago');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (19.0, 2.0, 'description', 2.0, 'Pós pago');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (20.0, 1.0, 'description', 2.0, 'Activo');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (20.0, 2.0, 'description', 2.0, 'Terminado');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (20.0, 3.0, 'description', 2.0, 'Suspenso');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35.0, 1.0, 'description', 2.0, 'Cheque');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35.0, 2.0, 'description', 2.0, 'Visa');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35.0, 3.0, 'description', 2.0, 'MasterCard');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (41.0, 1.0, 'description', 2.0, 'Com sucesso');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (41.0, 2.0, 'description', 2.0, 'Sem sucesso');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (41.0, 3.0, 'description', 2.0, 'Processador indisponível');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (41.0, 4.0, 'description', 2.0, 'Inserido');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46.0, 1.0, 'description', 2.0, 'Processo de facturação');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46.0, 2.0, 'description', 2.0, 'Manutenção de Utilizador');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46.0, 3.0, 'description', 2.0, 'Item de Manutenção');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46.0, 4.0, 'description', 2.0, 'Item tipo de Manutenção');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46.0, 5.0, 'description', 2.0, 'Item Manutenção de preço de utilizador');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46.0, 6.0, 'description', 2.0, 'Manutenção de promoção');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46.0, 7.0, 'description', 2.0, 'Manutenção por ordem');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46.0, 8.0, 'description', 2.0, 'Manutenção de cartão de crédito');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 1.0, 'description', 2.0, 'Uma ordem prê-paga tem tempo não facturado anterior data de facturação');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 2.0, 'description', 2.0, 'A ordem não tem nenhum período activo data de processamento.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 3.0, 'description', 2.0, 'Pelo menos um período completo tem de ser facturável.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 4.0, 'description', 2.0, 'Já há facturação para o período.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 5.0, 'description', 2.0, 'Esta ordem teve de ser marcada para exclusão do último processo.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 6.0, 'description', 2.0, 'Pre-paid order is being process after its expiration.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 7.0, 'description', 2.0, 'A linha marcada foi eliminada.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 8.0, 'description', 2.0, 'A senha de utilizador foi alterada.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 9.0, 'description', 2.0, 'Uma linha foi actualizada.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 10.0, 'description', 2.0, 'A correr um processo de facturação, foi encontrada uma revisão rejeitada.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 11.0, 'description', 2.0, 'A correr um processo de facturação, uma necessária mas não encontrada.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 12.0, 'description', 2.0, 'Um status de utilizador foi alterado.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 13.0, 'description', 2.0, 'Um status de uma ordem foi alterado.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 14.0, 'description', 2.0, 'Um utilizador foi inserido no processo de antiguidade, mas não há mais passos configurados.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 15.0, 'description', 2.0, 'Um parceiro tem um pagamento a receber, mas não tem instrumento de pagamento.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 1.0, 'description', 2.0, 'Processar pagamento com processo de facturação');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 2.0, 'description', 2.0, 'URL ou ficheiro CSS');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 3.0, 'description', 2.0, 'URL ou gráfico de logotipo');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 4.0, 'description', 2.0, 'Período de graça');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 5.0, 'description', 2.0, 'Percentagem do parceiro');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 6.0, 'description', 2.0, 'Valor de referência do parceiro');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 7.0, 'description', 2.0, 'Parceiro pagamento único');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 8.0, 'description', 2.0, 'Parceiro unidade do período de pagamento');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 9.0, 'description', 2.0, 'Parceiro valor do período de pagamento');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 10.0, 'description', 2.0, 'Parceiro pagamento automático');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 11.0, 'description', 2.0, 'Utilizador responsável pelos parceiros');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 12.0, 'description', 2.0, 'Parceiro moeda');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 13.0, 'description', 2.0, 'Entrega pelo mesmo das facturas em papel');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, 1.0, 'description', 2.0, 'Factura (email)');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, 2.0, 'description', 2.0, 'Utilizador Reactivado');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, 3.0, 'description', 2.0, 'Utilizador Em Atraso');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, 4.0, 'description', 2.0, 'Utilizador Em Atraso 2');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, 5.0, 'description', 2.0, 'Utilizador Em Atraso 3');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, 6.0, 'description', 2.0, 'Utilizador Suspenso');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, 7.0, 'description', 2.0, 'Utilizador Suspenso 2');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, 8.0, 'description', 2.0, 'Utilizador Suspenso 3');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, 9.0, 'description', 2.0, 'Utilizador Eliminado');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, 10.0, 'description', 2.0, 'Pagamento Remascente');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, 11.0, 'description', 2.0, 'Parceiro Pagamento');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, 12.0, 'description', 2.0, 'Factura (papel)');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 24.0, 'description', 2.0, 'Data Factura Fim do Mês');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4.0, 9.0, 'description', 2.0, 'DÓlar da Singapura');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4.0, 10.0, 'description', 2.0, 'Ringgit Malasiano');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4.0, 11.0, 'description', 2.0, 'DÓlar Australiano');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 19.0, 'description', 2.0, 'próximo NÚmero de factura');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (7.0, 3.0, 'description', 2.0, 'Email + Papel');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35.0, 8.0, 'description', 2.0, 'PayPal');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, 19.0, 'description', 2.0, 'Actualizar cartão de crédito');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (20.0, 4.0, 'description', 2.0, 'Suspender (auto)');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (18.0, 3.0, 'description', 2.0, 'Penalidade');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, 20.0, 'description', 2.0, 'Senha esquecida');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (89.0, 1.0, 'description', 1.0, 'None');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (89.0, 2.0, 'description', 1.0, 'Pre-paid balance');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (89.0, 3.0, 'description', 1.0, 'Credit limit');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (91.0, 1.0, 'description', 1.0, 'Done and billable');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (91.0, 2.0, 'description', 1.0, 'Done and not billable');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (91.0, 3.0, 'description', 1.0, 'Error detected');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (91.0, 4.0, 'description', 1.0, 'Error declared');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (92.0, 1.0, 'description', 1.0, 'Running');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (92.0, 2.0, 'description', 1.0, 'Finished: successful');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (92.0, 3.0, 'description', 1.0, 'Finished: failed');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23.0, 1.0, 'description', 1.0, 'Item management and order line total calculation');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23.0, 2.0, 'description', 1.0, 'Billing process: order filters');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23.0, 3.0, 'description', 1.0, 'Billing process: invoice filters');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23.0, 4.0, 'description', 1.0, 'Invoice presentation');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23.0, 5.0, 'description', 1.0, 'Billing process: order periods calculation');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23.0, 6.0, 'description', 1.0, 'Payment gateway integration');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23.0, 7.0, 'description', 1.0, 'Notifications');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23.0, 8.0, 'description', 1.0, 'Payment instrument selection');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23.0, 9.0, 'description', 1.0, 'Penalties for overdue invoices');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23.0, 10.0, 'description', 1.0, 'Alarms when a payment gateway is down');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23.0, 11.0, 'description', 1.0, 'Subscription status manager');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23.0, 12.0, 'description', 1.0, 'Parameters for asynchronous payment processing');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23.0, 13.0, 'description', 1.0, 'Add one product to order');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23.0, 14.0, 'description', 1.0, 'Product pricing');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23.0, 17.0, 'description', 1.0, 'Generic internal events listener');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23.0, 19.0, 'description', 1.0, 'Purchase validation against pre-paid balance / credit limit');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23.0, 20.0, 'description', 1.0, 'Billing process: customer selection');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23.0, 22.0, 'description', 1.0, 'Scheduled Plug-ins');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23.0, 23.0, 'description', 1.0, 'Rules Generators');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23.0, 24.0, 'description', 1.0, 'Ageing for customers with overdue invoices');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 1.0, 'title', 1.0, 'Default order totals');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 1.0, 'description', 1.0, 'Calculates the order total and the total for each line, considering the item prices, the quantity and if the prices are percentage or not.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 2.0, 'title', 1.0, 'VAT');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 2.0, 'description', 1.0, 'Adds an additional line to the order with a percentage charge to represent the value added tax.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 3.0, 'title', 1.0, 'Invoice due date');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 3.0, 'description', 1.0, 'A very simple implementation that sets the due date of the invoice. The due date is calculated by just adding the period of time to the invoice date.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 4.0, 'title', 1.0, 'Default invoice composition.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 4.0, 'description', 1.0, 'This task will copy all the lines on the orders and invoices to the new invoice, considering the periods involved for each order, but not the fractions of periods. It will not copy the lines that are taxes. The quantity and total of each line will be multiplied by the amount of periods.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 5.0, 'title', 1.0, 'Standard Order Filter');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 5.0, 'description', 1.0, 'Decides if an order should be included in an invoice for a given billing process.  This is done by taking the billing process time span, the order period, the active since/until, etc.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 6.0, 'title', 1.0, 'Standard Invoice Filter');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 6.0, 'description', 1.0, 'Always returns true, meaning that the overdue invoice will be carried over to a new invoice.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 7.0, 'title', 1.0, 'Default Order Periods');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 7.0, 'description', 1.0, 'Calculates the start and end period to be included in an invoice. This is done by taking the billing process time span, the order period, the active since/until, etc.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 8.0, 'title', 1.0, 'Authorize.net payment processor');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 8.0, 'description', 1.0, 'Integration with the authorize.net payment gateway.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 9.0, 'title', 1.0, 'Standard Email Notification');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 9.0, 'description', 1.0, 'Notifies a user by sending an email. It supports text and HTML emails');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 10.0, 'title', 1.0, 'Default payment information');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 10.0, 'description', 1.0, 'Finds the information of a payment method available to a customer, given priority to credit card. In other words, it will return the credit car of a customer or the ACH information in that order.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 11.0, 'title', 1.0, 'Testing plug-in for partner payouts');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 11.0, 'description', 1.0, 'Plug-in useful only for testing');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 12.0, 'title', 1.0, 'PDF invoice notification');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 12.0, 'description', 1.0, 'Will generate a PDF version of an invoice.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 14.0, 'title', 1.0, 'No invoice carry over');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 14.0, 'description', 1.0, 'Returns always false, which makes jBilling to never carry over an invoice into another newer invoice.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 15.0, 'title', 1.0, 'Default interest task');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 15.0, 'description', 1.0, 'Will create a new order with a penalty item. The item is taken as a parameter to the task.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 16.0, 'title', 1.0, 'Anticipated order filter');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 16.0, 'description', 1.0, 'Extends BasicOrderFilterTask, modifying the dates to make the order applicable a number of months before it would be by using the default filter.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 17.0, 'title', 1.0, 'Anticipate order periods.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 17.0, 'description', 1.0, 'Extends BasicOrderPeriodTask, modifying the dates to make the order applicable a number of months before itd be by using the default task.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 19.0, 'title', 1.0, 'Email & process authorize.net');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 19.0, 'description', 1.0, 'Extends the standard authorize.net payment processor to also send an email to the company after processing the payment.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 20.0, 'title', 1.0, 'Payment gateway down alarm');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 20.0, 'description', 1.0, 'Sends an email to the billing administrator as an alarm when a payment gateway is down.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 21.0, 'title', 1.0, 'Test payment processor');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 21.0, 'description', 1.0, 'A test payment processor implementation to be able to test jBillings functions without using a real payment gateway.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 22.0, 'title', 1.0, 'Router payment processor based on Custom Fields');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 22.0, 'description', 1.0, 'Allows a customer to be assigned a specific payment gateway. It checks a custom contact field to identify the gateway and then delegates the actual payment processing to another plugin.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 23.0, 'title', 1.0, 'Default subscription status manager');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 23.0, 'description', 1.0, 'It determines how a payment event affects the subscription status of a user, considering its present status and a state machine.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 24.0, 'title', 1.0, 'ACH Commerce payment processor');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 24.0, 'description', 1.0, 'Integration with the ACH commerce payment gateway.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 25.0, 'title', 1.0, 'Standard asynchronous parameters');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 25.0, 'description', 1.0, 'A dummy task that does not add any parameters for asynchronous payment processing. This is the default.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 26.0, 'title', 1.0, 'Router asynchronous parameters');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 26.0, 'description', 1.0, 'This plug-in adds parameters for asynchronous payment processing to have one processing message bean per payment processor. It is used in combination with the router payment processor plug-ins.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 28.0, 'title', 1.0, 'Standard Item Manager');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 28.0, 'description', 1.0, 'It adds items to an order. If the item is already in the order, it only updates the quantity.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 29.0, 'title', 1.0, 'Rules Item Manager');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 29.0, 'description', 1.0, 'This is a rules-based plug-in. It will do what the basic item manager does (actually calling it); but then it will execute external rules as well. These external rules have full control on changing the order that is getting new items.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 30.0, 'title', 1.0, 'Rules Line Total');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 30.0, 'description', 1.0, 'This is a rules-based plug-in. It calculates the total for an order line (typically this is the price multiplied by the quantity); allowing for the execution of external rules.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 31.0, 'title', 1.0, 'Rules Pricing');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 35.0, 'title', 1.0, 'Payment information without validation');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 35.0, 'description', 1.0, 'This is exactly the same as the standard payment information task, the only difference is that it does not validate if the credit card is expired. Use this plug-in only if you want to submit payment with expired credit cards.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 36.0, 'title', 1.0, 'Notification task for testing');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 36.0, 'description', 1.0, 'This plug-in is only used for testing purposes. Instead of sending an email (or other real notification); it simply stores the text to be sent in a file named emails_sent.txt.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 37.0, 'title', 1.0, 'Order periods calculator with pro rating.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 37.0, 'description', 1.0, 'This plugin takes into consideration the field cycle starts of orders to calculate fractional order periods.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 38.0, 'title', 1.0, 'Invoice composition task with pro-rating (day as fraction)');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 38.0, 'description', 1.0, 'When creating an invoice from an order, this plug-in will pro-rate any fraction of a period taking a day as the smallest billable unit.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 39.0, 'title', 1.0, 'Payment process for the Intraanuity payment gateway');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 39.0, 'description', 1.0, 'Integration with the Intraanuity payment gateway.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 40.0, 'title', 1.0, 'Automatic cancellation credit.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 40.0, 'description', 1.0, 'This plug-in will create a new order with a negative price to reflect a credit when an order is canceled within a period that has been already invoiced.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 41.0, 'title', 1.0, 'Fees for early cancellation of a plan.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 41.0, 'description', 1.0, 'This plug-in will use external rules to determine if an order that is being canceled should create a new order with a penalty fee. This is typically used for early cancels of a contract.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 42.0, 'title', 1.0, 'Blacklist filter payment processor.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 42.0, 'description', 1.0, 'Used for blocking payments from reaching real payment processors. Typically configured as first payment processor in the processing chain.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 43.0, 'title', 1.0, 'Blacklist user when their status becomes suspended or higher.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 43.0, 'description', 1.0, 'Causes users and their associated details (e.g., credit card number, phone number, etc.) to be blacklisted when their status becomes suspended or higher. ');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 49.0, 'title', 1.0, 'Currency Router payment processor');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 49.0, 'description', 1.0, 'Delegates the actual payment processing to another plug-in based on the currency of the payment.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 51.0, 'title', 1.0, 'Filters out negative invoices for carry over.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 51.0, 'description', 1.0, 'This filter will only invoices with a positive balance to be carried over to the next invoice.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 52.0, 'title', 1.0, 'File invoice exporter.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 52.0, 'description', 1.0, 'It will generate a file with one line per invoice generated.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 53.0, 'title', 1.0, 'Rules caller on an event.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 53.0, 'description', 1.0, 'It will call a package of rules when an internal event happens.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 54.0, 'title', 1.0, 'Dynamic balance manager');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 54.0, 'description', 1.0, 'It will update the dynamic balance of a customer (pre-paid or credit limit) when events affecting the balance happen.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 55.0, 'title', 1.0, 'Balance validator based on the customer balance.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 55.0, 'description', 1.0, 'Used for real-time mediation, this plug-in will validate a call based on the current dynamic balance of a customer.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 56.0, 'title', 1.0, 'Balance validator based on rules.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 56.0, 'description', 1.0, 'Used for real-time mediation, this plug-in will validate a call based on a package or rules');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 57.0, 'title', 1.0, 'Payment processor for Payments Gateway.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 57.0, 'description', 1.0, 'Integration with the Payments Gateway payment processor.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 58.0, 'title', 1.0, 'Credit cards are stored externally.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 58.0, 'description', 1.0, 'Saves the credit card information in the payment gateway, rather than the jBilling DB.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 59.0, 'title', 1.0, 'Rules Item Manager 2');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 59.0, 'description', 1.0, 'This is a rules-based plug-in compatible with the mediation module of jBilling 2.2.x. It will do what the basic item manager does (actually calling it); but then it will execute external rules as well. These external rules have full control on changing the order that is getting new items.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 60.0, 'title', 1.0, 'Rules Line Total - 2');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 60.0, 'description', 1.0, 'This is a rules-based plug-in, compatible with the mediation process of jBilling 2.2.x and later. It calculates the total for an order line (typically this is the price multiplied by the quantity); allowing for the execution of external rules.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 61.0, 'title', 1.0, 'Rules Pricing 2');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 61.0, 'description', 1.0, 'This is a rules-based plug-in compatible with the mediation module of jBilling 2.2.x. It gives a price to an item by executing external rules. You can then add logic externally for pricing. It is also integrated with the mediation process by having access to the mediation pricing data.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 63.0, 'title', 1.0, 'Test payment processor for external storage.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 63.0, 'description', 1.0, 'A fake plug-in to test payments that would be stored externally.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 64.0, 'title', 1.0, 'WorldPay integration');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 64.0, 'description', 1.0, 'Payment processor plug-in to integrate with RBS WorldPay');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 65.0, 'title', 1.0, 'WorldPay integration with external storage');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 65.0, 'description', 1.0, 'Payment processor plug-in to integrate with RBS WorldPay. It stores the credit card information (number, etc) in the gateway.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 66.0, 'title', 1.0, 'Auto recharge');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 66.0, 'description', 1.0, 'Monitors the balance of a customer and upon reaching a limit, it requests a real-time payment');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 67.0, 'title', 1.0, 'Beanstream gateway integration');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 67.0, 'description', 1.0, 'Payment processor for integration with the Beanstream payment gateway');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 68.0, 'title', 1.0, 'Sage payments gateway integration');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 68.0, 'description', 1.0, 'Payment processor for integration with the Sage payment gateway');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 69.0, 'title', 1.0, 'Standard billing process users filter');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 69.0, 'description', 1.0, 'Called when the billing process runs to select which users to evaluate. This basic implementation simply returns every user not in suspended (or worse) status');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 70.0, 'title', 1.0, 'Selective billing process users filter');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 70.0, 'description', 1.0, 'Called when the billing process runs to select which users to evaluate. This only returns users with orders that have a next invoice date earlier than the billing process.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 71.0, 'title', 1.0, 'Mediation file error handler');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 71.0, 'description', 1.0, 'Event records with errors are saved to a file');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 73.0, 'title', 1.0, 'Mediation data base error handler');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 73.0, 'description', 1.0, 'Event records with errors are saved to a database table');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 75.0, 'title', 1.0, 'Paypal integration with external storage');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 75.0, 'description', 1.0, 'Submits payments to paypal as a payment gateway and stores credit card information in PayPal as well');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 76.0, 'title', 1.0, 'Authorize.net integration with external storage');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 76.0, 'description', 1.0, 'Submits payments to authorize.net as a payment gateway and stores credit card information in authorize.net as well');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 77.0, 'title', 1.0, 'Payment method router payment processor');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 77.0, 'description', 1.0, 'Delegates the actual payment processing to another plug-in based on the payment method of the payment.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 78.0, 'title', 1.0, 'Dynamic rules generator');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 78.0, 'description', 1.0, 'Generates rules dynamically based on a Velocity template.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 80.0, 'title', 1.0, 'Billing Process Task');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 80.0, 'description', 1.0, 'A scheduled task to execute the Billing Process.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 87.0, 'title', 1.0, 'Basic ageing');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 87.0, 'description', 1.0, 'Ages a user based on the number of days that the account is overdue.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 88.0, 'title', 1.0, 'Ageing process task');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 88.0, 'description', 1.0, 'A scheduled task to execute the Ageing Process.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 89.0, 'title', 1.0, 'Business day ageing');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 89.0, 'description', 1.0, 'Ages a user based on the number of business days (excluding holidays) that the account is overdue.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 90.0, 'title', 1.0, 'Simple Tax Composition Task');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 90.0, 'description', 1.0, 'A pluggable task of the type AbstractChargeTask to apply tax item to an Invoice with a facility of exempting an exempt item or an exemp customer.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 91.0, 'title', 1.0, 'Country Tax Invoice Composition Task');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 91.0, 'description', 1.0, 'A pluggable task of the type AbstractChargeTask to apply tax item to the Invoice if the Partner''s country code is matching.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 92.0, 'title', 1.0, 'Payment Terms Penalty Task');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 92.0, 'description', 1.0, 'A pluggable task of the type AbstractChargeTask to apply a Penalty to an Invoice having a due date beyond a configurable days period.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 93.0, 'title', 1.0, 'Fees for early cancellation of a subscription');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, 93.0, 'description', 1.0, 'This plug-in will create a new order with a fee if a recurring order is cancelled too early');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 17.0, 'description', 1.0, 'The order line has been updated');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 18.0, 'description', 1.0, 'The order next billing date has been changed');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 19.0, 'description', 1.0, 'Last API call to get the the user subscription status transitions');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 20.0, 'description', 1.0, 'User subscription status has changed');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 21.0, 'description', 1.0, 'User account is now locked');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 22.0, 'description', 1.0, 'The order main subscription flag was changed');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 23.0, 'description', 1.0, 'All the one-time orders the mediation found were in status finished');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 24.0, 'description', 1.0, 'A valid payment method was not found. The payment request was cancelled');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 25.0, 'description', 1.0, 'A new row has been created');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 26.0, 'description', 1.0, 'An invoiced order was cancelled, a credit order was created');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 27.0, 'description', 1.0, 'A user id was added to the blacklist');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 28.0, 'description', 1.0, 'A user id was removed from the blacklist');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 32.0, 'description', 1.0, 'User subscription status has NOT changed');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 33.0, 'description', 1.0, 'The dynamic balance of a user has changed');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 34.0, 'description', 1.0, 'The invoice if child flag has changed');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (101.0, 1.0, 'description', 1.0, 'Invoice Reports');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (101.0, 2.0, 'description', 1.0, 'Order Reports');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (101.0, 3.0, 'description', 1.0, 'Payment Reports');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (101.0, 4.0, 'description', 1.0, 'Customer Reports');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100.0, 1.0, 'description', 1.0, 'Total amount invoiced grouped by period.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100.0, 2.0, 'description', 1.0, 'Detailed balance ageing report. Shows the age of outstanding customer balances.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100.0, 3.0, 'description', 1.0, 'Number of users subscribed to a specific product.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100.0, 4.0, 'description', 1.0, 'Total payment amount received grouped by period.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100.0, 5.0, 'description', 1.0, 'Number of customers created within a period.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100.0, 6.0, 'description', 1.0, 'Total revenue (sum of received payments) per customer.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100.0, 7.0, 'description', 1.0, 'Simple accounts receivable report showing current account balances.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100.0, 8.0, 'description', 1.0, 'General ledger details of all invoiced charges for the given day.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100.0, 9.0, 'description', 1.0, 'General ledger summary of all invoiced charges for the given day, grouped by item type.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100.0, 11.0, 'description', 1.0, 'Total invoiced per customer grouped by product category.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100.0, 12.0, 'description', 1.0, 'Total invoiced per customer over years grouped by year.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (104.0, 1.0, 'description', 1.0, 'Invoices');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (104.0, 2.0, 'description', 1.0, 'Orders');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (104.0, 3.0, 'description', 1.0, 'Payments');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (104.0, 4.0, 'description', 1.0, 'Users');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 25.0, 'description', 1.0, 'Use overdue penalties (interest).');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 27.0, 'description', 1.0, 'Use order anticipation.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 28.0, 'description', 1.0, 'Paypal account.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 29.0, 'description', 1.0, 'Paypal button URL.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 30.0, 'description', 1.0, 'URL for HTTP ageing callback.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 31.0, 'description', 1.0, 'Use continuous invoice dates.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 32.0, 'description', 1.0, 'Attach PDF invoice to email notification.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 33.0, 'description', 1.0, 'Force one order per invoice.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 35.0, 'description', 1.0, 'Add order Id to invoice lines.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 36.0, 'description', 1.0, 'Allow customers to edit own contact information.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 37.0, 'description', 1.0, 'Hide (mask) credit card numbers.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 38.0, 'description', 1.0, 'Link ageing to customer subscriber status.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 39.0, 'description', 1.0, 'Lock-out user after failed login attempts.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 40.0, 'description', 1.0, 'Expire user passwords after days.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 41.0, 'description', 1.0, 'Use main-subscription orders.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 42.0, 'description', 1.0, 'Use pro-rating.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 43.0, 'description', 1.0, 'Use payment blacklist.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 44.0, 'description', 1.0, 'Allow negative payments.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 45.0, 'description', 1.0, 'Delay negative invoice payments.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 46.0, 'description', 1.0, 'Allow invoice without orders.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 49.0, 'description', 1.0, 'Automatic customer recharge threshold.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 50.0, 'description', 1.0, 'Invoice decimal rounding.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 4.0, 'instruction', 1.0, 'Grace period in days before ageing a customer with an overdue invoice.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 5.0, 'instruction', 1.0, 'Partner default percentage commission rate. See the Partner section of the documentation.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 6.0, 'instruction', 1.0, 'Partner default flat fee to be paid as commission. See the Partner section of the documentation.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 7.0, 'instruction', 1.0, 'Set to ''1'' to enable one-time payment for partners. If set, partners will only get paid once per customer. See the Partner section of the documentation.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 8.0, 'instruction', 1.0, 'Partner default payout period unit. See the Partner section of the documentation.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 9.0, 'instruction', 1.0, 'Partner default payout period value. See the Partner section of the documentation.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 10.0, 'instruction', 1.0, 'Set to ''1'' to enable batch payment payouts using the billing process and the configured payment processor. See the Partner section of the documentation.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 11.0, 'instruction', 1.0, 'Partner default assigned clerk id. See the Partner section of the documentation.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 12.0, 'instruction', 1.0, 'Currency ID to use when paying partners. See the Partner section of the documentation.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 13.0, 'instruction', 1.0, 'Set to ''1'' to e-mail invoices as the billing company. ''0'' to deliver invoices as jBilling.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 14.0, 'instruction', 1.0, 'Set to ''1'' to show notes in invoices, ''0'' to disable.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 15.0, 'instruction', 1.0, 'Days before the orders ''active until'' date to send the 1st notification. Leave blank to disable.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 16.0, 'instruction', 1.0, 'Days before the orders ''active until'' date to send the 2nd notification. Leave blank to disable.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 17.0, 'instruction', 1.0, 'Days before the orders ''active until'' date to send the 3rd notification. Leave blank to disable.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 18.0, 'instruction', 1.0, 'Prefix value for generated invoice public numbers.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 19.0, 'instruction', 1.0, 'The current value for generated invoice public numbers. New invoices will be assigned a public number by incrementing this value.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 20.0, 'instruction', 1.0, 'Set to ''1'' to allow invoices to be deleted, ''0'' to disable.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 21.0, 'instruction', 1.0, 'Set to ''1'' to allow invoice reminder notifications, ''0'' to disable.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 24.0, 'instruction', 1.0, 'Set to ''1'' to enable, ''0'' to disable.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 25.0, 'instruction', 1.0, 'Set to ''1'' to enable the billing process to calculate interest on overdue payments, ''0'' to disable. Calculation of interest is handled by the selected penalty plug-in.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 27.0, 'instruction', 1.0, 'Set to ''1'' to use the ''OrderFilterAnticipateTask'' to invoice a number of months in advance, ''0'' to disable. Plug-in must be configured separately.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 28.0, 'instruction', 1.0, 'PayPal account name.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 29.0, 'instruction', 1.0, 'A URL where the graphic of the PayPal button resides. The button is displayed to customers when they are making a payment. The default is usually the best option, except when another language is needed.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 30.0, 'instruction', 1.0, 'URL for the HTTP Callback to invoke when the ageing process changes a status of a user.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 31.0, 'instruction', 1.0, 'Default blank. This preference has to be a date (In the format yyyy-mm-dd. Example: 2000-01-31), the system will make sure that all your invoices have their dates in an incremental way. Any invoice with a greater ''ID'' will also have a greater (or equal) date. In other words, a new invoice can not have an earlier date than an existing (older) invoice. To use this preference, set it as a string with the date where to start. This preference will not be used if blank');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 32.0, 'instruction', 1.0, 'Set to ''1'' to attach a PDF version of the invoice to all invoice notification e-mails. ''0'' to disable.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 33.0, 'instruction', 1.0, 'Set to ''1'' to show the ''include in separate invoice'' flag on an order. ''0'' to disable.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 35.0, 'instruction', 1.0, 'Set to ''1'' to include the ID of the order in the description text of the resulting invoice line. ''0'' to disable. This can help to easily track which exact orders is responsible for a line in an invoice, considering that many orders can be included in a single invoice.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 36.0, 'instruction', 1.0, 'Set to ''1'' to allow customers to edit their own contact information. ''0'' to disable.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 37.0, 'instruction', 1.0, 'Set to ''1'' to mask all credit card numbers. ''0'' to disable. When set, numbers are masked to all users, even administrators, and in all log files.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 38.0, 'instruction', 1.0, 'Set to ''1'' to change the subscription status of a user when the user ages. ''0'' to disable.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 39.0, 'instruction', 1.0, 'The number of retries to allow before locking the user account. A locked user account will have their password changed to the value of lockout_password in the jbilling.properties configuration file.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 40.0, 'instruction', 1.0, 'If greater than zero, it represents the number of days that a password is valid. After those days, the password is expired and the user is forced to change it.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 42.0, 'instruction', 1.0, 'Set to ''1'' to allow the use of pro-rating to invoice fractions of a period. Shows the ''cycle'' attribute of an order. Note that you need to configure the corresponding plug-ins for this feature to be fully functional.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 43.0, 'instruction', 1.0, 'If the payment blacklist feature is used, this is set to the id of the configuration of the PaymentFilterTask plug-in. See the Blacklist section of the documentation.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 44.0, 'instruction', 1.0, 'Set to ''1'' to allow negative payments. ''0'' to disable');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 45.0, 'instruction', 1.0, 'Set to ''1'' to delay payment of negative invoice amounts, causing the balance to be carried over to the next invoice. Invoices that have had negative balances from other invoices transferred to them are allowed to immediately make a negative payment (credit) if needed. ''0'' to disable. Preference 44 & 46 are usually also enabled.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 46.0, 'instruction', 1.0, 'Set to ''1'' to allow invoices with negative balances to generate a new invoice that isn''t composed of any orders so that their balances will always get carried over to a new invoice for the credit to take place. ''0'' to disable. Preference 44 & 45 are usually also enabled.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 49.0, 'instruction', 1.0, 'The threshold value for automatic payments. Pre-paid users with an automatic recharge value set will generate an automatic payment whenever the account balance falls below this threshold. Note that you need to configure the AutoRechargeTask plug-in for this feature to be fully functional.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 50.0, 'instruction', 1.0, 'The number of decimal places to be shown on the invoice. Defaults to 2.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (90.0, 1.0, 'description', 1.0, 'Paid');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (90.0, 2.0, 'description', 1.0, 'Unpaid');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (90.0, 3.0, 'description', 1.0, 'Carried');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 10.0, 'description', 1.0, 'Create customer');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 11.0, 'description', 1.0, 'Edit customer');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 12.0, 'description', 1.0, 'Delete customer');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 13.0, 'description', 1.0, 'Inspect customer');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 14.0, 'description', 1.0, 'Blacklist customer');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 15.0, 'description', 1.0, 'View customer details');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 16.0, 'description', 1.0, 'Download customer CSV');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 17.0, 'description', 1.0, 'View all customers');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 18.0, 'description', 1.0, 'View customer sub-accounts');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 20.0, 'description', 1.0, 'Create order');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 21.0, 'description', 1.0, 'Edit order');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 22.0, 'description', 1.0, 'Delete order');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 23.0, 'description', 1.0, 'Generate invoice for order');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 24.0, 'description', 1.0, 'View order details');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 25.0, 'description', 1.0, 'Download order CSV');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 26.0, 'description', 1.0, 'Edit line price');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 27.0, 'description', 1.0, 'Edit line description');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 28.0, 'description', 1.0, 'View all customers');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 29.0, 'description', 1.0, 'View customer sub-accounts');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 30.0, 'description', 1.0, 'Create payment');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 31.0, 'description', 1.0, 'Edit payment');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 32.0, 'description', 1.0, 'Delete payment');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 33.0, 'description', 1.0, 'Link payment to invoice');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 34.0, 'description', 1.0, 'View payment details');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 35.0, 'description', 1.0, 'Download payment CSV');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 36.0, 'description', 1.0, 'View all customers');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 37.0, 'description', 1.0, 'View customer sub-accounts');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 40.0, 'description', 1.0, 'Create product');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 41.0, 'description', 1.0, 'Edit product');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 42.0, 'description', 1.0, 'Delete product');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 43.0, 'description', 1.0, 'View product details');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 44.0, 'description', 1.0, 'Download Product CSV');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 50.0, 'description', 1.0, 'Create product category');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 51.0, 'description', 1.0, 'Edit product category');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 52.0, 'description', 1.0, 'Delete product category');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 70.0, 'description', 1.0, 'Delete invoice');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 71.0, 'description', 1.0, 'Send invoice notification');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 72.0, 'description', 1.0, 'View invoice details');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 73.0, 'description', 1.0, 'Download invoice CSV');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 74.0, 'description', 1.0, 'View all customers');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 75.0, 'description', 1.0, 'View customer sub-accounts');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 80.0, 'description', 1.0, 'Approve / Disapprove review');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 90.0, 'description', 1.0, 'Show customer menu');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 91.0, 'description', 1.0, 'Show invoices menu');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 92.0, 'description', 1.0, 'Show order menu');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 93.0, 'description', 1.0, 'Show payments & refunds menu');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 94.0, 'description', 1.0, 'Show billing menu');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 96.0, 'description', 1.0, 'Show reports menu');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 97.0, 'description', 1.0, 'Show products menu');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 99.0, 'description', 1.0, 'Show configuration menu');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 100.0, 'description', 1.0, 'Show partner menu');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 101.0, 'description', 1.0, 'Create partner');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 102.0, 'description', 1.0, 'Edit partner');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 103.0, 'description', 1.0, 'Delete partner');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 104.0, 'description', 1.0, 'View partner details');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 110.0, 'description', 1.0, 'Switch to sub-account');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 111.0, 'description', 1.0, 'Switch to any user');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59.0, 120.0, 'description', 1.0, 'Web Service API access');

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337972683141-32', 'aristokrates (generated)', 'descriptors/database/jbilling-init_data.xml', NOW(), 29, '7:c8e2d0e46f2d65b6615edb152c54c078', 'insert (x1067)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-init_data.xml::#14049-French and German Translation Texts::Manisha Gupta
INSERT INTO jbilling_test.language (id, code, description) VALUES (3.0, 'de', 'Deutsch');

INSERT INTO jbilling_test.language (id, code, description) VALUES (4.0, 'fr', 'French');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 10, 'description', 4, 'Historique des tarifs du plan pour tous les produits et les dates de début du plan.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 11, 'description', 3, 'Gesamtrechnungen pro Kunde nach Produktkategorien gruppiert.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 11, 'description', 4, 'Totaux facturés par client regroupés par catégorie de produit.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 12, 'description', 3, 'Gesamtrechnungen pro Kunde über die Jahre, in Jahre gruppiert.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 12, 'description', 4, 'Total facturé par client au fil des ans avec regroupement par année.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 13, 'description', 4, 'Relevé de l''activité de l''utilisateur pendant un nombre de jours spécifié');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 1, 'description', 3, 'Gesamtsumme berechnet, in Zeiträume gruppiert.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 1, 'description', 4, 'Montant total facturé regroupé par période');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 2, 'description', 3, 'Detaillierter Balance Datierungsbericht. Zeigt die Datierung der hervorragenden Kundenguthaben.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 2, 'description', 4, 'Rapport détaillé sur l''avancement des phases du solde. Affiche la phase d''avancement des soldes débiteurs de clients.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 3, 'description', 3, 'Anzahl der Benutzer die ein spezifisches Produkt abonniert haben');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 3, 'description', 4, 'Nombre d''utilisateurs abonnés à un produit spécifique.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 4, 'description', 3, 'Gesamtbezahlungen gruppiert bei Zeiträumen.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 4, 'description', 4, 'Montant total des paiements reçus regroupés par période');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 5, 'description', 3, 'Anzahl der Kunden die in diesem Zeitraum erstellt wurden Number');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 5, 'description', 4, 'Nombre de clients créés au sein d''une période.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 6, 'description', 3, 'Gesamteinnahmen (Summe der erhaltenen Bezahlunge) pro Kunde.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 6, 'description', 4, 'Total des revenus (somme des paiements reçus) par client.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 7, 'description', 3, 'Einfacher Forderungesbericht der Leistungsbilanzen anzeigt.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 7, 'description', 4, 'Simple rapport sur les comptes clients montrant les soldes actuels des comptes.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 8, 'description', 3, 'Hauptbuch Details aller in Rechnung gestellten Gebühren für den angegebenen Tag.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 8, 'description', 4, 'Détails du grand compte de tous les frais facturés pour le jour donné.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 9, 'description', 3, 'Hauptbuch Zusammenfassung aller in Rechnung gestellten Gebühren für den bestimmten Tag, in Elementtypen gruppiert.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (100, 9, 'description', 4, 'Synthèse du grand compte de tous les frais facturés pour le jour donné, groupés par type d''article.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (101, 1, 'description', 3, 'Rechnungsberichte');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (101, 1, 'description', 4, 'Rapports relatifs aux factures');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (101, 2, 'description', 3, 'Bestellungsberichte');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (101, 2, 'description', 4, 'Rapports relatifs aux commandes');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (101, 3, 'description', 3, 'Zahlungsberichte');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (101, 3, 'description', 4, 'Rapports relatifs aux paiements');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (101, 4, 'description', 3, 'Kundenberichte');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (101, 4, 'description', 4, 'Rapports relatifs aux clients');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (101, 5, 'description', 4, 'Rapports sur les plans');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (104, 1, 'description', 3, 'Rechnungen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (104, 1, 'description', 4, 'Factures.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (104, 2, 'description', 3, 'Bestellungen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (104, 2, 'description', 4, 'Commandes.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (104, 3, 'description', 3, 'Bezahlungen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (104, 3, 'description', 4, 'Paiements.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (104, 4, 'description', 3, 'Benutzer');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (104, 4, 'description', 4, 'Utilisateurs.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (104, 5, 'description', 4, 'Notifications personnalisées');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 10, 'errorMessage', 3, 'Bezahlungskartennummer ist nicht mehr gƒltig');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 10, 'errorMessage', 4, 'Le numéro de carte de paiement est invalide');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 11, 'errorMessage', 3, 'Auslaufsdatum sollte im Format MM/jjjj sein');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 11, 'errorMessage', 4, 'La date d''expiration doit être au format mm/aaaa');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 12, 'errorMessage', 3, 'ABA Routing oder Bank Kontonummer kann nur Zahlen sein');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 12, 'errorMessage', 4, 'Le numéro de routage ABA ou le numéro de compte bancaire ne peut contenir que des chiffres');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 20, 'errorMessage', 4, 'Le numéro de carte de paiement est invalide');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 21, 'errorMessage', 4, 'La date d''expiration doit être au format mm/aaaa');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 22, 'errorMessage', 4, 'Le numéro de routage ABA ou le numéro de compte bancaire ne peut contenir que des chiffres');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 23, 'errorMessage', 4, 'Le numéro de carte de paiement est invalide');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 24, 'errorMessage', 4, 'La date d''expiration doit être au format mm/aaaa');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 25, 'errorMessage', 4, 'Le numéro de routage ABA ou le numéro de compte bancaire ne peut contenir que des chiffres');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 26, 'errorMessage', 4, 'Le numéro de carte de paiement est invalide');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 27, 'errorMessage', 4, 'La date d''expiration doit être au format mm/aaaa');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 28, 'errorMessage', 4, 'Le numéro de routage ABA ou le numéro de compte bancaire ne peut contenir que des chiffres');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 29, 'errorMessage', 4, 'Le numéro de carte de paiement est invalide');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 30, 'errorMessage', 4, 'La date d''expiration doit être au format mm/aaaa');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 31, 'errorMessage', 4, 'Le numéro de routage ABA ou le numéro de compte bancaire ne peut contenir que des chiffres');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 32, 'errorMessage', 4, 'Le numéro de carte de paiement est invalide');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 33, 'errorMessage', 4, 'La date d''expiration doit être au format mm/aaaa');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 34, 'errorMessage', 4, 'Le numéro de routage ABA ou le numéro de compte bancaire ne peut contenir que des chiffres');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 35, 'errorMessage', 4, 'Le numéro de carte de paiement est invalide');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 36, 'errorMessage', 4, 'La date d''expiration doit être au format mm/aaaa');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 37, 'errorMessage', 4, 'Le numéro de routage ABA ou le numéro de compte bancaire ne peut contenir que des chiffres');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 38, 'errorMessage', 4, 'Le numéro de carte de paiement est invalide');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 39, 'errorMessage', 4, 'La date d''expiration doit être au format mm/aaaa');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 40, 'errorMessage', 4, 'Le numéro de routage ABA ou le numéro de compte bancaire ne peut contenir que des chiffres');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 41, 'errorMessage', 4, 'Le numéro de carte de paiement est invalide');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (114, 42, 'errorMessage', 4, 'La date d''expiration doit être au format mm/aaaa');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (17, 1, 'description', 3, 'Einmal');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (17, 1, 'description', 4, 'Une fois');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (17, 5, 'description', 3, 'Alle Auftrège');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (17, 5, 'description', 4, 'Toutes les commandes');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (18, 1, 'description', 3, 'Artikel');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (18, 1, 'description', 4, 'Articles');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (18, 2, 'description', 3, 'Steuer');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (18, 2, 'description', 4, 'Taxe');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (18, 3, 'description', 3, 'Strafe');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (18, 3, 'description', 4, 'Pénalité');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (18, 4, 'description', 3, 'Rabatt');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (18, 4, 'description', 4, 'Réduction');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (18, 5, 'description', 4, 'Abonnement');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (18, 5, 'description', 3, 'Abonnement');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (19, 1, 'description', 3, 'vorausbezahlt');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (19, 1, 'description', 4, 'prépayée');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (19, 2, 'description', 3, 'danach bezahlt');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (19, 2, 'description', 4, 'post-payée');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 10, 'description', 3, 'Alarmiert wen nein Zahlungs Gateway nicht funktioniert');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 10, 'description', 4, 'Alertes quand une passerelle de paiement est en dysfonctionnement');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 11, 'description', 3, 'Abonnement Status Manager');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 11, 'description', 4, 'Gestionnaire de statut des abonnements');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 12, 'description', 3, ' Parameter fƒr Asynchron-Zahlungsabwicklung');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 12, 'description', 4, 'Paramètres pour le traitement asynchrone des paiements');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 13, 'description', 3, 'Ein Produkt zur Bestllung hinzufƒgen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 13, 'description', 4, 'Ajouter un produit à commander');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 14, 'description', 3, 'Produktpreise');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 14, 'description', 4, 'Prix du produit');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 15, 'description', 3, 'Vermittlungs Reader');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 15, 'description', 4, 'Visionneuse de médiation');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 16, 'description', 3, 'Vermittlungs Prozessor');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 16, 'description', 4, 'Système de traitement de la médiation');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 17, 'description', 3, 'generische interne Ereignisse ZuhÖrer');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 17, 'description', 4, 'Observateur d''évènements internes génériques');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 18, 'description', 3, 'externer Beschaffungsprozessor ');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 18, 'description', 4, 'Système de traitement de l''approvisionnement externe');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 19, 'description', 3, ' Kauf Validierung gegen Prepaid-Guthaben / Kreditlimit');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 19, 'description', 4, 'Validation de l''achat par rapport au solde prépayé/à la limite de crédit');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 1, 'description', 3, 'Artikel Management und Auftragsposition Gesamtberechnung');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 1, 'description', 4, 'Gestion des articles et calcul du total des lignes de commande');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 20, 'description', 3, 'Abrechnungsprozess: Kundenauswahl');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 20, 'description', 4, 'Processus de facturation : sélection du client');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 21, 'description', 3, 'Vermittlungsfehler Steuerungsprogram');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 21, 'description', 4, 'Gestionnaire des erreurs de médiation');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 22, 'description', 3, 'Geplante Plug-ins');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 22, 'description', 4, 'Plugins programmés');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 23, 'description', 3, 'Regelgenarator');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 23, 'description', 4, 'Générateurs de règles');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 24, 'description', 3, 'Vergƒtung fƒr Kunden mit ƒberfèlligen Rechnungen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 24, 'description', 4, 'Avancement de phase pour les clients avec des factures en retard de paiement');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 25, 'description', 4, 'Processus de calcul des commissions des agents');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 26, 'description', 4, 'Échange de fichiers avec des sites distants, télécharger');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 2, 'description', 3, 'Abrechnungsprozess: Bestellung Filter');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 2, 'description', 4, 'Processus de facturation : filtres des commandes');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 3, 'description', 3, 'Abrechnungsprozess: Rechnung Filter');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 3, 'description', 4, 'Processus de facturation : filtres des factures');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 4, 'description', 3, 'Rechnungsvorlage');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 4, 'description', 4, 'Présentation des factures');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 5, 'description', 3, 'Abrechnungsprozess:  Auftragskalkulation Zeitraum');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 5, 'description', 4, 'Processus de facturation : calcul des périodes de commande');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 6, 'description', 3, 'Zahlungs Gateway integration');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 6, 'description', 4, 'Intégration d''une passerelle de paiement');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 7, 'description', 3, 'Mitteilungen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 7, 'description', 4, 'Notifications');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 8, 'description', 3, 'Zahlungsinstrument Auswahl');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 8, 'description', 4, 'Sélection d''un instrument de paiement');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 9, 'description', 3, 'Strafen fƒr ƒberfèllige Rechnungen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23, 9, 'description', 4, 'Pénalités pour les factures impayées');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 101, 'description', 3, 'Die Event basierte benutzerdefinierten Mitteilungsaufgabe nimmt die benutzerdefinierte Benachrichtigung und führt die Benachrichtigung durch, wenn ein internes Ereignis eingetreten ist');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 101, 'description', 4, 'La tâche Notification personnalisée basée sur les évènements prend le message de notification personnalisé et réalise la notification lorsque l''évènement interne survient');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 101, 'title', 3, 'Event basierte Kundenmitteilungsaufgabe');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 101, 'title', 4, 'Tâche Notification personnalisée basée sur les évènements');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 103, 'title', 3, 'Einfacher Vermittlungsprozessor');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 103, 'title', 4, 'Système de traitement de médiation simple');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 105, 'description', 3, 'Dieser plugin fügt Steuerzeilen auf die Rechnung hinzu durch die Befragung der Suretax Engine.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 105, 'description', 4, 'Ce plugin ajoute des lignes Taxe aux factures en consultant le moteur Suretax.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 105, 'title', 3, 'Suretax Plugin');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 105, 'title', 4, 'Plugin Suretax');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 107, 'description', 3, '');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 107, 'description', 4, 'Ce plugin définira la valeur du solde et du total d''une facture négative à 0, et il créera un paiement ''créditeur'' pour le montant restant.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 107, 'title', 3, 'Kredit auf negativer Rechnung');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 107, 'title', 4, 'Crédit sur facture négative');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 108, 'description', 4, 'Une tâche pour utiliser un plugin du type InternalEventsTask afin de vérifier si le solde prépayé des utilisateurs est inférieur à un niveau seuil et d''envoyer des notifications.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 108, 'title', 4, 'Tâche Notification du seuil du solde de l''utilisateur');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 109, 'description', 4, 'Ce plugin fournit une cartographie entre le statut de l''utilisateur (étapes d''avancement des phases) et les notifications devant être envoyées pour chaque statut');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 109, 'title', 4, 'Notifications personnalisées à l''utilisateur par étapes d''avancement des phases');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 10, 'description', 3, 'Findet die Informationen einer Zahlungsmethode die dem Kunden zur Verfƒgung stehen, Prioritèt auf Kreditkarten. Mit anderen Worten, es wird die Kreditkarte eines Kunden oder die ACH Informationen in dieser Reihenfolge zurƒckgeben.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 10, 'description', 4, 'Trouve les informations sur une méthode de paiement disponible pour un utilisateur, priorité étant donné aux cartes bancaires. En d''autres termes, it will return the credit car of a customer or the ACH information in that order.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 10, 'title', 3, 'Standard Zahlungsinformationen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 10, 'title', 4, 'Informations relatives au paiement par défaut');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 110, 'description', 4, 'Cette tâche supprimera les fichiers ultérieur à une certaine période.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 110, 'title', 4, 'Supprimer les anciens fichiers');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 111, 'description', 4, 'Ce plugin mettra à jour AssetTransitions en cas de changement de statut d''un actif.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 111, 'title', 4, 'Met à jour les transactions des actifs');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 112, 'description', 4, 'Ce plugin supprimera les propriétaires de l''actif au moment de l''expiration de la commande associée.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 112, 'title', 4, 'Supprimer les actifs des commandes TERMINÉES');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 113, 'description', 4, 'Une tâche pour utiliser un plugin de type InternalEventsTask pour contrôler des changements relatifs à activeUntil sur une commande');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 113, 'title', 4, 'Tâche d''annulation de la commande');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 117, 'description', 4, 'Ce plugin créera le regroupement d''utilisation pour le client si le client s''abonne à un plan qui est rattaché à des regroupements d''utilisation.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 117, 'title', 4, 'Créer un regroupement d''utilisation pour le client');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 118, 'description', 4, 'Ce plugin évaluera et mettra à jour les regroupements d''utilisation du client afin de définir les dates de fin du cycle conformément à la période de regroupement d''utilisation, et il réinitialisera les quantités conformément au paramètre de définition des regroupements d''utilisation.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 118, 'title', 4, 'Tâche d''évaluation et de mise à jour du regroupement d''utilisation du client');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 119, 'description', 4, 'Ce plugin mettra à jour le regroupement d''utilisation du client si un des évènements suivants se produit : NewOrderEvent, NewQuantityEvent, OrderDeletedEvent.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 119, 'title', 4, 'Tâche de mise à jour du regroupement d''utilisation du client');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 11, 'description', 3, 'Plug-in nur hilfreich fƒr Testing useful');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 11, 'description', 4, 'Plugin uniquement utile à des fins de test');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 11, 'title', 3, 'Testing plug-in fƒr Partner Auszahlungen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 11, 'title', 4, 'Test du plugin pour le paiement des partenaires');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 120, 'description', 4, 'Ce plugin mettra à jour les regroupements d''utilisation du client comme expirés si le client se désabonne d''un plan.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 120, 'title', 4, 'Il traite un évènement de désabonnement d''un plan pour un client. Il met à jour les regroupements d''utilisation du client comme expirés.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 121, 'description', 4, 'Si un évènement de consommation de regroupement d''utilisation a lieu, ce plugin lancera une action définie sur le FUP pour la consommation du pourcentage donnée');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 121, 'title', 4, 'Tâche de consommation du regroupement d''utilisation du client');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 122, 'description', 4, 'Ajoute des commandes d''approvisionnement pour la ligne de commande.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 122, 'title', 4, 'Ajoute des commandes d''approvisionnement pour la ligne de commande.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 123, 'description', 4, 'Ajoute des commandes d''approvisionnement lorsque les actifs sont créés, mis à jour et ajouté à la ligne du client');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 123, 'title', 4, 'Ajoute des commandes d''approvisionnement pour les actifs.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 124, 'description', 4, 'Ajouter une commande d''approvisionnement lorsque le paiement est effectué.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 124, 'title', 4, 'Ajoute une commande d''approvisionnement lorsque le paiement est effectué');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 125, 'description', 4, 'Traite le changement de statut de la commande');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 125, 'title', 4, 'Traite le changement de statut de la commande');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 126, 'description', 4, 'Crée des commandes à chaque qu''une ligne de commande est remplie via un changement de commande.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 126, 'title', 4, 'Crée des commandes d''approvisionnement pour le changement de commande.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 127, 'description', 4, 'Cette tâche planifie le processus qui calcule les commissions des agents.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 127, 'title', 4, 'Calculer les commissions des agents');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 128, 'description', 4, 'Cette tâche calcule les commissions des agents.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 128, 'title', 4, 'Tâche Commissions des agents basiques');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 129, 'description', 4, 'Ce plugin créera des commissions sur des paiements lorsque des paiements sont associés et désassociés des factures.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 129, 'title', 4, 'Générer des commissions sur les paiements pour les agents.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 12, 'description', 3, 'Wird eine PDF Version der Rechnung generieren.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 12, 'description', 4, 'Génèrera une version PDF d''une facture.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 12, 'title', 3, 'PDF Rechnung Mitteilung');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 12, 'title', 4, 'Notification de facture au format PDF');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 133, 'description', 4, 'Il déclenche le téléchargement par rapport à un système tiers');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 133, 'title', 4, 'Déclencher le téléchargement des fichiers');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 134, 'description', 4, 'Une tâche pour utiliser un plugin du type InternalEventsTask afin de vérifier si le solde prépayé des utilisateurs est inférieur aux niveaux 1 ou 2 de la limitation de crédit et d''envoyer des notifications.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 134, 'title', 3, 'Benutzer Kreditlimit Mitteilungsaufgabe');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 134, 'title', 4, 'Tâche Notification de la limitation de crédit de l''utilisateur');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 135, 'description', 4, 'Ce gestionnaire des erreurs de médiation enregistre automatiquement les CDR qui se sont soldés par un échec vers le tableau ''cdr_recycling'' de HBase.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 135, 'title', 4, 'Gestionnaire des erreurs de médiation HBase');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 136, 'description', 4, 'Ce plugin changera la statut de la commande au moment où le changement de la commande s''appliquer au changement de commande sélectionné.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 136, 'title', 4, 'Changer le statut de la commande au moment où le changement s''applique');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 137, 'description', 4, 'Si un évènement de facturation de consommation de regroupement d''utilisation a lieu, ce plugin facturera des frais au client');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 137, 'title', 4, 'Tâche Facturation de la consommation du regroupement d''utilisation');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 138, 'description', 4, 'Il s''agit d''un plugin programmé qui prend l''utilisateur qui ne s''est pas connecté pendant un nombre de jours indiqué dans Préférence 55 et qui met à jour son statut en Inactif.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 138, 'title', 4, 'Plugin de gestion des comptes utilisateur inactifs');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 14, 'description', 3, 'Kommt immer falsch zurƒck, das ist warum Jbilling nie eine Rechnung auf eine neue Rechnung ƒbertrègt.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 14, 'description', 4, 'Renvoie toujours une valeur fausse, ce qui que jBilling ne reporte jamais une facture sur une autre plus récente.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 14, 'title', 3, 'Keine åbertragung der Rechnung');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 14, 'title', 4, 'Aucune facture à reporter');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 15, 'description', 3, 'Wird eine neue Bestellung mit einem Strafeartikel erstellen. Der Artikel wird als Parameter der Aufgabe gemacht.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 15, 'description', 4, 'Créera une nouvelle commande avec un article Pénalité. l''article est considéré comme un paramètre de la tâche.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 15, 'title', 3, 'Standard Interessepflicht');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 15, 'title', 4, 'Tâche relative aux intérêts par défaut');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 16, 'description', 3, ' Erstreckt BasicOrderFilterTask, modifiziert die Daten, um die Bestellung ein paar Monaten im Vorraus zutreffen zu lassen, bevor es den Standardfilter benutzen wƒrde.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 16, 'description', 4, 'Étend BasicOrderFilterTask, en modifiant les dates pour que la commande soit applicable pendant un nombre de mois dans le passé plus élevé que ce qu''elle aurait dû en utilisant le filtre par défaut.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 16, 'title', 3, 'Voraussichtlicher Bestellungsfilter');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 16, 'title', 4, 'Filtre pour les commandes anticipées');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 17, 'description', 3, ' Erstreckt BasicOrderFilterTask, modifiziert die Daten, um die Bestellung ein paar Monaten im Vorraus zutreffen zu lassen, bevor es den Standardfilter benutzen wƒrde.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 17, 'description', 4, 'Étend BasicOrderPeriodTask, en modifiant les dates pour que la commande soit applicable pendant un nombre de mois dans le passé plus élevé que ce qu''elle aurait dû en utilisant la tâche par défaut.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 17, 'title', 3,'Voraussichtliche Bestellungszeitrèume.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 17, 'title', 4, 'Anticiper les périodes de commande');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 19, 'description', 3, ' Erweitert den standard authorize.net Zahlungsprozessor, und sendet auch eine E-Mail an das Unternehmen nach der Verarbeitung der Bezahlung.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 19, 'description', 4, 'Élargit les capacités du système de traitement des paiements standard authorize.net pour qu''il puisse également envoyer un e-mail à la société après le traitement du paiement.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 19, 'title', 3, 'Email & Prozess authorize.net');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 19, 'title', 4, 'E-mail et traitement authorize.net');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 1, 'description', 3, 'Berechnet die Auftragssumme und die Summe fƒr jede Zeile, unter Berƒcksichtigung der Artikelpreise, der Menge und ob die Preise ein Prozentsatz sind oder nicht.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 1, 'description', 4, 'Calcule le total de la commande et la total pour chaque ligne, en prenant en compte les prix des articles, the quantity and if the prices are percentage or not.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 1, 'title', 3, 'Standard Auftragssumme');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 1, 'title', 4, 'Totaux des commandes par défaut');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 20, 'description', 3, 'Sendet eine E-Mail an die Rechnungsadministrator als Alarm, wenn ein Zahlungsportal ausfèllt.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 20, 'description', 4, 'Envoie un e-mail au gestionnaire de facturation pour l''avertir qu''une passerelle de paiement est en dysfonctionnement.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 20, 'title', 3, 'Zahlungs Gateway ausgefallen alarm');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 20, 'title', 4, 'Alerte Passerelle en dysfonctionnement.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 21, 'description', 3, ' Ein Test der Zahlungsprozessorimplementierung, um jBillings Funktionen testen zu kÖnnen, ohne einen echten Zahlungs- Gateway zu benutzen.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 21, 'description', 4, 'Mise en place d''un système de traitement des paiements de test pour permettre de tester les fonctions de jBillings sans utiliser une véritable passerelle de paiement.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 21, 'title', 3, 'Test Zahlungsprozessor');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 21, 'title', 4, 'Traitement test des paiements');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 22, 'description', 3, 'AEin Kunde kann einem bestimmten Zahlungs-Gateway zugeordnet werden. Es prƒft ein benutzerdefiniertes Kontaktfeld, um den Gateway zu identifizieren und delegiert dann die Zahlungsabwicklung zu einem anderen Plug-in.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 22, 'description', 4, 'Il permet à un client de se voir assigné une passerelle de paiement spécifique. Le champ Contact personnalisé est vérifié en vue d''identifier la passerelle, puis le traitement du paiement réel est traité par un autre plugin.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 22, 'title', 3, 'Router Zahlungsprozessor auf kundenspezifische Felder basiert');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 22, 'title', 4, 'Système de traitement des paiements via un routeur basé sur les champs personnalisés');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 23, 'description', 3, 'Es legt fest, wie ein Zahlungsereignis sich auf den Abo-Status eines Benutzers auswirkt, gemessen an dem gegenwèrtigen Status und einer Zustandsmaschine.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 23, 'description', 4, 'Détermine la manière dont un évènement lié à un paiement affecte le statut de l''abonnement d''un utilisateur, en prenant en compte son statut actuel et une machine d''état.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 23, 'title', 3, 'Standard Abonnement Status Manager');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 23, 'title', 4, 'Gestionnaire de statut des abonnements par défaut');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 24, 'description', 3, 'Integration mit dem ACH commerce Zahlungs Gateway.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 24, 'description', 4, 'Intégration avec la passerelle de paiement commercial ACH.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 24, 'title', 3, 'ACH Commerce Zahlungsprozessor');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 24, 'title', 4, 'Système de traitement des paiements commerçants ACH');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 25, 'description', 3, ' Eine Dummy Aufgabe, die keine Parameter fƒr asynchrone Zahlungsabwicklung hinzufƒgt. Dies ist der Standard.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 25, 'description', 4, 'Une tâche factice qui n''ajoute aucun paramètre pour le traitement des paiements asynchrone. C''est le défaut.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 25, 'title', 3, 'Standard asynchrone Parameter ');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 25, 'title', 4, 'Paramètres asynchrones standards');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 26, 'description', 3, 'Dieser Plug-in fƒgt Parameter fƒr Asynchrone Zahlungsabwicklung hinzu, um eine Verarbeitungsnachricht bean pro Zahlungsprozessor zu haben. Es wird in Kombination mit den Router Zahlungsprozessor -PlugIns verwendet.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 26, 'description', 4, 'Ce plugin ajoute des paramètres pour le traitement des paiements asynchrone pour qu''il ait un ben de message de traitement par système de traitement des paiements. Il est utilisé en combinaison avec les plugins des systèmes de traitement des paiements via un routeur.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 26, 'title', 3, 'Router asynchrone Parameter');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 26, 'title', 4, 'Paramètres asynchrones via un routeur');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 28, 'description', 3, 'Es fƒgt Artikel zu einer Bestellung hinzu. Wenn der Artikel bereits in der Bestellung ist, aktualisiert es nur die Menge.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 28, 'description', 4, 'Il ajoute des articles à une commande. Si l''article est déjà dans la commande, il ne met à jour que la quantité.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 28, 'title', 3, 'Standard Artikel Manager');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 28, 'title', 4, 'Gestionnaire d''articles standard');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 29, 'description', 3, 'Dies ist ein regelbasierte Plug-in. Er wird das tun, was der Grundelementmanager tut (eigentlich genannt); aber dann wird er auch externe Regeln durchfƒhren. Diese externen Regeln haben die volle Kontrolle ƒber die Bestllung die neue Artikel bekommt.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 29, 'description', 4, 'Il s''agit d''un plugin basé sur des règles. Il fera ce que le gestionnaire d''articles basique fait (l''appeler en réalité), mais ensuite il exécutera également des règles externes. Ces règles externes ont un contrôle total sur le changement de la commande qui reçoit de nouveaux articles.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 29, 'title', 3, 'Regelartikel Manager');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 29, 'title', 4, 'Gestionnaire de l''article Règles');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 2, 'description', 3, 'Fƒgt eine zusètzliche Zeile zum Autrag hinzu mit einem Prozentsatz um die Mehrwertsteuer darzustellen.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 2, 'description', 4, 'Ajoute une ligne supplémentaire à la commentaire avec une majoration en pourcentage représentant la taxe sur la valeur ajoutée.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 2, 'title', 3, 'VAT');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 2, 'title', 4, 'TVA');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 30, 'description', 3, ' Dies ist ein regelbasierter Plug-in. Er berechnet die Gesamtsumme fƒr eine Bestellung (in der Regel ist dies der Preis, multipliziert mit der Menge); so dass externe Regeln durchgefƒhrt werden kÖnnen.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 30, 'description', 4, 'Il s''agit d''un plug-in basé sur des règles. Il calcule le total pour une ligne de commande (généralement il s''agit du prix multiplié par la quantité), permettant ainsi l''exécution des règles externes.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 30, 'title', 3, 'Regel Zeile Gesamtsumme');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 30, 'title', 4, 'Règles du total de la ligne');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 31, 'description', 3, 'Dies ist ein regelbasierter Plug-in. Er gibt den Preis eines Artikels durch die Ausfƒhrung externer Vorschriften. Anschlieºend kÖnnen Sie Logik extern fƒr die Preise hinzufƒgen. Es ist auch mit dem Vermittlungsverfahren integriert, durch den Zugang zu der Vermittlungspreisdaten.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 31, 'description', 4, 'Il s''agit d''un plug-in basé sur des règles. Il donne un prix à un article en appliquant des règles externes. Vous pouvez ajouter une logique externe pour la tarification. Il est également intégré avec le processus de médiation en ayant accès aux données de tarification de la médiation.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 31, 'title', 3, 'Regelpreise');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 31, 'title', 4, 'Règles de tarification');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 32, 'description', 3, ' Dies ist ein Reader fƒr das Vermittlungsverfahren. Er liest Datensètze aus einer Textdatei, deren Felder durch ein Zeichen (oder Zeichenfolge) getrennt sind.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 32, 'description', 4, 'Il s''agit d''une visionneuse pour le processus de médiation. Il lit les enregistrements provenant d''un fichier texte dont les champs sont séparés par un caractère (ou une chaîne de caractères).');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 32, 'title', 3, 'Trenner Datei Reader');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 32, 'title', 4, 'Visionneuse de fichier avec séparateur');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 33, 'description', 3, 'Dies ist ein regelbasierter Plug-In (siehe Kapitel 7). Er nimmt eine Ereignisaufzeichnung aus dem Vermittlungsverfahren und fƒhrt externe Regeln durch, um den Datensatz in aussagekrèftige Abrechungsdaten zu ƒbersetzen. Dies ist der Kern des Vermittlungselements, siehe die ? Telecom Guide? Dokumentation fƒr weitere Informationen.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 33, 'description', 4, 'Il s''agit d''un plug-in basé sur des règles (voir Chapitre 7) Il effectue un enregistrement des évènements à partir du processus de médiation et il exécute des règles externes pour traduire l''enregistrement en données de facturation pertinentes. Il s''agit d''un élément essentiel du composant de la médiation, reportez-vous au ''Guide des télécoms'' pour obtenir plus d''informations.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 33, 'title', 3,'Regel Vermittlungsprozessor');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 33, 'title', 4, 'Système de traitement des règles de médiation');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 34, 'description', 3, ' Dies ist ein Reader fƒr das Vermittlungsverfahren. Er liest Datensètze aus einer Textdatei, deren Felder fixierte Positionen haben, und der Datensatz hat eine feste Lènge.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 34, 'description', 4, 'Il s''agit d''une visionneuse pour le processus de médiation. Il lit les enregistrements provenant d''un fichier texte dont les champs ont des positions fixes, ''et l''enregistrement dispose d''une longueur fixe.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 34, 'title', 3,'Festgelegte Lènge Dateireader');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 34, 'title', 4, 'Lecteur de fichier avec longueur fixe');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 35, 'description', 3, 'Das ist genau das gleiche wie die Standard-Zahlungsinformationen Aufgabe, der einzige Unterschied ist, dass es nicht validiert, wenn die Kreditkarte abgelaufen ist. Verwenden Sie dieses Plug-in nur, wenn Sie die Zahlung mit abgelaufene Kreditkarten einreichen mÖchten.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 35, 'description', 4, 'Il s''agit d''exactement la même chose que pour la tâche des informations relatives aux paiements, la seule différence est qu''il ne valide pas si la carte bancaire a expiré. Utilisez ce plugin uniqumenet si vous voulez envoyer des paiements avec des cartes bancaires expirées.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 35, 'title', 3, 'Zahlungsinformationen ohne Bestètigung');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 35, 'title', 4, 'Informations relatives aux paiements sans validation');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 36, 'description', 3, ' Dieser Plug-in ist nur zu Testzwecken zu verwenden. Anstatt einer E-Mail (oder anderen wirklichen Mitteilungen); speichert es einfach den Text in einer Datei mit dem Namen emails_sent.txt.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 36, 'description', 4, 'Ce plugin est uniquement utilisé à des fins de test. Au lieu d''envoyer un e-mail (ou une autre notification réelle), il stocke simplement le texte à envoyer dans un fichier appelé emails_sent.txt.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 36, 'title', 3, 'Mitteilung fƒr Testing');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 36, 'title', 4, 'Tâche de notification à des fins de test');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 37, 'description', 3, ' Dieses Plugin berƒcksichtigt den Feldkreislauf der Bestellungen um zu die Teilbestellzeiten zu berechnen.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 37, 'description', 4, 'Ce plugin prend en considération le champ Débuts de cycles des commandes pour calculer des périodes de commande fractionnées.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 37, 'title', 3, ' Bestellfristen Rechner mit Pro-Bewertung.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 37, 'title', 4, 'Calculateur de périodes de commande avec paiement au prorata.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 38, 'description', 3, ' Bei der Erstellung einer Rechnung aus einer Bestellung, wird dieses Plug-in jeder Bruchteil eines Zeitraums berechnen, mit einem Tages als kleinste abrechenbare Einheit.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 38, 'description', 4, 'Lors de la création d''une facture à partir d''une commande, ce plugin payera au prorata toute fraction d''une période en prenant un jour comme unité facturable la plus petite.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 38, 'title', 3, ' Rechnungs Zusammensetzungsaufgabe mit pro-Rating (Tag-Fraktion)');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 38, 'title', 4, 'Tâche de composition des factures avec paiement au prorata (jour sous forme de fraction)');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 39, 'description', 3, 'Integration mit dem Intraanuity Zahlungs Gateway.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 39, 'description', 4, 'Intégration avec la passerelle de paiement Intraanuity.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 39, 'title', 3, 'Zahlungsprozess fƒr den Intraanuity Zahlungs Gateway');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 39, 'title', 4, 'Processus de paiement pour la passerelle de paiement Intraanuity');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 3, 'description', 3, 'Eine sehr einfache Implementierung, die das Fèlligkeitsdatum der Rechnung festsetzt. Das Fèlligkeitsdatum wird berechnet der Zeitraum auf das Rechnungsdatum hinzugefƒgt wird.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 3, 'description', 4, 'Une intégration très simple qui permet de définir la date d''échéance de la facture. La date d''échéance est calculée en ajoutant simplement la période de temps à la date facturée.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 3, 'title', 3, 'Rechnung Fèlligkeitsdatum');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 3, 'title', 4, 'Date d''échéance de la facture');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 40, 'description', 3, ' Dieser Plug-in wird eine neue Bestllung mit einem negativen Preis erstellen, welche einen Kredit widerspiegelt, wenn eine Bestellung innerhalb eines bereits abgerechneten Zeitraums storniert wurde.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 40, 'description', 4, 'Ce plugin créera une nouvelle commande avec un prix négatif afin de refléter un crédit lorsqu''une commande est annulée au cours d''une période qui a déjà été facturée.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 40, 'title', 3, 'Automatischer Storierungskredit.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 40, 'title', 4, 'Crédit automatique pour annulation.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 42, 'description', 3, ' Verwendet fƒr die Sperrung der Zahlungen vom Erreichen realer Zahlungsdienste. In der Regel als erster Zahlungsprozessor in der Verarbeitungskette konfiguriert.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 42, 'description', 4, 'Il est utilisé pour empêcher que les paiements n''atteignent de véritables systèmes de traitement des paiements. Il est généralement configuré comme premier système de traitement des paiements dans la chaîne de traitement.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 42, 'title', 3, 'Sperrliste Filter Zahlungsprozessor.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 42, 'title', 4, 'Filtre Liste noire pour systèmes de traitement des paiements.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 43, 'description', 3, 'Setzt Benutzer und die dazugehÖrigen Informationen (zB Kreditkartennummer, Telefonnummer, etc.) auf die schwarze Liste, wenn ihr Status ausgesetzt oder hÖher ist.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 43, 'description', 4, 'Entraîne l''inscription sur la liste noire des clients et de leurs informations associées (ex : numéro de carte bancaire, numéro de téléphone, etc.) si leur statut devient Suspendu ou supérieu. ');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 43, 'title', 3, ' Benutzer sperren, wenn deren Status wird ausgesetzt oder höher wird.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 43, 'title', 4, 'Place l''utilisateur sur une liste noire lorsque son statut devient suspendu ou supérieur.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 44, 'description', 3, 'Dies ist ein Reader für das Vermittlungsverfahren. Er liest Datensètze aus einer JDBC-Datenbankquelle.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 44, 'description', 4, 'Il s''agit d''une visionneuse pour le processus de médiation. Il lit les enregistrements à partir d''une source de bases de données JDBC.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 44, 'title', 3, 'JDBC Vermittlungs Reader.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 44, 'title', 4, 'Visionneuse de médiation JDBC');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 45, 'description', 3, 'Dies ist ein Reader für das Vermittlungssverfahren. Es ist eine Erweiterung des JDBC-Reader, der eine einfache Konfiguration einer MySQL-Datenbankquelle erlaubt.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 45, 'description', 4, 'Il s''agit d''une visionneuse pour le processus de médiation. C''est une extension du lecteur JDBC, permettant une configuration aisée d''une source de base de données MySQL.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 45, 'title', 4, 'Visionneuse de médiation MySQL.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 46, 'description', 3, 'Reagiert auf Events die mit Bestellungen verbunden sind. Lässt Regeln laufen, um Befehle zu erzeugen, die über JMS-Nachrichten an das externe Bereitstellungsmodul geschickt werden.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 46, 'description', 4, 'Il réagit aux évènements associées aux commandes. Il exécute des règles pour générer des commandes à envoyer via des messages JMS vers un module d''approvisionnement externe.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 46, 'title', 3, ' Bereitstellungsbefehle Regelaufgabe');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 46, 'title', 4, 'Tâche des règles des commandes d''approvisionnement.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 47, 'description', 3, 'Dieses Plug-in wird nur zu Testzwecken verwendet. Es ist eine Test externe Bereitstellungsaufgabe zum Testen der Bereitstellungsmodule.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 47, 'description', 4, 'Ce plugin est uniquement utilisé à des fins de test. Il s''agit d''une tâche de test d''approvisionnement externe afin de tester les modules d''approvisionnement.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 47, 'title', 3, 'Externe Bereitstellungsaufgabe testen.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 47, 'title', 4, 'Tâche de test d''approvisionnement externe.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 48, 'description', 3, 'Ein externer Bereitstellungs Plug-in für die Kommunikation mit dem Ericsson Kundenverwaltungs Interface (CAI).');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 48, 'description', 4, 'Un plugin d''approvisionnement externe pour communiquer avec l''interface d''administration des clients d''Erisson (CAI).');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 48, 'title', 3, 'CAI externe Bereitstellungsaufgabe');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 48, 'title', 4, 'Tâche d''approvisionnement externe pour CAI.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 49, 'description', 3, 'Delegiert die eigentliche Zahlungsabwicklung zu einem anderen Plug-in auf der Basis der Währung der Zahlung.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 49, 'description', 4, 'Il délègue le traitement réel des paiements à un autre plugin selon la devise du paiement.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 49, 'title', 3, 'Währungs Router Zahlungsanbieter');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 49, 'title', 4, 'Système de traitement des paiements avec routeur pour les devises');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 4, 'description', 3, 'Diese Aufgabe wird alle Linien auf den Bestellungen und Rechnungen auf die neuen Rechnung kopieren, unter Berƒcksichtigung der Zeitrèume fƒr jeden beteiligten Auftrag, nicht aber die Fraktionen von Zeitrèumen. Die Zeilen, die Steuern sind werden nicht kopiert. Die Menge und Gesamtbetrag jeder Zeile wird durch die Menge der Zeitrèume multipliziert werden.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 4, 'description', 4, 'Cette tâche copiera toutes les lignes sur les commandes et les factures vers la nouvelle facture, en prenant en compte les périodes concernées pour chaque commande, but not the fractions of periods. It will not copy the lines that are taxes. The quantity and total of each line will be multiplied by the amount of periods.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 4, 'title', 3, 'Standard Rechnungszusammensetzung.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 4, 'title', 4, 'Composition de la facture par défaut.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 50, 'description', 3, 'Ein externer Bereitstellungs plug-in für die Kommunikation mit dem TeliaSonera MMSC.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 50, 'description', 4, 'Un plugin d''approvisionnement externe pour communiquer avec le MMSC de TeliaSonera.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 50, 'title', 3, 'MMSC externe Bereitstellungsaufgabe');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 50, 'title', 4, 'Tâche d''approvisionnement externe pour MMSC.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 51, 'description', 3, 'Dieser Filter wird nur Rechnungen mit einem positiven Saldo auf die nächste Rechnung übertragen.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 51, 'description', 4, 'Ce plug-in filtrera uniquement les factures avec un solde positif devant être reportées sur la facture suivante.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 51, 'title', 3, 'Filtert negative Rechnungen für Übertragungen.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 51, 'title', 4, 'Filtre les factures négative pour les reports.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 52, 'description', 3, 'Es wird eine Datei mit einer Zeile pro Rechnung generieren.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 52, 'description', 4, 'Il génèrera un fichier avec une ligne par facture générée.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 52, 'title', 3, 'Datei-Rechnungs Exporteur.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 52, 'title', 4, 'Exportateur de fichier de factures.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 53, 'description', 3, 'Es wird ein Bündel von Vorschriften nennen, wenn ein internes Ereignis eintritt.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 53, 'description', 4, 'Il appellera un ensemble de règles lorsqu''un évènement interne se produira.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 53, 'title', 3, 'Regel Caller für ein Ereignis.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 53, 'title', 4, 'Contrôleur de règles pour un évènement.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 54, 'description', 3, 'Es wird das dynamische Gleichgewicht eines Kunden (Prepaid-oder Kreditlimit) aktualisieren, wenn Ereignisse mit Auswirkungen auf das Gleichgewicht auftreten.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 54, 'description', 4, 'Il mettra à jour le solde dynamique d''un client (prépayé ou limite de crédit) si des évènements affectant le solde se produisent.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 54, 'title', 3, 'Dynamischer Balance Manager');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 54, 'title', 4, 'Gestionnaire de solde dynamique');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 55, 'description', 3, 'Für die Echtzeit-Vermittlung benutzt, dieser Plug-in wird einen Anruf auf der Grundlage des aktuellen dynamischen Gleichgewichts eines Kunden validieren.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 55, 'description', 4, 'Utilisé pour la médiation en temps réel, ce plugin validera un appel selon le solde dynamique actuel d''un client.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 55, 'title', 3, 'Balanceprüfer auf der Grundlage der Kundenbilanz.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 55, 'title', 4, 'Validateur de solde basé sur le solde du client.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 56, 'description', 3, 'Für die Echtzeit-Vermittlung benutzt, dieses Plug-in wird einen Anruf auf der Grundlage eines Bündels oder Regeln validieren');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 56, 'description', 4, 'Utilisé pour la médiation en temps réel, ce plugin validera un appel selon un lot ou des règles.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 56, 'title', 3, 'Balanceprüfer basierend auf Regeln');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 56, 'title', 4, 'Validateur de solde basé sur des règles.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 57, 'description', 3, 'Integration mit dem Gateway-Zahlungs Zahlungsanbieter.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 57, 'description', 4, 'Intégration avec le système de traitement des paiements Payments Gateway.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 57, 'title', 3, 'Zahlungsanbiert für Zahlung Gateway.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 57, 'title', 4, 'Système de traitement de paiements Payments Gateway.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 58, 'description', 3, 'Speichert die Kreditkarteninformationen in dem Zahlungs-Gateway, anstatt der Jbilling DB.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 58, 'description', 4, 'Il enregistre les informations relatives à la carte bancaire sur la passerelle de paiement, au lieu de la base de données jBilling.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 58, 'title', 3, 'Kreditkarten werden extern gespeichert.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 58, 'title', 4, 'Les cartes bancaires sont stockées en externe.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 59, 'description', 3, 'Dies ist ein regelbasierter Plug-in kompatibel mit dem Vermittlungsmodul von Jbilling 2.2.x. Er wird das tun, was die Grundelementmanager tut (eigentlich genannt); aber dann wird er auch externen Regeln ausführen. Diese externen Regeln haben die volle Kontrolle über die Veränderung der Bestellung welche neue Artikel bekommt.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 59, 'description', 4, 'Il s''agit d''un plugin basé sur des règles avec le module de médiation de jBilling 2.2.x., Il fera ce que le gestionnaire d''articles basique fait (l''appeler en réalité), mais ensuite il exécutera également des règles externes. Ces règles externes ont un contrôle total sur le changement de la commande qui reçoit de nouveaux articles.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 59, 'title', 3, 'Artikelregel Manager 2');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 59, 'title', 4, 'Gestionnaire de l''article Règles 2');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 5, 'description', 3, ' Entscheidet, ob eine Bestellung in einer Rechnung fƒr einen bestimmten Abrechnungsprozess einbezogen werden soll. Dies geschieht, indem man die Abrechnungszeitspanne, den Zeitraum, die aktive Zeit seit/bis, usw berechnet');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 5, 'description', 4, 'Décide si une commande doit être incluse dans une facture pour un processus de facturation donné.  Cela s''effectue en prenant la période déterminée pour le processus de facturation, la période de commande, the active since/until, etc.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 5, 'title', 3, 'Standard Bestellungs Filter');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 5, 'title', 4, 'Filtre standard pour les commandes');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 60, 'description', 3, 'Dies ist ein regelbasierter Plug-in, kompatibel mit dem Vermittlungsverfahren von Jbilling 2.2.x und besser. Er berechnet die Gesamtleitung für einen Auftrag (in der Regel ist dies der Preis, multipliziert mit der Menge); so dass externen Regeln durchgeführt werden können.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 60, 'description', 4, 'Il s''agit d''un plugin basé sur des règles, compatible avec les versions du processus de médiation de jBilling 2.2.x et supérieures. Il calcule le total pour une ligne de commande (généralement il s''agit du prix multiplié par la quantité), permettant ainsi l''exécution des règles externes.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 60, 'title', 3, 'Regeln Gesamtzeilen- 2');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 60, 'title', 4, 'Règles du total de la ligne - 2');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 61, 'description', 3, 'Dies ist ein regelbasierter Plug-in kompatibel mit dem Vermittlungsmodul von Jbilling 2.2.x. Er gibt einen Preis zu einem Artikel an, durch Ausführen externer Vorschriften. Anschließend können Sie Logik extern für die Preise hinzufügen. Er ist auch mit dem Vermittlungsverfahren durch den Zugang zu der Vermittlungs Preisdaten integriert.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 61, 'description', 4, 'Il s''agit d''un plugin basé sur des règles avec le module de médiation de jBilling 2.2.x., Il donne un prix à un article en appliquant des règles externes. Vous pouvez ajouter une logique externe pour la tarification. Il est également intégré avec le processus de médiation en ayant accès aux données de tarification de la médiation.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 61, 'title', 3, 'Regel Preisliste 2');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 61, 'title', 4, 'Règles de tarification 2');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 63, 'description', 3, 'Eine falscher Plug-in, um Zahlungen, die extern gespeichert werden würden zu testen.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 63, 'description', 4, 'Un faux plugin pour tester les paiements qui seraient stockées en externe.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 63, 'title', 3, 'Test Zahlungprozessor für externe Speicher.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 63, 'title', 4, 'Système de traitement des paiements test pour stockage externe.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 64, 'description', 3, 'Zahlungsprozessor-Plug-in, mit RBS WorldPay integriert');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 64, 'description', 4, 'Plugin de système de traitement des paiements à intégrer avec RBS WorldPay.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 64, 'title', 3, 'WorldPay Integration');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 64, 'title', 4, 'Intégration de WorldPay.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 65, 'description', 3, ' Zahlungsprozessor-Plug-in, mit RBS WorldPay integriert. Er speichert die Kreditkarteninformationen (Nummer, usw.) in dem Gateway.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 65, 'description', 4, 'Plugin de système de traitement des paiements à intégrer avec RBS WorldPay. Il stocke les informations relatives à la carte bancaire (numéro, etc) sur la passerelle.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 65, 'title', 3, 'WorldPay Integration mit externem Speicher');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 65, 'title', 4, 'Intégration de WorldPay avec stockage externe.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 66, 'description', 3, 'Überwacht das Gleichgewicht von einem Kunden und beim Erreichen eines Limits, fordert eine Echtzeit-Zahlung an');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 66, 'description', 4, 'Il contrôle le solde d''un client et au moment d''atteindre une limite, il demande un paiement en temps réel');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 66, 'title', 3, 'Auto Aufladen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 66, 'title', 4, 'Recharge automatique.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 67, 'description', 3, 'Zahlungsanbiter für Integration mit dem Beanstream Zahlungs gateway');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 67, 'description', 4, 'Système de traitement des paiements pour une intégration avec la passerelle de paiement Beanstream.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 67, 'title', 3, 'Beanstream Gateway Integration');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 67, 'title', 4, 'Intégration d''une passerelle Beanstream');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 68, 'description', 3, 'Zahlunganbieter für Integration mit dem Sage Zahlungs Gateway');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 68, 'description', 4, 'Système de traitement des paiements pour une intégration avec la passerelle de paiement Sage.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 68, 'title', 3, 'Sage Zahlungs gateway Integration');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 68, 'title', 4, 'Intégration d''une passerelle de paiement Sage');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 69, 'description', 3, 'Wird aufgerufen, wenn die Abrechnung läuft um auszuwählen welche Benutzer bewertet werden. Diese grundlegende Implementierung zeigt einfach jedem Benutzer an der nicht im gesperrten (oder schlimmer) Status ist');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 69, 'description', 4, 'Appelé lorsque le processus de facturation s''exécute pour sélectionner quels utilisateurs évaluer. Cet exercice de base renvoie simplement le fait que tous les utilisateurs n''ont pas un statut Suspendu (ou pire)');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 69, 'title', 3, 'Standard Abrechnungs Benutzer Filter ');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 69, 'title', 4, 'Filtre utilisateurs pour le processus de facturation standard');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 6, 'description', 3, ' Gibt immer True zurƒck, was bedeutet, dass die ƒberfèllige Rechnung auf eine neue Rechnung ƒbertragen wird.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 6, 'description', 4, 'Renvoie toujours une valeur vraie, ce qui signifie que la facture impayée sera reportée sur une nouvelle facture.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 6, 'title', 3, 'Standard Rechnungs Filter');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 6, 'title', 4, 'Filtre pour les factures standard');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 70, 'description', 3, 'Wird aufgerufen, wenn die Abrechnung läuft, um auswählen, welche Benutzer zu bewerten. Dies zeigt nur Benutzer mit Bestellungen an, die ein nächstes Abrechnungsdatum früher als den Abrechnungsprozess haben.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 70, 'description', 4, 'Appelé lorsque le processus de facturation s''exécute pour sélectionner quels utilisateurs évaluer. Il ne renvoie que les utilisateurs avec des commandes dont la date de la prochaine facture est antérieure au processus de facturation.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 70, 'title', 3, 'Auswahl Abrechnungs Benutzerfilter');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 70, 'title', 4, 'Filtre utilisateurs pour le processus de facturation sélectif');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 71, 'description', 3, 'Ereignisdatensätze mit Fehlern werden in einer Datei gespeichert');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 71, 'description', 4, 'Les enregistrements avec des erreurs sont enregistrés dans un fichier');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 71, 'title', 3, 'Vermittlungs Datei Fehler Steuerungsprogramm');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 71, 'title', 4, 'Gestionnaire des erreurs du fichier de médiation');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 73, 'description', 3, ' Ereignis-Datensätzen mit Fehler werden in einer Datenbanktabelle gespeichert');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 73, 'description', 4, 'Les enregistrements avec des erreurs sont enregistrés dans la table d''une base de données');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 73, 'title', 3, 'Vermittlungsdatensatz basiertes Fehler Steuerungsprogramm');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 73, 'title', 4, 'Gestionnaire des erreurs de la base de données de médiation');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 75, 'description', 3, 'Sendet Zahlungen an PayPal als Zahlungsgateway und speichert auch Kreditkarteninformationen in PayPal');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 75, 'description', 4, 'Il envoie des paiements à PayPal en tant que passerelle de paiement et il stocke également les informations relatives à la carte bancaire dans PayPal');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 75, 'title', 3, 'Paypal Integration mit externem Speicher');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 75, 'title', 4, 'Intégration de PayPal avec stockage externe.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 76, 'description', 3, 'Sendet Zahlungen an authorize.net als Zahlungs-Gateway und speichert auch Kreditkarteninformationen in authorize.net');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 76, 'description', 4, 'Il envoie des paiements à authorize.net en tant que passerelle de paiement et il stocke également les informations relatives à la carte bancaire dans authorize.net');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 76, 'title', 3, 'Authorize.net Integration mit externem Speicher');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 76, 'title', 4, 'Intégration de authorize.net avec stockage externe.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 77, 'description', 3, 'Delegiert die eigentliche Zahlungsabwicklung zu einem anderen Plug-in auf der Grundlage der Zahlungsmethode der Zahlung.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 77, 'description', 4, 'Il délègue le traitement réel des paiements à un autre plugin selon la méthode de paiement.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 77, 'title', 3, 'Zahlungsmethode Router Zahlungsprozessor');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 77, 'title', 4, 'Système de traitement des paiements avec routage selon la méthode de paiement');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 78, 'description', 3, 'Erzeugt Regeln dynamisch, basiert auf auf eine Velocity Vorlage.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 78, 'description', 4, 'Il génère des règles de manière dynamique selon un modèle Velocity');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 78, 'title', 3, 'Dynamischer Regelgenerator');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 78, 'title', 4, 'Générateur de règles dynamiques');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 79, 'description', 3, 'Dies ist ein Plugin, das sich mit Preisberechnungbefasst, auf die it von den implemenations der verschiedenen Preismodelle basiert.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 79, 'description', 4, 'Il s''agit d''un plugin qui gère le calcul des tarifs selon l''exécution de différents modèles de prix.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 79, 'title', 3, 'Preismodell Preisaufgabe');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 79, 'title', 4, 'Tâche de tarification selon des modèles de prix.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 7, 'description', 3, 'Berechnet den Beginn und den Endzeitraum in einer Rechnung. Dies geschieht, indem man die Abrechnungszeitspanne, den Zeitraum, die aktiven Zeit seit/bis, usw berechnet.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 7, 'description', 4, 'Calcule le début et la fin de la période à inclure dans une facture. Cela s''effectue en prenant la période déterminée pour le processus de facturation, la période de commande, the active since/until, etc.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 7, 'title', 3, 'Standard Bestellungszeitraum');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 7, 'title', 4, 'Périodes de commande par défaut');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 80, 'description', 3, 'Eine geplante Aufgabe, um den Abrechnungsablauf durchzuführen.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 80, 'description', 4, 'Une tâche programmée pour exécuter le processus de facturation.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 80, 'title', 3, 'Abrechnungsaufgabe');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 80, 'title', 4, 'Tâche Processus de facturation');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 81, 'description', 3, 'Eine geplante Aufgabe, um den Vermittlungsablauf auszuführen.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 81, 'description', 4, 'Une tâche programmée pour exécuter le processus de médiation.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 81, 'title', 3, 'Vermittlungsprozessaufgabe');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 81, 'title', 4, 'Tâche Processus de médiation');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 87, 'description', 3, ' Datiert einen Benutzer auf der Grundlage der Anzahl der Tage, die das Konto überfällig ist.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 87, 'description', 4, 'Détermine la phase d''un utilisateur selon le nombre de jours pendant lequel le compte est débiteur.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 87, 'title', 3, 'Einfache Datierung');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 87, 'title', 4, 'Avancement basique des phases');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 88, 'description', 3, 'Eine geplante Aufgabe, um den Datierungsprozess auszuführen.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 88, 'description', 4, 'Une tâche programmée pour exécuter le processus d''avancement des phases.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 88, 'title', 3, 'Datierungprozessaufgabe');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 88, 'title', 4, 'Tâche Processus d''avancement des phases');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 89, 'description', 3, 'Datiert einen Benutzer auf der Grundlage der Anzahl von Werktagen (außer an Feiertagen), die das Konto überfällig ist.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 89, 'description', 4, 'Détermine la phase d''un utilisateur selon le nombre de jours ouvrés (hors week-end et jours fériés) pendant lequel le compte est débiteur.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 89, 'title', 3, 'Werktag Datierung');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 89, 'title', 4, 'Avancement des phases en jours ouvrés');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 8, 'description', 3, 'Integration mit dem  authorize.net Zahlungs Gateway.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 8, 'description', 4, 'Intégration avec la passerelle de paiement authorize.net.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 8, 'title', 3, 'Authorize.net Zahlungsprozessor');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 8, 'title', 4, 'Système de traitement des paiements Authorize.net');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 90, 'description', 3, 'Eine steckbare Aufgabe der Art von AbstractChargeTask um einen Steuer Artikel auf die Rechnung hinzuzüfugen, mit einer Einrichtung der Freistellung um einen Artikel freizugeben oder einen Kunden freizustellen.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 90, 'description', 4, 'Une tâche pour utiliser le plugin du type AbstractChargeTask pour appliquer un article fiscal à une facture avec une fonction permettant d''exempter un article ou un client.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 90, 'title', 3, 'Einfache Steuer Zusammensetzungsaufgabe');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 90, 'title', 4, 'Tâche Composition fiscale simple');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 91, 'description', 3, 'Eine steckbare Aufgabe der Art von AbstractChargeTask um einen Steuer Artikel auf die Rechnung hinzuzufügen, wenn der Ländercode des Partners übereinstimmt.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 91, 'description', 4, 'Une tâche pour utiliser un plugin AbstractChargeTask pour appliquer un article fiscal à la facture si le code pays du partenaire correspond.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 91, 'title', 3, 'Landsteuerrechnung Zusammensetzungsaufgabe ');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 91, 'title', 4, 'Tâche Composition d''une facture de taxe nationale');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 92, 'description', 3, 'Eine steckbare Aufgabe der Art von AbstractChargeTask um eine Strafe auf eine Rechnung hinzuzufügen, die ein Fälligkeitsdatum über einen konfigurierbaren Zeitraum hinweg hat.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 92, 'description', 4, 'Une tâche pour utiliser un plugin du type AbstractChargeTask pour appliquer une pénalité à une facture dont la date d''échéance est au-delà de la période configurable en termes de nombre de jours.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 92, 'title', 3, 'Zahlungsbedingungen Strafaufgabe');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 92, 'title', 4, 'Tâche Pénalité relative aux Conditions de Paiement');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 96, 'description', 3, 'Dies ist ein Abonnement Ereignis basiertes Plugin. Es nimmt Datensätze aus dem Vermittlungsverfahren auf und übersetzt sie in aussagekräftige Rechnungsdaten. Es konzentriert sich auf wiederkehrende Bestellungen. Wenn kein Bestellung verfügbar ist, erstellt es eine neue.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 96, 'description', 4, 'Plugin basé sur les évènements liés aux abonnements. Il effectue des enregistrements à partir du processus de médiation et il les traduit en données de facturation pertinentes. Il se centre sur des commandes récurrentes. Si aucune facture n''est disponible, il en créer une nouvelle.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 96, 'title', 3, 'Abonnement Ereignisprozessor');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 96, 'title', 4, 'Système de traitement des évènements liés aux abonnements');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 97, 'description', 3, 'Diese Aufgabe ist zum Anlegen eines % -Satzes oder einem festen Strafbetrag auf eine überfällige Rechnung verantwortlich. Diese Aufgabe ist aussagekräftig, weil es diese Aktion kurz vor dem Abrechnungsprozess der gesammelten Bestellungen ausführt.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 97, 'description', 4, 'Cette tâche est chargée d''appliquer une pénalité correspondant à un pourcentage ou à un montant fixe sur une facture impayée. Cette tâche est très efficace car elle effectue cette action juste avant que le processus de facturation ne collecte les commandes.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 97, 'title', 3, 'Strafaufgabe für überfällige Rechnung');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 97, 'title', 4, 'Tâche Pénalité sur les impayés');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 9, 'description', 3, 'Teil dem Benutzer etwas per Email mit. Text und HTML Emails sind unterstƒzt.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 9, 'description', 4, 'Notifie un utilisateur par l''envoi d''un e-mail. Les e-mails texte et HTML sont pris en charge');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 9, 'title', 3, 'Standard Email Mitteilungen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24, 9, 'title', 4, 'Notification standard par e-mail');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35, 15, 'description', 3, 'Kredit');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35, 15, 'description', 4, 'Crédit');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35, 1, 'description', 3, 'Scheck');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35, 1, 'description', 4, 'Chèque');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35, 2, 'description', 3, 'Visa');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35, 2, 'description', 4, 'Visa');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35, 3, 'description', 3, 'MasterCard');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35, 3, 'description', 4, 'MasterCard');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35, 4, 'description', 3, 'AMEX');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35, 4, 'description', 4, 'AMEX');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35, 5, 'description', 3, 'ACH');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35, 5, 'description', 4, 'ACH');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35, 6, 'description', 3, 'Entdeckung');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35, 6, 'description', 4, 'Discover');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35, 7, 'description', 3, 'Diners');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35, 7, 'description', 4, 'Diners');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35, 8, 'description', 3, 'PayPal');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (35, 8, 'description', 4, 'PayPal');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 10, 'description', 3, 'Malaysischer Ringgit');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 10, 'description', 4, 'Ringgit malaysien');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 11, 'description', 3, 'Australischer Dollar');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (41, 1, 'description', 3, 'Erfoglreich');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 11, 'description', 4, 'Dollar australien');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (41, 1, 'description', 4, 'Réussite');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (41, 2, 'description', 3, 'Fehlgeschlagen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (41, 2, 'description', 4, 'Échec');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (41, 3, 'description', 3, 'Prozessor nicht verfƒgbar');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (41, 3, 'description', 4, 'Système de traitement indisponible');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (41, 4, 'description', 3, 'Eingetreten');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (41, 4, 'description', 4, 'Saisie');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 1, 'description', 3, 'US-Dollar');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 1, 'description', 4, 'Dollar américain');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 2, 'description', 3, 'Kanadischer Dollar');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 2, 'description', 4, 'Dollar canadien');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 3, 'description', 3, 'Euro');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 3, 'description', 4, 'Euro');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 4, 'description', 3, 'Yen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 4, 'description', 4, 'Yen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 5, 'description', 3, 'Pfund Sterling');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 5, 'description', 4, 'Livre Sterling');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 60, 'description', 4, 'Dollar australien');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46, 11, 'description', 3, 'Steckbare Aufgabenwartung');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46, 11, 'description', 4, 'Entretien des tâches pour utiliser des plugins');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46, 1, 'description', 3, 'Abrechnungsprozess');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 61, 'description', 4, 'AUd');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46, 1, 'description', 4, 'Processus de facturation');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46, 2, 'description', 3, 'Benutzerwartung');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 62, 'description', 4, 'Dollar australien');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46, 2, 'description', 4, 'Entretien des préférences de l''utilisateur');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46, 3, 'description', 3, 'Artikelwartung');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 63, 'description', 4, 'Dollar australien');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46, 3, 'description', 4, 'Entretien des articles');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46, 4, 'description', 3, 'Artikeltyp Wartung');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 64, 'description', 4, 'Bitcoin');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46, 4, 'description', 4, 'Entretien du type d''articles');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46, 5, 'description', 3, 'Artikel Kundenpreis Wartung');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46, 5, 'description', 4, 'Entretien du prix de l''article pour l''utilisateur');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46, 6, 'description', 3, 'Promotion Wartung');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46, 6, 'description', 4, 'Entretien des promotions');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46, 7, 'description', 3, 'Bestellungswartung');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46, 7, 'description', 4, 'Entretien des commandes');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46, 8, 'description', 3, 'Kreditkareten Wartung');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46, 8, 'description', 4, 'Entretien des cartes bancaires');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46, 9, 'description', 3, 'Rechnungswartung');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (46, 9, 'description', 4, 'Entretien de la facture');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 6, 'description', 3, 'Won');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 6, 'description', 4, 'Won');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 10, 'description', 3, ' Ein Abrechnungprozess lèuft, aber eine Prƒfung wurde als ungenehmigt befunden.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 10, 'description', 4, 'Exécution d''un processus de facturation, mais un examen s''avère non approuvé');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 11, 'description', 3, ' Ein Abrechnungprozess lèuft, eine Prƒfung ist notwendig aber wurde nicht gefunden.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 11, 'description', 4, 'Exécution d''un processus de facturation, un examen est requis mais non présent.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 12, 'description', 3, 'Ein Benutzerstatus wurde geèndert.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 12, 'description', 4, 'Le statut d''un utilisateur a été modifié.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 13, 'description', 3, 'Ein Bestellungszustand wurde geèndert.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 13, 'description', 4, 'Le statut d''une commande a été modifié.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 14, 'description', 3, ' Ein Benutzer musste vegƒted werden, aber keine weiteren Schritte sind konfiguriert.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 14, 'description', 4, 'Un utilisateur doit être à un stade, mais il n''y a plus d''étapes configurées');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 15, 'description', 3, 'Ein Partner hat eine Bezahlung, aber kein Bezahlungsinstrument.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 15, 'description', 4, 'Un paiement est prêt pour un partenaire, mais aucun instrument de paiement.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 16, 'description', 3, 'Eine Bestellung wurde manuell auf eine Rechnung hinzugefƒgt.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 16, 'description', 4, 'Un bon de commande a été manuellement appliqué à une facture.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 17, 'description', 3, 'Die Bestellungszeile wurde aktualisiert');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 17, 'description', 4, 'La ligne de commande a été mise à jour');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 18, 'description', 3, 'Das Abrechnunsdatung der Betellung wurde geändert');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 18, 'description', 4, 'La prochaine de facturation des commandes a été modifiée');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 19, 'description', 3, 'Letzer API-Aufruf, um die Benutzer Abonnement Zustandsübergänge zu erhalten');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 19, 'description', 4, 'Dernier appel API pour obtenir les changements du statut des abonnements des utilisateurs');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 1, 'description', 3, 'Eine voraus bezahlte Bestellung hat noch nicht abgerechneten Zeit vor dem Abrechnungsdatum');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 1, 'description', 4, 'Une commande prépayée comprend du temps non facturé avant la date de traitement de la facturation');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 20, 'description', 3, 'Benutzer Abonnement Status wurde geändert');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 20, 'description', 4, 'Le statut de l''abonnement de l''utilisateur a changé');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 21, 'description', 3, 'Benutzerkonto ist jetzt gesperrt');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 21, 'description', 4, 'Le compte utilisateur est désormais bloqué');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 22, 'description', 3, 'Die Hauptabonnement Markierung der Betstellung wurde geändert');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 22, 'description', 4, 'La case à cocher Abonnement principal pour les commandes a été modifiée');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 23, 'description', 3, 'Alle einmaligen Bestellungen die Vermittlung befanden sich im beendeten Status');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 23, 'description', 4, 'Toutes les commandes uniques trouvées par la médiation avaient le statut Terminée');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 24, 'description', 3, 'Eine gültige Zahlungsmethode konnte nicht gefunden werden. Die Zahlungsanforderung wurde storniert');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 24, 'description', 4, 'Aucune méthode de paiement valide n''a été trouvée. La demande de paiement a été annulée');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 25, 'description', 3, 'Eine neue Zeile wurde erstellt');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 25, 'description', 4, 'Une nouvelle ligne a été créée');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 26, 'description', 3, 'Eine abrechnete Bestellung wurde storniert, eine Kreditbestellung wurde erstellt');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 26, 'description', 4, 'Une commande facturée a été annulée, un ordre de crédit a été créé');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 27, 'description', 3, 'Eine Benutzer ID wurde auf die Sperrliste hinzugefügt');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 27, 'description', 4, 'Un identifiant utilisateur a été ajouté à la liste noire');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 28, 'description', 3, 'Eine Benutzer ID wurde von der Sperrliste entfernt');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 28, 'description', 4, 'Un identifiant utilisateur a été supprimé de la liste noire');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 29, 'description', 3, 'Verwendet einen Bereitstellungsbefehl mit einem UUID');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 29, 'description', 4, 'A publié une commande d''approvisionnement en utilisant un UUId');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 2, 'description', 3, ' Bestellung hat keine aktive Zeit zum Zeitpunkt des Prozesses.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 2, 'description', 4, 'La commande n''a pas d''heure active à la date du traitement.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 30, 'description', 3, 'Es wurde ein Befehl für die Bereitstellung veröffentlicht');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 30, 'description', 4, 'Une commande d''approvisionnement a été publiée');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 31, 'description', 3, 'Der Bereitstellungsstatus einer Bestellzeile hat sich geändert');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 31, 'description', 4, 'Le statut d''approvisionnement d''une ligne de commande a changé');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 32, 'description', 3, 'Benutzer Abonnement Status wurde NICHT geändert');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 32, 'description', 4, 'Le statut de l''abonnement de l''utilisateur n''a PAS changé');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 33, 'description', 3, 'Die dynamische Balance eines Benutzers hat sich geändert');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 33, 'description', 4, 'Le solde dynamique d''un utilisateur a changé');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 34, 'description', 3, 'Die Rechnung wenn eine Untermarkierung sich geändert hat');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 34, 'description', 4, 'La facture si la case à cocher Enfant a changé');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 35, 'description', 4, 'Une commande revendeur a été créée pour l''entité racine au cours de la génération d''une facture pour une entité enfant.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 37, 'description', 4, 'Une tentative de connexion infructueuse a été effectuée.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 3, 'description', 3, ' Mindestens ein kompletter Zeitraum ist abrechenbar.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 3, 'description', 4, 'Au moins une période complète doit être facturable.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 4, 'description', 3, 'Bereits fƒr das jetzige Datum abgrechnet.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 4, 'description', 4, 'Déjà facturée pour la date actuelle.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 5, 'description', 3, ' Diese Bestellung musste im letzten Prozess als ausgeschlossen markiert werden.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 5, 'description', 4, 'Cette commande a dû être exclu lors du dernier traitement.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 6, 'description', 3, ' Vorausbezahlte Bestellung wird nach dem Verfallsprozess bearbeitet.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 6, 'description', 4, 'La commande prépayée est traitée après son expiration');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 7, 'description', 3, 'Eine Linie wurde als gelÖscht markiert.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 7, 'description', 4, 'Une ligne a été signalée comme supprimée.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 8, 'description', 3, 'Ein Benutzerpassword wurde geèndert.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 8, 'description', 4, 'Le mot de passe d''un utilisateur a été modifié.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 9, 'description', 3, 'Eine Linie wurde aktualisiert.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47, 9, 'description', 4, 'Une ligne a été mise à jour.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 7, 'description', 3, 'Schweizer Franken');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 7, 'description', 4, 'Franc suisse');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 8, 'description', 3, 'Schwedische Krone');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 8, 'description', 4, 'couronne suédoise');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 9, 'description', 3, 'Singapur Dollar');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (4, 9, 'description', 4, 'Dollar de Singapour');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 13, 'description', 3, 'Selbstbelieferung von Papierrechnungen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 13, 'description', 4, 'Factures papier par courrier postal');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 13, 'instruction', 3, 'Auf ''1'' einstellen um Rechnungen als Abrechnungsunternehmen per Email zu schicken. “0” um Rechnungen als jBilling zu schicken.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 13, 'instruction', 4, 'Configurez sur ''1'' pour envoyer des factures par e-mail sous le nom de la société de facturation. Sur ''0'' pour transmettre les factures en tant que jBilling.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 14, 'description', 3, 'Kundenanmerkungen zur Rechnung hinzufƒgen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 14, 'description', 4, 'Inclure les notes du client sur la facture');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 14, 'instruction', 3, 'Auf ''1'' einstellen um Anmerkungen in Rechnungen anzuzeigen, “0” um dies auszuschalten.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 14, 'instruction', 4, 'Configurez sur ''1'' pour afficher des notes sur les factures'', sur ''0'' pour désactiver.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 15, 'description', 3, 'Tage vor Ablauf der Auftragsbenachrichtigung');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 15, 'description', 4, 'Jours avant l''expiration de la notification de la commande');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 15, 'instruction', 3, 'Tage vor dem Bestellungs ''aktiv bis '' Datum um die 1. Benachrichtigung zu senden. Leer lassen, um zu deaktivieren.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 15, 'instruction', 4, 'Jours avant la date ''actives jusqu''au'' des commandes pour envoyer la 1ère notification. Laissez ce champ vide pour désactiver.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 16, 'description', 3, 'Tage vor Ablauf der Auftragsbenachrichtigung 2');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 16, 'description', 4, 'Jours avant l''expiration pour la notification de la commande 2');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 16, 'instruction', 3, 'Tage vor dem Bestellungs ''aktiv bis '' Datum um die 2. Benachrichtigung zu senden. Leer lassen, um zu deaktivieren.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 16, 'instruction', 4, 'Jours avant la date ''actives jusqu''au'' des commandes pour envoyer la 2ème notification. Laissez ce champ vide pour désactiver.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 17, 'description', 3, 'Tage vor Ablauf der Auftragsbenachrichtigung 3');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 17, 'description', 4, 'Jours avant l''expiration pour la notification de la commande 3');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 17, 'instruction', 3, 'Tage vor dem Bestellungs ''aktiv bis '' Datum um die 3. Benachrichtigung zu senden. Leer lassen, um zu deaktivieren.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 17, 'instruction', 4, 'Jours avant la date ''actives jusqu''au'' des commandes pour envoyer la 3ème notification. Laissez ce champ vide pour désactiver.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 18, 'description', 3, 'Rechnungsnummer Prèfix ');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 18, 'description', 4, 'Préfixe du numéro de facture');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 18, 'instruction', 3, ' Prefix Wert für generierte Rechnung öffentlichen Zahlen.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 18, 'instruction', 4, 'Valeur du préfixe pour les numéros publics des factures générés.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 19, 'description', 3, 'Nèchste Rechnungsnummer');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 19, 'description', 4, 'Prochain numéro de facture');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 19, 'instruction', 3, ' Der aktuelle Wert für die generierte Rechnung öffentlichen Zahlen. Neuen Rechnungen wird eine öffentliche Zahl zugewiesen durch Eröhung dieses Werts.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 19, 'instruction', 4, 'La valeur actuelle pour les numéros publics des factures générés. Les nouvelles factures se verront assignées un numéro public en incrémentant cette valeur.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 1, 'description', 3, ' Bezahlung mit dem Zahlungsprozess durchfƒhren ');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 1, 'description', 4, 'Traiter le paiement avec le processus de facturation');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 20, 'description', 3, 'Manuelle Rechnungslöschung');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 20, 'description', 4, 'Suppression manuelle de la facture');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 20, 'instruction', 3, 'Auf '' 1 '' einstellen, um es zu ermöglichen Rechnungen zu löschen, '' 0 '' um dies zu deaktivieren.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 20, 'instruction', 4, 'Configurez sur ''1'' pour autoriser la suppression des factures, sur ''0'' pour désactiver.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 21, 'description', 3, 'Rechnungserinnerungen benutzen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 21, 'description', 4, 'Utiliser des relances de facture');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 21, 'instruction', 3, ' Auf '' 1 '' einstellen um Rechnungsbenachrichtigungen zu erlauben '' 0 '' um dies zu deaktivieren.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 21, 'instruction', 4, 'Configurez sur ''1'' pour autoriser les notifications de relances, sur ''0'' pour désactiver.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 22, 'description', 3, 'Anzahl der Tage nach der Rechnungsgenerierung fƒr die erste Mahnung');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 22, 'description', 4, 'Nombre de jours après la génération de la facture pour la première relance');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 23, 'description', 3, 'Anzahl der Tage fƒr die nèchste Erinnerung');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 23, 'description', 4, 'Nombre de jours pour la prochaine relance');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 24, 'description', 3, 'Datei Fattura Fine Mese');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 24, 'description', 4, 'Data Fattura Fine Mese');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 24, 'instruction', 3, 'Auf ''1'' einstellen um es zu ermögliche, “0” um es zu deakivieren.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 24, 'instruction', 4, 'Configurez sur ''1'' pour activer, sur ''0'' pour désactiver.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 25, 'description', 3, 'Verwenden Sie überfällig Strafen (Zinsen).');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 25, 'description', 4, 'Utiliser des pénalités pour impayés (intérêt).');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 25, 'instruction', 3, ' Auf ''1'' einstellen, um den Abrechnungsablauf zu ermöglichen Verzugszinsen zu berechnen, '' 0 '' um dies zu deaktivieren. Berechnung der Zinsen wird durch den gewählten Straf Plug-in bearbeitet.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 25, 'instruction', 4, 'Configurez sur ''1'' pour activer le processus de facturation pour calculer les intérêts sur les retards de paiement, sur ''0'' pour désactiver. Le calcul des intérêts est géré par le plugin des pénalités sélectionné.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 27, 'description', 3, 'Bestellungsvorgriffe verwenden.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 27, 'description', 4, 'Utiliser l''anticipation des commandes.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 27, 'instruction', 3, 'Auf ''1'' einstellen, um den ''OrderFilterAnticipateTask'' zu verwenden, um eine Anzahl von Monate im Voraus in Rechnung zu setzen, '' 0 '' um dies zu deaktivieren. Plug-ins müssen separat konfiguriert werden.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 27, 'instruction', 4, 'Configurez sur ''1'' pour utiliser OrderFilterAnticipateTask pour facturer un certain nombre de mois à l''avance, sur ''0'' pour désactiver. Le plugin doit être configuré séparément.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 28, 'description', 3, 'Paypal Konto.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 28, 'description', 4, 'Compte PayPal.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 28, 'instruction', 3, 'PayPal Kontoname .');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 28, 'instruction', 4, 'Nom du compte PayPal.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 29, 'description', 3, 'Paypal Knopf URL.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 29, 'description', 4, 'URL du bouton PayPal.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 29, 'instruction', 3, 'Eine URL, wo sich die Grafik des PayPal-Button befindet. Die Taste wird für die Kunden angezeigt, wenn sie eine Zahlung durchführen. Der Standardwert ist in der Regel die beste Option, es sei denn, eine andere Sprache wird benötigt.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 29, 'instruction', 4, 'Une URL où l''image du bouton PayPal est présente. Le bouton est affiché pour les clients lorsqu''ils effectuent un paiement. l''option Par défaut est la meilleure, sauf quand une autre langue est nécessaire.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 2, 'description', 3, 'URL der CSS Datei');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 2, 'description', 4, 'URL du fichier CSS');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 30, 'description', 3, 'URL für HTTP Datierungsaufruf.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 30, 'description', 4, 'URL pour le rappel des phases de vieillissement en HTTP.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 30, 'instruction', 3, 'URL des HTTP Rückrufs wenn der Datierungsprozess den Status eines Benutzers ändert.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 30, 'instruction', 4, 'URL pour le rappel au format HTTP afin d''invoquer le moment où le processus d''avancement des phases modifie le statut d''un utilisateur.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 31, 'description', 3, ' Kontinuierliche Rechnungsdaten verwenden.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 31, 'description', 4, 'Utiliser des dates de facture continues.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 31, 'instruction', 3, 'Standard: leer. Diese Einstellung muss ein Datum (im Format JJJJ-MM-TT. Beispiel: 2000.01.31) sein, das System wird sicherstellen, dass alle Ihre Rechnungen ihre Daten in einer inkrementellen Weise haben. Jede Rechnung mit einer größeren '' ID '' wird auch ein größeres (oder gleiches) Datum haben. In anderen Worten, kann eine neue Rechnung kein früheres Datum als eine bestehende (ältere) Rechnung haben. Um diese Einstellung zu verwenden, setzen Sie diese als Kette mit dem Tag, andem es anfangen soll. Diese Einstellung wird nicht verwendet werden wenn es leer ist ');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 31, 'instruction', 4, 'Espace par défaut. Cette préférence doit être une date (au format aaaa-mm-dd. Exemple : 2000-01-31); le système s''assurera que les dates de toutes vos factures sont incrémentales. Toute facture avec un ''ID'' supérieur aura également une date postérieure (ou égale). En d''autres termes, '', a new invoice can not have an earlier date than an existing (older) invoice. To use this preference, set it as a string with the date where to start. This preference will not be used if blank');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 32, 'description', 3, 'PDF Rechnung zur Email hinzufügen.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 32, 'description', 4, 'Attacher une facture PDF aux notifications par e-mail.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 32, 'instruction', 3, 'Auf ''1'' einstellen, um eine PDF-Version der Rechnung für alle Rechnungs Benachrichtigungs-E-Mails anzuhängen. '' 0 '' um dies zu deaktivieren.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 32, 'instruction', 4, 'Configurez sur ''1'' pour joindre une version PDF de la facture à toutes les notifications de factures par e-mail. Sur ''0'' pour désactiver.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 33, 'description', 3, ' Erzwingen einer Bestellung pro Rechnung.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 33, 'description', 4, 'Forcer une commande par facture.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 33, 'instruction', 3, 'Auf ''1'' einstellen, um die ''zur separaten Rechnung hinzugefügt'' Markierung auf einer Bestellung anzuzeigen. ''0'' um dies zu deaktivieren.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 33, 'instruction', 4, 'Configurez sur ''1'' pour afficher la case à cocher ''inclure dans une facture séparée'' sur une commande. Sur ''0'' pour désactiver.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 35, 'description', 3, 'Bestellungs ID zu Rechnungszeilen hinzufügen.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 35, 'description', 4, 'Ajouter un ID de commande aux lignes de la facture.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 35, 'instruction', 3, 'Auf ''1'' einstellen , um die ID der Bestellung im Beschreibungstext der resultierenden Rechnungsposten hinzuzufügen. ''0'' um dies zu deaktivieren. Dies kann helfen, zu verfolgen, welche Aufträge für eine exakte Linie in einer Rechnung zuständig ist, wenn man bedenkt, dass viele Aufträge in einer einzigen Rechnung aufgenommen werden können.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 35, 'instruction', 4, 'Configurez sur ''1'' pour inclure l''ID de la commande dans le texte descriptif de la ligne de facture résultante. Sur ''0'' pour désactiver. Cela peut aider à suivre avec précision quelles sont exactement les commandes responsables pour une ligne sur une facture, en prenant en compte que de nombreuses commandes peuvent être incluses dans une facture unique.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 36, 'description', 3, 'Es Kunden erlauben Kontaktinformationen zu editieren.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 36, 'description', 4, 'Autoriser les clients à modifier ses propres coordonnées.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 36, 'instruction', 3, 'Auf ''1'' einstellen um es Kunden zu erlauben ihre eigenen Kontaktinformationen zu editieren. ''0'' um dies zu deaktivieren.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 36, 'instruction', 4, 'Configurez sur ''1'' pour autoriser les clients à modifier leurs propres coordonnées. Sur ''0'' pour désactiver.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 37, 'description', 3, 'Kreditkartennummern verstecken (verschleiern).');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 37, 'description', 4, 'Cacher (masquer) des numéros de carte bancaire.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 37, 'instruction', 3, 'Auf''1'' einstellen um all Kreditkartennummern zu verschleiern. ''0'' um dies zu deaktivieren. Wenn ausgewählt, sind Nummern für alle Benutzer verschleiert, sogar Admins, und in allen Dateisätzen.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 37, 'instruction', 4, 'Configurez sur ''1'' pour maquer tous les numéros des cartes bancaires. Sur ''0'' pour désactiver. Lorsque l''option est configurée, les chiffres sont masqués pour tous les utilisateurs, même les administrateurs, et dans tous les fichiers journaux.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 38, 'description', 3, 'Datierung mit dem Kundenabonnentenstatus vebinden.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 38, 'description', 4, 'Lien des phases d''avancement vers le statut d''abonné du client.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 38, 'instruction', 3, ' Auf ''1'' einstellen, um den Abo-Status eines Benutzers zu ändern, wenn der Benutzer datiert wird. ''0'' um dies zu deaktivieren.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 38, 'instruction', 4, 'Configurez sur ''1'' pour modifier le statut de l''abonnement d''un utilisateur lorsqu''il y a un avancement dans les phases de ce dernier. Sur ''0'' pour désactiver.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 39, 'description', 3, 'Benutzer nach fehlgeschlagenen Anmeldeversuchen sperren.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 39, 'description', 4, 'Bloquer l''utilisateur après des tentatives de connexion échouées.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 39, 'instruction', 4, 'Le nombre de tentatives à autoriser avant le blocage du compte utilisateur. Un compte utilisateur bloqué le sera pendant le nombre de minutes indiquées dans Préférence 68. Pour activer cette fonction de blocage, configurer la Préférence 68 sur une valeur différente de zéro est un plus.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 3, 'description', 3, 'URL der Logografik');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 3, 'description', 4, 'URL de l''image du logo');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 40, 'description', 3, 'Benutzerpasswörter nach zwei Tagen ablaufen lassen.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 40, 'description', 4, 'Faire expirer les mots de passe des utilisateurs après plusieurs jours.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 40, 'instruction', 3, 'Wenn größer als Null, stellt es die Anzahl der Tage dar, für die ein Passwort gültig ist. Nach diesen Tagen, ist das Passwort abgelaufen und der Benutzer ist gezwungen, es zu ändern.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 40, 'instruction', 4, 'Si la valeur est supérieure à zéro, Il représente le nombre de jours pendant lesquels un mot de passe est valide. Une fois ces jours passés, the password is expired and the user is forced to change it.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 41, 'description', 3, 'Hauptabonnement Bestellungen benutzen.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 41, 'description', 4, 'Utiliser les commandes de l''abonnement principal.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 41, 'instruction', 3, 'Auf ''1'' einstellen, um die Nutzung der ''Haupt Abonnement'' Markierung für Bestellungen zu ermöglichen. Diese Markierung wird nur durch das Vermittlungsverfahren gelesen, wenn festgelegt wird wo Bezahlungen eingefügt werden müssen, die von externen Ereignissen kommen.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 41, 'instruction', 4, 'Configurez sur ''1'' pour autoriser l''utilisation de la case à cocher ''abonnement principal'' pour les commandes. Cette case est uniquement lu par le processus de médiation au moment de déterminer où placer les frais provenant d''évènements externes. ');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 42, 'description', 3, 'Pro-rating benutzen.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 42, 'description', 4, 'Utiliser les paiements au prorata.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 42, 'instruction', 3, 'Auf '' 1 '' einstellen, um den Einsatz von pro-rating zu ermöglichen, um Bruchteile einer Zeitraum in Rechnung zu stellen. Zeigt das '' Zyklus '' Attribut einer Bestellung. Beachten Sie, dass Sie die entsprechenden Plug-Ins für diese Funktion konfigurieren müssen, um voll funktionsfähig zu sein.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 42, 'instruction', 4, 'Configurez sur ''1'' pour autoriser l''utilisation des paiements au prorata pour facturer des fractions d''une période. Afficher l''attribut ''cycle'' d''une commande. Notez que vous devez configurer les plugins correspondants pour que cette fonction soit totalement fonctionnelle.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 43, 'description', 3, 'Zahlungssperrliste benutzen.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 43, 'description', 4, 'Utiliser la liste noire des paiements.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 43, 'instruction', 3, 'Wenn die Zahlung Sperrfunktion verwendet wird, dies wird auf die ID der Konfiguration des PaymentFilterTask plug-in eingestellt. Siehe den Sperrlist-Abschnitt der Dokumentation.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 43, 'instruction', 4, 'Si la fonction d''inscription sur la liste noire des paiements est utilisée, cet élément est défini comme l''ID de configuration du plugin PaymentFilterTask. Consultez la section Liste noire de la documentation.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 44, 'description', 3, 'Negative Zahlugen erlauben.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 44, 'description', 4, 'Autoriser les paiements négatifs.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 44, 'instruction', 3, 'Auf ''1'' einstellen um negatives Zahlugen zu erlauben. ''0'' um dies zu deaktivieren');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 44, 'instruction', 4, 'Configurez sur ''1'' pour autoriser les paiements négatifs. Sur ''0'' pour désactiver.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 45, 'description', 3, 'Negative Rechnungszahlungen verzögern.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 45, 'description', 4, 'Retarder les paiements des factures négatives.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 45, 'instruction', 3, 'Auf '' 1 '' einstellen, um die Zahlung der negativen Rechnungsbeträge zu verzögern, wodurch die Balance auf die nächste Rechnung übertragen wird. Rechnungen, die negative Salden von anderen Rechnungen auf sie übertragen haben dürfen unverzüglich eine negative Zahlung (Kredit) durchführen, wenn nötig. ''0'' um dies zu deaktivieren. Präferenz 44 & 46 sind in der Regel ebenfalls aktiviert.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 45, 'instruction', 4, 'Configurez sur ''1'' pour retarder le paiement des montants de factures négatifs, '', causant le report su solde sur la facture suivante. Les factures ayant des soldes négatifs provenant d''autres factures sont autorisées à effectuer immédiatement un paiement négatif (crédit) si nécessaire. sur ''0'' pour désactiver. Les préférences 44 et 46 sont généralement également activées.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 46, 'description', 3, 'Rechnung ohne Bestellungen erlaube.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 46, 'description', 4, 'Autoriser les factures sans commandes.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 46, 'instruction', 3, 'Auf ''1'' einstellen, damit Rechnungen mit Negativsalden zu erlauben eine neue Rechnung zu erstellen, die nicht aus Bestellungen bestehet, so dass ihr Guthaben wird immer auf eine neue Rechnung übertragen wird, damit der Kredit erfolgen kann. ''0'' um dies zu deaktivieren. Präferenz 44 & 45 sind in der Regel ebenfalls aktiviert.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 46, 'instruction', 4, 'Configurez sur ''1'' pour autoriser les factures avec des soles négatifs à générer une nouvelle facture qui n''est pas composée de commandes afin que leurs soldes soient toujours reportés sur une nouvelle facture pour que le crédit soit pris en compte. Sur ''0'' pour désactiver. Les préférences 44 et 45 sont généralement également activées.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 47, 'description', 3, 'Zuletzt gelesene Vermittlungsbericht ID.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 47, 'description', 4, 'Dernier ID d''enregistrement la médiation lu.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 47, 'instruction', 3, 'ID des letzten Datensatzes durch das Vermittlungs verfahren. Dies wird verwendet, um festzustellen, welche Datensätze ''neu'' sind und gelesen weren müssen.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 47, 'instruction', 4, 'ID du dernier enregistrement lu par le processus de médiation. Cela sert à déterminer quels enregistrements sont ''nouveaux'' et doivent être lus.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 48, 'description', 3, 'Bereitstellung benutzen.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 48, 'description', 4, 'Utiliser l''approvisionnement.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 48, 'instruction', 3, 'Auf ''1'' einstellen um die Benutzung von Bereitstellungen zu erlauben. ''0'' um dies zu deaktivieren.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 48, 'instruction', 4, 'Configurez sur ''1'' pour autoriser l''utilisation de l''approvisionnement. Sur ''0'' pour désactiver.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 49, 'description', 3, 'Automatische Kundenaufladeschwelle.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 49, 'description', 4, 'Seuil de recharge automatique des clients.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 49, 'instruction', 3, 'Der Schwellwert für automatische Zahlungen. Prepaid-Nutzer mit einem eingestellten automatischen Wiederaufladungwert eingestellte erzeugen eine automatische Zahlung, wenn der Kontostand unter diesen Schwellwert fällt. Beachten Sie, dass Sie der AutoRechargeTask Plug-in für diese Funktion konfiguriert werden muss, um voll funktionsfähig zu sein.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 49, 'instruction', 4, 'La valeur seuil pour les paiements automatiques. Les utilisateurs prépayés avec une valeur de recharge automatique définie génèreront un paiement automatique à chaque fois que le solde du compte tombe sous ce seuil. Notez que vous devez configurer les plugins correspondants pour que le plugin AutoRechargeTask soit totalement fonctionnel.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 4, 'description', 3, 'Frist');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 4, 'description', 4, 'Délai supplémentaire');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 4, 'instruction', 3, 'Schonfrist in Tagen vor der Datierung eines Kunden mit einer überfälligen Rechnung.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 4, 'instruction', 4, 'Délai supplémentaire en jours avant l''avancement des phases d''un client avec un retard de paiement pour une facture.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 50, 'description', 3, 'Dezimale Rechnunsaufrundung.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 50, 'description', 4, 'Arrondissement des factures aux décimales.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 50, 'instruction', 3, 'Die Anzahl der Dezimalstellen welche auf der Rechnung ausgewiesen sind. Der Standardwert ist 2.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 50, 'instruction', 4, 'Le nombre de décimales à afficher sur la facture. Par défaut sur 2.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 51, 'description', 3, 'Minimum Balance um Datierung zu ignorieren');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 51, 'description', 4, 'Solde minimum pour lequel ignorer l''avancement des phases');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 51, 'instruction', 3, 'Minimum Balance, welche das Unternehmen bereit ist zu ignorieren, wenn überfällig auf einer Rechnung. Wenn dies eingestellt ist, wird dieser Wert bestimmen, ob der Nutzer hat genug Balance hat weiter zu datieren oder Benachrichtigungen für unbezahlten Rechnungen erhält');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 51, 'instruction', 4, 'Solde minimum que la société est prête à ignorer en cas de retard de paiement sur une facture. Si l''option est configurée, cette valeur déterminera si l''utilisateur a un solde suffisant pour continuer à avancer dans les phases ou pour recevoir des notifications pour des factures impayées');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 52, 'description', 3, 'Aktuelle Rechnung an alle überfälligen Mitteilungen anhängen.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 52, 'description', 4, 'Joindre la dernière facture à toutes les Notifications de retard de paiement.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 52, 'instruction', 3, 'Überfällig Mitteilungen 1, 2 und 3 hängen normalerweise keine Rechnungen an die E-Mail-Benachrichtigungen an. Mit dieser Einstellung kann die neueste Rechnung automatisch auf diese Mitteilungen befestigt werden.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 52, 'instruction', 4, 'Notification d''impayé. Impayés 1, 2 et 3 par défaut ne joignent pas de factures à la notification par e-mail. Avec cette préférence, la dernière facture peut être jointe automatiquement à ces notifications.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 53, 'description', 3, 'Spezifische Emails erzwingen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 53, 'description', 4, 'Forcer les e-mails uniques');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 53, 'instruction', 3, 'Auf 1 einstellen, um spezifische E-Mails zwischen den Benutzern/Kunden und den Unternehmen zu erzwingen. Ansonsten auf 0 gesetzt.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 53, 'instruction', 4, 'Configurez sur ''1'' pour forcer les e-mails uniques parmi les utilisateurs/clients dans la société. Sinon, configurez sur ''0''');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 55, 'description', 4, 'Code produit unique');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 55, 'instruction', 4, 'Autorise un code produit unique, S''il est défini, le code produit ou la référence interne d''un produit/article doit être forcé(e) pour être unique');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 61, 'description', 3, 'Agent Provisions Typ');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 61, 'description', 4, 'Type de commission des agents');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 61, 'instruction', 3, 'Definiert den Provisionstyp des Standardagenten für das Unternehmen, einer dieser: RECHNUNG, ZAHLUNG');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 61, 'instruction', 4, 'Il définit le type de commission des agents par défaut pour l''entité, une des : FACTURE, PAYMENT');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 62, 'description', 4, 'Afficher les articles du plan sans impact');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 63, 'description', 3, 'Sollte JQGrid für Tabellen benutzen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 63, 'description', 4, 'Doit utiliser JQGrid pour les tableaux');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 63, 'instruction', 3, 'Auf ''0''einstellen um den Stadardlayout zu benutzen, oder auf ''1'' einstellen um JQGrid auf den Tabellen der Seite zu benutzen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 63, 'instruction', 4, 'Configurez sur ''0'' pour utiliser la disposition classique, ou sur ''1'' pour utiliser JQGrid  sur les tableaux du site');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 64, 'description', 4, 'Royaume de destination Diameter');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 64, 'instruction', 4, 'Le royaume à facturer. Il peut être utilisé pour router les messages Diameter, il faut donc que cela corresponde au royaume configuré localement.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 65, 'description', 4, 'Seuil du quota Diameter');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 65, 'instruction', 4, 'Lorsque ce nombre de secondes demeure, l''unité de traitement des appels doit demander une nouvelle autorisation.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 66, 'description', 4, 'Délai supplémentaire pour la session Diameter');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 66, 'instruction', 4, 'Nombre de secondes à attendre avant que les sessions Diameter soient fermées de force.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 67, 'description', 4, 'Multiplicateur/Diviseur d''unités Diameter');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 67, 'instruction', 4, 'La valeur des unités reçues de la part de Diameter est divisée/multipliée par ce facteur pour convertir les secondes entrées en d''autres unités de temps. Les valeurs < 1 configurent le multiplicateur sur 1.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 68, 'description', 4, 'Durée de blocage du compte');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 68, 'instruction', 4, 'Nombre de minutes pendant lesquelles un compte utilisateur restera bloqué après que le nombre de tentatives autorisées soit épuisé (Préférence 39).');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 69, 'description', 4, 'Notification de facture ITG');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 69, 'instruction', 4, 'Actives les notifications de factures ITG (Générateur de modèles de factures).');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 70, 'description', 4, 'Faire expirer les comptes inactifs après plusieurs jours.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50, 70, 'instruction', 4, 'Nombre de jours après lesquels un compte utilisateur devient inactif. Cela désactiver la capacité de cet utilisateur à se connecter à jBilling.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 12, 'description', 3, 'Rechnung (Papier)');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 12, 'description', 4, 'Facture (papier)');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 13, 'description', 3, 'Bestellung verfèllt bald. Schritt 1');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 13, 'description', 4, 'Commande sur le point d''expirer. Étape 1');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 14, 'description', 3, 'Bestellung verfèllt bald. Schritt 2');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 14, 'description', 4, 'Commande sur le point d''expirer. Étape 2');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 15, 'description', 3, 'Bestellung verfèllt bald. Schritt 3');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 15, 'description', 4, 'Commande sur le point d''expirer. Étape 3');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 16, 'description', 3, 'Payment (erfolgreich)');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 16, 'description', 4, 'Paiement (réussi)');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 17, 'description', 3, 'Bezahlung (fehlgeschlagen)');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 17, 'description', 4, 'Paiement (échec)');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 18, 'description', 4, 'Relance de facture');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 19, 'description', 3, 'Kreditkarte aktualisieren');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 19, 'description', 4, 'Mettre à jour la carte bancaire');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 1, 'description', 3, 'Rechnung (email)');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 1, 'description', 4, 'Facture (e-mail)');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 20, 'description', 3, 'Passwort verloren');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 20, 'description', 4, 'Mot de passe perdu');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 22, 'description', 3, 'Bezahlung eingegeben');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 22, 'description', 4, 'Paiement saisi');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 23, 'description', 3, 'Bezahlung (Rückerstattung)');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 23, 'description', 4, 'Paiement (remboursement)');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 24, 'description', 4, 'Seuil inférieur au solde');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 25, 'description', 4, 'Consommation du regroupement d''utilisation');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 26, 'description', 4, 'Limitation de crédit 1');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 27, 'description', 4, 'Limitation de crédit 2');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 2, 'description', 3, 'Benutzer neu aktiviert');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 2, 'description', 4, 'Utilisateur réactivé');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 3, 'description', 3, 'Benutzer ƒberfèllig');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 3, 'description', 4, 'Retard de paiement du client');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 4, 'description', 3, 'Benutzer ƒberfèllig 2');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 4, 'description', 4, 'Retard de paiement 2 du client');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 5, 'description', 3, 'Benutzer ƒberfèllig 3');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 5, 'description', 4, 'Retard de paiement 3 du client');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 6, 'description', 3, 'Benutzer gesperrt');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 6, 'description', 4, 'Utilisateur suspendu');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 7, 'description', 3, 'Benutzer gesperrt 2');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 7, 'description', 4, 'Utilisateur suspendu 2');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 8, 'description', 3, 'Benutzer gesperrt 3');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 8, 'description', 4, 'Utilisateur suspendu 3');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 9, 'description', 3, 'Benutzer gelÖscht');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52, 9, 'description', 4, 'Utilisateur supprimé');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 100, 'description', 3, 'Agentmenü erstellen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 100, 'description', 4, 'Afficher le menu Agent');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 101, 'description', 3, 'Agent erstellen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 101, 'description', 4, 'Créer un agent');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 102, 'description', 4, 'Modifier l''agent');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 103, 'description', 4, 'Supprimer l''agent');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 104, 'description', 4, 'Voir les détails de l''agent');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 10, 'description', 3, 'Kunden erstellen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 10, 'description', 4, 'Créer un client');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 110, 'description', 3, 'Zu Unterkonto wechseln');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 110, 'description', 4, 'Passer au sous-compte');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 111, 'description', 3, 'Zu anderem Benutzer wechseln');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 111, 'description', 4, 'Passer à n''importe quel utilisateur');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 11, 'description', 3, 'Kunden editieren');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 11, 'description', 4, 'Modifier le client');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 120, 'description', 3, 'Web Service API Zugriff');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 120, 'description', 4, 'Accès l''API du service web');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 121, 'description', 3, 'Abrechnungszeitraum des Kunden editieren');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 121, 'description', 4, 'Modifier le cycle de facturation du client');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 12, 'description', 3, 'Kunden löschen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 12, 'description', 4, 'Supprimer le client');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 130, 'description', 4, 'Ajouter un actif');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 131, 'description', 4, 'Modifier l''actif');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 132, 'description', 4, 'Supprimer l''actif');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 133, 'description', 4, 'Télécharger le fichier des actifs');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 13, 'description', 3, 'Kunden prüfen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 13, 'description', 4, 'Inspecter le client');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 140, 'description', 4, 'Ajouter un code utilisateur');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 141, 'description', 4, 'Modifier le code utilisateur');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 142, 'description', 4, 'Voir le code utilisateur');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 143, 'description', 4, 'Assigner le code utilisateur à l''entité');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 144, 'description', 4, 'Modifier le code utilisateur pour l''entité');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 145, 'description', 4, 'Forçage du mot de passe');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 14, 'description', 3, 'Kunden sperren');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 14, 'description', 4, 'Inscrire le client sur la liste noire');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 151, 'description', 4, 'Créer une réduction');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 152, 'description', 4, 'Supprimer la réduction');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 153, 'description', 4, 'Modifier la réduction');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 15, 'description', 3, 'Kundendetails ansehen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 15, 'description', 4, 'Voir les informations du client');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 160, 'description', 4, 'Voir mon compte');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 161, 'description', 4, 'Modifier le mot de passe');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 162, 'description', 4, 'Modifier mon compte');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 16, 'description', 3, 'Kunden CSV herunterladen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 16, 'description', 4, 'Télécharger le CSV du client');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 170, 'description', 4, 'Modifier les requêtes générales');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 17, 'description', 3, 'Alle Kunden anzeigen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 17, 'description', 4, 'Voir tous les clients');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 180, 'description', 4, 'Modifier les modèles de factures');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 181, 'description', 4, 'Ajouter des modèles de facture');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 182, 'description', 4, 'Liste des modèles de factures');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 183, 'description', 4, 'Supprimer des modèles de factures');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 18, 'description', 3, 'Alle Kunden Unterkonten anzeigen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 18, 'description', 4, 'Voir les sous-comptes du client');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 19, 'description', 3, 'Nächstes Rechnungsdatum editieren');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 19, 'description', 4, 'Modifier la date de la prochaine facture');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 20, 'description', 3, 'Bestellung erstellen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 20, 'description', 4, 'Créer une commande');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 21, 'description', 3, 'Bestellung editieren');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 21, 'description', 4, 'Modifier la commande');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 22, 'description', 3, 'Bestellung löschen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 22, 'description', 4, 'Supprimer la commande');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 23, 'description', 3, 'Rechnung für Bestellung erzeugen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 23, 'description', 4, 'Générer une facture pour la commande');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 24, 'description', 3, 'Bestellungsdetails anzeigen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 24, 'description', 4, 'Voir les détails de la commande');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 25, 'description', 3, 'Bestellungs CSV herunterladen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 25, 'description', 4, 'Télécharger le CSV des commandes');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 26, 'description', 3, 'Zeilenpreis editieren');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 26, 'description', 4, 'Modifier le prix de la ligne');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 27, 'description', 3, 'Zeilenbeschreibung editieren');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 27, 'description', 4, 'Modifier la description de la ligne');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 28, 'description', 3, 'Alle Kunden anzeigen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 28, 'description', 4, 'Voir tous les clients');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 29, 'description', 3, 'Alle Kunden Unterkonten anzeigen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 29, 'description', 4, 'Voir les sous-comptes du client');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 30, 'description', 3, 'Zahlung erstellen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 30, 'description', 4, 'Créer un paiement');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 31, 'description', 3, 'Bezahlung editieren');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 31, 'description', 4, 'Modifier le paiement.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 32, 'description', 3, 'Zahlung löschen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 32, 'description', 4, 'Supprimer le paiement');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 33, 'description', 3, 'Zahlung mit der Rechnung verbinden');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 33, 'description', 4, 'Il associe les paiements aux factures.');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 34, 'description', 3, 'Zahlungsdetails anzeigen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 34, 'description', 4, 'Voir les détails du paiement');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 35, 'description', 3, 'Zahlungs CSV herunterladen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 35, 'description', 4, 'Télécharger le CSV des paiements');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 36, 'description', 3, 'Alle Kunden anzeigen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 36, 'description', 4, 'Voir tous les clients');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 37, 'description', 3, 'Kunden Unterkonten anzeigen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 37, 'description', 4, 'Voir les sous-comptes du client');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 40, 'description', 3, 'Produkt erstellen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 40, 'description', 4, 'Créer un produit');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 41, 'description', 3, 'Produkt editieren');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 41, 'description', 4, 'Modifier le produit');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 42, 'description', 3, 'Produkt löschen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 42, 'description', 4, 'Supprimer le produit');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 43, 'description', 3, 'Produkt Details anzeigen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 43, 'description', 4, 'Voir les détails du produit');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 44, 'description', 3, 'Zahlungs CSV anzeigen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 44, 'description', 4, 'Télécharger le CSV des paiements');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 50, 'description', 3, 'Produktkategorie erstellen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 50, 'description', 4, 'Créer une catégorie de produit');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 51, 'description', 3, 'Produktkategorie erstellen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 51, 'description', 4, 'Modifier la catégorie de produit');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 52, 'description', 3, 'Produktkategorie löschen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 52, 'description', 4, 'Supprimer la catégorie de produit');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 53, 'description', 4, 'Modifier les statuts de la catégorie');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 54, 'description', 4, 'Modifier les meta-champs de la catégorie');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 60, 'description', 3, 'Plan erstellen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 60, 'description', 4, 'Créer un plan');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 61, 'description', 3, 'Plan editieren');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 61, 'description', 4, 'Modifier le plan');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 62, 'description', 3, 'Plan löschen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 62, 'description', 4, 'Supprimer le plan');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 63, 'description', 3, 'Plan details anzeigen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 63, 'description', 4, 'Voir les détails du plan');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 70, 'description', 3, 'Rechnung löschen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 70, 'description', 4, 'Supprimer la facture');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 71, 'description', 3, 'Rechnungsmitteilung schicken');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 71, 'description', 4, 'Envoi d''une notification pour la facture');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 72, 'description', 3, 'Rechnungsdetails anzeigen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 72, 'description', 4, 'Voir les détails de la facture');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 73, 'description', 3, 'Rechnungs CSV anzeigen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 73, 'description', 4, 'Télécharger le CSV des factures');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 74, 'description', 3, 'Alle Kunden anzeigen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 74, 'description', 4, 'Voir tous les clients');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 75, 'description', 3, 'Kundenunterkonten anzeigen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 75, 'description', 4, 'Voir les sous-comptes du client');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 80, 'description', 3, 'Review Genehmigen/nicht genehmigen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 80, 'description', 4, 'Approuver/Désapprouver l''examen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 900, 'description', 4, 'Afficher le menu Approvisionnement');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 901, 'description', 4, 'Afficher le menu Agent');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 902, 'description', 4, 'Afficher le menu Réductions');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 90, 'description', 3, 'Kundenmenü anzeigen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 90, 'description', 4, 'Afficher le menu Client');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 91, 'description', 3, 'Rechnungsmenü anzeigen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 91, 'description', 4, 'Afficher le menu Factures');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 92, 'description', 3, 'Bestellungsmenü anzeigen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 92, 'description', 4, 'Afficher le menu Commande');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 93, 'description', 3, 'Zahlungs und Rückerstattungsmenü anzeigen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 93, 'description', 4, 'Afficher le menu Paiements et remboursements');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 94, 'description', 3, 'Abrechnungsmenü anzeigen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 94, 'description', 4, 'Afficher le menu Facturation');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 95, 'description', 3, 'Vermittlungsmenü anzeigen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 95, 'description', 4, 'Afficher le menu Médiation');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 96, 'description', 3, 'Berichtmenü anzeigen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 96, 'description', 4, 'Afficher le menu Rapports');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 97, 'description', 3, 'Produktmenü anzeigen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 97, 'description', 4, 'Afficher le menu Produits');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 98, 'description', 3, 'Planmenü anzeigen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 98, 'description', 4, 'Afficher le menu Plans');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 99, 'description', 3, 'Einstellungsmenü anzeigen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (59, 99, 'description', 4, 'Afficher le menu Configuration');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 1, 'description', 3, 'Ein interner Benutzer mit allen Rechten');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 1, 'description', 4, 'Un utilisateur interne disposant de toutes les permissions');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 1, 'title', 3, 'Intern');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 1, 'title', 4, 'Interne');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 2, 'description', 3, 'Der super User eines Unternehmens');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 2, 'description', 4, 'Le super utilisateur d''une entité');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 2, 'title', 3, 'Super User');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 2, 'title', 4, 'Super utilisateur');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 3, 'description', 3, 'Ein Buchhalter');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 3, 'description', 4, 'Un employé chargé de la facturation');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 3, 'title', 3, 'Angestellter');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 3, 'title', 4, 'Employé');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 4, 'description', 3, 'Ein Agent der Kunden bringen wird');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 4, 'description', 4, 'Un agent qui ramènera des clients');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 4, 'title', 3, 'Agent');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 4, 'title', 4, 'Agent');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 5, 'description', 3, 'Ein Kunde der sein/ihr Konto abfragen wird');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 5, 'description', 4, 'Un client qui cherchera son compte');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 5, 'title', 3, 'Kunde');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 5, 'title', 4, 'Client');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 60, 'description', 3, 'Der Super User eines Unternehmens');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 60, 'description', 4, 'Le super utilisateur d''une entité');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 60, 'title', 3, 'Super User');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 60, 'title', 4, 'Super utilisateur');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 61, 'description', 3, 'ein Buchhalterc');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 61, 'description', 4, 'Un employé chargé de la facturation');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 61, 'title', 3, 'Angestellter');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 61, 'title', 4, 'Employé');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 62, 'description', 3, ' Ein Kunde, der sein/ihr Konto abfragen wird');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 62, 'description', 4, 'Un client qui cherchera son compte');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 62, 'title', 3, 'Kunde');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 62, 'title', 4, 'Client');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 63, 'description', 3, 'Ein Agent der Kunden bringen wird');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 63, 'description', 4, 'Un agent qui ramènera des clients');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 63, 'title', 3, 'Agent');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 63, 'title', 4, 'Agent');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 70, 'description', 4, 'Le super utilisateur d''une entité');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 70, 'title', 4, 'Super utilisateur');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 71, 'description', 4, 'Un employé chargé de la facturation');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 71, 'title', 4, 'Employé');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 72, 'description', 4, 'Un client qui cherchera son compte');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 72, 'title', 4, 'Client');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 73, 'description', 4, 'Un agent qui ramènera des clients');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 73, 'title', 4, 'Agent');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 74, 'description', 4, 'Le super utilisateur d''une entité');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 74, 'title', 4, 'Super utilisateur');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 75, 'description', 4, 'Un employé chargé de la facturation');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 75, 'title', 4, 'Employé');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 76, 'description', 4, 'Un client qui cherchera son compte');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 76, 'title', 4, 'Client');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 77, 'description', 4, 'Un agent qui ramènera des clients');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 77, 'title', 4, 'Agent');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 78, 'description', 4, 'Le super utilisateur d''une entité');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 78, 'title', 4, 'Super utilisateur');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 79, 'description', 4, 'Un employé chargé de la facturation');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 79, 'title', 4, 'Employé');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 80, 'description', 4, 'Un client qui cherchera son compte');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 80, 'title', 4, 'Client');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 81, 'description', 4, 'Un agent qui ramènera des clients');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 81, 'title', 4, 'Agent');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 82, 'description', 4, 'Le super utilisateur d''une entité');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 82, 'title', 4, 'Super utilisateur');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 83, 'description', 4, 'Un employé chargé de la facturation');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 83, 'title', 4, 'Employé');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 84, 'description', 4, 'Un client qui cherchera son compte');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 84, 'title', 4, 'Client');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 85, 'description', 4, 'Un agent qui ramènera des clients');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 85, 'title', 4, 'Agent');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 87, 'description', 4, 'Le super utilisateur d''une entité');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 87, 'title', 4, 'Super utilisateur');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 88, 'description', 4, 'Un employé chargé de la facturation');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 88, 'title', 4, 'Employé');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 89, 'description', 4, 'Un client qui cherchera son compte');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 89, 'title', 4, 'Client');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 90, 'description', 4, 'Un agent qui ramènera des clients');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 90, 'title', 4, 'Agent');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 91, 'description', 4, 'Le super utilisateur d''une entité');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 91, 'title', 4, 'Super utilisateur');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 92, 'description', 4, 'Un employé chargé de la facturation');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 92, 'title', 4, 'Employé');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 93, 'description', 4, 'Un client qui cherchera son compte');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 93, 'title', 4, 'Client');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 94, 'description', 4, 'Un agent qui ramènera des clients');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 94, 'title', 4, 'Agent');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 95, 'description', 4, 'Le super utilisateur d''une entité');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 95, 'title', 4, 'Super utilisateur');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 96, 'description', 4, 'Un employé chargé de la facturation');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 96, 'title', 4, 'Employé');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 97, 'description', 4, 'Un client qui cherchera son compte');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 97, 'title', 4, 'Client');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 98, 'description', 4, 'Un agent qui ramènera des clients');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (60, 98, 'title', 4, 'Agent');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (6, 1, 'description', 3, 'Monat');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (6, 1, 'description', 4, 'Mois');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (6, 2, 'description', 3, 'Woche');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (6, 2, 'description', 4, 'Semaine');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (6, 3, 'description', 3, 'Tag');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (6, 3, 'description', 4, 'Jour');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 100, 'description', 3, 'Indonesien');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 100, 'description', 4, 'Indonésie');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 101, 'description', 3, 'Iran');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 101, 'description', 4, 'Iran');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 102, 'description', 3, 'Irak');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 102, 'description', 4, 'Irak');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 103, 'description', 3, 'Irland');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 103, 'description', 4, 'Irlande');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 104, 'description', 3, 'Israel');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 104, 'description', 4, 'Israël');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 105, 'description', 3, 'Italien');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 105, 'description', 4, 'Italie');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 106, 'description', 3, 'Jamaica');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 106, 'description', 4, 'Jamaïque');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 107, 'description', 3, 'Japan');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 107, 'description', 4, 'Japon');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 108, 'description', 3, 'Jordan');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 108, 'description', 4, 'Jordanie');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 109, 'description', 3, 'Kazakhstan');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 109, 'description', 4, 'Kazakhstan');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 10, 'description', 3, 'Argentinien');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 10, 'description', 4, 'Argentine');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 110, 'description', 3, 'Kenia');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 110, 'description', 4, 'Kenya');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 111, 'description', 3, 'Kiribati');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 111, 'description', 4, 'Kiribati');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 112, 'description', 3, 'Korea');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 112, 'description', 4, 'Corée');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 113, 'description', 3, 'Kuwait');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 113, 'description', 4, 'Koweït');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 114, 'description', 3, 'Kyrgyzstan');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 114, 'description', 4, 'Kirghizistan');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 115, 'description', 3, 'Laos');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 115, 'description', 4, 'Laos');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 116, 'description', 3, 'Latvia');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 116, 'description', 4, 'Lettonie');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 117, 'description', 3, 'Lebanon');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 117, 'description', 4, 'Liban');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 118, 'description', 3, 'Lesotho');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 118, 'description', 4, 'Lesotho');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 119, 'description', 3, 'Liberia');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 119, 'description', 4, 'Liberia');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 11, 'description', 3, 'Armenien');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 11, 'description', 4, 'Arménie');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 120, 'description', 3, 'Libia');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 120, 'description', 4, 'Libye');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 121, 'description', 3, 'Liechtenstein');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 121, 'description', 4, 'Liechtenstein');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 122, 'description', 3, 'Lithuanien');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 122, 'description', 4, 'Lituanie');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 123, 'description', 3, 'Luxemburg');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 123, 'description', 4, 'Luxembourg');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 124, 'description', 3, 'Macao SAR');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 124, 'description', 4, 'Macao - Région administrative spéciale');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 125, 'description', 3, 'Mazedonien,ehemalige Jugoslavische Republik');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 125, 'description', 4, 'Macédoine, ancienne République yougoslave de');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 126, 'description', 3, 'Madagaskar');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 126, 'description', 4, 'Madagascar');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 127, 'description', 3, 'Malawi');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 127, 'description', 4, 'Malawi');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 128, 'description', 3, 'Malaysia');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 128, 'description', 4, 'Malaisie');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 129, 'description', 3, 'Maldiven');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 129, 'description', 4, 'Maldives');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 12, 'description', 3, 'Aruba');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 12, 'description', 4, 'Aruba');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 130, 'description', 3, 'Mali');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 130, 'description', 4, 'Mali');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 131, 'description', 3, 'Malta');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 131, 'description', 4, 'Malte');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 132, 'description', 3, 'Marshall Inseln');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 132, 'description', 4, 'Îles Marshall');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 133, 'description', 3, 'Martinique');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 133, 'description', 4, 'Martinique');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 134, 'description', 3, 'Mauritanien');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 134, 'description', 4, 'Mauritanie');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 135, 'description', 3, 'Mauritius');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 135, 'description', 4, 'Maurice');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 136, 'description', 3, 'Mayotte');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 136, 'description', 4, 'Mayotte');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 137, 'description', 3, 'Mexiko');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 137, 'description', 4, 'Mexique');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 138, 'description', 3, 'Mikronesien');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 138, 'description', 4, 'Micronésie');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 139, 'description', 3, 'Moldawien');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 139, 'description', 4, 'Moldavie');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 13, 'description', 3, 'Australia');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 13, 'description', 4, 'Australie');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 140, 'description', 3, 'Monaco');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 140, 'description', 4, 'Monaco');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 141, 'description', 3, 'Mongolien');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 141, 'description', 4, 'Mongolie');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 142, 'description', 3, 'Montserrat');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 142, 'description', 4, 'Montserrat');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 143, 'description', 3, 'Marokko');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 143, 'description', 4, 'Maroc');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 144, 'description', 3, 'Mozambique');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 144, 'description', 4, 'Mozambique');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 145, 'description', 3, 'Myanmar');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 145, 'description', 4, 'Myanmar');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 146, 'description', 3, 'Namibien');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 146, 'description', 4, 'Namibie');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 147, 'description', 3, 'Nauru');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 147, 'description', 4, 'Nauru');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 148, 'description', 3, 'Nepal');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 148, 'description', 4, 'Népal');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 149, 'description', 3, 'Holland');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 149, 'description', 4, 'Pays-Bas');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 14, 'description', 3, 'àsterreich');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 14, 'description', 4, 'Autriche');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 150, 'description', 3, 'Niederlèndische Antillen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 150, 'description', 4, 'Antilles néerlandaises');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 151, 'description', 3, 'Neukaledonien');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 151, 'description', 4, 'Nouvelle-Calédonie');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 152, 'description', 3, 'Neuseeland');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 152, 'description', 4, 'Nouvelle-Zélande');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 153, 'description', 3, 'Nicaragua');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 153, 'description', 4, 'Nicaragua');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 154, 'description', 3, 'Niger');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 154, 'description', 4, 'Niger');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 155, 'description', 3, 'Nigeria');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 155, 'description', 4, 'Nigéria');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 156, 'description', 3, 'Niue');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 156, 'description', 4, 'Niue');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 157, 'description', 3, 'Norfolk Island');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 157, 'description', 4, 'Île Norfolk');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 158, 'description', 3, 'Nord Korea');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 158, 'description', 4, 'Corée du Nord');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 159, 'description', 3, 'NÖrdliche Mariana Islands');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 159, 'description', 4, 'Îles Mariannes du Nord');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 15, 'description', 3, 'Azerbaijan');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 15, 'description', 4, 'Azerbaïdjan');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 160, 'description', 3, 'Norwegen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 160, 'description', 4, 'Norvège');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 161, 'description', 3, 'Oman');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 161, 'description', 4, 'Oman');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 162, 'description', 3, 'Pakistan');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 162, 'description', 4, 'Pakistan');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 163, 'description', 3, 'Palau');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 163, 'description', 4, 'Palaos');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 164, 'description', 3, 'Panama');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 164, 'description', 4, 'Panama');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 165, 'description', 3, 'Papua Neu Guinea');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 165, 'description', 4, 'Papouasie-Nouvelle-Guinée');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 166, 'description', 3, 'Paraguay');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 166, 'description', 4, 'Paraguay');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 167, 'description', 3, 'Peru');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 167, 'description', 4, 'Pérou');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 168, 'description', 3, 'Philippien');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 168, 'description', 4, 'Philippines');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 169, 'description', 3, 'Pitcairn Islands');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 169, 'description', 4, 'Îles Pitcairn');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 16, 'description', 3, 'Bahamas');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 16, 'description', 4, 'Bahamas');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 170, 'description', 3, 'Polen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 170, 'description', 4, 'Pologne');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 171, 'description', 3, 'Portugal');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 171, 'description', 4, 'Portugal');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 172, 'description', 3, 'Puerto Rico');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 172, 'description', 4, 'Porto Rico');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 173, 'description', 3, 'Qatar');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 173, 'description', 4, 'Qatar');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 174, 'description', 3, 'Reunion');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 174, 'description', 4, 'Réunion');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 175, 'description', 3, 'Romènien');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 175, 'description', 4, 'Roumanie');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 176, 'description', 3, 'Russland');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 176, 'description', 4, 'Russie');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 177, 'description', 3, 'Rwanda');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 177, 'description', 4, 'Rwanda');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 178, 'description', 3, 'Samoa');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 178, 'description', 4, 'Samoa');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 179, 'description', 3, 'San Marino');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 179, 'description', 4, 'San Marin');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 17, 'description', 3, 'Bahrain');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 17, 'description', 4, 'Bahreïn');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 180, 'description', 3, 'Sao Tome und Principe');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 180, 'description', 4, 'Sao Tomé-et-Principe');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 181, 'description', 3, 'Saudi Arabien');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 181, 'description', 4, 'Arabie Saoudite');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 182, 'description', 3, 'Senegal');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 182, 'description', 4, 'Sénégal');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 183, 'description', 3, 'Serben und Montenegro');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 183, 'description', 4, 'Serbie-et-Monténégro');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 184, 'description', 3, 'Seychellen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 184, 'description', 4, 'Seychelles');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 185, 'description', 3, 'Sierra Leone');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 185, 'description', 4, 'Sierra Leone');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 186, 'description', 3, 'Singapur');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 186, 'description', 4, 'Singapour');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 187, 'description', 3, 'Slovakien');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 187, 'description', 4, 'Slovaquie');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 188, 'description', 3, 'Slovenien');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 188, 'description', 4, 'Slovénie');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 189, 'description', 3, 'Solomon Islands');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 189, 'description', 4, 'Îles Salomon');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 18, 'description', 3, 'Bangladesch');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 18, 'description', 4, 'Bangladesh');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 190, 'description', 3, 'Somalien');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 190, 'description', 4, 'Somalie');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 191, 'description', 3, 'Sƒdafrika');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 191, 'description', 4, 'Afrique du Sud');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 192, 'description', 3, 'Sƒdgeorgien und sƒdliche Sandwichinseln');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 192, 'description', 4, 'Géorgie du Sud-et-les Îles Sandwich du Sud');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 193, 'description', 3, 'Spanien');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 193, 'description', 4, 'Espagne');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 194, 'description', 3, 'Sri Lanka');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 194, 'description', 4, 'Sri Lanka');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 195, 'description', 3, 'St. Helena');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 195, 'description', 4, 'Sainte- Hélène');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 196, 'description', 3, 'St. Kitts und Nevis');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 196, 'description', 4, 'Saint- Christophe-et-Niévès');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 197, 'description', 3, 'St. Lucia');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 197, 'description', 4, 'Saint- Lucie');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 198, 'description', 3, 'St. Pierre und Miquelon');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 198, 'description', 4, 'Saint- Pierre-et-Miquelon');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 199, 'description', 3, 'St. Vincent and the Grenadines');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 199, 'description', 4, 'Saint- Vincent-et-les-Grenadines');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 19, 'description', 3, 'Barbados');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 19, 'description', 4, 'Barbade');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 1, 'description', 3, 'Afghanistan');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 1, 'description', 4, 'Afghanistan');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 200, 'description', 3, 'Sudan');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 200, 'description', 4, 'Soudan');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 201, 'description', 3, 'Suriname');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 201, 'description', 4, 'Suriname');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 202, 'description', 3, 'Svalbard und Jan Mayen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 202, 'description', 4, 'Svalbard et Jan Mayen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 203, 'description', 3, 'Swaziland');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 203, 'description', 4, 'Swaziland');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 204, 'description', 3, 'Schweden');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 204, 'description', 4, 'Suède');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 205, 'description', 3, 'Schweiz');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 205, 'description', 4, 'Suisse');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 206, 'description', 3, 'Syrien');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 206, 'description', 4, 'Syrie');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 207, 'description', 3, 'Taiwan');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 207, 'description', 4, 'Taïwan');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 208, 'description', 3, 'Tajikistan');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 208, 'description', 4, 'Tadjikistan');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 209, 'description', 3, 'Tanzania');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 209, 'description', 4, 'Tanzanie');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 20, 'description', 3, 'Belarus');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 20, 'description', 4, 'Biélorussie');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 210, 'description', 3, 'Thailand');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 210, 'description', 4, 'Thaïlande');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 211, 'description', 3, 'Togo');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 211, 'description', 4, 'Togo');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 212, 'description', 3, 'Tokelau');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 212, 'description', 4, 'Tokelau');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 213, 'description', 3, 'Tonga');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 213, 'description', 4, 'Tonga');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 214, 'description', 3, 'Trinidad und Tobago');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 214, 'description', 4, 'Trinité-et-Tobago');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 215, 'description', 3, 'Tunesien');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 215, 'description', 4, 'Tunisie');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 216, 'description', 3, 'Turkei');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 216, 'description', 4, 'Turquie');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 217, 'description', 3, 'Turkmenistan');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 217, 'description', 4, 'Turkménistan');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 218, 'description', 3, 'Turks und Caicos Islands');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 218, 'description', 4, 'Îles Turques-et-Caïques');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 219, 'description', 3, 'Tuvalu');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 219, 'description', 4, 'Tuvalu');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 21, 'description', 3, 'Belgien');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 21, 'description', 4, 'Belgique');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 220, 'description', 3, 'Uganda');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 220, 'description', 4, 'Ouganda');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 221, 'description', 3, 'Ukraine');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 221, 'description', 4, 'Ukraine');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 222, 'description', 3, 'Vereinigte Arabische Emirate');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 222, 'description', 4, 'Émirats Arabes Unis');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 223, 'description', 3, 'Vereinigtes KÖnigreich');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 223, 'description', 4, 'Royaume-Uni');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 224, 'description', 3, 'Vereinigte Staaten');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 224, 'description', 4, 'États-Unis');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 225, 'description', 3, 'Amerikanisch Ozeanien');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 225, 'description', 4, 'Îles mineures éloignées des États-Unis');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 226, 'description', 3, 'Uruguay');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 226, 'description', 4, 'Uruguay');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 227, 'description', 3, 'Uzbekistan');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 227, 'description', 4, 'Ouzbékistan');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 228, 'description', 3, 'Vanuatu');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 228, 'description', 4, 'Vanuatu');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 229, 'description', 3, 'Vatikanstadt');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 229, 'description', 4, 'Cité du Vatican');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 22, 'description', 3, 'Belize');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 22, 'description', 4, 'Belize');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 230, 'description', 3, 'Venezuela');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 230, 'description', 4, 'Venezuela');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 231, 'description', 3, 'Vietnam');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 231, 'description', 4, 'Vietnam');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 232, 'description', 3, 'Britische Junferninseln');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 232, 'description', 4, 'Îles Vierges britanniques');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 233, 'description', 3, 'Jungferninseln');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 233, 'description', 4, 'Îles Vierges');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 234, 'description', 3, 'Wallis und Futuna');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 234, 'description', 4, 'Wallis-et-Futuna');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 235, 'description', 3, 'Yemen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 235, 'description', 4, 'Yémen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 236, 'description', 3, 'Zambia');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 236, 'description', 4, 'Zambie');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 237, 'description', 3, 'Zimbabwe');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 237, 'description', 4, 'Zimbabwe');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 23, 'description', 3, 'Benin');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 23, 'description', 4, 'Benin');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 24, 'description', 3, 'Bermudas');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 24, 'description', 4, 'Bermudes');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 25, 'description', 3, 'Bhutan');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 25, 'description', 4, 'Bhoutan');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 26, 'description', 3, 'Bolivien');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 26, 'description', 4, 'Bolivie');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 27, 'description', 3, 'Bosnien und Herzegovina');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 27, 'description', 4, 'Bosnie-Herzégovine');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 28, 'description', 3, 'Botswana');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 28, 'description', 4, 'Botswana');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 29, 'description', 3, 'Bouvet Insel');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 29, 'description', 4, 'Île Bouvet');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 2, 'description', 3, 'Albanien');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 2, 'description', 4, 'Albanie');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 30, 'description', 3, 'Brazilien');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 30, 'description', 4, 'Brésil');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 31, 'description', 3, 'Britisches Territorium im Indischen Ozean');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 31, 'description', 4, 'Territoire britannique de l''Océan Indien');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 32, 'description', 3, 'Brunei');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 32, 'description', 4, 'Brunei');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 33, 'description', 3, 'Bulgarien');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 33, 'description', 4, 'Bulgarie');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 34, 'description', 3, 'Burkina Faso');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 34, 'description', 4, 'Burkina Faso');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 35, 'description', 3, 'Burundi');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 35, 'description', 4, 'Burundi');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 36, 'description', 3, 'Kambodien');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 36, 'description', 4, 'Cambodge');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 37, 'description', 3, 'Karmun');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 37, 'description', 4, 'Cameroun');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 38, 'description', 3, 'Kanada');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 38, 'description', 4, 'Canada');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 39, 'description', 3, 'Kap Verde');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 39, 'description', 4, 'Cap-Vert');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 3, 'description', 3, 'Algerien');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 3, 'description', 4, 'Algérie');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 40, 'description', 3, 'Kaimaninseln');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 40, 'description', 4, 'Îles Caïmans');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 41, 'description', 3, 'Zentralfrikanische Republik');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 41, 'description', 4, 'République centrafricaine');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 42, 'description', 3, 'Chad');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 42, 'description', 4, 'Tchad');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 43, 'description', 3, 'Chile');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 43, 'description', 4, 'Chili');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 44, 'description', 3, 'China');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 44, 'description', 4, 'Chine');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 45, 'description', 3, 'Weihnachtsinsel');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 45, 'description', 4, 'Île Christmas');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 46, 'description', 3, 'Cocos - Keeling Islands');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 46, 'description', 4, 'Îles Cocos');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 47, 'description', 3, 'Kolumbien');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 47, 'description', 4, 'Colombie');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 48, 'description', 3, 'Komoren');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 48, 'description', 4, 'Comores');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 49, 'description', 3, 'Kongo');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 49, 'description', 4, 'Congo');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 4, 'description', 3, 'Amerikanisch-Samoa');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 4, 'description', 4, 'Samoa américaines');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 50, 'description', 3, 'Cook Inseln');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 50, 'description', 4, 'Îles Cook');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 51, 'description', 3, 'Costa Rica');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 51, 'description', 4, 'Costa Rica');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 52, 'description', 3, 'Cote d Ivoire');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 52, 'description', 4, 'Côte d''Ivoire');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 53, 'description', 3, 'Kroatien');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 53, 'description', 4, 'Croatie');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 54, 'description', 3, 'Kuba');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 54, 'description', 4, 'Cuba');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 55, 'description', 3, 'Zypern');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 55, 'description', 4, 'Chypre');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 56, 'description', 3, 'Tschechische Republik');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 56, 'description', 4, 'République Tchèque');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 57, 'description', 3, 'Kongo - DRC');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 57, 'description', 4, 'Congo - République démocratique du Congo');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 58, 'description', 3, 'Dènemarkd');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 58, 'description', 4, 'Danemark');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 59, 'description', 3, 'Djibouti');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 59, 'description', 4, 'Djibouti');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 5, 'description', 3, 'Andorra');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 5, 'description', 4, 'Andorre');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 60, 'description', 3, 'Dominica');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 60, 'description', 4, 'Dominique');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 61, 'description', 3, 'Dominikanische Republike');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 61, 'description', 4, 'République Dominicaine');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 62, 'description', 3, 'ost Timor');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 62, 'description', 4, 'Timor oriental');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 63, 'description', 3, 'Equador');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 63, 'description', 4, 'Equateur');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 64, 'description', 3, 'Çgypten');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 64, 'description', 4, 'Égypte');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 65, 'description', 3, 'El Salvador');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 65, 'description', 4, 'El Salvador');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 66, 'description', 3, 'quatorialguinea');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 66, 'description', 4, 'Guinée équatoriale');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 67, 'description', 3, 'Eritrea');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 67, 'description', 4, 'Érythrée');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 68, 'description', 3, 'Estonien');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 68, 'description', 4, 'Estonie');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 69, 'description', 3, 'Ethiopien');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 69, 'description', 4, 'Éthiopie');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 6, 'description', 3, 'Angola');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 6, 'description', 4, 'Angola');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 70, 'description', 3, 'Malediven');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 70, 'description', 4, 'Îles Malouines');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 71, 'description', 3, 'FèrÖr');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 71, 'description', 4, 'Îles Féroé');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 72, 'description', 3, 'Fiji Inseln');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 72, 'description', 4, 'Îles Fidji');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 73, 'description', 3, 'Finland');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 73, 'description', 4, 'Finlande');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 74, 'description', 3, 'Frankreich');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 74, 'description', 4, 'France');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 75, 'description', 3,'FranzÖsisch-Guayana');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 75, 'description', 4, 'Guyane');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 76, 'description', 3, 'FranzÖsisch Polynesien' );

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 76, 'description', 4, 'Polynésie française');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 77, 'description', 3, 'FranzÖsische Sƒd- und Antartisgebiete');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 77, 'description', 4, 'Terres australes et antarctiques françaises');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 78, 'description', 3, 'Gabon');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 78, 'description', 4, 'Gabon');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 79, 'description', 3, 'Gambia');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 79, 'description', 4, 'Gambie');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 7, 'description', 3, 'Anguilla');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 7, 'description', 4, 'Anguilla');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 80, 'description', 3, 'Georgien');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 80, 'description', 4, 'Géorgie');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 81, 'description', 3, 'Deutschland');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 81, 'description', 4, 'Allemagne');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 82, 'description', 3, 'Ghana');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 82, 'description', 4, 'Ghana');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 83, 'description', 3, 'Gibraltar');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 83, 'description', 4, 'Gibraltar');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 84, 'description', 3, 'Griechenland');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 84, 'description', 4, 'Grèce');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 85, 'description', 3, 'GrÖnland');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 85, 'description', 4, 'Groenland');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 86, 'description', 3, 'Grenada');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 86, 'description', 4, 'Grenade');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 87, 'description', 3, 'Guadeloupe');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 87, 'description', 4, 'Guadeloupe');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 88, 'description', 3, 'Guam');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 88, 'description', 4, 'Guam');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 89, 'description', 3, 'mala');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 89, 'description', 4, 'Guatemala');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 8, 'description', 3, 'Antarktik');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 8, 'description', 4, 'Antarctique');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 90, 'description', 3, 'Guinea');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 90, 'description', 4, 'Guinée');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 91, 'description', 3, 'Guinea-Bissau');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 91, 'description', 4, 'Guinée-Bissau');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 92, 'description', 3, 'Guyana');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 92, 'description', 4, 'Guyane');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 93, 'description', 3, 'Haiti');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 93, 'description', 4, 'Haïti');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 94, 'description', 3, 'Heard Inseln und McDonald Inseln');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 94, 'description', 4, 'Îles Heard-et-MacDonald');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 95, 'description', 3, 'Honduras');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 95, 'description', 4, 'Honduras');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 96, 'description', 3, 'Hong Kong SAR');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 96, 'description', 4, 'Hong Kong - Région administrative spéciale');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 97, 'description', 3, 'Ungarn');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 97, 'description', 4, 'Hongrie');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 98, 'description', 3, 'Island');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 98, 'description', 4, 'Islande');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 99, 'description', 3, 'Indien');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 99, 'description', 4, 'Inde');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 9, 'description', 3, 'Antigua und Barbuda');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (64, 9, 'description', 4, 'Antigua-et-Barbuda');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (6, 4, 'description', 3, 'Jahr');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (6, 4, 'description', 4, 'Année');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (6, 5, 'description', 3, 'Zeimal monatlich');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (6, 5, 'description', 4, 'Deux fois par mois');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (7, 1, 'description', 3, 'Email');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (7, 1, 'description', 4, 'E-mail');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (7, 2, 'description', 3, 'Papoer');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (7, 2, 'description', 4, 'Papier');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (7, 3, 'description', 3, 'Email + Papier');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (7, 3, 'description', 4, 'E-mail + Papier');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (81, 1, 'description', 3, 'Aktiv');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (81, 1, 'description', 4, 'Actif');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (81, 2, 'description', 3, 'Anstehende Kƒndigung');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (81, 2, 'description', 4, 'Désabonnement imminent');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (81, 3, 'description', 3, 'Gekƒndigt');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (81, 3, 'description', 4, 'Désabonné');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (81, 4, 'description', 3, 'Anstehender Verfall');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (81, 4, 'description', 4, 'Expiration imminente');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (81, 5, 'description', 3, 'verfallen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (81, 5, 'description', 4, 'Expiré');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (81, 6, 'description', 3, 'Nichtabonnentend');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (81, 6, 'description', 4, 'Non-abonné');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (81, 7, 'description', 3, 'Eingestellt');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (81, 7, 'description', 4, 'Interrompu');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (88, 1, 'description', 3, 'Aktiv');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (88, 1, 'description', 4, 'Actif');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (88, 2, 'description', 3, 'Inaktiv');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (88, 2, 'description', 4, 'Inactif');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (88, 3, 'description', 3, 'ausstehend aktiv');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (88, 3, 'description', 4, 'En attente d''être actif');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (88, 4, 'description', 3, 'ausstehend inaktiv');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (88, 4, 'description', 4, 'En attente d''être inactif');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (88, 5, 'description', 3, 'Fehlgeschlagen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (88, 5, 'description', 4, 'Échec');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (88, 6, 'description', 3, 'nicht verfƒgbar');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (88, 6, 'description', 4, 'Indisponible');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (90, 1, 'description', 3, 'Bezahlt');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (90, 1, 'description', 4, 'Payée');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (90, 2, 'description', 3, 'Unbezahlt');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (90, 2, 'description', 4, 'Impayée');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (90, 3, 'description', 3, 'Übertragen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (90, 3, 'description', 4, 'Reportée');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (91, 1, 'description', 3, 'Fertig und abrechenbar');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (91, 1, 'description', 4, 'Terminée et facturable');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (91, 2, 'description', 3, 'Fertig und nicht abrechenbar');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (91, 2, 'description', 4, 'Terminée et non facturable');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (91, 3, 'description', 3, 'Fehler gefunden');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (91, 3, 'description', 4, 'Erreur détectée');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (91, 4, 'description', 3, 'Fehler gemeldet');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (91, 4, 'description', 4, 'Erreur déclarée');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9, 1, 'description', 3, 'Aktiv');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9, 1, 'description', 4, 'Actif');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (92, 1, 'description', 3, 'Laufend');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (92, 1, 'description', 4, 'En cours d''exécution');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (92, 2, 'description', 3, 'Fertig: Erfolgreich');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (92, 2, 'description', 4, 'Terminée : succès');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (92, 3, 'description', 3, 'Fertig: Fehlgeschlagen');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (92, 3, 'description', 4, 'Terminée : échec');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9, 600, 'description', 4, 'Avertissement');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9, 601, 'description', 4, 'Avertissement 2');

INSERT INTO international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (9, 602, 'description', 4, 'Paiement');

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#14049-French and German Translation Texts', 'Manisha Gupta', 'descriptors/database/jbilling-init_data.xml', NOW(), 30, '7:dd6d45fab927aac247b1c011ab789ef4', 'insert (x2), sql', '', 'EXECUTED', '3.2.2');

