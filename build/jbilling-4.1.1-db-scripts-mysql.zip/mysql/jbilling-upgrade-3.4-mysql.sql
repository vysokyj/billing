--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::#4938 - Asset Management - Entites::Gerhard Maree
--  Asset Status related changes
--  Item related changes
--  ItemType related changes
--  Asset related changes
--  Asset Transition related changes
CREATE TABLE jbilling_test.asset_status (id INT NOT NULL, item_type_id INT NULL, is_default INT NOT NULL, is_order_saved INT NOT NULL, is_available INT NOT NULL, deleted INT NOT NULL, optlock INT NOT NULL, CONSTRAINT asset_status_pkey PRIMARY KEY (id));

ALTER TABLE jbilling_test.asset_status ADD CONSTRAINT asset_status_fk_1 FOREIGN KEY (item_type_id) REFERENCES jbilling_test.item_type (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('asset_status', 1.0);

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES ((select max(jt.id)+1 from jbilling_table jt), 'asset_status');

ALTER TABLE jbilling_test.item ADD asset_management_enabled INT NOT NULL DEFAULT 0;

CREATE TABLE jbilling_test.item_type_meta_field_def_map (item_type_id INT NOT NULL, meta_field_id INT NOT NULL);

ALTER TABLE jbilling_test.item_type_meta_field_def_map ADD CONSTRAINT item_type_meta_field_def_map_fk_1 FOREIGN KEY (item_type_id) REFERENCES jbilling_test.item_type (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.item_type_meta_field_def_map ADD CONSTRAINT item_type_meta_field_def_map_fk_2 FOREIGN KEY (meta_field_id) REFERENCES jbilling_test.meta_field_name (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.item_type ADD allow_asset_management INT NOT NULL DEFAULT 0;

ALTER TABLE jbilling_test.item_type ADD asset_identifier_label VARCHAR(50) NULL;

CREATE TABLE jbilling_test.asset (id INT NOT NULL, identifier VARCHAR(200) NOT NULL, create_datetime TIMESTAMP NOT NULL, status_id INT NOT NULL, entity_id INT NOT NULL, deleted INT NOT NULL, item_id INT NOT NULL, order_line_id INT NULL, notes VARCHAR(1000) NULL, optlock INT NOT NULL, CONSTRAINT asset_pkey PRIMARY KEY (id));

ALTER TABLE jbilling_test.asset ADD CONSTRAINT asset_fk_4 FOREIGN KEY (entity_id) REFERENCES jbilling_test.entity (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.asset ADD CONSTRAINT asset_fk_3 FOREIGN KEY (status_id) REFERENCES jbilling_test.asset_status (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.asset ADD CONSTRAINT asset_fk_2 FOREIGN KEY (order_line_id) REFERENCES jbilling_test.order_line (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.asset ADD CONSTRAINT asset_fk_1 FOREIGN KEY (item_id) REFERENCES jbilling_test.item (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('asset', 1.0);

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES ((select max(jt.id)+1 from jbilling_table jt), 'asset');

CREATE TABLE jbilling_test.asset_meta_field_map (asset_id INT NOT NULL, meta_field_value_id INT NOT NULL);

ALTER TABLE jbilling_test.asset_meta_field_map ADD CONSTRAINT asset_meta_field_map_fk_1 FOREIGN KEY (asset_id) REFERENCES jbilling_test.asset (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.asset_meta_field_map ADD CONSTRAINT asset_meta_field_map_fk_2 FOREIGN KEY (meta_field_value_id) REFERENCES jbilling_test.meta_field_value (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

CREATE TABLE jbilling_test.asset_transition (id INT NOT NULL, create_datetime TIMESTAMP NOT NULL, previous_status_id INT NULL, new_status_id INT NOT NULL, asset_id INT NOT NULL, user_id INT NULL, assigned_to_id INT NULL, CONSTRAINT asset_transition_pkey PRIMARY KEY (id));

ALTER TABLE jbilling_test.asset_transition ADD CONSTRAINT asset_transition_fk_1 FOREIGN KEY (assigned_to_id) REFERENCES jbilling_test.base_user (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.asset_transition ADD CONSTRAINT asset_transition_fk_2 FOREIGN KEY (user_id) REFERENCES jbilling_test.base_user (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.asset_transition ADD CONSTRAINT asset_transition_fk_3 FOREIGN KEY (asset_id) REFERENCES jbilling_test.asset (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.asset_transition ADD CONSTRAINT asset_transition_fk_4 FOREIGN KEY (new_status_id) REFERENCES jbilling_test.asset_status (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.asset_transition ADD CONSTRAINT asset_transition_fk_5 FOREIGN KEY (previous_status_id) REFERENCES jbilling_test.asset_status (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('asset_transition', 1.0);

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES ((select max(jt.id)+1 from jbilling_table jt), 'asset_transition');

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#4938 - Asset Management - Entites', 'Gerhard Maree', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 1, '7:d2fdd52f6735f83b8e5f6b04460b54a5', 'createTable, addForeignKeyConstraint, insert (x2), addColumn, createTable, addForeignKeyConstraint (x2), addColumn (x2), createTable, addForeignKeyConstraint (x4), insert (x2), createTable, addForeignKeyConstraint (x2), createTable, addForeignKeyC...', 'Asset Status related changes
Item related changes
ItemType related changes
Asset related changes
Asset Transition related changes', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::#4938 - Asset Management - Pluggable Tasks::Gerhard Maree
--  Register 3 new tasks:
--              FileCleanupTask - This task will delete files older than a certain time. The task is only
--                  scheduled for the first entity since it will look at the same folder for all entities.
--              AssetUpdatedTask - Create AssetTransitionDTO objects when asset status changes
--              RemoveAssetFromFinishedOrderTask - When an Order moves into a FINISHED state all assets are
--                  unlinked and changed back to the default status
INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (coalesce((select max(p.id)+1 from pluggable_task_type p),1), 22.0, 'com.sapienter.jbilling.server.pluggableTask.FileCleanupTask', 2.0);

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, (select max(p.id) from pluggable_task_type p), 'title', 1.0, 'Delete old files');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, (select max(p.id) from pluggable_task_type p), 'description', 1.0, 'This task will delete files older than a certain time.');

INSERT INTO pluggable_task (id, entity_id, type_id, processing_order, optlock)
                   select (select max(p.id)+1 from pluggable_task p) ,
                          e1.id,
                          (select max(p.id) from pluggable_task_type p),
                          4,
                          1
                   from entity e1
                   where e1.id in (select min(id) from entity);

INSERT INTO pluggable_task_parameter (id, task_id, name, str_value, optlock)
                   select (select max(pp.id)+1 from pluggable_task_parameter pp) ,
                          (select max(pt.id) from pluggable_task pt),
                          'folder.1',
                          '${base_dir}/reports/assets',
                          1
                   from entity e1
                   where e1.id in (select min(id) from entity);

INSERT INTO pluggable_task_parameter (id, task_id, name, str_value, optlock)
                   select (select max(pp.id)+1 from pluggable_task_parameter pp) ,
                          (select max(pt.id) from pluggable_task pt),
                          'file_name_regex.1',
                          'asset.*',
                          1
                   from entity e1
                   where e1.id in (select min(id) from entity);

INSERT INTO pluggable_task_parameter (id, task_id, name, int_value, optlock)
                   select (select max(pp.id)+1 from pluggable_task_parameter pp) ,
                          (select max(pt.id) from pluggable_task pt),
                          'age_in_minutes.1',
                          120,
                          1
                   from entity e1
                   where e1.id in (select min(id) from entity);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (coalesce((select max(p.id)+1 from pluggable_task_type p),1), 17.0, 'com.sapienter.jbilling.server.item.tasks.AssetUpdatedTask', 0.0);

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, (select max(p.id) from pluggable_task_type p), 'title', 1.0, 'Updates Asset Transitions');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, (select max(p.id) from pluggable_task_type p), 'description', 1.0, 'This plug-in will update AssetTransitions when an asset status changes.');

INSERT INTO pluggable_task (id, entity_id, type_id, processing_order, optlock)
                   select (select max(p.id)+1 from pluggable_task p) + (select count(*) from entity e2 where e1.id > e2.id and e2.id <> e1.id),
                          e1.id,
                          (select max(p.id) from pluggable_task_type p),
                          1,
                          1
                   from entity e1
                   order by e1.id;

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (coalesce((select max(p.id)+1 from pluggable_task_type p),1), 17.0, 'com.sapienter.jbilling.server.item.tasks.RemoveAssetFromFinishedOrderTask', 0.0);

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, (select max(p.id) from pluggable_task_type p), 'title', 1.0, 'Remove Assets From FINISHED Orders');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, (select max(p.id) from pluggable_task_type p), 'description', 1.0, 'This plug-in will remove Asset owners when the linked order expires.');

UPDATE jbilling_test.jbilling_seqs SET next_id = coalesce((select max(p.id)+1 from pluggable_task_type p),1) WHERE name='pluggable_task_type';

INSERT INTO pluggable_task (id, entity_id, type_id, processing_order, optlock)
                   select (select max(p.id)+1 from pluggable_task p) + (select count(*) from entity e2 where e1.id > e2.id and e2.id <> e1.id),
                          e1.id,
                          (select max(p.id) from pluggable_task_type p),
                          1,
                          1
                   from entity e1
                   order by e1.id;

UPDATE jbilling_test.jbilling_seqs SET next_id = coalesce((select max(p.id)+1 from pluggable_task p), 1) WHERE name='pluggable_task';

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#4938 - Asset Management - Pluggable Tasks', 'Gerhard Maree', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 2, '7:a30c26ed09010e0ef0bfd85459179416', 'insert (x3), sql, insert (x3), sql, insert (x3), update, sql, update', 'Register 3 new tasks:
            FileCleanupTask - This task will delete files older than a certain time. The task is only
                scheduled for the first entity since it will look at the same folder for all entities.
            AssetUpd...', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::20130719 #5729: - Asset Groups - Entites::Gerhard Maree
--  Asset Groups related changes
insert into asset_status (id, deleted, item_type_id, is_default, is_order_saved, is_available, optlock)
            select 100+id+(select next_id from jbilling_seqs where name='asset_status'), deleted, item_type_id, is_default, is_order_saved, is_available, 1
            from asset_status where id < 100;

UPDATE jbilling_test.asset SET status_id = 100 + status_id + (select next_id from jbilling_seqs where name='asset_status') WHERE status_id < 100;

UPDATE jbilling_test.asset_transition SET new_status_id = 100 + new_status_id + (select next_id from jbilling_seqs where name='asset_status') WHERE new_status_id < 100;

UPDATE jbilling_test.asset_transition SET previous_status_id = 100 + previous_status_id + (select next_id from jbilling_seqs where name='asset_status') WHERE previous_status_id < 100;

UPDATE jbilling_test.international_description SET foreign_id = 100 + foreign_id + (select next_id from jbilling_seqs where name='asset_status') WHERE table_id=108 AND foreign_id < 100;

DELETE FROM jbilling_test.asset_status  WHERE id < 100;

UPDATE jbilling_test.jbilling_seqs SET next_id = coalesce((select max(p.id)+1 from asset_status p), 1) WHERE name='asset_status';

ALTER TABLE jbilling_test.asset ADD group_id INT NULL;

ALTER TABLE jbilling_test.asset_status ADD is_internal INT NOT NULL DEFAULT 0;

INSERT INTO jbilling_test.asset_status (id, deleted, is_default, is_order_saved, is_available, is_internal, optlock) VALUES (1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0);

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (108.0, 1.0, 'description', 1.0, 'Member Of Group');

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('20130719 #5729: - Asset Groups - Entites', 'Gerhard Maree', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 3, '7:0794a98449f5c2e12f9bed3b52bc3b1a', 'sql, update (x4), delete, update, addColumn (x2), insert (x2)', 'Asset Groups related changes', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::spring-batch-tables::Emiliano Conde
--  These are the tables and sequences needed by Spring Batch to work.
--              Note that this will not work on MySQL, since it does not have sequences
--              Yet S Batch does support MySQL so there has to be some alternative
CREATE TABLE jbilling_test.batch_job_execution (job_execution_id INT NOT NULL, version INT NULL, job_instance_id INT NOT NULL, create_time TIMESTAMP NOT NULL, start_time TIMESTAMP NULL, end_time TIMESTAMP NULL, status VARCHAR(10) NULL, exit_code VARCHAR(100) NULL, exit_message VARCHAR(2500) NULL, last_updated TIMESTAMP NULL, job_configuration_location VARCHAR(2500) NULL, CONSTRAINT batch_job_execution_pkey PRIMARY KEY (job_execution_id));

CREATE TABLE jbilling_test.batch_job_execution_context (job_execution_id BIGINT NOT NULL, short_context VARCHAR(2500) NOT NULL, serialized_context LONGTEXT NULL, CONSTRAINT batch_job_execution_context_pkey PRIMARY KEY (job_execution_id));

CREATE TABLE jbilling_test.batch_job_instance (job_instance_id INT NOT NULL, version INT NULL, job_name VARCHAR(100) NOT NULL, job_key VARCHAR(32) NOT NULL, CONSTRAINT batch_job_instance_pkey PRIMARY KEY (job_instance_id));

CREATE TABLE jbilling_test.batch_job_execution_params (job_execution_id INT NOT NULL, type_cd VARCHAR(6) NOT NULL, key_name VARCHAR(100) NOT NULL, string_val VARCHAR(250) NULL, date_val TIMESTAMP NULL, long_val INT NULL, double_val numeric(17) NULL, identifying CHAR(1) NULL);

CREATE TABLE jbilling_test.batch_step_execution (step_execution_id INT NOT NULL, version INT NOT NULL, step_name VARCHAR(100) NOT NULL, job_execution_id INT NOT NULL, start_time TIMESTAMP NOT NULL, end_time TIMESTAMP NULL, status VARCHAR(10) NULL, commit_count INT NULL, read_count INT NULL, filter_count INT NULL, write_count INT NULL, read_skip_count INT NULL, write_skip_count INT NULL, process_skip_count INT NULL, rollback_count INT NULL, exit_code VARCHAR(100) NULL, exit_message VARCHAR(2500) NULL, last_updated TIMESTAMP NULL, CONSTRAINT batch_step_execution_pkey PRIMARY KEY (step_execution_id));

CREATE TABLE jbilling_test.batch_step_execution_context (step_execution_id INT NOT NULL, short_context VARCHAR(2500) NOT NULL, serialized_context LONGTEXT NULL, CONSTRAINT batch_step_execution_context_pkey PRIMARY KEY (step_execution_id));

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('spring-batch-tables', 'Emiliano Conde', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 4, '7:171c3c92d345411b881249972ed15ce1', 'createTable (x6)', 'These are the tables and sequences needed by Spring Batch to work.
            Note that this will not work on MySQL, since it does not have sequences
            Yet S Batch does support MySQL so there has to be some alternative', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::spring-batch-key-gen-mysql::Gerhard Maree
--  These are the tables and sequences needed by Spring Batch to work on MySQL.
CREATE TABLE jbilling_test.batch_step_execution_seq (id BIGINT AUTO_INCREMENT NOT NULL, CONSTRAINT PK_BATCH_STEP_EXECUTION_SEQ PRIMARY KEY (id));

CREATE TABLE jbilling_test.batch_job_seq (id BIGINT AUTO_INCREMENT NOT NULL, CONSTRAINT PK_BATCH_JOB_SEQ PRIMARY KEY (id));

CREATE TABLE jbilling_test.batch_job_execution_seq (id BIGINT AUTO_INCREMENT NOT NULL, CONSTRAINT PK_BATCH_JOB_EXECUTION_SEQ PRIMARY KEY (id));

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('spring-batch-key-gen-mysql', 'Gerhard Maree', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 5, '7:cb06b648182082a393a14d70607e0b10', 'createTable (x3)', 'These are the tables and sequences needed by Spring Batch to work on MySQL.', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::Customer Account Type::Rahul Asthana
CREATE TABLE jbilling_test.account_type (id INT NOT NULL, credit_limit numeric(22, 10) NULL, invoice_design VARCHAR(100) NULL, invoice_delivery_method_id INT NULL, date_created TIMESTAMP NULL, credit_notification_limit1 numeric(22, 10) NULL, credit_notification_limit2 numeric(22, 10) NULL, language_id INT NULL, entity_id INT NULL, currency_id INT NULL, optlock INT NOT NULL, main_subscript_order_period_id INT NOT NULL, next_invoice_day_of_period INT NOT NULL, CONSTRAINT account_type_pkey PRIMARY KEY (id));

ALTER TABLE jbilling_test.account_type ADD CONSTRAINT account_type_main_subscription_period_FK FOREIGN KEY (main_subscript_order_period_id) REFERENCES jbilling_test.order_period (id);

ALTER TABLE jbilling_test.account_type ADD CONSTRAINT account_type_currency_id_FK FOREIGN KEY (currency_id) REFERENCES jbilling_test.currency (id);

ALTER TABLE jbilling_test.account_type ADD CONSTRAINT account_type_language_id_FK FOREIGN KEY (language_id) REFERENCES jbilling_test.language (id);

ALTER TABLE jbilling_test.account_type ADD CONSTRAINT invoice_delivery_method_id_FK FOREIGN KEY (invoice_delivery_method_id) REFERENCES jbilling_test.invoice_delivery_method (id);

ALTER TABLE jbilling_test.account_type ADD CONSTRAINT account_type_entity_id_FK FOREIGN KEY (entity_id) REFERENCES jbilling_test.entity (id);

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('Customer Account Type', 'Rahul Asthana', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 6, '7:9f5503ac5a2c53c02ec46203641f4838', 'createTable, addForeignKeyConstraint (x5)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::add-account-type-in-jbilling_table::Rahul Asthana
INSERT INTO jbilling_test.jbilling_table (id, name) VALUES ((select max(jt.id)+1 from jbilling_table jt), 'account_type');

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('add-account-type-in-jbilling_table', 'Rahul Asthana', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 7, '7:cf0e47a00053bd4f99942c4ce646b197', 'insert', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::5015-remove-auto-payment::Gurdev Parmar
ALTER TABLE jbilling_test.billing_process_configuration DROP COLUMN auto_payment;

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('5015-remove-auto-payment', 'Gurdev Parmar', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 8, '7:a8840e138fbc85667758c15a348a4f1d', 'dropColumn', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::20130514-#4987-account-type-management::Vladimir Carevski
INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('account_type', 1.0);

ALTER TABLE jbilling_test.customer ADD account_type_id INT NULL;

ALTER TABLE jbilling_test.customer ADD invoice_design VARCHAR(100) NULL;

ALTER TABLE jbilling_test.customer ADD CONSTRAINT customer_account_type_fk FOREIGN KEY (account_type_id) REFERENCES jbilling_test.account_type (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('20130514-#4987-account-type-management', 'Vladimir Carevski', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 9, '7:44dda31d011da48e31cf24dd75f36b59', 'insert, addColumn, addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::20130516-#4988-account-type-pricing::Panche Isajeski
CREATE TABLE jbilling_test.account_type_price (account_type_id INT NOT NULL, create_datetime TIMESTAMP NOT NULL);

CREATE TABLE jbilling_test.item_account_type_availability (item_id INT NULL, account_type_id INT NULL);

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('20130516-#4988-account-type-pricing', 'Panche Isajeski', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 10, '7:a3561ad5969bb383639dbbfd40165abd', 'createTable (x2)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::20130516-#4988-account-type-pricing-item-std-avail::Gerhard Maree
ALTER TABLE jbilling_test.item ADD standard_availability BIT(1) NOT NULL DEFAULT 1;

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('20130516-#4988-account-type-pricing-item-std-avail', 'Gerhard Maree', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 11, '7:0ff0e80ad5debd037875c0bdac53cdf0', 'addColumn', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::20130429-#4920::Oleg Baskakov
--  Requirement #4920 - Create MetaField Groups.
CREATE TABLE jbilling_test.meta_field_group (id INT NOT NULL, date_created date NULL, date_updated date NULL, entity_id INT NOT NULL, display_order INT NULL, optlock INT NULL, entity_type VARCHAR(32) NOT NULL, CONSTRAINT metafield_group_pkey PRIMARY KEY (id));

CREATE TABLE jbilling_test.metafield_group_meta_field_map (metafield_group_id INT NOT NULL, meta_field_value_id INT NOT NULL);

ALTER TABLE jbilling_test.meta_field_name ADD validation_rule VARCHAR(256) NULL;

ALTER TABLE jbilling_test.meta_field_name ADD error_message VARCHAR(256) NULL;

INSERT INTO jbilling_test.jbilling_table (name, id) VALUES ('meta_field_group', (select max(jt.id)+1 from jbilling_table jt));

INSERT INTO jbilling_test.jbilling_table (name, id) VALUES ('meta_field_name', (select max(jt.id)+1 from jbilling_table jt));

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('meta_field_group', '1');

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('20130429-#4920', 'Oleg Baskakov', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 12, '7:d8cd8ca4d3f3f1cc4f3e25c049ee2a71', 'createTable (x2), addColumn, insert (x3)', 'Requirement #4920 - Create MetaField Groups.', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::20130429-#4920-bool-fix::Gerhard Maree
ALTER TABLE jbilling_test.meta_field_name ADD is_primary BIT(1) NULL DEFAULT 1;

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('20130429-#4920-bool-fix', 'Gerhard Maree', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 13, '7:605967cf59b64c8a6d2173ea24e69582', 'addColumn', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::20130506-#4921::Oleg Baskakov
--  Requirement #4921 - MetaField validation rules.
CREATE TABLE jbilling_test.metafield_type_map (metafield_id INT NOT NULL, field_usage VARCHAR(32) NOT NULL);

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('20130506-#4921', 'Oleg Baskakov', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 14, '7:a65ad49096481e8b5f8e32abf20ccc85', 'createTable', 'Requirement #4921 - MetaField validation rules.', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::20130513-#4922::Oleg Baskakov
--  Requirements #4922 - Create Account Information Types (AIT)
ALTER TABLE jbilling_test.meta_field_group ADD discriminator VARCHAR(30) NOT NULL;

ALTER TABLE jbilling_test.meta_field_group ADD name VARCHAR(32) NULL;

ALTER TABLE jbilling_test.meta_field_group ADD account_type_id INT NULL;

ALTER TABLE jbilling_test.meta_field_group ADD CONSTRAINT account_type_main_subscription_period_FK2 FOREIGN KEY (account_type_id) REFERENCES jbilling_test.account_type (id);

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('20130513-#4922', 'Oleg Baskakov', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 15, '7:1970e21215fc78e9db1c896c99bb0c35', 'addColumn, addForeignKeyConstraint', 'Requirements #4922 - Create Account Information Types (AIT)', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::#5388-Java based Metafield validation::Panche Isajeski
--  Metafields - Custom Java validators
CREATE TABLE jbilling_test.validation_rule (id INT NOT NULL, rule_type VARCHAR(25) NOT NULL, enabled BIT(1) NULL, optlock INT NOT NULL, CONSTRAINT validation_rule_pkey PRIMARY KEY (id));

ALTER TABLE jbilling_test.meta_field_name DROP COLUMN validation_rule;

ALTER TABLE jbilling_test.meta_field_name ADD validation_rule_id INT NULL;

ALTER TABLE jbilling_test.meta_field_name ADD CONSTRAINT validation_rule_fk_1 FOREIGN KEY (validation_rule_id) REFERENCES jbilling_test.validation_rule (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

CREATE TABLE jbilling_test.validation_rule_attributes (validation_rule_id INT NOT NULL, attribute_name VARCHAR(255) NOT NULL, attribute_value VARCHAR(255) NULL);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('validation_rule', 1.0);

INSERT INTO jbilling_test.jbilling_table (name, id) VALUES ('validation_rule', (select max(jt.id)+1 from jbilling_table jt));

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#5388-Java based Metafield validation', 'Panche Isajeski', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 16, '7:1387a5fbc16e5986b74c3fe3c5c49ad4', 'createTable, dropColumn, addColumn, addForeignKeyConstraint, createTable, insert (x2)', 'Metafields - Custom Java validators', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::#5137-remove-contact-type-constraints-on-contact-map::Vladimir Carevski
ALTER TABLE jbilling_test.contact_map MODIFY type_id INT NULL;

ALTER TABLE jbilling_test.contact_map DROP FOREIGN KEY contact_map_fk_1;

DROP INDEX contact_map_i_3 ON jbilling_test.contact_map;

ALTER TABLE jbilling_test.contact_map ADD CONSTRAINT contact_map_fk_1 FOREIGN KEY (table_id) REFERENCES jbilling_test.jbilling_table (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#5137-remove-contact-type-constraints-on-contact-map', 'Vladimir Carevski', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 17, '7:881e8c84288d3af8cffdc4d0667417ce', 'dropNotNullConstraint, dropForeignKeyConstraint, dropIndex, addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::20130531-#5237-product-dependencies::Shweta Gupta
CREATE TABLE jbilling_test.item_type_mandatory_map (item_id INT NOT NULL, mandatory_type_id INT NOT NULL);

ALTER TABLE jbilling_test.item_type_mandatory_map ADD PRIMARY KEY (item_id, mandatory_type_id);

ALTER TABLE jbilling_test.item_type_mandatory_map ADD CONSTRAINT item_type_mandatory_item_id_fk FOREIGN KEY (item_id) REFERENCES jbilling_test.item (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.item_type_mandatory_map ADD CONSTRAINT item_type_mandatory_type_id_fk FOREIGN KEY (mandatory_type_id) REFERENCES jbilling_test.item_type (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

CREATE TABLE jbilling_test.item_type_optional_map (item_id INT NOT NULL, optional_type_id INT NOT NULL);

ALTER TABLE jbilling_test.item_type_optional_map ADD PRIMARY KEY (item_id, optional_type_id);

ALTER TABLE jbilling_test.item_type_optional_map ADD CONSTRAINT item_type_optional_item_id_fk FOREIGN KEY (item_id) REFERENCES jbilling_test.item (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.item_type_optional_map ADD CONSTRAINT item_type_optional_type_id_fk FOREIGN KEY (optional_type_id) REFERENCES jbilling_test.item_type (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

CREATE TABLE jbilling_test.item_mandatory_map (item_id INT NOT NULL, mandatory_item_id INT NOT NULL);

ALTER TABLE jbilling_test.item_mandatory_map ADD PRIMARY KEY (item_id, mandatory_item_id);

ALTER TABLE jbilling_test.item_mandatory_map ADD CONSTRAINT item_mandatory_map_item_id_fk FOREIGN KEY (item_id) REFERENCES jbilling_test.item (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.item_mandatory_map ADD CONSTRAINT item_mandatory_map_mandatory_item_id_fk FOREIGN KEY (mandatory_item_id) REFERENCES jbilling_test.item (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

CREATE TABLE jbilling_test.item_optional_map (item_id INT NOT NULL, optional_item_id INT NOT NULL);

ALTER TABLE jbilling_test.item_optional_map ADD PRIMARY KEY (item_id, optional_item_id);

ALTER TABLE jbilling_test.item_optional_map ADD CONSTRAINT item_optional_map_item_id_fk FOREIGN KEY (item_id) REFERENCES jbilling_test.item (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.item_optional_map ADD CONSTRAINT item_optional_map_optional_item_id_fk FOREIGN KEY (optional_item_id) REFERENCES jbilling_test.item (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('20130531-#5237-product-dependencies', 'Shweta Gupta', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 18, '7:ec8bd52646e88556a9e0b14df38d0b04', 'createTable, addPrimaryKey, addForeignKeyConstraint (x2), createTable, addPrimaryKey, addForeignKeyConstraint (x2), createTable, addPrimaryKey, addForeignKeyConstraint (x2), createTable, addPrimaryKey, addForeignKeyConstraint (x2)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::#5293_product_inherited_order_meta_fields::Alexander Aksenov
--  Item related changes
CREATE TABLE jbilling_test.order_line_meta_fields_map (item_id INT NOT NULL, meta_field_id INT NOT NULL);

ALTER TABLE jbilling_test.order_line_meta_fields_map ADD CONSTRAINT ol_meta_fields_map_fk_1 FOREIGN KEY (item_id) REFERENCES jbilling_test.item (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.order_line_meta_fields_map ADD CONSTRAINT ol_meta_fields_map_fk_2 FOREIGN KEY (meta_field_id) REFERENCES jbilling_test.meta_field_name (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#5293_product_inherited_order_meta_fields', 'Alexander Aksenov', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 19, '7:218b3ffdf03f97e2e369076b4537a734', 'createTable, addForeignKeyConstraint (x2)', 'Item related changes', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::1337623084753-114::Maruthi
CREATE TABLE jbilling_test.order_status (id INT NOT NULL, order_status_flag INT NULL, entity_id INT NULL, CONSTRAINT order_status_pkey PRIMARY KEY (id));

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('1337623084753-114', 'Maruthi', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 20, '7:91bbe9c305dc6d45e0ebb5712cbf6d03', 'createTable', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::#5338 Route-based Rating::Rahul Asthana
CREATE TABLE jbilling_test.route (id INT NOT NULL, name VARCHAR(255) NOT NULL, table_name VARCHAR(50) NOT NULL, entity_id INT NOT NULL, optlock INT NOT NULL, CONSTRAINT route_pkey PRIMARY KEY (id));

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#5338 Route-based Rating', 'Rahul Asthana', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 21, '7:74d50fa474a8287b861d9889a09e815b', 'createTable', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::#5557 Matching Field::Rahul Asthana
CREATE TABLE jbilling_test.matching_field (id INT NOT NULL, description VARCHAR(255) NOT NULL, required BIT(1) NOT NULL, route_id INT NULL, matching_field VARCHAR(255) NOT NULL, type VARCHAR(255) NOT NULL, order_sequence INT NOT NULL, optlock INT NOT NULL, longest_value INT NOT NULL, smallest_value INT NOT NULL, mandatory_fields_query VARCHAR(1000) NOT NULL, CONSTRAINT matching_field_pkey PRIMARY KEY (id));

ALTER TABLE jbilling_test.matching_field ADD CONSTRAINT matching_field_route_id_FK FOREIGN KEY (route_id) REFERENCES jbilling_test.route (id);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('matching_field', 1.0);

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#5557 Matching Field', 'Rahul Asthana', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 22, '7:b4999f87529380b9c16a22d45a9dc479', 'createTable, addForeignKeyConstraint, insert', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::#5373 - Development: Order Hierarchies::Alexander Aksenov
ALTER TABLE jbilling_test.purchase_order ADD parent_order_id INT NULL;

ALTER TABLE jbilling_test.purchase_order ADD CONSTRAINT purchase_order_parent__order_id_fk FOREIGN KEY (parent_order_id) REFERENCES jbilling_test.purchase_order (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.order_line ADD parent_line_id INT NULL;

ALTER TABLE jbilling_test.order_line ADD CONSTRAINT order_line_parent_line_id_fk FOREIGN KEY (parent_line_id) REFERENCES jbilling_test.order_line (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#5373 - Development: Order Hierarchies', 'Alexander Aksenov', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 23, '7:7bcddb9931fc77dbfc1468c28ed2166b', 'addColumn, addForeignKeyConstraint, addColumn, addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::#5712 - MF1J - Java based Metafield validation::Shweta Gupta
ALTER TABLE jbilling_test.validation_rule_attributes ADD CONSTRAINT validation_rule_fk_2 FOREIGN KEY (validation_rule_id) REFERENCES jbilling_test.validation_rule (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#5712 - MF1J - Java based Metafield validation', 'Shweta Gupta', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 24, '7:5858b0d04db53a21ea68c7f472adbbef', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::#5294_order_cancellation_fields::Bilal Nasir
--  Adding fields in purchase_order table for order cancellation fees
ALTER TABLE jbilling_test.purchase_order ADD cancellation_fee_type VARCHAR(50) NULL;

ALTER TABLE jbilling_test.purchase_order ADD cancellation_fee INT NULL;

ALTER TABLE jbilling_test.purchase_order ADD cancellation_fee_percentage INT NULL;

ALTER TABLE jbilling_test.purchase_order ADD cancellation_maximum_fee INT NULL;

ALTER TABLE jbilling_test.purchase_order ADD cancellation_minimum_period INT NULL;

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#5294_order_cancellation_fields', 'Bilal Nasir', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 25, '7:5e6b43749bcbda647a86bd6891fd2839', 'addColumn', 'Adding fields in purchase_order table for order cancellation fees', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::#5294_order_cancellation_fields_table_entries::Bilal Nasir
INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES ((select max(t.id)+1 from pluggable_task_type t), 17.0, 'com.sapienter.jbilling.server.order.task.OrderCancellationTask', 1.0);

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, (select max(t.id) from pluggable_task_type t), 'description', 1.0, 'A pluggable task of type InternalEventsTask to monitor when activeUntil changes of an order');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, (select max(t.id) from pluggable_task_type t), 'title', 1.0, 'Order Cancellation Task');

DELETE FROM jbilling_test.pluggable_task_parameter  WHERE task_id=450;

DELETE FROM jbilling_test.pluggable_task  WHERE id=450;

DELETE FROM jbilling_test.international_description  WHERE foreign_id=93 and table_id=24;

DELETE FROM jbilling_test.pluggable_task_type  WHERE id=93;

DELETE FROM jbilling_test.pluggable_task  WHERE type_id=41;

DELETE FROM jbilling_test.international_description  WHERE foreign_id=41 and table_id=24;

UPDATE jbilling_test.jbilling_seqs SET next_id = (select max(p.id)+1 from pluggable_task_type p) WHERE name='pluggable_task_type';

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#5294_order_cancellation_fields_table_entries', 'Bilal Nasir', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 26, '7:97b97b614724bbde22367f3d19a3ce34', 'insert (x3), delete (x6), update', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::requirement # 5292 - 01::Khobab Chaudhary
CREATE TABLE jbilling_test.reseller_entityid_map (entity_id INT NOT NULL, user_id INT NOT NULL);

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('requirement # 5292 - 01', 'Khobab Chaudhary', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 27, '7:35ac07f331f3c11d41982ef04953ba2d', 'createTable', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::requirement # 5292 - 02::Khobab Chaudhary
ALTER TABLE jbilling_test.reseller_entityid_map ADD CONSTRAINT reseller_entityid_map_fk_1 FOREIGN KEY (entity_id) REFERENCES jbilling_test.entity (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.reseller_entityid_map ADD CONSTRAINT reseller_entityid_map_fk_2 FOREIGN KEY (user_id) REFERENCES jbilling_test.base_user (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('requirement # 5292 - 02', 'Khobab Chaudhary', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 28, '7:f9a9541a223b7905f5ccf71cafa5c8af', 'addForeignKeyConstraint (x2)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::requirement # 5292 - 03::Khobab Chaudhary
ALTER TABLE jbilling_test.entity ADD invoice_as_reseller BIT(1) NOT NULL DEFAULT 0;

ALTER TABLE jbilling_test.entity ADD parent_id INT NULL;

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('requirement # 5292 - 03', 'Khobab Chaudhary', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 29, '7:2815b73b41101a9567d0c49dde4ad0db', 'addColumn', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::requirement # 5292 - 04::Khobab Chaudhary
ALTER TABLE jbilling_test.entity ADD CONSTRAINT entity_fk_3 FOREIGN KEY (parent_id) REFERENCES jbilling_test.entity (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('requirement # 5292 - 04', 'Khobab Chaudhary', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 30, '7:a01619e40c28ad9505f080f276c44372', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::requirement # 5292 - 05::Khobab Chaudhary
CREATE TABLE jbilling_test.item_entity_map (item_id INT NOT NULL, entity_id INT NOT NULL);

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('requirement # 5292 - 05', 'Khobab Chaudhary', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 31, '7:76b7bf5d31d076ea4ae38bb45110c3d1', 'createTable', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::requirement # 5292 - 06::Khobab Chaudhary
CREATE TABLE jbilling_test.item_type_entity_map (item_type_id INT NOT NULL, entity_id INT NOT NULL);

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('requirement # 5292 - 06', 'Khobab Chaudhary', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 32, '7:ae82d4daa14928c7b38f34d96d4ef4c9', 'createTable', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::requirement # 5292 - 07::Khobab Chaudhary
ALTER TABLE jbilling_test.item_entity_map ADD CONSTRAINT item_entity_map_fk1 FOREIGN KEY (entity_id) REFERENCES jbilling_test.entity (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('requirement # 5292 - 07', 'Khobab Chaudhary', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 33, '7:b2eef522b8addd13d271c89c76fa2fbf', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::requirement # 5292 - 08::Khobab Chaudhary
ALTER TABLE jbilling_test.item_entity_map ADD CONSTRAINT item_entity_map_fk2 FOREIGN KEY (item_id) REFERENCES jbilling_test.item (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('requirement # 5292 - 08', 'Khobab Chaudhary', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 34, '7:354ce8459251270332180a883ec30e4c', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::requirement # 5292 - 09::Khobab Chaudhary
ALTER TABLE jbilling_test.item_type_entity_map ADD CONSTRAINT item_type_entity_map_fk1 FOREIGN KEY (entity_id) REFERENCES jbilling_test.entity (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('requirement # 5292 - 09', 'Khobab Chaudhary', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 35, '7:299292a3b10a69946707299c7aa4529e', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::requirement # 5292 - 10::Khobab Chaudhary
ALTER TABLE jbilling_test.item_type_entity_map ADD CONSTRAINT item_type_entity_map_fk2 FOREIGN KEY (item_type_id) REFERENCES jbilling_test.item_type (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('requirement # 5292 - 10', 'Khobab Chaudhary', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 36, '7:edce3c6ab8382969e9a86616211c3b10', 'addForeignKeyConstraint', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::requirement # 5292 - 11::Khobab Chaudhary
ALTER TABLE jbilling_test.item ADD global BIT(1) NOT NULL DEFAULT 0;

ALTER TABLE jbilling_test.item_type ADD global BIT(1) NOT NULL DEFAULT 0;

ALTER TABLE jbilling_test.purchase_order ADD reseller_order INT NULL;

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('requirement # 5292 - 11', 'Khobab Chaudhary', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 37, '7:266de35f318964ea6e5545b627d56361', 'addColumn (x3)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::requirement # 5292 - 15::Khobab Chaudhary
INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES ((select max(t.id)+1 from pluggable_task_type t), 17.0, 'com.sapienter.jbilling.server.order.task.CreateOrderForResellerTask', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES ((select max(t.id)+1 from pluggable_task_type t), 17.0, 'com.sapienter.jbilling.server.invoice.task.DeleteResellerOrderTask', 0.0);

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('requirement # 5292 - 15', 'Khobab Chaudhary', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 38, '7:47e7d73bd6ae93e363b5fdbeae40884f', 'insert (x2)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::requirement 5546 - 20130716::Vikas Bodani
INSERT INTO jbilling_test.event_log_message (id) VALUES ((select max(e.id)+1 from event_log_message e));

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (47.0, 35.0, 'description', 1.0, 'A Reseller Order was created for the Root Entity during Invoice generation for a Child Entity.');

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('requirement 5546 - 20130716', 'Vikas Bodani', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 39, '7:04f4f30ff077cf6232bf16ff28d07515', 'insert (x2)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::requirement # 5292 - remove-asset-entity-not-null-constraint::Khobab Chaudhary
ALTER TABLE jbilling_test.asset MODIFY entity_id INT NULL;

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('requirement # 5292 - remove-asset-entity-not-null-constraint', 'Khobab Chaudhary', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 40, '7:503c9aa34417ed7ea608a1b03a56c6d6', 'dropNotNullConstraint', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::#5487-script-meta-field::Vladimir Carevski
ALTER TABLE jbilling_test.meta_field_name ADD filename VARCHAR(100) NULL;

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#5487-script-meta-field', 'Vladimir Carevski', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 41, '7:bdab9ba9fe71dcf375b29e12b29cf63a', 'addColumn', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::#6168 - item_type_nullable_entity::Khobab Chaudhary
ALTER TABLE jbilling_test.item_type MODIFY entity_id INT NULL;

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#6168 - item_type_nullable_entity', 'Khobab Chaudhary', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 42, '7:db4aaea8fc94c588bbcbf5c8669f6b18', 'dropNotNullConstraint', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::#6168 - unique constraint on item_entity_map::Vikas Bodani
ALTER TABLE jbilling_test.item_entity_map ADD CONSTRAINT item_entity_map_uc_1 UNIQUE (entity_id, item_id);

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#6168 - unique constraint on item_entity_map', 'Vikas Bodani', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 43, '7:4dafd75c51626cba097550e5a361bf64', 'addUniqueConstraint', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::#5711 - ait-timeline::Khobab Chaudhary
CREATE TABLE jbilling_test.customer_account_info_type_timeline (id INT NOT NULL, customer_id INT NOT NULL, account_info_type_id INT NOT NULL, meta_field_value_id INT NOT NULL, effective_date date NOT NULL);

ALTER TABLE jbilling_test.customer_account_info_type_timeline ADD PRIMARY KEY (id);

ALTER TABLE jbilling_test.customer_account_info_type_timeline ADD CONSTRAINT customer_account_info_type_timeline_uk UNIQUE (customer_id, meta_field_value_id, account_info_type_id);

ALTER TABLE jbilling_test.customer_account_info_type_timeline ADD CONSTRAINT customer_account_info_type_timeline_customer_id_fk FOREIGN KEY (customer_id) REFERENCES jbilling_test.customer (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.customer_account_info_type_timeline ADD CONSTRAINT customer_account_info_type_timeline_account_info_type_id_fk FOREIGN KEY (account_info_type_id) REFERENCES jbilling_test.meta_field_group (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.customer_account_info_type_timeline ADD CONSTRAINT customer_account_info_type_timeline_meta_field_value_id_fk FOREIGN KEY (meta_field_value_id) REFERENCES jbilling_test.meta_field_value (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#5711 - ait-timeline', 'Khobab Chaudhary', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 44, '7:417f4c5985c69d9d73152ea0c3a4a2f5', 'createTable, addPrimaryKey, addUniqueConstraint, addForeignKeyConstraint (x3)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::20130912-#5815 Minimum Quantities for Dependencies::Gerhard Maree
--  Specify minimum and maximum quantities for product dependencies
CREATE TABLE jbilling_test.item_dependency (id INT NOT NULL, dtype VARCHAR(10) NOT NULL, item_id INT NOT NULL, min INT NOT NULL, max INT NULL, dependent_item_id INT NULL, dependent_item_type_id INT NULL, CONSTRAINT item_dependency_pk PRIMARY KEY (id));

ALTER TABLE jbilling_test.item_dependency ADD CONSTRAINT item_dependency_fk1 FOREIGN KEY (item_id) REFERENCES jbilling_test.item (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.item_dependency ADD CONSTRAINT item_dependency_fk2 FOREIGN KEY (dependent_item_id) REFERENCES jbilling_test.item (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.item_dependency ADD CONSTRAINT item_dependency_fk3 FOREIGN KEY (dependent_item_type_id) REFERENCES jbilling_test.item_type (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO jbilling_test.jbilling_table (name, id) VALUES ('item_dependency', coalesce((select max(t.id)+1 from item_dependency t),1));

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('item_dependency', 1.0);

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('20130912-#5815 Minimum Quantities for Dependencies', 'Gerhard Maree', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 45, '7:d49db9f84717e284b7619fab51e4a853', 'createTable, addForeignKeyConstraint (x3), insert (x2)', 'Specify minimum and maximum quantities for product dependencies', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::20130912-#5815 Migration::Gerhard Maree
insert into item_dependency(id, dtype, item_id, min, max, dependent_item_id, dependent_item_type_id)
                    select coalesce( (select max(id)+1 from item_dependency),1) + (@curRank := @curRank + 1)
                        ,'item', item_id ,1, null, mandatory_item_id, null from item_mandatory_map, (SELECT @curRank := 0) r;

insert into item_dependency(id, dtype, item_id, min, max, dependent_item_id, dependent_item_type_id)
                    select coalesce( (select max(id)+1 from item_dependency),1) + (@curRank := @curRank + 1)
                        ,'item', item_id ,0, null, optional_item_id, null from item_optional_map, (SELECT @curRank := 0) r;

insert into item_dependency(id, dtype, item_id, min, max, dependent_item_id, dependent_item_type_id)
                    select coalesce( (select max(id)+1 from item_dependency),1) + (@curRank := @curRank + 1)
                        ,'item_type', item_id ,1, null, mandatory_type_id, null from item_type_mandatory_map, (SELECT @curRank := 0) r;

insert into item_dependency(id, dtype, item_id, min, max, dependent_item_id, dependent_item_type_id)
                    select coalesce( (select max(id)+1 from item_dependency),1) + (@curRank := @curRank + 1)
                        ,'item_type', item_id ,0, null, optional_type_id, null from item_type_optional_map, (SELECT @curRank := 0) r;

DROP TABLE jbilling_test.item_type_mandatory_map;

DROP TABLE jbilling_test.item_type_optional_map;

DROP TABLE jbilling_test.item_mandatory_map;

DROP TABLE jbilling_test.item_optional_map;

UPDATE jbilling_test.jbilling_seqs SET next_id = (select coalesce( (select max(id)+1 from item_dependency),1)) WHERE name='item_dependency';

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('20130912-#5815 Migration', 'Gerhard Maree', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 46, '7:975da7d2d4d6f749dcd12258f7a38293', 'sql, dropTable (x4), update', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::20130830-#5611::Maeis Gharibjanian
--  Adds columns to customer for credit notification limit1 and limit2
ALTER TABLE jbilling_test.customer ADD credit_notification_limit1 numeric(22, 10) NULL;

ALTER TABLE jbilling_test.customer ADD credit_notification_limit2 numeric(22, 10) NULL;

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('20130830-#5611', 'Maeis Gharibjanian', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 47, '7:39859cc89c1f1b4fde2672682aa2a5e8', 'addColumn', 'Adds columns to customer for credit notification limit1 and limit2', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::springbatch - #5336 - 1::Khobab
CREATE TABLE jbilling_test.batch_process_info (id INT NOT NULL, process_id INT NOT NULL, job_execution_id INT NOT NULL, total_failed_users INT NOT NULL, total_successful_users INT NOT NULL, optlock INT NOT NULL, CONSTRAINT billing_process_info_pkey PRIMARY KEY (id));

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('springbatch - #5336 - 1', 'Khobab', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 48, '7:2f860f0f6789fb382e59594e7b5b2a3f', 'createTable', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::springbatch - #5336 - 3::Khobab
CREATE TABLE jbilling_test.billing_process_failed_user (id INT NOT NULL, batch_process_id INT NOT NULL, user_id INT NOT NULL, optlock INT NOT NULL, CONSTRAINT billing_process_failed_user_pkey PRIMARY KEY (id));

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('springbatch - #5336 - 3', 'Khobab', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 49, '7:eec0f5a2272c3b8dfa082371c5f89dd7', 'createTable', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::#5447 - Development: Order Changes as Entities::Alexander Aksenov
ALTER TABLE jbilling_test.generic_status ADD ordr INT NULL;

ALTER TABLE jbilling_test.generic_status ADD attribute1 VARCHAR(20) NULL;

ALTER TABLE jbilling_test.generic_status ADD entity_id INT NULL;

ALTER TABLE jbilling_test.generic_status ADD deleted INT NULL;

ALTER TABLE jbilling_test.generic_status ADD CONSTRAINT generic_status_entity_id_fk FOREIGN KEY (entity_id) REFERENCES jbilling_test.entity (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO jbilling_test.generic_status_type (id) VALUES ('order_change_status');

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES ((select max(t.id)+1 from jbilling_table t), 'order_change_status');

INSERT INTO jbilling_test.generic_status (id, dtype, status_value, can_login, entity_id, deleted, ordr, attribute1) VALUES ((select max(t.id)+1 from generic_status t), 'order_change_status', 1.0, NULL, NULL, 0.0, 0.0, 'NO');

INSERT INTO jbilling_test.generic_status (id, dtype, status_value, can_login, entity_id, deleted, ordr, attribute1) VALUES ((select max(t.id)+1 from generic_status t), 'order_change_status', 2.0, NULL, NULL, 0.0, 0.0, 'NO');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES ((select t.id from jbilling_table t where t.name = 'order_change_status'), 1.0, 'description', 1.0, 'PENDING');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES ((select t.id from jbilling_table t where t.name = 'order_change_status'), 2.0, 'description', 1.0, 'APPLY ERROR');

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('order_change_status', 3.0);

UPDATE jbilling_test.jbilling_seqs SET next_id = (select max(t.id)+1 from generic_status t) WHERE name='generic_status';

CREATE TABLE jbilling_test.order_change (id INT NOT NULL, parent_order_change_id INT NULL, parent_order_line_id INT NULL, order_id INT NOT NULL, item_id INT NOT NULL, quantity numeric(22, 10) NULL, price numeric(22, 10) NULL, description VARCHAR(1000) NULL, use_item INT NULL, user_id INT NOT NULL, create_datetime TIMESTAMP NOT NULL, start_date date NOT NULL, application_date TIMESTAMP NULL, status_id INT NOT NULL, user_assigned_status_id INT NOT NULL, order_line_id INT NULL, optlock INT NOT NULL, error_message VARCHAR(500) NULL, error_codes VARCHAR(200) NULL, CONSTRAINT order_change_pkey PRIMARY KEY (id));

ALTER TABLE jbilling_test.order_change ADD CONSTRAINT order_change_order_id_fk FOREIGN KEY (order_id) REFERENCES jbilling_test.purchase_order (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.order_change ADD CONSTRAINT order_change_item_id_fk FOREIGN KEY (item_id) REFERENCES jbilling_test.item (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.order_change ADD CONSTRAINT order_change_user_id_fk FOREIGN KEY (user_id) REFERENCES jbilling_test.base_user (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.order_change ADD CONSTRAINT order_change_status_id_fk FOREIGN KEY (status_id) REFERENCES jbilling_test.generic_status (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.order_change ADD CONSTRAINT order_change_user_status_id_fk FOREIGN KEY (user_assigned_status_id) REFERENCES jbilling_test.generic_status (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.order_change ADD CONSTRAINT order_change_order_line_id_fk FOREIGN KEY (order_line_id) REFERENCES jbilling_test.order_line (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.order_change ADD CONSTRAINT order_change_parent_order_line_id_fk FOREIGN KEY (parent_order_line_id) REFERENCES jbilling_test.order_line (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.order_change ADD CONSTRAINT order_change_parent_order_change_fk FOREIGN KEY (parent_order_change_id) REFERENCES jbilling_test.order_change (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

CREATE TABLE jbilling_test.order_change_asset_map (order_change_id INT NOT NULL, asset_id INT NOT NULL);

ALTER TABLE jbilling_test.order_change_asset_map ADD CONSTRAINT order_change_asset_map_change_id_fk FOREIGN KEY (order_change_id) REFERENCES jbilling_test.order_change (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.order_change_asset_map ADD CONSTRAINT order_change_asset_map_asset_id_fk FOREIGN KEY (asset_id) REFERENCES jbilling_test.asset (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES ((select max(t.id)+1 from jbilling_table t), 'order_change');

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('order_change', 1.0);

UPDATE jbilling_test.jbilling_seqs SET next_id = 3.0 WHERE name='order_change_status';

UPDATE jbilling_test.jbilling_seqs SET next_id = (select max(t.id)+1 from generic_status t) WHERE name='generic_status';

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES ((select max(t.id)+1 from pluggable_task_type t), 22.0, 'com.sapienter.jbilling.server.order.task.OrderChangeUpdateTask', 0.0);

UPDATE jbilling_test.jbilling_seqs SET next_id = (select max(t.id)+1 from pluggable_task_type t) WHERE name='pluggable_task_type';

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#5447 - Development: Order Changes as Entities', 'Alexander Aksenov', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 50, '7:f112cf5da994ab8cd38cccf951609b08', 'addColumn, addForeignKeyConstraint, insert (x7), update, createTable, addForeignKeyConstraint (x8), createTable, addForeignKeyConstraint (x2), insert (x2), update (x2), insert, update', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::#5449 - Integrate Product Meta Fields into Order Changes::Gerhard Maree
--  Order Change Meta Fields
--  Order Line Meta Fields
CREATE TABLE jbilling_test.order_change_meta_field_map (order_change_id INT NOT NULL, meta_field_value_id INT NOT NULL);

ALTER TABLE jbilling_test.order_change_meta_field_map ADD CONSTRAINT order_change_meta_field_map_fk_1 FOREIGN KEY (order_change_id) REFERENCES jbilling_test.order_change (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.order_change_meta_field_map ADD CONSTRAINT order_change_meta_field_map_fk_2 FOREIGN KEY (meta_field_value_id) REFERENCES jbilling_test.meta_field_value (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

CREATE TABLE jbilling_test.order_line_meta_field_map (order_line_id INT NOT NULL, meta_field_value_id INT NOT NULL);

ALTER TABLE jbilling_test.order_line_meta_field_map ADD CONSTRAINT ol_meta_field_map_fk_1 FOREIGN KEY (order_line_id) REFERENCES jbilling_test.order_line (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.order_line_meta_field_map ADD CONSTRAINT ol_meta_field_map_fk_2 FOREIGN KEY (meta_field_value_id) REFERENCES jbilling_test.meta_field_value (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#5449 - Integrate Product Meta Fields into Order Changes', 'Gerhard Maree', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 51, '7:8e8ab3bc5294b39365aee082e96c19f7', 'createTable, addForeignKeyConstraint (x2), createTable, addForeignKeyConstraint (x2)', 'Order Change Meta Fields
Order Line Meta Fields', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::#6719 - User Codes - Entities::Gerhard Maree
CREATE TABLE jbilling_test.user_code (id INT NOT NULL, user_id INT NOT NULL, identifier VARCHAR(55) NOT NULL, external_ref VARCHAR(50) NULL, type VARCHAR(50) NULL, type_desc VARCHAR(250) NULL, valid_from date NULL, valid_to date NULL, CONSTRAINT user_code_pkey PRIMARY KEY (id), CONSTRAINT user_code_identifier_key UNIQUE (identifier));

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('user_code', 1.0);

CREATE TABLE jbilling_test.user_code_link (id INT NOT NULL, user_code_id INT NOT NULL, object_type VARCHAR(50) NOT NULL, object_id INT NULL, CONSTRAINT user_code_link_pkey PRIMARY KEY (id));

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('user_code_link', 1.0);

INSERT INTO enumeration (id, entity_id, name, optlock)
            SELECT coalesce( (select max(id)+1 from enumeration),1)+e.id, e.id, 'User Code Type', 0 FROM entity e;

UPDATE jbilling_test.jbilling_seqs SET next_id = (coalesce( (select max(id)+1 from enumeration),1) ) WHERE name='enumeration';

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#6719 - User Codes - Entities', 'Gerhard Maree', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 52, '7:ecc7ba52218940cc22955493a97830fa', 'createTable, insert, createTable, insert, sql, update', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::#6593-order-line-tiers::Bilal Nasir
CREATE TABLE jbilling_test.order_line_tier (id INT NOT NULL, order_line_id INT NULL, tier_number INT NULL, quantity numeric(22, 10) NULL, price numeric(22, 10) NULL, amount numeric(22, 10) NULL, CONSTRAINT order_line_tier_pkey PRIMARY KEY (id));

ALTER TABLE jbilling_test.order_line_tier ADD CONSTRAINT order_line_tier_fk_1 FOREIGN KEY (order_line_id) REFERENCES jbilling_test.order_line (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('order_line_tier', 1.0);

INSERT INTO jbilling_test.jbilling_table (id, name) VALUES ((select max(T.id)+1 from jbilling_table T), 'order_line_tier');

INSERT INTO jbilling_test.preference_type (id, def_value) VALUES ((select max(T.id)+1 from preference_type T), 0.0);

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, (select max(T.id) from preference_type T), 'description', 1.0, 'Create Invoice Lines based on Order Line Tiers');

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#6593-order-line-tiers', 'Bilal Nasir', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 53, '7:c5ae291e303f1323fae1aef75f5825c1', 'createTable, addForeignKeyConstraint, insert (x4)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::#6652-olt-add-column::Amol Gadre
ALTER TABLE jbilling_test.order_line_tier ADD tier_type VARCHAR(100) NOT NULL;

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#6652-olt-add-column', 'Amol Gadre', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 54, '7:b979830baca77dd6e95a0e345f12f5d9', 'addColumn', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::#6652-order-add-column::Amol Gadre
ALTER TABLE jbilling_test.purchase_order ADD free_usage_quantity numeric(22, 10) NULL;

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#6652-order-add-column', 'Amol Gadre', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 55, '7:2c72e0d8e34d747f3815c3a22471c92f', 'addColumn', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::account-payment-information - #6315::Khobab
CREATE TABLE jbilling_test.payment_method_template (id INT NOT NULL, template_name VARCHAR(20) NOT NULL, OPTLOCK INT NOT NULL, CONSTRAINT payment_method_template_pkey PRIMARY KEY (id), UNIQUE (template_name));

CREATE TABLE jbilling_test.payment_method_template_meta_fields_map (method_template_id INT NOT NULL, meta_field_id INT NOT NULL);

CREATE TABLE jbilling_test.payment_method_type (id INT NOT NULL, method_name VARCHAR(20) NOT NULL, is_recurring BIT(1) DEFAULT 0 NOT NULL, entity_id INT NOT NULL, template_id INT NOT NULL, OPTLOCK INT NOT NULL, CONSTRAINT payment_method_type_pkey PRIMARY KEY (id));

CREATE TABLE jbilling_test.payment_method_meta_fields_map (payment_method_id INT NOT NULL, meta_field_id INT NOT NULL);

CREATE TABLE jbilling_test.payment_information (id INT NOT NULL, user_id INT NULL, payment_method_id INT NOT NULL, processing_order INT NULL, deleted INT NOT NULL, OPTLOCK INT NOT NULL, CONSTRAINT payment_information_pkey PRIMARY KEY (id));

CREATE TABLE jbilling_test.payment_information_meta_fields_map (payment_information_id INT NOT NULL, meta_field_value_id INT NOT NULL);

CREATE TABLE jbilling_test.payment_method_account_type_map (payment_method_id INT NOT NULL, account_type_id INT NOT NULL);

ALTER TABLE jbilling_test.payment_method_template_meta_fields_map ADD CONSTRAINT payment_method_template_meta_fields_map_FK1 FOREIGN KEY (method_template_id) REFERENCES jbilling_test.payment_method_template (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.payment_method_template_meta_fields_map ADD CONSTRAINT payment_method_template_meta_fields_map_FK2 FOREIGN KEY (meta_field_id) REFERENCES jbilling_test.meta_field_name (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.payment_method_type ADD CONSTRAINT payment_method_type_FK1 FOREIGN KEY (entity_id) REFERENCES jbilling_test.entity (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.payment_method_type ADD CONSTRAINT payment_method_type_FK2 FOREIGN KEY (template_id) REFERENCES jbilling_test.payment_method_template (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.payment_method_meta_fields_map ADD CONSTRAINT payment_method_meta_fields_map_FK1 FOREIGN KEY (payment_method_id) REFERENCES jbilling_test.payment_method_type (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.payment_method_meta_fields_map ADD CONSTRAINT payment_method_meta_fields_map_FK2 FOREIGN KEY (meta_field_id) REFERENCES jbilling_test.meta_field_name (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.payment_information ADD CONSTRAINT payment_information_FK1 FOREIGN KEY (user_id) REFERENCES jbilling_test.base_user (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.payment_information ADD CONSTRAINT payment_information_FK2 FOREIGN KEY (payment_method_id) REFERENCES jbilling_test.payment_method_type (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.payment_information_meta_fields_map ADD CONSTRAINT payment_information_meta_fields_map_FK1 FOREIGN KEY (payment_information_id) REFERENCES jbilling_test.payment_information (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.payment_information_meta_fields_map ADD CONSTRAINT payment_information_meta_fields_map_FK2 FOREIGN KEY (meta_field_value_id) REFERENCES jbilling_test.meta_field_value (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.payment_method_account_type_map ADD CONSTRAINT payment_method_account_type_map_FK1 FOREIGN KEY (payment_method_id) REFERENCES jbilling_test.payment_method_type (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.payment_method_account_type_map ADD CONSTRAINT payment_method_account_type_map_FK2 FOREIGN KEY (account_type_id) REFERENCES jbilling_test.account_type (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('payment_method_template', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('payment_method_type', 1.0);

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('payment_information', 1.0);

INSERT INTO jbilling_test.payment_method_template (id, template_name, optlock) VALUES ((select coalesce(max(pm.id)+1,1) from payment_method_template pm), 'Payment Card', 0.0);

INSERT INTO jbilling_test.payment_method_template (id, template_name, optlock) VALUES ((select max(pm.id)+1 from payment_method_template pm), 'ACH', 0.0);

INSERT INTO jbilling_test.payment_method_template (id, template_name, optlock) VALUES ((select max(pm.id)+1 from payment_method_template pm), 'Cheque', 0.0);

ALTER TABLE jbilling_test.payment MODIFY method_id INT NULL;

CREATE TABLE jbilling_test.payment_instrument_info (id INT NOT NULL, result_id INT NOT NULL, method_id INT NOT NULL, instrument_id INT NOT NULL, payment_id INT NOT NULL, CONSTRAINT payment_instrument_info_pkey PRIMARY KEY (id));

INSERT INTO jbilling_test.jbilling_seqs (name, next_id) VALUES ('payment_instrument_info', 1.0);

ALTER TABLE jbilling_test.payment_instrument_info ADD CONSTRAINT payment_instrument_info_FK1 FOREIGN KEY (result_id) REFERENCES jbilling_test.payment_result (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.payment_instrument_info ADD CONSTRAINT payment_instrument_info_FK2 FOREIGN KEY (method_id) REFERENCES jbilling_test.payment_method (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.payment_instrument_info ADD CONSTRAINT payment_instrument_info_FK3 FOREIGN KEY (instrument_id) REFERENCES jbilling_test.payment_information (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

ALTER TABLE jbilling_test.payment_instrument_info ADD CONSTRAINT payment_instrument_info_FK4 FOREIGN KEY (payment_id) REFERENCES jbilling_test.payment (id) ON UPDATE NO ACTION ON DELETE NO ACTION;

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('account-payment-information - #6315', 'Khobab', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 56, '7:83a9e0c94b5a665d2dfa68895f491e2b', 'createTable (x7), addForeignKeyConstraint (x12), insert (x6), dropNotNullConstraint, createTable, insert, addForeignKeyConstraint (x4)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::#7308-usage-pool-consumption-notification::Amol Gadre
INSERT INTO jbilling_test.notification_message_type (id, category_id, optlock) VALUES ((select max(nmt.id)+1 from notification_message_type nmt), 4.0, 0.0);

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, (select max(nmt.id) from notification_message_type nmt), 'description', 1.0, 'Usage Pool Consumption');

UPDATE jbilling_test.jbilling_seqs SET next_id = coalesce((select round(max(id)/100)+1 from notification_message), 1) WHERE name = 'notification_message';

UPDATE jbilling_test.jbilling_seqs SET next_id = coalesce((select round(max(id)/100)+1 from notification_message_section), 1) WHERE name = 'notification_message_section';

UPDATE jbilling_test.jbilling_seqs SET next_id = coalesce((select round(max(id)/100)+1 from notification_message_line), 1) WHERE name = 'notification_message_line';

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#7308-usage-pool-consumption-notification', 'Amol Gadre', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 57, '7:9c648bdc6740de93779d9533edcf3bfe', 'insert (x2), update (x3)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::#7308-usage-pool-consumption-notification-test::Amol Gadre
INSERT INTO notification_message (id, type_id, entity_id, language_id, use_flag, optlock)
                   select (select COALESCE(max(nm.id),0)+1 from notification_message nm) + (select count(*) from entity e2 where e1.id > e2.id and e2.id <> e1.id),
                          (select foreign_id from international_description where table_id=52 and content='Usage Pool Consumption'),
                          e1.id,
                          1,
                          1,
                          0
                   from entity e1
                   order by e1.id;

INSERT INTO jbilling_test.notification_message_section (id, message_id, section, optlock) VALUES ((select COALESCE(max(nms.id),0)+1 from notification_message_section nms), (select max(n.id) from notification_message n), 1.0, 0.0);

INSERT INTO jbilling_test.notification_message_line (id, message_section_id, content, optlock) VALUES ((select COALESCE(max(nml.id),0)+1 from notification_message_line nml), (select max(n.id) from notification_message_section n), 'Usage pool consumption status.', 0.0);

INSERT INTO jbilling_test.notification_message_section (id, message_id, section, optlock) VALUES ((select COALESCE(max(nms.id),0)+1 from notification_message_section nms), (select max(n.id) from notification_message n), 2.0, 0.0);

INSERT INTO jbilling_test.notification_message_line (id, message_section_id, content, optlock) VALUES ((select max(nml.id)+1 from notification_message_line nml), (select max(n.id) from notification_message_section n), 'Dear $userSalutation,\\r\\n\\r\\nYou have used $percentageConsumption% from Free Usage Pool - $usagePoolName.\\r\\n\\r\\nThanks.', 0.0);

INSERT INTO jbilling_test.notification_message_section (id, message_id, section, optlock) VALUES ((select max(nms.id)+1 from notification_message_section nms), (select max(n.id) from notification_message n), 3.0, 0.0);

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#7308-usage-pool-consumption-notification-test', 'Amol Gadre', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 58, '7:0eb341e7dab62b491edb3fe9932e044e', 'sql, insert (x5)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::#7659-Free-Usage-Pool-Consumption-enhancements::Marco Manzi
CREATE TABLE jbilling_test.notification_medium_type (notification_id INT NOT NULL, medium_type VARCHAR(255) NOT NULL, CONSTRAINT PK_NOTIFICATION_MEDIUM_TYPE PRIMARY KEY (notification_id, medium_type));

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (1.0, 'SMS');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (1.0, 'EMAIL');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (1.0, 'PDF');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (2.0, 'SMS');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (2.0, 'EMAIL');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (2.0, 'PDF');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (3.0, 'SMS');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (3.0, 'EMAIL');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (3.0, 'PDF');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (4.0, 'SMS');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (4.0, 'EMAIL');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (4.0, 'PDF');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (7.0, 'SMS');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (7.0, 'EMAIL');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (7.0, 'PDF');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (8.0, 'SMS');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (8.0, 'EMAIL');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (8.0, 'PDF');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (9.0, 'SMS');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (9.0, 'EMAIL');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (9.0, 'PDF');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (10.0, 'SMS');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (10.0, 'EMAIL');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (10.0, 'PDF');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (11.0, 'SMS');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (11.0, 'EMAIL');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (11.0, 'PDF');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (12.0, 'SMS');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (12.0, 'EMAIL');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (12.0, 'PDF');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (13.0, 'SMS');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (13.0, 'EMAIL');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (13.0, 'PDF');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (14.0, 'SMS');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (14.0, 'EMAIL');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (14.0, 'PDF');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (15.0, 'SMS');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (15.0, 'EMAIL');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (15.0, 'PDF');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (17.0, 'SMS');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (17.0, 'EMAIL');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (17.0, 'PDF');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (18.0, 'SMS');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (18.0, 'EMAIL');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (18.0, 'PDF');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (19.0, 'SMS');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (19.0, 'EMAIL');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (19.0, 'PDF');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (16.0, 'SMS');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (16.0, 'EMAIL');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (16.0, 'PDF');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (20.0, 'SMS');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (20.0, 'EMAIL');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (20.0, 'PDF');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (21.0, 'SMS');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (21.0, 'EMAIL');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (21.0, 'PDF');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (22.0, 'SMS');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (22.0, 'EMAIL');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (22.0, 'PDF');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (23.0, 'SMS');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (23.0, 'EMAIL');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (23.0, 'PDF');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (24.0, 'SMS');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (24.0, 'EMAIL');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (24.0, 'PDF');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (25.0, 'SMS');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (25.0, 'EMAIL');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (25.0, 'PDF');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (26.0, 'SMS');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (26.0, 'EMAIL');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (26.0, 'PDF');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (27.0, 'SMS');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (27.0, 'EMAIL');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (27.0, 'PDF');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (28.0, 'SMS');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (28.0, 'EMAIL');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (28.0, 'PDF');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (29.0, 'SMS');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (29.0, 'EMAIL');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (29.0, 'PDF');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (30.0, 'SMS');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (30.0, 'EMAIL');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (30.0, 'PDF');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (31.0, 'SMS');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (31.0, 'EMAIL');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (31.0, 'PDF');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (32.0, 'SMS');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (32.0, 'EMAIL');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (32.0, 'PDF');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (33.0, 'SMS');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (33.0, 'EMAIL');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (33.0, 'PDF');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (34.0, 'SMS');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (34.0, 'EMAIL');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (34.0, 'PDF');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (35.0, 'SMS');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (35.0, 'EMAIL');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (35.0, 'PDF');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (36.0, 'SMS');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (36.0, 'EMAIL');

INSERT INTO jbilling_test.notification_medium_type (notification_id, medium_type) VALUES (36.0, 'PDF');

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#7659-Free-Usage-Pool-Consumption-enhancements', 'Marco Manzi', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 59, '7:883b751603c3b1299174c1a6df32e43c', 'createTable, insert (x102)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::#7308-fup-consumption-notification-fix1::Vishwajeet Borade
INSERT INTO notification_message_section (id, message_id, section, optlock)
                select (select max(p.id)+1 from notification_message_section p) + (select count(*) from entity e2 where e1.id > e2.id and e2.id <> e1.id),
                       (select max(p.id) from notification_message p) - (select count(*) from entity e2 where e1.id > e2.id and e2.id <> e1.id),
                       1,
                       1
                from entity e1
                order by e1.id;

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#7308-fup-consumption-notification-fix1', 'Vishwajeet Borade', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 60, '7:1720b88970f225f807be644b2d125c28', 'sql', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::#7308-fup-consumption-notification-fix2::Vishwajeet Borade
INSERT INTO notification_message_section (id, message_id, section, optlock)
                select (select max(p.id)+1 from notification_message_section p) + (select count(*) from entity e2 where e1.id > e2.id and e2.id <> e1.id),
                       (select max(p.id) from notification_message p) - (select count(*) from entity e2 where e1.id > e2.id and e2.id <> e1.id),
                       2,
                       1
                from entity e1
                order by e1.id;

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#7308-fup-consumption-notification-fix2', 'Vishwajeet Borade', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 61, '7:4020163297c93573760e0645041ddcdb', 'sql', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::#7308-fup-consumption-notification-fix3::Vishwajeet Borade
INSERT INTO notification_message_section (id, message_id, section, optlock)
                select (select max(p.id)+1 from notification_message_section p) + (select count(*) from entity e2 where e1.id > e2.id and e2.id <> e1.id),
                       (select max(p.id) from notification_message p) - (select count(*) from entity e2 where e1.id > e2.id and e2.id <> e1.id),
                       3,
                       1
                from entity e1
                order by e1.id;

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#7308-fup-consumption-notification-fix3', 'Vishwajeet Borade', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 62, '7:d0e293b6414a84ce567927961e73ad1e', 'sql', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::#7308-fup-consumption-notification-fix4::Vishwajeet Borade
INSERT INTO notification_message_line (id, message_section_id, content, optlock)
                select (select max(p.id)+1 from notification_message_line p) + (select count(*) from entity e2 where e1.id > e2.id and e2.id <> e1.id),
                       (select max(p.id)+1 from notification_message_section p) - (select count(*) * 3 from entity ecant) + (select count(*) from entity e2 where e1.id > e2.id and e2.id <> e1.id),
                       'Usage pool consumption status.',
                       1
                from entity e1
                order by e1.id;

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#7308-fup-consumption-notification-fix4', 'Vishwajeet Borade', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 63, '7:5a7cc6544394c7727cf3d163f8a2fd98', 'sql', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::#7308-fup-consumption-notification-fix5::Vishwajeet Borade
INSERT INTO notification_message_line (id, message_section_id, content, optlock)
                select (select max(p.id)+1 from notification_message_line p) + (select count(*) from entity e2 where e1.id > e2.id and e2.id <> e1.id),
                       (select max(p.id)+1 from notification_message_section p) - (select count(*) * 2 from entity ecant) + (select count(*) from entity e2 where e1.id > e2.id and e2.id <> e1.id),
                       'Dear $userSalutation, You have used $percentageConsumption% from Free Usage Pool - $usagePoolName. Thanks.',
                       1
                from entity e1
                order by e1.id;

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#7308-fup-consumption-notification-fix5', 'Vishwajeet Borade', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 64, '7:4c018f3bea4ef8a47887d4c6d2e075fa', 'sql', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::#7308-fup-consumption-notification-fix6::Vishwajeet Borade
INSERT INTO notification_message_line (id, message_section_id, content, optlock)
                select (select max(p.id)+1 from notification_message_line p) + (select count(*) from entity e2 where e1.id > e2.id and e2.id <> e1.id),
                       (select max(p.id)+1 from notification_message_section p) - (select count(*) * 1 from entity ecant) + (select count(*) from entity e2 where e1.id > e2.id and e2.id <> e1.id),
                       'Dear $userSalutation,<p>You have used $percentageConsumption% from Free Usage Pool - $usagePoolName.<p>Thanks.',
                       1
                from entity e1
                order by e1.id;

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#7308-fup-consumption-notification-fix6', 'Vishwajeet Borade', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 65, '7:4b81145d0c0e67bd459e28816c484296', 'sql', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::#8048-usercodes-unique-per-company::Nelson Secchi
ALTER TABLE jbilling_test.user_code DROP KEY user_code_identifier_key;

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#8048-usercodes-unique-per-company', 'Nelson Secchi', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 66, '7:28980cb681fbdc0e448c86dc2f04e98d', 'dropUniqueConstraint', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::7043 - Agents and Commissions::Oscar Bidabehere
--  Add partnerType, partner.parentId, standard and master percentages
--  Add commission exception
--  Add referral commission
--  Add agent commission type property
--  Create partner commission
--  Create commission run
--  Create invoice commission
--  Create payment commission
--  Agent commission schedule task
--  Agent commission process plugin category
--  Create commission process configuration
--  Basic agent commission process plugin implementation
--  Add basic commission plugin to all entities
--  Event listener to create payment commissions
--  Add payment commission plugin to all entities
ALTER TABLE jbilling_test.partner ADD type VARCHAR(250) NULL;

ALTER TABLE jbilling_test.partner ADD parent_id INT NULL;

ALTER TABLE jbilling_test.item ADD standard_partner_percentage numeric(22, 10) NULL;

ALTER TABLE jbilling_test.item ADD master_partner_percentage numeric(22, 10) NULL;

CREATE TABLE jbilling_test.partner_commission_exception (id INT NOT NULL, partner_id INT NULL, start_date date NULL, end_date date NULL, percentage numeric(22, 10) NULL, item_id INT NULL);

CREATE TABLE jbilling_test.partner_referral_commission (id INT NOT NULL, referral_id INT NULL, referrer_id INT NULL, start_date date NULL, end_date date NULL, percentage numeric(22, 10) NULL);

ALTER TABLE jbilling_test.partner ADD commission_type VARCHAR(255) NULL;

CREATE TABLE jbilling_test.partner_commission (id INT NOT NULL, amount numeric(22, 10) NULL, type VARCHAR(255) NULL, partner_id INT NULL, commission_process_run_id INT NULL);

CREATE TABLE jbilling_test.partner_commission_process_run (id INT NOT NULL, run_date date NULL, period_start date NULL, period_end date NULL, entity_id INT NULL);

CREATE TABLE jbilling_test.invoice_commission (id INT NOT NULL, partner_id INT NULL, referral_partner_id INT NULL, commission_process_run_id INT NULL, invoice_id INT NULL, standard_amount numeric(22, 10) NULL, master_amount numeric(22, 10) NULL, exception_amount numeric(22, 10) NULL, referral_amount numeric(22, 10) NULL, commission_id INT NULL);

CREATE TABLE jbilling_test.payment_commission (id INT NOT NULL, invoice_id INT NULL, payment_amount numeric(22, 10) NULL);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (coalesce((select max(p.id)+1 from pluggable_task_type p),1), 22.0, 'com.sapienter.jbilling.server.user.partner.task.CalculateCommissionTask', 0.0);

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, (select max(p.id) from pluggable_task_type p), 'title', 1.0, 'Calculate Agents'' Commissions');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, (select max(p.id) from pluggable_task_type p), 'description', 1.0, 'This task schedules the process that calculates the Agents'' Commissions.');

INSERT INTO jbilling_test.pluggable_task_type_category (id, interface_name) VALUES (25.0, 'com.sapienter.jbilling.server.user.partner.task.IPartnerCommissionTask');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23.0, 25, 'description', 1.0, 'Agent Commission Calculation Process.');

CREATE TABLE jbilling_test.partner_commission_proc_config (id INT NOT NULL, entity_id INT NULL, next_run_date date NULL, period_unit_id INT NULL, period_value INT NULL);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES (coalesce((select max(p.id)+1 from pluggable_task_type p),1), 25.0, 'com.sapienter.jbilling.server.user.partner.task.BasicPartnerCommissionTask', 0.0);

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, (select max(p.id) from pluggable_task_type p), 'title', 1.0, 'Basic Agents'' Commissions task');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, (select max(p.id) from pluggable_task_type p), 'description', 1.0, 'This task calculates the Agents'' Commissions.');

INSERT INTO pluggable_task (id, entity_id, type_id, processing_order, optlock)
                   select (select max(p.id)+1 from pluggable_task p) + (select count(*) from entity e2 where e1.id > e2.id and e2.id <> e1.id),
                          e1.id,
                          (select max(p.id) from pluggable_task_type p),
                          1,
                          1
                   from entity e1
                   order by e1.id;

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES ((select max(p.id)+1 from pluggable_task_type p), 17.0, 'com.sapienter.jbilling.server.payment.tasks.GeneratePaymentCommissionTask', 0.0);

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, (select max(p.id) from pluggable_task_type p), 'title', 1.0, 'Generate payment commissions for agents.');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, (select max(p.id) from pluggable_task_type p), 'description', 1.0, 'This plug-in will create payment commissions when payments are linked an unlinked from invoices.');

INSERT INTO pluggable_task (id, entity_id, type_id, processing_order, optlock)
                   select (select max(p.id)+1 from pluggable_task p) + (select count(*) from entity e2 where e1.id > e2.id and e2.id <> e1.id),
                          e1.id,
                          (select max(p.id) from pluggable_task_type p),
                          1,
                          1
                   from entity e1
                   order by e1.id;

ALTER TABLE jbilling_test.partner DROP COLUMN one_time;

ALTER TABLE jbilling_test.partner DROP COLUMN automatic_process;

ALTER TABLE jbilling_test.partner DROP COLUMN next_payout_date;

ALTER TABLE jbilling_test.partner DROP COLUMN period_value;

ALTER TABLE jbilling_test.partner DROP FOREIGN KEY partner_fk_1;

ALTER TABLE jbilling_test.partner DROP COLUMN period_unit_id;

ALTER TABLE jbilling_test.partner DROP FOREIGN KEY partner_fk_2;

ALTER TABLE jbilling_test.partner DROP COLUMN fee_currency_id;

ALTER TABLE jbilling_test.partner DROP COLUMN percentage_rate;

ALTER TABLE jbilling_test.partner DROP COLUMN referral_fee;

ALTER TABLE jbilling_test.partner DROP COLUMN balance;

ALTER TABLE jbilling_test.partner DROP FOREIGN KEY partner_fk_3;

ALTER TABLE jbilling_test.partner DROP COLUMN related_clerk;

DROP TABLE jbilling_test.partner_range;

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('7043 - Agents and Commissions', 'Oscar Bidabehere', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 67, '7:63bac3333365edfa44eb80427e11b93d', 'addColumn (x4), createTable (x2), addColumn, createTable (x4), insert (x5), createTable, insert (x3), sql, insert (x3), sql, dropColumn (x4), dropForeignKeyConstraint, dropColumn, dropForeignKeyConstraint, dropColumn (x4), dropForeignKeyConstraint...', 'Add partnerType, partner.parentId, standard and master percentages
Add commission exception
Add referral commission
Add agent commission type property
Create partner commission
Create commission run
Create invoice commission
Create payment commiss...', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::Source Readers: pluggable tasks::Marco Manzi
INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES ((select max(t.id)+1 from pluggable_task_type t), 22.0, 'com.sapienter.jbilling.server.process.task.FtpRemoteCopyTask', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES ((select max(t.id)+1 from pluggable_task_type t), 22.0, 'com.sapienter.jbilling.server.process.task.FtpsRemoteCopyTask', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES ((select max(t.id)+1 from pluggable_task_type t), 22.0, 'com.sapienter.jbilling.server.process.task.StpRemoteCopyTask', 0.0);

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('Source Readers: pluggable tasks', 'Marco Manzi', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 68, '7:1e1d51ff104dbbe2f25cff972dcdf3c2', 'insert (x3)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::Source Readers: file exchange plugin::Marco Manzi
DELETE FROM jbilling_test.pluggable_task_type  WHERE class_name = 'com.sapienter.jbilling.server.process.task.StpRemoteCopyTask' and category_id = 22;

DELETE FROM jbilling_test.pluggable_task_type  WHERE class_name = 'com.sapienter.jbilling.server.process.task.FtpsRemoteCopyTask' and category_id = 22;

DELETE FROM jbilling_test.pluggable_task_type  WHERE class_name = 'com.sapienter.jbilling.server.process.task.FtpRemoteCopyTask' and category_id = 22;

INSERT INTO jbilling_test.pluggable_task_type_category (id, interface_name) VALUES (26, 'com.sapienter.jbilling.server.process.task.IFileExchangeTask');

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES ((select max(t.id)+1 from pluggable_task_type t), 26.0, 'com.sapienter.jbilling.server.process.task.FtpRemoteCopyTask', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES ((select max(t.id)+1 from pluggable_task_type t), 26.0, 'com.sapienter.jbilling.server.process.task.FtpsRemoteCopyTask', 0.0);

INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES ((select max(t.id)+1 from pluggable_task_type t), 26.0, 'com.sapienter.jbilling.server.process.task.StpRemoteCopyTask', 0.0);

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (23.0, 26.0, 'description', 1.0, 'Files exchange with remote locations, upload and download');

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('Source Readers: file exchange plugin', 'Marco Manzi', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 69, '7:5d0b7abcbbf2287d47133aaad9b51c8a', 'delete (x3), insert (x5)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::#7514 - Plans Enhancement::Khobab Chaudhary
ALTER TABLE jbilling_test.item ADD active_since date NULL;

ALTER TABLE jbilling_test.item ADD active_until date NULL;

ALTER TABLE jbilling_test.item_type ADD one_per_order BIT(1) NOT NULL DEFAULT 0;

ALTER TABLE jbilling_test.item_type ADD one_per_customer BIT(1) NOT NULL DEFAULT 0;

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#7514 - Plans Enhancement', 'Khobab Chaudhary', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 70, '7:3eebe2b901823f735e1af9c338fb9ab6', 'addColumn (x4)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::#6266-file-exchange-trigger::Vladimir Carevski
INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES ((select max(t.id)+1 from pluggable_task_type t), 22, 'com.sapienter.jbilling.server.process.task.FileExchangeTriggerTask', 1.0);

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, (select max(t.id) from pluggable_task_type t), 'title', 1.0, 'Trigger File Download/Upload');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, (select max(t.id) from pluggable_task_type t), 'description', 1.0, 'Triggers File Download/Upload against third party system');

UPDATE jbilling_test.jbilling_seqs SET next_id = (select max(p.id)+1 from pluggable_task_type p) WHERE name='pluggable_task_type';

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#6266-file-exchange-trigger', 'Vladimir Carevski', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 71, '7:95ecc9a183e2e43e0d74e6eb32f42c8a', 'insert (x3), update', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::#7223 - Preference for enabling JQGrid on the site::Nelson Secchi
--  Should use JQGrid for tables
INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (63.0, '0');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 63.0, 'description', 1.0, 'Should use JQGrid for tables');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 63.0, 'instruction', 1.0, 'Set to ''0'' to use the common layout or set to ''1'' to use JQGrid on the site''s tables');

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#7223 - Preference for enabling JQGrid on the site', 'Nelson Secchi', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 72, '7:0795907fcd15d8777f2df05286dbf047', 'insert (x3)', 'Should use JQGrid for tables', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::#8418 - adding currency to commissions::Morales Fernando G.
--  Add currency to commissions
ALTER TABLE jbilling_test.partner_commission ADD currency_id INT NULL;

ALTER TABLE jbilling_test.partner_commission ADD CONSTRAINT partner_commission_currency_id_FK FOREIGN KEY (currency_id) REFERENCES jbilling_test.currency (id);

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#8418 - adding currency to commissions', 'Morales Fernando G.', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 73, '7:599beaeb7aa83fa707ea18b19b0b7258', 'addColumn, addForeignKeyConstraint', 'Add currency to commissions', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::#8009-Validation message for lnvalid 'expiry date' field::Sagar Dond
UPDATE jbilling_test.international_description SET content = 'Expiry date should be in format MM/YYYY' WHERE content = 'Expiry date should be in format MM/yyyy';

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#8009-Validation message for lnvalid ''expiry date'' field', 'Sagar Dond', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 74, '7:5f623e0c502a92b6cccc88f1f1215d76', 'update', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::#6652 - Delete reference of order line tier::Ashok Kale
DROP TABLE jbilling_test.order_line_tier;

DELETE FROM jbilling_test.jbilling_seqs  WHERE name='order_line_tier';

DELETE FROM jbilling_test.jbilling_table  WHERE name='order_line_tier';

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#6652 - Delete reference of order line tier', 'Ashok Kale', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 75, '7:bf1239f8e9385db08b1da96c0efc5e12', 'dropTable, delete (x2)', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::agent_default_preference::Morales Fernando G.
--  Add Agent commission type preference
INSERT INTO jbilling_test.preference_type (id, def_value) VALUES (61.0, 'INVOICE');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 61.0, 'description', 1.0, 'Agent Commission Type');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (50.0, 61.0, 'instruction', 1.0, 'Defines the default agents'' commission type for the entity, one of: INVOICE, PAYMENT');

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('agent_default_preference', 'Morales Fernando G.', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 76, '7:3b9f1b6dedb65bdac5086bd35e4ac733', 'insert (x3)', 'Add Agent commission type preference', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::removed-order-line-tier::Mahesh Shivarkar
--  Removed unused preference for order line tiers i.e. 'Create Invoice Lines based on Order Line Tiers'
DELETE FROM jbilling_test.international_description  WHERE table_id = 50 and foreign_id = 56;

DELETE FROM jbilling_test.preference  WHERE type_id = 56;

DELETE FROM jbilling_test.preference_type  WHERE id = 56;

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('removed-order-line-tier', 'Mahesh Shivarkar', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 77, '7:edd844449601a623c204668044c6654f', 'delete (x3)', 'Removed unused preference for order line tiers i.e. ''Create Invoice Lines based on Order Line Tiers''', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::20141104-#10343 - entity_id should not be null::Aman Goel
ALTER TABLE jbilling_test.item_type MODIFY entity_id INT NOT NULL;

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('20141104-#10343 - entity_id should not be null', 'Aman Goel', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 78, '7:3668a67b8bb39013dae8514af6fd12dd', 'addNotNullConstraint', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::#9958 - different activeSince and activeUntil dates in same PO::Igor Poteryaev
--  Add db objects for order line tiers support
ALTER TABLE jbilling_test.order_change ADD applied_manually INT NULL;

ALTER TABLE jbilling_test.order_change ADD removal INT NULL;

ALTER TABLE jbilling_test.order_change ADD next_billable_date date NULL;

ALTER TABLE jbilling_test.order_change ADD end_date date NULL;

ALTER TABLE jbilling_test.order_line ADD start_date date NULL;

ALTER TABLE jbilling_test.order_line ADD end_date date NULL;

CREATE INDEX order_change_idx_order_line ON jbilling_test.order_change(order_line_id);

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#9958 - different activeSince and activeUntil dates in same PO', 'Igor Poteryaev', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 79, '7:32f57a2b2dddc066ccbbbb147f326e81', 'addColumn (x2), createIndex', 'Add db objects for order line tiers support', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::#10777 - CreditLimitationNotificationTask is missing::Juan Vidal
INSERT INTO jbilling_test.pluggable_task_type (id, category_id, class_name, min_parameters) VALUES ((select max(ptt.id)+1 from pluggable_task_type ptt), 17.0, 'com.sapienter.jbilling.server.user.tasks.CreditLimitationNotificationTask', 0.0);

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, (select max(ptt.id) from pluggable_task_type ptt), 'title', 1.0, 'User Credit Limitation notification task');

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (24.0, (select max(ptt.id) from pluggable_task_type ptt), 'description', 1.0, 'A pluggable task of the type InternalEventsTask to monitor if users pre-paid balance is below a credit limitation 1 or 2 levels and send notifications.');

INSERT INTO jbilling_test.notification_message_type (id, category_id, optlock) VALUES ((select max(nmt.id)+1 from notification_message_type nmt), 4.0, 0.0);

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, (select max(nmt.id) from notification_message_type nmt), 'description', 1.0, 'Credit Limitation 1');

INSERT INTO jbilling_test.notification_message_type (id, category_id, optlock) VALUES ((select max(nmt.id)+1 from notification_message_type nmt), 4.0, 0.0);

INSERT INTO jbilling_test.international_description (table_id, foreign_id, psudo_column, language_id, content) VALUES (52.0, (select max(nmt.id) from notification_message_type nmt), 'description', 1.0, 'Credit Limitation 2');

UPDATE jbilling_test.jbilling_seqs SET next_id = (select max(id) from notification_message_type) WHERE name = 'notification_message_type';

INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#10777 - CreditLimitationNotificationTask is missing', 'Juan Vidal', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 80, '7:9afafd7f13099e9812dbd5123a432019', 'insert (x7), update', '', 'EXECUTED', '3.2.2');

--  Changeset descriptors/database/jbilling-upgrade-3.4.xml::#12343-Update customer data::Fernando G. Morales
--  Set next_invoice_date value
INSERT INTO jbilling_test.DATABASECHANGELOG (ID, AUTHOR, FILENAME, DATEEXECUTED, ORDEREXECUTED, MD5SUM, DESCRIPTION, COMMENTS, EXECTYPE, LIQUIBASE) VALUES ('#12343-Update customer data', 'Fernando G. Morales', 'descriptors/database/jbilling-upgrade-3.4.xml', NOW(), 81, '7:67d910c5822eb841887706244f0b23f9', 'customChange', 'Set next_invoice_date value', 'EXECUTED', '3.2.2');

